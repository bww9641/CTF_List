audio files

Sound effects and music are available for breakout.lua and overlay-demo.lua. You need two things:
1. A build of Golly that is compiled with sound support (see the Makefiles for ENABLE_SOUND)
2. The audio files which can be downloaded as zip file from: http://lazyslug.no-ip.biz/lifeview/audio/audio.zip

The zip file contains the following:

breakout/
breakout/bat.ogg
breakout/bonusloop.ogg
breakout/brick1.ogg
breakout/brick2.ogg
breakout/brick3.ogg
breakout/brick4.ogg
breakout/brick5.ogg
breakout/brick6.ogg
breakout/edge.ogg
breakout/gameloop.ogg
breakout/gamelostloop.ogg
breakout/gamestart.ogg
breakout/levelcompleteloop.ogg
breakout/lostball.ogg
breakout/top.ogg
overlay-demo/animation.ogg

The zip file must be extracted to <Golly Home>/Scripts/Lua/oplus/sounds

For example the path to bat.ogg should be <Golly Home>/Scripts/Lua/oplus/sounds/breakout/bat.ogg

