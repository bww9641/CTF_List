-- Life to LifeHistory converter, intended to be mapped to keyboard shortcut, e.g., Alt+H
local g = golly()
g.setrule("LifeHistory")
