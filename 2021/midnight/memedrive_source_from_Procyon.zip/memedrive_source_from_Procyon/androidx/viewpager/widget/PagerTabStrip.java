// 
// Decompiled by Procyon v0.5.36
// 

package androidx.viewpager.widget;

import androidx.core.content.ContextCompat;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.view.View;
import android.view.View$OnClickListener;
import android.view.ViewConfiguration;
import android.util.AttributeSet;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.Paint;

public class PagerTabStrip extends PagerTitleStrip
{
    private static final int FULL_UNDERLINE_HEIGHT = 1;
    private static final int INDICATOR_HEIGHT = 3;
    private static final int MIN_PADDING_BOTTOM = 6;
    private static final int MIN_STRIP_HEIGHT = 32;
    private static final int MIN_TEXT_SPACING = 64;
    private static final int TAB_PADDING = 16;
    private static final int TAB_SPACING = 32;
    private static final String TAG = "PagerTabStrip";
    private boolean mDrawFullUnderline;
    private boolean mDrawFullUnderlineSet;
    private int mFullUnderlineHeight;
    private boolean mIgnoreTap;
    private int mIndicatorColor;
    private int mIndicatorHeight;
    private float mInitialMotionX;
    private float mInitialMotionY;
    private int mMinPaddingBottom;
    private int mMinStripHeight;
    private int mMinTextSpacing;
    private int mTabAlpha;
    private int mTabPadding;
    private final Paint mTabPaint;
    private final Rect mTempRect;
    private int mTouchSlop;
    
    public PagerTabStrip(final Context context) {
        this(context, null);
    }
    
    public PagerTabStrip(final Context context, final AttributeSet set) {
        super(context, set);
        final Paint mTabPaint = new Paint();
        this.mTabPaint = mTabPaint;
        this.mTempRect = new Rect();
        this.mTabAlpha = 255;
        this.mDrawFullUnderline = false;
        this.mDrawFullUnderlineSet = false;
        mTabPaint.setColor(this.mIndicatorColor = this.mTextColor);
        final float density = context.getResources().getDisplayMetrics().density;
        this.mIndicatorHeight = (int)(0.5f + 3.0f * density);
        this.mMinPaddingBottom = (int)(0.5f + 6.0f * density);
        this.mMinTextSpacing = (int)(64.0f * density);
        this.mTabPadding = (int)(0.5f + 16.0f * density);
        this.mFullUnderlineHeight = (int)(0.5f + 1.0f * density);
        this.mMinStripHeight = (int)(0.5f + density * 32.0f);
        this.mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.setPadding(this.getPaddingLeft(), this.getPaddingTop(), this.getPaddingRight(), this.getPaddingBottom());
        this.setTextSpacing(this.getTextSpacing());
        this.setWillNotDraw(false);
        this.mPrevText.setFocusable(true);
        this.mPrevText.setOnClickListener((View$OnClickListener)new View$OnClickListener() {
            public void onClick(final View view) {
                PagerTabStrip.this.mPager.setCurrentItem(-1 + PagerTabStrip.this.mPager.getCurrentItem());
            }
        });
        this.mNextText.setFocusable(true);
        this.mNextText.setOnClickListener((View$OnClickListener)new View$OnClickListener() {
            public void onClick(final View view) {
                PagerTabStrip.this.mPager.setCurrentItem(1 + PagerTabStrip.this.mPager.getCurrentItem());
            }
        });
        if (this.getBackground() == null) {
            this.mDrawFullUnderline = true;
        }
    }
    
    public boolean getDrawFullUnderline() {
        return this.mDrawFullUnderline;
    }
    
    @Override
    int getMinHeight() {
        return Math.max(super.getMinHeight(), this.mMinStripHeight);
    }
    
    public int getTabIndicatorColor() {
        return this.mIndicatorColor;
    }
    
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        final int height = this.getHeight();
        final int n = this.mCurrText.getLeft() - this.mTabPadding;
        final int n2 = this.mCurrText.getRight() + this.mTabPadding;
        final int n3 = height - this.mIndicatorHeight;
        this.mTabPaint.setColor(this.mTabAlpha << 24 | (0xFFFFFF & this.mIndicatorColor));
        final float n4 = (float)n;
        final float n5 = (float)n3;
        final float n6 = (float)n2;
        final float n7 = (float)height;
        canvas.drawRect(n4, n5, n6, n7, this.mTabPaint);
        if (this.mDrawFullUnderline) {
            this.mTabPaint.setColor(0xFF000000 | (0xFFFFFF & this.mIndicatorColor));
            canvas.drawRect((float)this.getPaddingLeft(), (float)(height - this.mFullUnderlineHeight), (float)(this.getWidth() - this.getPaddingRight()), n7, this.mTabPaint);
        }
    }
    
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        final int action = motionEvent.getAction();
        if (action != 0 && this.mIgnoreTap) {
            return false;
        }
        final float x = motionEvent.getX();
        final float y = motionEvent.getY();
        if (action != 0) {
            if (action != 1) {
                if (action == 2) {
                    if (Math.abs(x - this.mInitialMotionX) > this.mTouchSlop || Math.abs(y - this.mInitialMotionY) > this.mTouchSlop) {
                        this.mIgnoreTap = true;
                    }
                }
            }
            else if (x < this.mCurrText.getLeft() - this.mTabPadding) {
                this.mPager.setCurrentItem(this.mPager.getCurrentItem() - 1);
            }
            else if (x > this.mCurrText.getRight() + this.mTabPadding) {
                this.mPager.setCurrentItem(1 + this.mPager.getCurrentItem());
            }
        }
        else {
            this.mInitialMotionX = x;
            this.mInitialMotionY = y;
            this.mIgnoreTap = false;
        }
        return true;
    }
    
    public void setBackgroundColor(final int backgroundColor) {
        super.setBackgroundColor(backgroundColor);
        if (!this.mDrawFullUnderlineSet) {
            this.mDrawFullUnderline = ((backgroundColor & 0xFF000000) == 0x0);
        }
    }
    
    public void setBackgroundDrawable(final Drawable backgroundDrawable) {
        super.setBackgroundDrawable(backgroundDrawable);
        if (!this.mDrawFullUnderlineSet) {
            this.mDrawFullUnderline = (backgroundDrawable == null);
        }
    }
    
    public void setBackgroundResource(final int backgroundResource) {
        super.setBackgroundResource(backgroundResource);
        if (!this.mDrawFullUnderlineSet) {
            this.mDrawFullUnderline = (backgroundResource == 0);
        }
    }
    
    public void setDrawFullUnderline(final boolean mDrawFullUnderline) {
        this.mDrawFullUnderline = mDrawFullUnderline;
        this.mDrawFullUnderlineSet = true;
        this.invalidate();
    }
    
    public void setPadding(final int n, final int n2, final int n3, int n4) {
        final int mMinPaddingBottom = this.mMinPaddingBottom;
        if (n4 < mMinPaddingBottom) {
            n4 = mMinPaddingBottom;
        }
        super.setPadding(n, n2, n3, n4);
    }
    
    public void setTabIndicatorColor(final int n) {
        this.mIndicatorColor = n;
        this.mTabPaint.setColor(n);
        this.invalidate();
    }
    
    public void setTabIndicatorColorResource(final int n) {
        this.setTabIndicatorColor(ContextCompat.getColor(this.getContext(), n));
    }
    
    @Override
    public void setTextSpacing(int textSpacing) {
        final int mMinTextSpacing = this.mMinTextSpacing;
        if (textSpacing < mMinTextSpacing) {
            textSpacing = mMinTextSpacing;
        }
        super.setTextSpacing(textSpacing);
    }
    
    @Override
    void updateTextPositions(final int n, final float n2, final boolean b) {
        final Rect mTempRect = this.mTempRect;
        final int height = this.getHeight();
        final int n3 = this.mCurrText.getLeft() - this.mTabPadding;
        final int n4 = this.mCurrText.getRight() + this.mTabPadding;
        final int n5 = height - this.mIndicatorHeight;
        mTempRect.set(n3, n5, n4, height);
        super.updateTextPositions(n, n2, b);
        this.mTabAlpha = (int)(255.0f * (2.0f * Math.abs(n2 - 0.5f)));
        mTempRect.union(this.mCurrText.getLeft() - this.mTabPadding, n5, this.mCurrText.getRight() + this.mTabPadding, height);
        this.invalidate(mTempRect);
    }
}
