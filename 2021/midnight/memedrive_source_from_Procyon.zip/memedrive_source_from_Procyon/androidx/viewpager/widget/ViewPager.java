// 
// Decompiled by Procyon v0.5.36
// 

package androidx.viewpager.widget;

import android.os.Parcel;
import android.os.Parcelable$ClassLoaderCreator;
import android.os.Parcelable$Creator;
import androidx.customview.view.AbsSavedState;
import android.os.Bundle;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import android.content.res.TypedArray;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Inherited;
import java.lang.annotation.Annotation;
import androidx.core.content.ContextCompat;
import android.database.DataSetObserver;
import android.view.View$MeasureSpec;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.AccessibilityDelegateCompat;
import android.view.ViewConfiguration;
import android.graphics.Canvas;
import android.view.accessibility.AccessibilityEvent;
import android.view.KeyEvent;
import android.os.SystemClock;
import android.view.SoundEffectConstants;
import android.view.FocusFinder;
import android.util.Log;
import android.view.ViewGroup$LayoutParams;
import java.util.Collections;
import android.view.MotionEvent;
import android.view.ViewParent;
import android.graphics.Paint;
import androidx.core.view.ViewCompat;
import android.util.AttributeSet;
import android.content.Context;
import android.view.VelocityTracker;
import android.graphics.Rect;
import android.widget.Scroller;
import android.os.Parcelable;
import android.graphics.drawable.Drawable;
import android.widget.EdgeEffect;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import android.view.animation.Interpolator;
import java.util.Comparator;
import android.view.ViewGroup;

public class ViewPager extends ViewGroup
{
    private static final int CLOSE_ENOUGH = 2;
    private static final Comparator<ItemInfo> COMPARATOR;
    private static final boolean DEBUG = false;
    private static final int DEFAULT_GUTTER_SIZE = 16;
    private static final int DEFAULT_OFFSCREEN_PAGES = 1;
    private static final int DRAW_ORDER_DEFAULT = 0;
    private static final int DRAW_ORDER_FORWARD = 1;
    private static final int DRAW_ORDER_REVERSE = 2;
    private static final int INVALID_POINTER = -1;
    static final int[] LAYOUT_ATTRS;
    private static final int MAX_SETTLE_DURATION = 600;
    private static final int MIN_DISTANCE_FOR_FLING = 25;
    private static final int MIN_FLING_VELOCITY = 400;
    public static final int SCROLL_STATE_DRAGGING = 1;
    public static final int SCROLL_STATE_IDLE = 0;
    public static final int SCROLL_STATE_SETTLING = 2;
    private static final String TAG = "ViewPager";
    private static final boolean USE_CACHE = false;
    private static final Interpolator sInterpolator;
    private static final ViewPositionComparator sPositionComparator;
    private int mActivePointerId;
    PagerAdapter mAdapter;
    private List<OnAdapterChangeListener> mAdapterChangeListeners;
    private int mBottomPageBounds;
    private boolean mCalledSuper;
    private int mChildHeightMeasureSpec;
    private int mChildWidthMeasureSpec;
    private int mCloseEnough;
    int mCurItem;
    private int mDecorChildCount;
    private int mDefaultGutterSize;
    private int mDrawingOrder;
    private ArrayList<View> mDrawingOrderedChildren;
    private final Runnable mEndScrollRunnable;
    private int mExpectedAdapterCount;
    private long mFakeDragBeginTime;
    private boolean mFakeDragging;
    private boolean mFirstLayout;
    private float mFirstOffset;
    private int mFlingDistance;
    private int mGutterSize;
    private boolean mInLayout;
    private float mInitialMotionX;
    private float mInitialMotionY;
    private OnPageChangeListener mInternalPageChangeListener;
    private boolean mIsBeingDragged;
    private boolean mIsScrollStarted;
    private boolean mIsUnableToDrag;
    private final ArrayList<ItemInfo> mItems;
    private float mLastMotionX;
    private float mLastMotionY;
    private float mLastOffset;
    private EdgeEffect mLeftEdge;
    private Drawable mMarginDrawable;
    private int mMaximumVelocity;
    private int mMinimumVelocity;
    private boolean mNeedCalculatePageOffsets;
    private PagerObserver mObserver;
    private int mOffscreenPageLimit;
    private OnPageChangeListener mOnPageChangeListener;
    private List<OnPageChangeListener> mOnPageChangeListeners;
    private int mPageMargin;
    private PageTransformer mPageTransformer;
    private int mPageTransformerLayerType;
    private boolean mPopulatePending;
    private Parcelable mRestoredAdapterState;
    private ClassLoader mRestoredClassLoader;
    private int mRestoredCurItem;
    private EdgeEffect mRightEdge;
    private int mScrollState;
    private Scroller mScroller;
    private boolean mScrollingCacheEnabled;
    private final ItemInfo mTempItem;
    private final Rect mTempRect;
    private int mTopPageBounds;
    private int mTouchSlop;
    private VelocityTracker mVelocityTracker;
    
    static {
        LAYOUT_ATTRS = new int[] { 16842931 };
        COMPARATOR = new Comparator<ItemInfo>() {
            @Override
            public int compare(final ItemInfo itemInfo, final ItemInfo itemInfo2) {
                return itemInfo.position - itemInfo2.position;
            }
        };
        sInterpolator = (Interpolator)new Interpolator() {
            public float getInterpolation(final float n) {
                final float n2 = n - 1.0f;
                return 1.0f + n2 * (n2 * (n2 * (n2 * n2)));
            }
        };
        sPositionComparator = new ViewPositionComparator();
    }
    
    public ViewPager(final Context context) {
        super(context);
        this.mItems = new ArrayList<ItemInfo>();
        this.mTempItem = new ItemInfo();
        this.mTempRect = new Rect();
        this.mRestoredCurItem = -1;
        this.mRestoredAdapterState = null;
        this.mRestoredClassLoader = null;
        this.mFirstOffset = -3.4028235E38f;
        this.mLastOffset = Float.MAX_VALUE;
        this.mOffscreenPageLimit = 1;
        this.mActivePointerId = -1;
        this.mFirstLayout = true;
        this.mNeedCalculatePageOffsets = false;
        this.mEndScrollRunnable = new Runnable() {
            @Override
            public void run() {
                ViewPager.this.setScrollState(0);
                ViewPager.this.populate();
            }
        };
        this.mScrollState = 0;
        this.initViewPager();
    }
    
    public ViewPager(final Context context, final AttributeSet set) {
        super(context, set);
        this.mItems = new ArrayList<ItemInfo>();
        this.mTempItem = new ItemInfo();
        this.mTempRect = new Rect();
        this.mRestoredCurItem = -1;
        this.mRestoredAdapterState = null;
        this.mRestoredClassLoader = null;
        this.mFirstOffset = -3.4028235E38f;
        this.mLastOffset = Float.MAX_VALUE;
        this.mOffscreenPageLimit = 1;
        this.mActivePointerId = -1;
        this.mFirstLayout = true;
        this.mNeedCalculatePageOffsets = false;
        this.mEndScrollRunnable = new Runnable() {
            @Override
            public void run() {
                ViewPager.this.setScrollState(0);
                ViewPager.this.populate();
            }
        };
        this.mScrollState = 0;
        this.initViewPager();
    }
    
    private void calculatePageOffsets(final ItemInfo itemInfo, final int n, final ItemInfo itemInfo2) {
        final int count = this.mAdapter.getCount();
        final int clientWidth = this.getClientWidth();
        float n2;
        if (clientWidth > 0) {
            n2 = this.mPageMargin / (float)clientWidth;
        }
        else {
            n2 = 0.0f;
        }
        if (itemInfo2 != null) {
            final int position = itemInfo2.position;
            if (position < itemInfo.position) {
                float offset = n2 + (itemInfo2.offset + itemInfo2.widthFactor);
                for (int i = position + 1, n3 = 0; i <= itemInfo.position && n3 < this.mItems.size(); ++i) {
                    ItemInfo itemInfo3;
                    for (itemInfo3 = this.mItems.get(n3); i > itemInfo3.position && n3 < -1 + this.mItems.size(); ++n3, itemInfo3 = this.mItems.get(n3)) {}
                    while (i < itemInfo3.position) {
                        offset += n2 + this.mAdapter.getPageWidth(i);
                        ++i;
                    }
                    itemInfo3.offset = offset;
                    offset += n2 + itemInfo3.widthFactor;
                }
            }
            else if (position > itemInfo.position) {
                int n4 = -1 + this.mItems.size();
                float offset2 = itemInfo2.offset;
                for (int j = position - 1; j >= itemInfo.position && n4 >= 0; --j) {
                    ItemInfo itemInfo4;
                    for (itemInfo4 = this.mItems.get(n4); j < itemInfo4.position && n4 > 0; --n4, itemInfo4 = this.mItems.get(n4)) {}
                    while (j > itemInfo4.position) {
                        offset2 -= n2 + this.mAdapter.getPageWidth(j);
                        --j;
                    }
                    offset2 -= n2 + itemInfo4.widthFactor;
                    itemInfo4.offset = offset2;
                }
            }
        }
        final int size = this.mItems.size();
        float offset3 = itemInfo.offset;
        int k = -1 + itemInfo.position;
        float offset4;
        if (itemInfo.position == 0) {
            offset4 = itemInfo.offset;
        }
        else {
            offset4 = -3.4028235E38f;
        }
        this.mFirstOffset = offset4;
        final int position2 = itemInfo.position;
        final int n5 = count - 1;
        float mLastOffset;
        if (position2 == n5) {
            mLastOffset = itemInfo.offset + itemInfo.widthFactor - 1.0f;
        }
        else {
            mLastOffset = Float.MAX_VALUE;
        }
        this.mLastOffset = mLastOffset;
        for (int l = n - 1; l >= 0; --l, --k) {
            ItemInfo itemInfo5;
            int n6;
            for (itemInfo5 = this.mItems.get(l); k > itemInfo5.position; k = n6) {
                final PagerAdapter mAdapter = this.mAdapter;
                n6 = k - 1;
                offset3 -= n2 + mAdapter.getPageWidth(k);
            }
            offset3 -= n2 + itemInfo5.widthFactor;
            itemInfo5.offset = offset3;
            if (itemInfo5.position == 0) {
                this.mFirstOffset = offset3;
            }
        }
        float offset5 = n2 + (itemInfo.offset + itemInfo.widthFactor);
        for (int n7 = 1 + itemInfo.position, index = n + 1; index < size; ++index, ++n7) {
            ItemInfo itemInfo6;
            int n8;
            for (itemInfo6 = this.mItems.get(index); n7 < itemInfo6.position; n7 = n8) {
                final PagerAdapter mAdapter2 = this.mAdapter;
                n8 = n7 + 1;
                offset5 += n2 + mAdapter2.getPageWidth(n7);
            }
            if (itemInfo6.position == n5) {
                this.mLastOffset = offset5 + itemInfo6.widthFactor - 1.0f;
            }
            itemInfo6.offset = offset5;
            offset5 += n2 + itemInfo6.widthFactor;
        }
        this.mNeedCalculatePageOffsets = false;
    }
    
    private void completeScroll(final boolean b) {
        int n;
        if (this.mScrollState == 2) {
            n = 1;
        }
        else {
            n = 0;
        }
        if (n != 0) {
            this.setScrollingCacheEnabled(false);
            if (true ^ this.mScroller.isFinished()) {
                this.mScroller.abortAnimation();
                final int scrollX = this.getScrollX();
                final int scrollY = this.getScrollY();
                final int currX = this.mScroller.getCurrX();
                final int currY = this.mScroller.getCurrY();
                if (scrollX != currX || scrollY != currY) {
                    this.scrollTo(currX, currY);
                    if (currX != scrollX) {
                        this.pageScrolled(currX);
                    }
                }
            }
        }
        this.mPopulatePending = false;
        for (int i = 0; i < this.mItems.size(); ++i) {
            final ItemInfo itemInfo = this.mItems.get(i);
            if (itemInfo.scrolling) {
                itemInfo.scrolling = false;
                n = 1;
            }
        }
        if (n != 0) {
            if (b) {
                ViewCompat.postOnAnimation((View)this, this.mEndScrollRunnable);
            }
            else {
                this.mEndScrollRunnable.run();
            }
        }
    }
    
    private int determineTargetPage(int max, final float n, final int a, final int a2) {
        if (Math.abs(a2) > this.mFlingDistance && Math.abs(a) > this.mMinimumVelocity) {
            if (a <= 0) {
                ++max;
            }
        }
        else {
            float n2;
            if (max >= this.mCurItem) {
                n2 = 0.4f;
            }
            else {
                n2 = 0.6f;
            }
            max += (int)(n + n2);
        }
        if (this.mItems.size() > 0) {
            final ItemInfo itemInfo = this.mItems.get(0);
            final ArrayList<ItemInfo> mItems = this.mItems;
            max = Math.max(itemInfo.position, Math.min(max, mItems.get(-1 + mItems.size()).position));
        }
        return max;
    }
    
    private void dispatchOnPageScrolled(final int n, final float n2, final int n3) {
        final OnPageChangeListener mOnPageChangeListener = this.mOnPageChangeListener;
        if (mOnPageChangeListener != null) {
            mOnPageChangeListener.onPageScrolled(n, n2, n3);
        }
        final List<OnPageChangeListener> mOnPageChangeListeners = this.mOnPageChangeListeners;
        if (mOnPageChangeListeners != null) {
            for (int i = 0; i < mOnPageChangeListeners.size(); ++i) {
                final OnPageChangeListener onPageChangeListener = this.mOnPageChangeListeners.get(i);
                if (onPageChangeListener != null) {
                    onPageChangeListener.onPageScrolled(n, n2, n3);
                }
            }
        }
        final OnPageChangeListener mInternalPageChangeListener = this.mInternalPageChangeListener;
        if (mInternalPageChangeListener != null) {
            mInternalPageChangeListener.onPageScrolled(n, n2, n3);
        }
    }
    
    private void dispatchOnPageSelected(final int n) {
        final OnPageChangeListener mOnPageChangeListener = this.mOnPageChangeListener;
        if (mOnPageChangeListener != null) {
            mOnPageChangeListener.onPageSelected(n);
        }
        final List<OnPageChangeListener> mOnPageChangeListeners = this.mOnPageChangeListeners;
        if (mOnPageChangeListeners != null) {
            for (int i = 0; i < mOnPageChangeListeners.size(); ++i) {
                final OnPageChangeListener onPageChangeListener = this.mOnPageChangeListeners.get(i);
                if (onPageChangeListener != null) {
                    onPageChangeListener.onPageSelected(n);
                }
            }
        }
        final OnPageChangeListener mInternalPageChangeListener = this.mInternalPageChangeListener;
        if (mInternalPageChangeListener != null) {
            mInternalPageChangeListener.onPageSelected(n);
        }
    }
    
    private void dispatchOnScrollStateChanged(final int n) {
        final OnPageChangeListener mOnPageChangeListener = this.mOnPageChangeListener;
        if (mOnPageChangeListener != null) {
            mOnPageChangeListener.onPageScrollStateChanged(n);
        }
        final List<OnPageChangeListener> mOnPageChangeListeners = this.mOnPageChangeListeners;
        if (mOnPageChangeListeners != null) {
            for (int i = 0; i < mOnPageChangeListeners.size(); ++i) {
                final OnPageChangeListener onPageChangeListener = this.mOnPageChangeListeners.get(i);
                if (onPageChangeListener != null) {
                    onPageChangeListener.onPageScrollStateChanged(n);
                }
            }
        }
        final OnPageChangeListener mInternalPageChangeListener = this.mInternalPageChangeListener;
        if (mInternalPageChangeListener != null) {
            mInternalPageChangeListener.onPageScrollStateChanged(n);
        }
    }
    
    private void enableLayers(final boolean b) {
        for (int childCount = this.getChildCount(), i = 0; i < childCount; ++i) {
            int mPageTransformerLayerType;
            if (b) {
                mPageTransformerLayerType = this.mPageTransformerLayerType;
            }
            else {
                mPageTransformerLayerType = 0;
            }
            this.getChildAt(i).setLayerType(mPageTransformerLayerType, (Paint)null);
        }
    }
    
    private void endDrag() {
        this.mIsBeingDragged = false;
        this.mIsUnableToDrag = false;
        final VelocityTracker mVelocityTracker = this.mVelocityTracker;
        if (mVelocityTracker != null) {
            mVelocityTracker.recycle();
            this.mVelocityTracker = null;
        }
    }
    
    private Rect getChildRectInPagerCoordinates(Rect rect, final View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewPager viewPager;
        for (ViewParent viewParent = view.getParent(); viewParent instanceof ViewGroup && viewParent != this; viewParent = viewPager.getParent()) {
            viewPager = (ViewPager)viewParent;
            rect.left += viewPager.getLeft();
            rect.right += viewPager.getRight();
            rect.top += viewPager.getTop();
            rect.bottom += viewPager.getBottom();
        }
        return rect;
    }
    
    private int getClientWidth() {
        return this.getMeasuredWidth() - this.getPaddingLeft() - this.getPaddingRight();
    }
    
    private ItemInfo infoForCurrentScrollPosition() {
        final int clientWidth = this.getClientWidth();
        float offset = 0.0f;
        float n;
        if (clientWidth > 0) {
            n = this.getScrollX() / (float)clientWidth;
        }
        else {
            n = 0.0f;
        }
        float n2;
        if (clientWidth > 0) {
            n2 = this.mPageMargin / (float)clientWidth;
        }
        else {
            n2 = 0.0f;
        }
        ItemInfo itemInfo = null;
        float widthFactor = 0.0f;
        int position = -1;
        int i = 0;
        int n3 = 1;
        while (i < this.mItems.size()) {
            ItemInfo mTempItem = this.mItems.get(i);
            if (n3 == 0) {
                final int position2 = mTempItem.position;
                final int position3 = position + 1;
                if (position2 != position3) {
                    mTempItem = this.mTempItem;
                    mTempItem.offset = n2 + (offset + widthFactor);
                    mTempItem.position = position3;
                    mTempItem.widthFactor = this.mAdapter.getPageWidth(mTempItem.position);
                    --i;
                }
            }
            offset = mTempItem.offset;
            final float n4 = n2 + (offset + mTempItem.widthFactor);
            if (n3 == 0 && n < offset) {
                return itemInfo;
            }
            if (n < n4 || i == this.mItems.size() - 1) {
                return mTempItem;
            }
            position = mTempItem.position;
            widthFactor = mTempItem.widthFactor;
            ++i;
            itemInfo = mTempItem;
            n3 = 0;
        }
        return itemInfo;
    }
    
    private static boolean isDecorView(final View view) {
        return view.getClass().getAnnotation(DecorView.class) != null;
    }
    
    private boolean isGutterDrag(final float n, final float n2) {
        return (n < this.mGutterSize && n2 > 0.0f) || (n > this.getWidth() - this.mGutterSize && n2 < 0.0f);
    }
    
    private void onSecondaryPointerUp(final MotionEvent motionEvent) {
        final int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.mActivePointerId) {
            int n;
            if (actionIndex == 0) {
                n = 1;
            }
            else {
                n = 0;
            }
            this.mLastMotionX = motionEvent.getX(n);
            this.mActivePointerId = motionEvent.getPointerId(n);
            final VelocityTracker mVelocityTracker = this.mVelocityTracker;
            if (mVelocityTracker != null) {
                mVelocityTracker.clear();
            }
        }
    }
    
    private boolean pageScrolled(final int n) {
        if (this.mItems.size() == 0) {
            if (this.mFirstLayout) {
                return false;
            }
            this.mCalledSuper = false;
            this.onPageScrolled(0, 0.0f, 0);
            if (this.mCalledSuper) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
        else {
            final ItemInfo infoForCurrentScrollPosition = this.infoForCurrentScrollPosition();
            final int clientWidth = this.getClientWidth();
            final int mPageMargin = this.mPageMargin;
            final int n2 = clientWidth + mPageMargin;
            final float n3 = (float)mPageMargin;
            final float n4 = (float)clientWidth;
            final float n5 = n3 / n4;
            final int position = infoForCurrentScrollPosition.position;
            final float n6 = (n / n4 - infoForCurrentScrollPosition.offset) / (n5 + infoForCurrentScrollPosition.widthFactor);
            final int n7 = (int)(n6 * n2);
            this.mCalledSuper = false;
            this.onPageScrolled(position, n6, n7);
            if (this.mCalledSuper) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }
    
    private boolean performDrag(final float mLastMotionX) {
        final float n = this.mLastMotionX - mLastMotionX;
        this.mLastMotionX = mLastMotionX;
        float n2 = n + this.getScrollX();
        final float n3 = (float)this.getClientWidth();
        float n4 = n3 * this.mFirstOffset;
        float n5 = n3 * this.mLastOffset;
        final ItemInfo itemInfo = this.mItems.get(0);
        final ArrayList<ItemInfo> mItems = this.mItems;
        final ItemInfo itemInfo2 = mItems.get(mItems.size() - 1);
        boolean b;
        if (itemInfo.position != 0) {
            n4 = n3 * itemInfo.offset;
            b = false;
        }
        else {
            b = true;
        }
        boolean b2;
        if (itemInfo2.position != this.mAdapter.getCount() - 1) {
            n5 = n3 * itemInfo2.offset;
            b2 = false;
        }
        else {
            b2 = true;
        }
        boolean b3;
        if (n2 < n4) {
            b3 = false;
            if (b) {
                this.mLeftEdge.onPull(Math.abs(n4 - n2) / n3);
                b3 = true;
            }
            n2 = n4;
        }
        else {
            final float n6 = fcmpl(n2, n5);
            b3 = false;
            if (n6 > 0) {
                b3 = false;
                if (b2) {
                    this.mRightEdge.onPull(Math.abs(n2 - n5) / n3);
                    b3 = true;
                }
                n2 = n5;
            }
        }
        final float mLastMotionX2 = this.mLastMotionX;
        final int n7 = (int)n2;
        this.mLastMotionX = mLastMotionX2 + (n2 - n7);
        this.scrollTo(n7, this.getScrollY());
        this.pageScrolled(n7);
        return b3;
    }
    
    private void recomputeScrollPosition(final int n, final int n2, final int n3, final int n4) {
        if (n2 > 0 && !this.mItems.isEmpty()) {
            if (!this.mScroller.isFinished()) {
                this.mScroller.setFinalX(this.getCurrentItem() * this.getClientWidth());
            }
            else {
                this.scrollTo((int)(this.getScrollX() / (float)(n4 + (n2 - this.getPaddingLeft() - this.getPaddingRight())) * (n3 + (n - this.getPaddingLeft() - this.getPaddingRight()))), this.getScrollY());
            }
        }
        else {
            final ItemInfo infoForPosition = this.infoForPosition(this.mCurItem);
            float min;
            if (infoForPosition != null) {
                min = Math.min(infoForPosition.offset, this.mLastOffset);
            }
            else {
                min = 0.0f;
            }
            final int n5 = (int)(min * (n - this.getPaddingLeft() - this.getPaddingRight()));
            if (n5 != this.getScrollX()) {
                this.completeScroll(false);
                this.scrollTo(n5, this.getScrollY());
            }
        }
    }
    
    private void removeNonDecorViews() {
        for (int i = 0; i < this.getChildCount(); ++i) {
            if (!((LayoutParams)this.getChildAt(i).getLayoutParams()).isDecor) {
                this.removeViewAt(i);
                --i;
            }
        }
    }
    
    private void requestParentDisallowInterceptTouchEvent(final boolean b) {
        final ViewParent parent = this.getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(b);
        }
    }
    
    private boolean resetTouch() {
        this.mActivePointerId = -1;
        this.endDrag();
        this.mLeftEdge.onRelease();
        this.mRightEdge.onRelease();
        return this.mLeftEdge.isFinished() || this.mRightEdge.isFinished();
    }
    
    private void scrollToItem(final int n, final boolean b, final int n2, final boolean b2) {
        final ItemInfo infoForPosition = this.infoForPosition(n);
        int n3;
        if (infoForPosition != null) {
            n3 = (int)(this.getClientWidth() * Math.max(this.mFirstOffset, Math.min(infoForPosition.offset, this.mLastOffset)));
        }
        else {
            n3 = 0;
        }
        if (b) {
            this.smoothScrollTo(n3, 0, n2);
            if (b2) {
                this.dispatchOnPageSelected(n);
            }
        }
        else {
            if (b2) {
                this.dispatchOnPageSelected(n);
            }
            this.completeScroll(false);
            this.scrollTo(n3, 0);
            this.pageScrolled(n3);
        }
    }
    
    private void setScrollingCacheEnabled(final boolean mScrollingCacheEnabled) {
        if (this.mScrollingCacheEnabled != mScrollingCacheEnabled) {
            this.mScrollingCacheEnabled = mScrollingCacheEnabled;
        }
    }
    
    private void sortChildDrawingOrder() {
        if (this.mDrawingOrder != 0) {
            final ArrayList<View> mDrawingOrderedChildren = this.mDrawingOrderedChildren;
            if (mDrawingOrderedChildren == null) {
                this.mDrawingOrderedChildren = new ArrayList<View>();
            }
            else {
                mDrawingOrderedChildren.clear();
            }
            for (int childCount = this.getChildCount(), i = 0; i < childCount; ++i) {
                this.mDrawingOrderedChildren.add(this.getChildAt(i));
            }
            Collections.sort(this.mDrawingOrderedChildren, ViewPager.sPositionComparator);
        }
    }
    
    public void addFocusables(final ArrayList<View> list, final int n, final int n2) {
        final int size = list.size();
        final int descendantFocusability = this.getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i = 0; i < this.getChildCount(); ++i) {
                final View child = this.getChildAt(i);
                if (child.getVisibility() == 0) {
                    final ItemInfo infoForChild = this.infoForChild(child);
                    if (infoForChild != null && infoForChild.position == this.mCurItem) {
                        child.addFocusables((ArrayList)list, n, n2);
                    }
                }
            }
        }
        if (descendantFocusability != 262144 || size == list.size()) {
            if (!this.isFocusable()) {
                return;
            }
            if ((n2 & 0x1) == 0x1 && this.isInTouchMode() && !this.isFocusableInTouchMode()) {
                return;
            }
            if (list != null) {
                list.add((View)this);
            }
        }
    }
    
    ItemInfo addNewItem(final int position, final int index) {
        final ItemInfo itemInfo = new ItemInfo();
        itemInfo.position = position;
        itemInfo.object = this.mAdapter.instantiateItem(this, position);
        itemInfo.widthFactor = this.mAdapter.getPageWidth(position);
        if (index >= 0 && index < this.mItems.size()) {
            this.mItems.add(index, itemInfo);
        }
        else {
            this.mItems.add(itemInfo);
        }
        return itemInfo;
    }
    
    public void addOnAdapterChangeListener(final OnAdapterChangeListener onAdapterChangeListener) {
        if (this.mAdapterChangeListeners == null) {
            this.mAdapterChangeListeners = new ArrayList<OnAdapterChangeListener>();
        }
        this.mAdapterChangeListeners.add(onAdapterChangeListener);
    }
    
    public void addOnPageChangeListener(final OnPageChangeListener onPageChangeListener) {
        if (this.mOnPageChangeListeners == null) {
            this.mOnPageChangeListeners = new ArrayList<OnPageChangeListener>();
        }
        this.mOnPageChangeListeners.add(onPageChangeListener);
    }
    
    public void addTouchables(final ArrayList<View> list) {
        for (int i = 0; i < this.getChildCount(); ++i) {
            final View child = this.getChildAt(i);
            if (child.getVisibility() == 0) {
                final ItemInfo infoForChild = this.infoForChild(child);
                if (infoForChild != null && infoForChild.position == this.mCurItem) {
                    child.addTouchables((ArrayList)list);
                }
            }
        }
    }
    
    public void addView(final View view, final int n, ViewGroup$LayoutParams generateLayoutParams) {
        if (!this.checkLayoutParams(generateLayoutParams)) {
            generateLayoutParams = this.generateLayoutParams(generateLayoutParams);
        }
        final LayoutParams layoutParams = (LayoutParams)generateLayoutParams;
        layoutParams.isDecor |= isDecorView(view);
        if (this.mInLayout) {
            if (layoutParams != null && layoutParams.isDecor) {
                throw new IllegalStateException("Cannot add pager decor view during layout");
            }
            layoutParams.needsMeasure = true;
            this.addViewInLayout(view, n, generateLayoutParams);
        }
        else {
            super.addView(view, n, generateLayoutParams);
        }
    }
    
    public boolean arrowScroll(final int n) {
        View focus = this.findFocus();
        Label_0179: {
            Label_0010: {
                if (focus != this) {
                    if (focus != null) {
                        ViewParent viewParent = focus.getParent();
                        while (true) {
                            while (viewParent instanceof ViewGroup) {
                                if (viewParent == this) {
                                    final boolean b = true;
                                    if (!b) {
                                        final StringBuilder sb = new StringBuilder();
                                        sb.append(focus.getClass().getSimpleName());
                                        for (ViewParent viewParent2 = focus.getParent(); viewParent2 instanceof ViewGroup; viewParent2 = viewParent2.getParent()) {
                                            sb.append(" => ");
                                            sb.append(viewParent2.getClass().getSimpleName());
                                        }
                                        final StringBuilder sb2 = new StringBuilder();
                                        sb2.append("arrowScroll tried to find focus based on non-child current focused view ");
                                        sb2.append(sb.toString());
                                        Log.e("ViewPager", sb2.toString());
                                        break Label_0010;
                                    }
                                    break Label_0179;
                                }
                                else {
                                    viewParent = viewParent.getParent();
                                }
                            }
                            final boolean b = false;
                            continue;
                        }
                    }
                    break Label_0179;
                }
            }
            focus = null;
        }
        final View nextFocus = FocusFinder.getInstance().findNextFocus((ViewGroup)this, focus, n);
        boolean b3 = false;
        Label_0374: {
            if (nextFocus != null && nextFocus != focus) {
                boolean b2;
                if (n == 17) {
                    final int left = this.getChildRectInPagerCoordinates(this.mTempRect, nextFocus).left;
                    final int left2 = this.getChildRectInPagerCoordinates(this.mTempRect, focus).left;
                    if (focus != null && left >= left2) {
                        b2 = this.pageLeft();
                    }
                    else {
                        b2 = nextFocus.requestFocus();
                    }
                }
                else {
                    b3 = false;
                    if (n != 66) {
                        break Label_0374;
                    }
                    final int left3 = this.getChildRectInPagerCoordinates(this.mTempRect, nextFocus).left;
                    final int left4 = this.getChildRectInPagerCoordinates(this.mTempRect, focus).left;
                    if (focus != null && left3 <= left4) {
                        b2 = this.pageRight();
                    }
                    else {
                        b2 = nextFocus.requestFocus();
                    }
                }
                b3 = b2;
            }
            else if (n != 17 && n != 1) {
                if (n != 66) {
                    b3 = false;
                    if (n != 2) {
                        break Label_0374;
                    }
                }
                b3 = this.pageRight();
            }
            else {
                b3 = this.pageLeft();
            }
        }
        if (b3) {
            this.playSoundEffect(SoundEffectConstants.getContantForFocusDirection(n));
        }
        return b3;
    }
    
    public boolean beginFakeDrag() {
        if (this.mIsBeingDragged) {
            return false;
        }
        this.mFakeDragging = true;
        this.setScrollState(1);
        this.mLastMotionX = 0.0f;
        this.mInitialMotionX = 0.0f;
        final VelocityTracker mVelocityTracker = this.mVelocityTracker;
        if (mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
        else {
            mVelocityTracker.clear();
        }
        final long uptimeMillis = SystemClock.uptimeMillis();
        final MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 0, 0.0f, 0.0f, 0);
        this.mVelocityTracker.addMovement(obtain);
        obtain.recycle();
        this.mFakeDragBeginTime = uptimeMillis;
        return true;
    }
    
    protected boolean canScroll(final View view, final boolean b, final int n, final int n2, final int n3) {
        final boolean b2 = view instanceof ViewGroup;
        int n4 = 1;
        if (b2) {
            final ViewGroup viewGroup = (ViewGroup)view;
            final int scrollX = view.getScrollX();
            final int scrollY = view.getScrollY();
            for (int i = viewGroup.getChildCount() - n4; i >= 0; --i) {
                final View child = viewGroup.getChildAt(i);
                final int n5 = n2 + scrollX;
                if (n5 >= child.getLeft() && n5 < child.getRight()) {
                    final int n6 = n3 + scrollY;
                    if (n6 >= child.getTop() && n6 < child.getBottom() && this.canScroll(child, true, n, n5 - child.getLeft(), n6 - child.getTop())) {
                        return n4 != 0;
                    }
                }
            }
        }
        if (!b || !view.canScrollHorizontally(-n)) {
            n4 = 0;
        }
        return n4 != 0;
    }
    
    public boolean canScrollHorizontally(final int n) {
        if (this.mAdapter == null) {
            return false;
        }
        final int clientWidth = this.getClientWidth();
        final int scrollX = this.getScrollX();
        if (n < 0) {
            final int n2 = (int)(clientWidth * this.mFirstOffset);
            boolean b = false;
            if (scrollX > n2) {
                b = true;
            }
            return b;
        }
        boolean b2 = false;
        if (n > 0) {
            final int n3 = (int)(clientWidth * this.mLastOffset);
            b2 = false;
            if (scrollX < n3) {
                b2 = true;
            }
        }
        return b2;
    }
    
    protected boolean checkLayoutParams(final ViewGroup$LayoutParams viewGroup$LayoutParams) {
        return viewGroup$LayoutParams instanceof LayoutParams && super.checkLayoutParams(viewGroup$LayoutParams);
    }
    
    public void clearOnPageChangeListeners() {
        final List<OnPageChangeListener> mOnPageChangeListeners = this.mOnPageChangeListeners;
        if (mOnPageChangeListeners != null) {
            mOnPageChangeListeners.clear();
        }
    }
    
    public void computeScroll() {
        this.mIsScrollStarted = true;
        if (!this.mScroller.isFinished() && this.mScroller.computeScrollOffset()) {
            final int scrollX = this.getScrollX();
            final int scrollY = this.getScrollY();
            final int currX = this.mScroller.getCurrX();
            final int currY = this.mScroller.getCurrY();
            if (scrollX != currX || scrollY != currY) {
                this.scrollTo(currX, currY);
                if (!this.pageScrolled(currX)) {
                    this.mScroller.abortAnimation();
                    this.scrollTo(0, currY);
                }
            }
            ViewCompat.postInvalidateOnAnimation((View)this);
            return;
        }
        this.completeScroll(true);
    }
    
    void dataSetChanged() {
        final int count = this.mAdapter.getCount();
        this.mExpectedAdapterCount = count;
        boolean b = this.mItems.size() < 1 + 2 * this.mOffscreenPageLimit && this.mItems.size() < count;
        int n = this.mCurItem;
        int i = 0;
        int n2 = 0;
        while (i < this.mItems.size()) {
            final ItemInfo itemInfo = this.mItems.get(i);
            final int itemPosition = this.mAdapter.getItemPosition(itemInfo.object);
            Label_0230: {
                if (itemPosition != -1) {
                    if (itemPosition == -2) {
                        this.mItems.remove(i);
                        --i;
                        if (n2 == 0) {
                            this.mAdapter.startUpdate(this);
                            n2 = 1;
                        }
                        this.mAdapter.destroyItem(this, itemInfo.position, itemInfo.object);
                        if (this.mCurItem == itemInfo.position) {
                            n = Math.max(0, Math.min(this.mCurItem, count - 1));
                        }
                    }
                    else {
                        if (itemInfo.position == itemPosition) {
                            break Label_0230;
                        }
                        if (itemInfo.position == this.mCurItem) {
                            n = itemPosition;
                        }
                        itemInfo.position = itemPosition;
                    }
                    b = true;
                }
            }
            ++i;
        }
        if (n2 != 0) {
            this.mAdapter.finishUpdate(this);
        }
        Collections.sort(this.mItems, ViewPager.COMPARATOR);
        if (b) {
            for (int childCount = this.getChildCount(), j = 0; j < childCount; ++j) {
                final LayoutParams layoutParams = (LayoutParams)this.getChildAt(j).getLayoutParams();
                if (!layoutParams.isDecor) {
                    layoutParams.widthFactor = 0.0f;
                }
            }
            this.setCurrentItemInternal(n, false, true);
            this.requestLayout();
        }
    }
    
    public boolean dispatchKeyEvent(final KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || this.executeKeyEvent(keyEvent);
    }
    
    public boolean dispatchPopulateAccessibilityEvent(final AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        for (int childCount = this.getChildCount(), i = 0; i < childCount; ++i) {
            final View child = this.getChildAt(i);
            if (child.getVisibility() == 0) {
                final ItemInfo infoForChild = this.infoForChild(child);
                if (infoForChild != null && infoForChild.position == this.mCurItem && child.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    float distanceInfluenceForSnapDuration(final float n) {
        return (float)Math.sin(0.47123894f * (n - 0.5f));
    }
    
    public void draw(final Canvas canvas) {
        super.draw(canvas);
        final int overScrollMode = this.getOverScrollMode();
        boolean b = false;
        Label_0258: {
            Label_0062: {
                if (overScrollMode != 0) {
                    if (overScrollMode == 1) {
                        final PagerAdapter mAdapter = this.mAdapter;
                        if (mAdapter != null && mAdapter.getCount() > 1) {
                            break Label_0062;
                        }
                    }
                    this.mLeftEdge.finish();
                    this.mRightEdge.finish();
                    b = false;
                    break Label_0258;
                }
            }
            final boolean finished = this.mLeftEdge.isFinished();
            b = false;
            if (!finished) {
                final int save = canvas.save();
                final int n = this.getHeight() - this.getPaddingTop() - this.getPaddingBottom();
                final int width = this.getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float)(-n + this.getPaddingTop()), this.mFirstOffset * width);
                this.mLeftEdge.setSize(n, width);
                b = (false | this.mLeftEdge.draw(canvas));
                canvas.restoreToCount(save);
            }
            if (!this.mRightEdge.isFinished()) {
                final int save2 = canvas.save();
                final int width2 = this.getWidth();
                final int n2 = this.getHeight() - this.getPaddingTop() - this.getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float)(-this.getPaddingTop()), -(1.0f + this.mLastOffset) * width2);
                this.mRightEdge.setSize(n2, width2);
                b |= this.mRightEdge.draw(canvas);
                canvas.restoreToCount(save2);
            }
        }
        if (b) {
            ViewCompat.postInvalidateOnAnimation((View)this);
        }
    }
    
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        final Drawable mMarginDrawable = this.mMarginDrawable;
        if (mMarginDrawable != null && mMarginDrawable.isStateful()) {
            mMarginDrawable.setState(this.getDrawableState());
        }
    }
    
    public void endFakeDrag() {
        if (this.mFakeDragging) {
            if (this.mAdapter != null) {
                final VelocityTracker mVelocityTracker = this.mVelocityTracker;
                mVelocityTracker.computeCurrentVelocity(1000, (float)this.mMaximumVelocity);
                final int n = (int)mVelocityTracker.getXVelocity(this.mActivePointerId);
                this.mPopulatePending = true;
                final int clientWidth = this.getClientWidth();
                final int scrollX = this.getScrollX();
                final ItemInfo infoForCurrentScrollPosition = this.infoForCurrentScrollPosition();
                this.setCurrentItemInternal(this.determineTargetPage(infoForCurrentScrollPosition.position, (scrollX / (float)clientWidth - infoForCurrentScrollPosition.offset) / infoForCurrentScrollPosition.widthFactor, n, (int)(this.mLastMotionX - this.mInitialMotionX)), true, true, n);
            }
            this.endDrag();
            this.mFakeDragging = false;
            return;
        }
        throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
    }
    
    public boolean executeKeyEvent(final KeyEvent keyEvent) {
        if (keyEvent.getAction() == 0) {
            final int keyCode = keyEvent.getKeyCode();
            if (keyCode != 21) {
                if (keyCode != 22) {
                    if (keyCode == 61) {
                        if (keyEvent.hasNoModifiers()) {
                            return this.arrowScroll(2);
                        }
                        if (keyEvent.hasModifiers(1)) {
                            return this.arrowScroll(1);
                        }
                    }
                }
                else {
                    if (keyEvent.hasModifiers(2)) {
                        return this.pageRight();
                    }
                    return this.arrowScroll(66);
                }
            }
            else {
                if (keyEvent.hasModifiers(2)) {
                    return this.pageLeft();
                }
                return this.arrowScroll(17);
            }
        }
        return false;
    }
    
    public void fakeDragBy(final float n) {
        if (!this.mFakeDragging) {
            throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
        }
        if (this.mAdapter == null) {
            return;
        }
        this.mLastMotionX += n;
        float n2 = this.getScrollX() - n;
        final float n3 = (float)this.getClientWidth();
        float n4 = n3 * this.mFirstOffset;
        float n5 = n3 * this.mLastOffset;
        final ItemInfo itemInfo = this.mItems.get(0);
        final ArrayList<ItemInfo> mItems = this.mItems;
        final ItemInfo itemInfo2 = mItems.get(-1 + mItems.size());
        if (itemInfo.position != 0) {
            n4 = n3 * itemInfo.offset;
        }
        if (itemInfo2.position != -1 + this.mAdapter.getCount()) {
            n5 = n3 * itemInfo2.offset;
        }
        if (n2 < n4) {
            n2 = n4;
        }
        else if (n2 > n5) {
            n2 = n5;
        }
        final float mLastMotionX = this.mLastMotionX;
        final int n6 = (int)n2;
        this.mLastMotionX = mLastMotionX + (n2 - n6);
        this.scrollTo(n6, this.getScrollY());
        this.pageScrolled(n6);
        final MotionEvent obtain = MotionEvent.obtain(this.mFakeDragBeginTime, SystemClock.uptimeMillis(), 2, this.mLastMotionX, 0.0f, 0);
        this.mVelocityTracker.addMovement(obtain);
        obtain.recycle();
    }
    
    protected ViewGroup$LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }
    
    public ViewGroup$LayoutParams generateLayoutParams(final AttributeSet set) {
        return new LayoutParams(this.getContext(), set);
    }
    
    protected ViewGroup$LayoutParams generateLayoutParams(final ViewGroup$LayoutParams viewGroup$LayoutParams) {
        return this.generateDefaultLayoutParams();
    }
    
    public PagerAdapter getAdapter() {
        return this.mAdapter;
    }
    
    protected int getChildDrawingOrder(final int n, int index) {
        if (this.mDrawingOrder == 2) {
            index = n - 1 - index;
        }
        return ((LayoutParams)this.mDrawingOrderedChildren.get(index).getLayoutParams()).childIndex;
    }
    
    public int getCurrentItem() {
        return this.mCurItem;
    }
    
    public int getOffscreenPageLimit() {
        return this.mOffscreenPageLimit;
    }
    
    public int getPageMargin() {
        return this.mPageMargin;
    }
    
    ItemInfo infoForAnyChild(View view) {
        while (true) {
            final ViewParent parent = view.getParent();
            if (parent == this) {
                return this.infoForChild(view);
            }
            if (parent == null || !(parent instanceof View)) {
                return null;
            }
            view = (View)parent;
        }
    }
    
    ItemInfo infoForChild(final View view) {
        for (int i = 0; i < this.mItems.size(); ++i) {
            final ItemInfo itemInfo = this.mItems.get(i);
            if (this.mAdapter.isViewFromObject(view, itemInfo.object)) {
                return itemInfo;
            }
        }
        return null;
    }
    
    ItemInfo infoForPosition(final int n) {
        for (int i = 0; i < this.mItems.size(); ++i) {
            final ItemInfo itemInfo = this.mItems.get(i);
            if (itemInfo.position == n) {
                return itemInfo;
            }
        }
        return null;
    }
    
    void initViewPager() {
        this.setWillNotDraw(false);
        this.setDescendantFocusability(262144);
        this.setFocusable(true);
        final Context context = this.getContext();
        this.mScroller = new Scroller(context, ViewPager.sInterpolator);
        final ViewConfiguration value = ViewConfiguration.get(context);
        final float density = context.getResources().getDisplayMetrics().density;
        this.mTouchSlop = value.getScaledPagingTouchSlop();
        this.mMinimumVelocity = (int)(400.0f * density);
        this.mMaximumVelocity = value.getScaledMaximumFlingVelocity();
        this.mLeftEdge = new EdgeEffect(context);
        this.mRightEdge = new EdgeEffect(context);
        this.mFlingDistance = (int)(25.0f * density);
        this.mCloseEnough = (int)(2.0f * density);
        this.mDefaultGutterSize = (int)(density * 16.0f);
        ViewCompat.setAccessibilityDelegate((View)this, new MyAccessibilityDelegate());
        if (ViewCompat.getImportantForAccessibility((View)this) == 0) {
            ViewCompat.setImportantForAccessibility((View)this, 1);
        }
        ViewCompat.setOnApplyWindowInsetsListener((View)this, new OnApplyWindowInsetsListener() {
            private final Rect mTempRect = new Rect();
            
            @Override
            public WindowInsetsCompat onApplyWindowInsets(final View view, final WindowInsetsCompat windowInsetsCompat) {
                final WindowInsetsCompat onApplyWindowInsets = ViewCompat.onApplyWindowInsets(view, windowInsetsCompat);
                if (onApplyWindowInsets.isConsumed()) {
                    return onApplyWindowInsets;
                }
                final Rect mTempRect = this.mTempRect;
                mTempRect.left = onApplyWindowInsets.getSystemWindowInsetLeft();
                mTempRect.top = onApplyWindowInsets.getSystemWindowInsetTop();
                mTempRect.right = onApplyWindowInsets.getSystemWindowInsetRight();
                mTempRect.bottom = onApplyWindowInsets.getSystemWindowInsetBottom();
                for (int i = 0; i < ViewPager.this.getChildCount(); ++i) {
                    final WindowInsetsCompat dispatchApplyWindowInsets = ViewCompat.dispatchApplyWindowInsets(ViewPager.this.getChildAt(i), onApplyWindowInsets);
                    mTempRect.left = Math.min(dispatchApplyWindowInsets.getSystemWindowInsetLeft(), mTempRect.left);
                    mTempRect.top = Math.min(dispatchApplyWindowInsets.getSystemWindowInsetTop(), mTempRect.top);
                    mTempRect.right = Math.min(dispatchApplyWindowInsets.getSystemWindowInsetRight(), mTempRect.right);
                    mTempRect.bottom = Math.min(dispatchApplyWindowInsets.getSystemWindowInsetBottom(), mTempRect.bottom);
                }
                return onApplyWindowInsets.replaceSystemWindowInsets(mTempRect.left, mTempRect.top, mTempRect.right, mTempRect.bottom);
            }
        });
    }
    
    public boolean isFakeDragging() {
        return this.mFakeDragging;
    }
    
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mFirstLayout = true;
    }
    
    protected void onDetachedFromWindow() {
        this.removeCallbacks(this.mEndScrollRunnable);
        final Scroller mScroller = this.mScroller;
        if (mScroller != null && !mScroller.isFinished()) {
            this.mScroller.abortAnimation();
        }
        super.onDetachedFromWindow();
    }
    
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);
        if (this.mPageMargin > 0 && this.mMarginDrawable != null && this.mItems.size() > 0 && this.mAdapter != null) {
            final int scrollX = this.getScrollX();
            final int width = this.getWidth();
            final float n = (float)this.mPageMargin;
            final float n2 = (float)width;
            float n3 = n / n2;
            final ArrayList<ItemInfo> mItems = this.mItems;
            int index = 0;
            ItemInfo itemInfo = mItems.get(0);
            float offset = itemInfo.offset;
            float n4;
            float n6;
            for (int size = this.mItems.size(), i = itemInfo.position; i < this.mItems.get(size - 1).position; ++i, offset = n4, n3 = n6) {
                while (i > itemInfo.position && index < size) {
                    final ArrayList<ItemInfo> mItems2 = this.mItems;
                    ++index;
                    itemInfo = mItems2.get(index);
                }
                float a;
                if (i == itemInfo.position) {
                    a = n2 * (itemInfo.offset + itemInfo.widthFactor);
                    n4 = n3 + (itemInfo.offset + itemInfo.widthFactor);
                }
                else {
                    final float pageWidth = this.mAdapter.getPageWidth(i);
                    final float n5 = n2 * (offset + pageWidth);
                    n4 = offset + (pageWidth + n3);
                    a = n5;
                }
                if (a + this.mPageMargin > scrollX) {
                    final Drawable mMarginDrawable = this.mMarginDrawable;
                    final int round = Math.round(a);
                    final int mTopPageBounds = this.mTopPageBounds;
                    final int round2 = Math.round(a + this.mPageMargin);
                    n6 = n3;
                    mMarginDrawable.setBounds(round, mTopPageBounds, round2, this.mBottomPageBounds);
                    this.mMarginDrawable.draw(canvas);
                }
                else {
                    n6 = n3;
                }
                if (a > scrollX + width) {
                    break;
                }
            }
        }
    }
    
    public boolean onInterceptTouchEvent(final MotionEvent motionEvent) {
        final int n = 0xFF & motionEvent.getAction();
        if (n != 3 && n != 1) {
            if (n != 0) {
                if (this.mIsBeingDragged) {
                    return true;
                }
                if (this.mIsUnableToDrag) {
                    return false;
                }
            }
            if (n != 0) {
                if (n != 2) {
                    if (n == 6) {
                        this.onSecondaryPointerUp(motionEvent);
                    }
                }
                else {
                    final int mActivePointerId = this.mActivePointerId;
                    if (mActivePointerId != -1) {
                        final int pointerIndex = motionEvent.findPointerIndex(mActivePointerId);
                        final float x = motionEvent.getX(pointerIndex);
                        final float a = x - this.mLastMotionX;
                        final float abs = Math.abs(a);
                        final float y = motionEvent.getY(pointerIndex);
                        final float abs2 = Math.abs(y - this.mInitialMotionY);
                        if (a != 0.0f && !this.isGutterDrag(this.mLastMotionX, a) && this.canScroll((View)this, false, (int)a, (int)x, (int)y)) {
                            this.mLastMotionX = x;
                            this.mLastMotionY = y;
                            this.mIsUnableToDrag = true;
                            return false;
                        }
                        final int mTouchSlop = this.mTouchSlop;
                        if (abs > mTouchSlop && abs * 0.5f > abs2) {
                            this.requestParentDisallowInterceptTouchEvent(this.mIsBeingDragged = true);
                            this.setScrollState(1);
                            float mLastMotionX;
                            if (a > 0.0f) {
                                mLastMotionX = this.mInitialMotionX + this.mTouchSlop;
                            }
                            else {
                                mLastMotionX = this.mInitialMotionX - this.mTouchSlop;
                            }
                            this.mLastMotionX = mLastMotionX;
                            this.mLastMotionY = y;
                            this.setScrollingCacheEnabled(true);
                        }
                        else if (abs2 > mTouchSlop) {
                            this.mIsUnableToDrag = true;
                        }
                        if (this.mIsBeingDragged && this.performDrag(x)) {
                            ViewCompat.postInvalidateOnAnimation((View)this);
                        }
                    }
                }
            }
            else {
                final float x2 = motionEvent.getX();
                this.mInitialMotionX = x2;
                this.mLastMotionX = x2;
                final float y2 = motionEvent.getY();
                this.mInitialMotionY = y2;
                this.mLastMotionY = y2;
                this.mActivePointerId = motionEvent.getPointerId(0);
                this.mIsUnableToDrag = false;
                this.mIsScrollStarted = true;
                this.mScroller.computeScrollOffset();
                if (this.mScrollState == 2 && Math.abs(this.mScroller.getFinalX() - this.mScroller.getCurrX()) > this.mCloseEnough) {
                    this.mScroller.abortAnimation();
                    this.mPopulatePending = false;
                    this.populate();
                    this.requestParentDisallowInterceptTouchEvent(this.mIsBeingDragged = true);
                    this.setScrollState(1);
                }
                else {
                    this.completeScroll(false);
                    this.mIsBeingDragged = false;
                }
            }
            if (this.mVelocityTracker == null) {
                this.mVelocityTracker = VelocityTracker.obtain();
            }
            this.mVelocityTracker.addMovement(motionEvent);
            return this.mIsBeingDragged;
        }
        this.resetTouch();
        return false;
    }
    
    protected void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        final int childCount = this.getChildCount();
        final int n5 = n3 - n;
        final int n6 = n4 - n2;
        int paddingLeft = this.getPaddingLeft();
        int paddingTop = this.getPaddingTop();
        int paddingRight = this.getPaddingRight();
        int paddingBottom = this.getPaddingBottom();
        final int scrollX = this.getScrollX();
        int i = 0;
        int mDecorChildCount = 0;
        while (i < childCount) {
            final View child = this.getChildAt(i);
            if (child.getVisibility() != 8) {
                final LayoutParams layoutParams = (LayoutParams)child.getLayoutParams();
                if (layoutParams.isDecor) {
                    final int n7 = 0x7 & layoutParams.gravity;
                    final int n8 = 0x70 & layoutParams.gravity;
                    int n9 = 0;
                    Label_0210: {
                        int max;
                        if (n7 != 1) {
                            if (n7 == 3) {
                                n9 = paddingLeft + child.getMeasuredWidth();
                                break Label_0210;
                            }
                            if (n7 != 5) {
                                n9 = paddingLeft;
                                break Label_0210;
                            }
                            max = n5 - paddingRight - child.getMeasuredWidth();
                            paddingRight += child.getMeasuredWidth();
                        }
                        else {
                            max = Math.max((n5 - child.getMeasuredWidth()) / 2, paddingLeft);
                        }
                        final int n10 = max;
                        n9 = paddingLeft;
                        paddingLeft = n10;
                    }
                    int n11 = 0;
                    Label_0306: {
                        int max2;
                        if (n8 != 16) {
                            if (n8 == 48) {
                                n11 = paddingTop + child.getMeasuredHeight();
                                break Label_0306;
                            }
                            if (n8 != 80) {
                                n11 = paddingTop;
                                break Label_0306;
                            }
                            max2 = n6 - paddingBottom - child.getMeasuredHeight();
                            paddingBottom += child.getMeasuredHeight();
                        }
                        else {
                            max2 = Math.max((n6 - child.getMeasuredHeight()) / 2, paddingTop);
                        }
                        final int n12 = max2;
                        n11 = paddingTop;
                        paddingTop = n12;
                    }
                    final int n13 = paddingLeft + scrollX;
                    child.layout(n13, paddingTop, n13 + child.getMeasuredWidth(), paddingTop + child.getMeasuredHeight());
                    ++mDecorChildCount;
                    paddingTop = n11;
                    paddingLeft = n9;
                }
            }
            ++i;
        }
        final int n14 = n5 - paddingLeft - paddingRight;
        for (int j = 0; j < childCount; ++j) {
            final View child2 = this.getChildAt(j);
            if (child2.getVisibility() != 8) {
                final LayoutParams layoutParams2 = (LayoutParams)child2.getLayoutParams();
                if (!layoutParams2.isDecor) {
                    final ItemInfo infoForChild = this.infoForChild(child2);
                    if (infoForChild != null) {
                        final float n15 = (float)n14;
                        final int n16 = paddingLeft + (int)(n15 * infoForChild.offset);
                        if (layoutParams2.needsMeasure) {
                            layoutParams2.needsMeasure = false;
                            child2.measure(View$MeasureSpec.makeMeasureSpec((int)(n15 * layoutParams2.widthFactor), 1073741824), View$MeasureSpec.makeMeasureSpec(n6 - paddingTop - paddingBottom, 1073741824));
                        }
                        child2.layout(n16, paddingTop, n16 + child2.getMeasuredWidth(), paddingTop + child2.getMeasuredHeight());
                    }
                }
            }
        }
        this.mTopPageBounds = paddingTop;
        this.mBottomPageBounds = n6 - paddingBottom;
        this.mDecorChildCount = mDecorChildCount;
        if (this.mFirstLayout) {
            this.scrollToItem(this.mCurItem, false, 0, false);
        }
        this.mFirstLayout = false;
    }
    
    protected void onMeasure(final int n, final int n2) {
        this.setMeasuredDimension(getDefaultSize(0, n), getDefaultSize(0, n2));
        final int measuredWidth = this.getMeasuredWidth();
        this.mGutterSize = Math.min(measuredWidth / 10, this.mDefaultGutterSize);
        int n3 = measuredWidth - this.getPaddingLeft() - this.getPaddingRight();
        int n4 = this.getMeasuredHeight() - this.getPaddingTop() - this.getPaddingBottom();
        final int childCount = this.getChildCount();
        int n5 = 0;
        boolean mInLayout;
        int n6;
        while (true) {
            mInLayout = true;
            n6 = 1073741824;
            if (n5 >= childCount) {
                break;
            }
            final View child = this.getChildAt(n5);
            if (child.getVisibility() != 8) {
                final LayoutParams layoutParams = (LayoutParams)child.getLayoutParams();
                if (layoutParams != null && layoutParams.isDecor) {
                    final int n7 = 0x7 & layoutParams.gravity;
                    final int n8 = 0x70 & layoutParams.gravity;
                    final boolean b = n8 == 48 || n8 == 80;
                    if (n7 != 3) {
                        if (n7 != 5) {
                            mInLayout = false;
                        }
                    }
                    int n9 = Integer.MIN_VALUE;
                    int n10 = 0;
                    Label_0228: {
                        if (b) {
                            n9 = 1073741824;
                        }
                        else if (mInLayout) {
                            n10 = 1073741824;
                            break Label_0228;
                        }
                        n10 = Integer.MIN_VALUE;
                    }
                    int width;
                    int n11;
                    if (layoutParams.width != -2) {
                        if (layoutParams.width != -1) {
                            width = layoutParams.width;
                        }
                        else {
                            width = n3;
                        }
                        n11 = 1073741824;
                    }
                    else {
                        n11 = n9;
                        width = n3;
                    }
                    int height;
                    if (layoutParams.height != -2) {
                        if (layoutParams.height != -1) {
                            height = layoutParams.height;
                        }
                        else {
                            height = n4;
                        }
                    }
                    else {
                        height = n4;
                        n6 = n10;
                    }
                    child.measure(View$MeasureSpec.makeMeasureSpec(width, n11), View$MeasureSpec.makeMeasureSpec(height, n6));
                    if (b) {
                        n4 -= child.getMeasuredHeight();
                    }
                    else if (mInLayout) {
                        n3 -= child.getMeasuredWidth();
                    }
                }
            }
            ++n5;
        }
        this.mChildWidthMeasureSpec = View$MeasureSpec.makeMeasureSpec(n3, n6);
        this.mChildHeightMeasureSpec = View$MeasureSpec.makeMeasureSpec(n4, n6);
        this.mInLayout = mInLayout;
        this.populate();
        int i = 0;
        this.mInLayout = false;
        while (i < this.getChildCount()) {
            final View child2 = this.getChildAt(i);
            if (child2.getVisibility() != 8) {
                final LayoutParams layoutParams2 = (LayoutParams)child2.getLayoutParams();
                if (layoutParams2 == null || !layoutParams2.isDecor) {
                    child2.measure(View$MeasureSpec.makeMeasureSpec((int)(n3 * layoutParams2.widthFactor), n6), this.mChildHeightMeasureSpec);
                }
            }
            ++i;
        }
    }
    
    protected void onPageScrolled(final int n, final float n2, final int n3) {
        final int mDecorChildCount = this.mDecorChildCount;
        int i = 0;
        if (mDecorChildCount > 0) {
            final int scrollX = this.getScrollX();
            int paddingLeft = this.getPaddingLeft();
            int paddingRight = this.getPaddingRight();
            final int width = this.getWidth();
            for (int childCount = this.getChildCount(), j = 0; j < childCount; ++j) {
                final View child = this.getChildAt(j);
                final LayoutParams layoutParams = (LayoutParams)child.getLayoutParams();
                if (layoutParams.isDecor) {
                    final int n4 = 0x7 & layoutParams.gravity;
                    int n5 = 0;
                    Label_0186: {
                        int max;
                        if (n4 != 1) {
                            if (n4 == 3) {
                                n5 = paddingLeft + child.getWidth();
                                break Label_0186;
                            }
                            if (n4 != 5) {
                                n5 = paddingLeft;
                                break Label_0186;
                            }
                            max = width - paddingRight - child.getMeasuredWidth();
                            paddingRight += child.getMeasuredWidth();
                        }
                        else {
                            max = Math.max((width - child.getMeasuredWidth()) / 2, paddingLeft);
                        }
                        final int n6 = max;
                        n5 = paddingLeft;
                        paddingLeft = n6;
                    }
                    final int n7 = paddingLeft + scrollX - child.getLeft();
                    if (n7 != 0) {
                        child.offsetLeftAndRight(n7);
                    }
                    paddingLeft = n5;
                }
            }
        }
        this.dispatchOnPageScrolled(n, n2, n3);
        if (this.mPageTransformer != null) {
            final int scrollX2 = this.getScrollX();
            while (i < this.getChildCount()) {
                final View child2 = this.getChildAt(i);
                if (!((LayoutParams)child2.getLayoutParams()).isDecor) {
                    this.mPageTransformer.transformPage(child2, (child2.getLeft() - scrollX2) / (float)this.getClientWidth());
                }
                ++i;
            }
        }
        this.mCalledSuper = true;
    }
    
    protected boolean onRequestFocusInDescendants(final int n, final Rect rect) {
        final int childCount = this.getChildCount();
        final int n2 = n & 0x2;
        int n3 = -1;
        int n4;
        int i;
        if (n2 != 0) {
            n3 = childCount;
            n4 = 1;
            i = 0;
        }
        else {
            i = childCount - 1;
            n4 = -1;
        }
        while (i != n3) {
            final View child = this.getChildAt(i);
            if (child.getVisibility() == 0) {
                final ItemInfo infoForChild = this.infoForChild(child);
                if (infoForChild != null && infoForChild.position == this.mCurItem && child.requestFocus(n, rect)) {
                    return true;
                }
            }
            i += n4;
        }
        return false;
    }
    
    public void onRestoreInstanceState(final Parcelable parcelable) {
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        final SavedState savedState = (SavedState)parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        final PagerAdapter mAdapter = this.mAdapter;
        if (mAdapter != null) {
            mAdapter.restoreState(savedState.adapterState, savedState.loader);
            this.setCurrentItemInternal(savedState.position, false, true);
        }
        else {
            this.mRestoredCurItem = savedState.position;
            this.mRestoredAdapterState = savedState.adapterState;
            this.mRestoredClassLoader = savedState.loader;
        }
    }
    
    public Parcelable onSaveInstanceState() {
        final SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.position = this.mCurItem;
        final PagerAdapter mAdapter = this.mAdapter;
        if (mAdapter != null) {
            savedState.adapterState = mAdapter.saveState();
        }
        return (Parcelable)savedState;
    }
    
    protected void onSizeChanged(final int n, final int n2, final int n3, final int n4) {
        super.onSizeChanged(n, n2, n3, n4);
        if (n != n3) {
            final int mPageMargin = this.mPageMargin;
            this.recomputeScrollPosition(n, n3, mPageMargin, mPageMargin);
        }
    }
    
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        if (this.mFakeDragging) {
            return true;
        }
        final int action = motionEvent.getAction();
        boolean b = false;
        if (action == 0 && motionEvent.getEdgeFlags() != 0) {
            return false;
        }
        final PagerAdapter mAdapter = this.mAdapter;
        if (mAdapter != null && mAdapter.getCount() != 0) {
            if (this.mVelocityTracker == null) {
                this.mVelocityTracker = VelocityTracker.obtain();
            }
            this.mVelocityTracker.addMovement(motionEvent);
            final int n = 0xFF & motionEvent.getAction();
            Label_0641: {
                if (n != 0) {
                    if (n != 1) {
                        if (n != 2) {
                            if (n != 3) {
                                if (n != 5) {
                                    if (n != 6) {
                                        b = false;
                                    }
                                    else {
                                        this.onSecondaryPointerUp(motionEvent);
                                        this.mLastMotionX = motionEvent.getX(motionEvent.findPointerIndex(this.mActivePointerId));
                                        b = false;
                                    }
                                }
                                else {
                                    final int actionIndex = motionEvent.getActionIndex();
                                    this.mLastMotionX = motionEvent.getX(actionIndex);
                                    this.mActivePointerId = motionEvent.getPointerId(actionIndex);
                                    b = false;
                                }
                            }
                            else {
                                final boolean mIsBeingDragged = this.mIsBeingDragged;
                                b = false;
                                if (mIsBeingDragged) {
                                    this.scrollToItem(this.mCurItem, true, 0, false);
                                    b = this.resetTouch();
                                }
                            }
                        }
                        else {
                            if (!this.mIsBeingDragged) {
                                final int pointerIndex = motionEvent.findPointerIndex(this.mActivePointerId);
                                if (pointerIndex == -1) {
                                    b = this.resetTouch();
                                    break Label_0641;
                                }
                                final float x = motionEvent.getX(pointerIndex);
                                final float abs = Math.abs(x - this.mLastMotionX);
                                final float y = motionEvent.getY(pointerIndex);
                                final float abs2 = Math.abs(y - this.mLastMotionY);
                                if (abs > this.mTouchSlop && abs > abs2) {
                                    this.requestParentDisallowInterceptTouchEvent(this.mIsBeingDragged = true);
                                    final float mInitialMotionX = this.mInitialMotionX;
                                    float mLastMotionX;
                                    if (x - mInitialMotionX > 0.0f) {
                                        mLastMotionX = mInitialMotionX + this.mTouchSlop;
                                    }
                                    else {
                                        mLastMotionX = mInitialMotionX - this.mTouchSlop;
                                    }
                                    this.mLastMotionX = mLastMotionX;
                                    this.mLastMotionY = y;
                                    this.setScrollState(1);
                                    this.setScrollingCacheEnabled(true);
                                    final ViewParent parent = this.getParent();
                                    if (parent != null) {
                                        parent.requestDisallowInterceptTouchEvent(true);
                                    }
                                }
                            }
                            final boolean mIsBeingDragged2 = this.mIsBeingDragged;
                            b = false;
                            if (mIsBeingDragged2) {
                                b = (false | this.performDrag(motionEvent.getX(motionEvent.findPointerIndex(this.mActivePointerId))));
                            }
                        }
                    }
                    else {
                        final boolean mIsBeingDragged3 = this.mIsBeingDragged;
                        b = false;
                        if (mIsBeingDragged3) {
                            final VelocityTracker mVelocityTracker = this.mVelocityTracker;
                            mVelocityTracker.computeCurrentVelocity(1000, (float)this.mMaximumVelocity);
                            final int n2 = (int)mVelocityTracker.getXVelocity(this.mActivePointerId);
                            this.mPopulatePending = true;
                            final int clientWidth = this.getClientWidth();
                            final int scrollX = this.getScrollX();
                            final ItemInfo infoForCurrentScrollPosition = this.infoForCurrentScrollPosition();
                            final float n3 = (float)this.mPageMargin;
                            final float n4 = (float)clientWidth;
                            this.setCurrentItemInternal(this.determineTargetPage(infoForCurrentScrollPosition.position, (scrollX / n4 - infoForCurrentScrollPosition.offset) / (n3 / n4 + infoForCurrentScrollPosition.widthFactor), n2, (int)(motionEvent.getX(motionEvent.findPointerIndex(this.mActivePointerId)) - this.mInitialMotionX)), true, true, n2);
                            b = this.resetTouch();
                        }
                    }
                }
                else {
                    this.mScroller.abortAnimation();
                    this.mPopulatePending = false;
                    this.populate();
                    final float x2 = motionEvent.getX();
                    this.mInitialMotionX = x2;
                    this.mLastMotionX = x2;
                    final float y2 = motionEvent.getY();
                    this.mInitialMotionY = y2;
                    this.mLastMotionY = y2;
                    this.mActivePointerId = motionEvent.getPointerId(0);
                }
            }
            if (b) {
                ViewCompat.postInvalidateOnAnimation((View)this);
            }
            return true;
        }
        return false;
    }
    
    boolean pageLeft() {
        final int mCurItem = this.mCurItem;
        if (mCurItem > 0) {
            this.setCurrentItem(mCurItem - 1, true);
            return true;
        }
        return false;
    }
    
    boolean pageRight() {
        final PagerAdapter mAdapter = this.mAdapter;
        if (mAdapter != null && this.mCurItem < mAdapter.getCount() - 1) {
            this.setCurrentItem(1 + this.mCurItem, true);
            return true;
        }
        return false;
    }
    
    void populate() {
        this.populate(this.mCurItem);
    }
    
    void populate(final int p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     4: istore_2       
        //     5: iload_2        
        //     6: iload_1        
        //     7: if_icmpeq       24
        //    10: aload_0        
        //    11: iload_2        
        //    12: invokevirtual   androidx/viewpager/widget/ViewPager.infoForPosition:(I)Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //    15: astore_3       
        //    16: aload_0        
        //    17: iload_1        
        //    18: putfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //    21: goto            26
        //    24: aconst_null    
        //    25: astore_3       
        //    26: aload_0        
        //    27: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //    30: ifnonnull       38
        //    33: aload_0        
        //    34: invokespecial   androidx/viewpager/widget/ViewPager.sortChildDrawingOrder:()V
        //    37: return         
        //    38: aload_0        
        //    39: getfield        androidx/viewpager/widget/ViewPager.mPopulatePending:Z
        //    42: ifeq            50
        //    45: aload_0        
        //    46: invokespecial   androidx/viewpager/widget/ViewPager.sortChildDrawingOrder:()V
        //    49: return         
        //    50: aload_0        
        //    51: invokevirtual   androidx/viewpager/widget/ViewPager.getWindowToken:()Landroid/os/IBinder;
        //    54: ifnonnull       58
        //    57: return         
        //    58: aload_0        
        //    59: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //    62: aload_0        
        //    63: invokevirtual   androidx/viewpager/widget/PagerAdapter.startUpdate:(Landroid/view/ViewGroup;)V
        //    66: aload_0        
        //    67: getfield        androidx/viewpager/widget/ViewPager.mOffscreenPageLimit:I
        //    70: istore          4
        //    72: iconst_0       
        //    73: aload_0        
        //    74: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //    77: iload           4
        //    79: isub           
        //    80: invokestatic    java/lang/Math.max:(II)I
        //    83: istore          5
        //    85: aload_0        
        //    86: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //    89: invokevirtual   androidx/viewpager/widget/PagerAdapter.getCount:()I
        //    92: istore          6
        //    94: iload           6
        //    96: iconst_1       
        //    97: isub           
        //    98: iload           4
        //   100: aload_0        
        //   101: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   104: iadd           
        //   105: invokestatic    java/lang/Math.min:(II)I
        //   108: istore          7
        //   110: iload           6
        //   112: aload_0        
        //   113: getfield        androidx/viewpager/widget/ViewPager.mExpectedAdapterCount:I
        //   116: if_icmpne       1045
        //   119: iconst_0       
        //   120: istore          21
        //   122: iload           21
        //   124: aload_0        
        //   125: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   128: invokevirtual   java/util/ArrayList.size:()I
        //   131: if_icmpge       181
        //   134: aload_0        
        //   135: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   138: iload           21
        //   140: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   143: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   146: astore          22
        //   148: aload           22
        //   150: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   153: aload_0        
        //   154: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   157: if_icmplt       175
        //   160: aload           22
        //   162: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   165: aload_0        
        //   166: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   169: if_icmpne       181
        //   172: goto            184
        //   175: iinc            21, 1
        //   178: goto            122
        //   181: aconst_null    
        //   182: astore          22
        //   184: aload           22
        //   186: ifnonnull       206
        //   189: iload           6
        //   191: ifle            206
        //   194: aload_0        
        //   195: aload_0        
        //   196: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   199: iload           21
        //   201: invokevirtual   androidx/viewpager/widget/ViewPager.addNewItem:(II)Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   204: astore          22
        //   206: aload           22
        //   208: ifnull          822
        //   211: iload           21
        //   213: iconst_1       
        //   214: isub           
        //   215: istore          33
        //   217: iload           33
        //   219: iflt            239
        //   222: aload_0        
        //   223: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   226: iload           33
        //   228: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   231: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   234: astore          34
        //   236: goto            242
        //   239: aconst_null    
        //   240: astore          34
        //   242: aload_0        
        //   243: invokespecial   androidx/viewpager/widget/ViewPager.getClientWidth:()I
        //   246: istore          35
        //   248: iload           35
        //   250: ifgt            259
        //   253: fconst_0       
        //   254: fstore          36
        //   256: goto            278
        //   259: fconst_2       
        //   260: aload           22
        //   262: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.widthFactor:F
        //   265: fsub           
        //   266: aload_0        
        //   267: invokevirtual   androidx/viewpager/widget/ViewPager.getPaddingLeft:()I
        //   270: i2f            
        //   271: iload           35
        //   273: i2f            
        //   274: fdiv           
        //   275: fadd           
        //   276: fstore          36
        //   278: iconst_m1      
        //   279: aload_0        
        //   280: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   283: iadd           
        //   284: istore          37
        //   286: fconst_0       
        //   287: fstore          38
        //   289: iload           37
        //   291: iflt            494
        //   294: fload           38
        //   296: fload           36
        //   298: fcmpl          
        //   299: iflt            388
        //   302: iload           37
        //   304: iload           5
        //   306: if_icmpge       388
        //   309: aload           34
        //   311: ifnonnull       317
        //   314: goto            494
        //   317: iload           37
        //   319: aload           34
        //   321: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   324: if_icmpne       488
        //   327: aload           34
        //   329: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.scrolling:Z
        //   332: ifne            488
        //   335: aload_0        
        //   336: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   339: iload           33
        //   341: invokevirtual   java/util/ArrayList.remove:(I)Ljava/lang/Object;
        //   344: pop            
        //   345: aload_0        
        //   346: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //   349: aload_0        
        //   350: iload           37
        //   352: aload           34
        //   354: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.object:Ljava/lang/Object;
        //   357: invokevirtual   androidx/viewpager/widget/PagerAdapter.destroyItem:(Landroid/view/ViewGroup;ILjava/lang/Object;)V
        //   360: iinc            33, -1
        //   363: iinc            21, -1
        //   366: iload           33
        //   368: iflt            481
        //   371: aload_0        
        //   372: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   375: iload           33
        //   377: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   380: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   383: astore          46
        //   385: goto            484
        //   388: aload           34
        //   390: ifnull          438
        //   393: iload           37
        //   395: aload           34
        //   397: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   400: if_icmpne       438
        //   403: fload           38
        //   405: aload           34
        //   407: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.widthFactor:F
        //   410: fadd           
        //   411: fstore          38
        //   413: iinc            33, -1
        //   416: iload           33
        //   418: iflt            481
        //   421: aload_0        
        //   422: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   425: iload           33
        //   427: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   430: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   433: astore          46
        //   435: goto            484
        //   438: fload           38
        //   440: aload_0        
        //   441: iload           37
        //   443: iload           33
        //   445: iconst_1       
        //   446: iadd           
        //   447: invokevirtual   androidx/viewpager/widget/ViewPager.addNewItem:(II)Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   450: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.widthFactor:F
        //   453: fadd           
        //   454: fstore          38
        //   456: iinc            21, 1
        //   459: iload           33
        //   461: iflt            481
        //   464: aload_0        
        //   465: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   468: iload           33
        //   470: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   473: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   476: astore          46
        //   478: goto            484
        //   481: aconst_null    
        //   482: astore          46
        //   484: aload           46
        //   486: astore          34
        //   488: iinc            37, -1
        //   491: goto            289
        //   494: aload           22
        //   496: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.widthFactor:F
        //   499: fstore          39
        //   501: iload           21
        //   503: iconst_1       
        //   504: iadd           
        //   505: istore          40
        //   507: fload           39
        //   509: fconst_2       
        //   510: fcmpg          
        //   511: ifge            796
        //   514: iload           40
        //   516: aload_0        
        //   517: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   520: invokevirtual   java/util/ArrayList.size:()I
        //   523: if_icmpge       543
        //   526: aload_0        
        //   527: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   530: iload           40
        //   532: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   535: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   538: astore          41
        //   540: goto            546
        //   543: aconst_null    
        //   544: astore          41
        //   546: iload           35
        //   548: ifgt            557
        //   551: fconst_0       
        //   552: fstore          42
        //   554: goto            570
        //   557: fconst_2       
        //   558: aload_0        
        //   559: invokevirtual   androidx/viewpager/widget/ViewPager.getPaddingRight:()I
        //   562: i2f            
        //   563: iload           35
        //   565: i2f            
        //   566: fdiv           
        //   567: fadd           
        //   568: fstore          42
        //   570: aload_0        
        //   571: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   574: istore          43
        //   576: iinc            43, 1
        //   579: iload           43
        //   581: iload           6
        //   583: if_icmpge       796
        //   586: fload           39
        //   588: fload           42
        //   590: fcmpl          
        //   591: iflt            687
        //   594: iload           43
        //   596: iload           7
        //   598: if_icmple       687
        //   601: aload           41
        //   603: ifnonnull       609
        //   606: goto            796
        //   609: iload           43
        //   611: aload           41
        //   613: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   616: if_icmpne       793
        //   619: aload           41
        //   621: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.scrolling:Z
        //   624: ifne            793
        //   627: aload_0        
        //   628: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   631: iload           40
        //   633: invokevirtual   java/util/ArrayList.remove:(I)Ljava/lang/Object;
        //   636: pop            
        //   637: aload_0        
        //   638: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //   641: aload_0        
        //   642: iload           43
        //   644: aload           41
        //   646: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.object:Ljava/lang/Object;
        //   649: invokevirtual   androidx/viewpager/widget/PagerAdapter.destroyItem:(Landroid/view/ViewGroup;ILjava/lang/Object;)V
        //   652: iload           40
        //   654: aload_0        
        //   655: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   658: invokevirtual   java/util/ArrayList.size:()I
        //   661: if_icmpge       681
        //   664: aload_0        
        //   665: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   668: iload           40
        //   670: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   673: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   676: astore          41
        //   678: goto            793
        //   681: aconst_null    
        //   682: astore          41
        //   684: goto            793
        //   687: aload           41
        //   689: ifnull          744
        //   692: iload           43
        //   694: aload           41
        //   696: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   699: if_icmpne       744
        //   702: fload           39
        //   704: aload           41
        //   706: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.widthFactor:F
        //   709: fadd           
        //   710: fstore          39
        //   712: iinc            40, 1
        //   715: iload           40
        //   717: aload_0        
        //   718: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   721: invokevirtual   java/util/ArrayList.size:()I
        //   724: if_icmpge       681
        //   727: aload_0        
        //   728: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   731: iload           40
        //   733: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   736: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   739: astore          41
        //   741: goto            793
        //   744: aload_0        
        //   745: iload           43
        //   747: iload           40
        //   749: invokevirtual   androidx/viewpager/widget/ViewPager.addNewItem:(II)Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   752: astore          44
        //   754: iinc            40, 1
        //   757: fload           39
        //   759: aload           44
        //   761: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.widthFactor:F
        //   764: fadd           
        //   765: fstore          39
        //   767: iload           40
        //   769: aload_0        
        //   770: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   773: invokevirtual   java/util/ArrayList.size:()I
        //   776: if_icmpge       681
        //   779: aload_0        
        //   780: getfield        androidx/viewpager/widget/ViewPager.mItems:Ljava/util/ArrayList;
        //   783: iload           40
        //   785: invokevirtual   java/util/ArrayList.get:(I)Ljava/lang/Object;
        //   788: checkcast       Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   791: astore          41
        //   793: goto            576
        //   796: aload_0        
        //   797: aload           22
        //   799: iload           21
        //   801: aload_3        
        //   802: invokespecial   androidx/viewpager/widget/ViewPager.calculatePageOffsets:(Landroidx/viewpager/widget/ViewPager$ItemInfo;ILandroidx/viewpager/widget/ViewPager$ItemInfo;)V
        //   805: aload_0        
        //   806: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //   809: aload_0        
        //   810: aload_0        
        //   811: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   814: aload           22
        //   816: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.object:Ljava/lang/Object;
        //   819: invokevirtual   androidx/viewpager/widget/PagerAdapter.setPrimaryItem:(Landroid/view/ViewGroup;ILjava/lang/Object;)V
        //   822: aload_0        
        //   823: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //   826: aload_0        
        //   827: invokevirtual   androidx/viewpager/widget/PagerAdapter.finishUpdate:(Landroid/view/ViewGroup;)V
        //   830: aload_0        
        //   831: invokevirtual   androidx/viewpager/widget/ViewPager.getChildCount:()I
        //   834: istore          23
        //   836: iconst_0       
        //   837: istore          24
        //   839: iload           24
        //   841: iload           23
        //   843: if_icmpge       928
        //   846: aload_0        
        //   847: iload           24
        //   849: invokevirtual   androidx/viewpager/widget/ViewPager.getChildAt:(I)Landroid/view/View;
        //   852: astore          30
        //   854: aload           30
        //   856: invokevirtual   android/view/View.getLayoutParams:()Landroid/view/ViewGroup$LayoutParams;
        //   859: checkcast       Landroidx/viewpager/widget/ViewPager$LayoutParams;
        //   862: astore          31
        //   864: aload           31
        //   866: iload           24
        //   868: putfield        androidx/viewpager/widget/ViewPager$LayoutParams.childIndex:I
        //   871: aload           31
        //   873: getfield        androidx/viewpager/widget/ViewPager$LayoutParams.isDecor:Z
        //   876: ifne            922
        //   879: aload           31
        //   881: getfield        androidx/viewpager/widget/ViewPager$LayoutParams.widthFactor:F
        //   884: fconst_0       
        //   885: fcmpl          
        //   886: ifne            922
        //   889: aload_0        
        //   890: aload           30
        //   892: invokevirtual   androidx/viewpager/widget/ViewPager.infoForChild:(Landroid/view/View;)Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   895: astore          32
        //   897: aload           32
        //   899: ifnull          922
        //   902: aload           31
        //   904: aload           32
        //   906: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.widthFactor:F
        //   909: putfield        androidx/viewpager/widget/ViewPager$LayoutParams.widthFactor:F
        //   912: aload           31
        //   914: aload           32
        //   916: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   919: putfield        androidx/viewpager/widget/ViewPager$LayoutParams.position:I
        //   922: iinc            24, 1
        //   925: goto            839
        //   928: aload_0        
        //   929: invokespecial   androidx/viewpager/widget/ViewPager.sortChildDrawingOrder:()V
        //   932: aload_0        
        //   933: invokevirtual   androidx/viewpager/widget/ViewPager.hasFocus:()Z
        //   936: ifeq            1044
        //   939: aload_0        
        //   940: invokevirtual   androidx/viewpager/widget/ViewPager.findFocus:()Landroid/view/View;
        //   943: astore          25
        //   945: aload           25
        //   947: ifnull          961
        //   950: aload_0        
        //   951: aload           25
        //   953: invokevirtual   androidx/viewpager/widget/ViewPager.infoForAnyChild:(Landroid/view/View;)Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //   956: astore          26
        //   958: goto            964
        //   961: aconst_null    
        //   962: astore          26
        //   964: aload           26
        //   966: ifnull          981
        //   969: aload           26
        //   971: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //   974: aload_0        
        //   975: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //   978: if_icmpeq       1044
        //   981: iconst_0       
        //   982: istore          27
        //   984: iload           27
        //   986: aload_0        
        //   987: invokevirtual   androidx/viewpager/widget/ViewPager.getChildCount:()I
        //   990: if_icmpge       1044
        //   993: aload_0        
        //   994: iload           27
        //   996: invokevirtual   androidx/viewpager/widget/ViewPager.getChildAt:(I)Landroid/view/View;
        //   999: astore          28
        //  1001: aload_0        
        //  1002: aload           28
        //  1004: invokevirtual   androidx/viewpager/widget/ViewPager.infoForChild:(Landroid/view/View;)Landroidx/viewpager/widget/ViewPager$ItemInfo;
        //  1007: astore          29
        //  1009: aload           29
        //  1011: ifnull          1038
        //  1014: aload           29
        //  1016: getfield        androidx/viewpager/widget/ViewPager$ItemInfo.position:I
        //  1019: aload_0        
        //  1020: getfield        androidx/viewpager/widget/ViewPager.mCurItem:I
        //  1023: if_icmpne       1038
        //  1026: aload           28
        //  1028: iconst_2       
        //  1029: invokevirtual   android/view/View.requestFocus:(I)Z
        //  1032: ifeq            1038
        //  1035: goto            1044
        //  1038: iinc            27, 1
        //  1041: goto            984
        //  1044: return         
        //  1045: aload_0        
        //  1046: invokevirtual   androidx/viewpager/widget/ViewPager.getResources:()Landroid/content/res/Resources;
        //  1049: aload_0        
        //  1050: invokevirtual   androidx/viewpager/widget/ViewPager.getId:()I
        //  1053: invokevirtual   android/content/res/Resources.getResourceName:(I)Ljava/lang/String;
        //  1056: astore          8
        //  1058: goto            1070
        //  1061: aload_0        
        //  1062: invokevirtual   androidx/viewpager/widget/ViewPager.getId:()I
        //  1065: invokestatic    java/lang/Integer.toHexString:(I)Ljava/lang/String;
        //  1068: astore          8
        //  1070: new             Ljava/lang/StringBuilder;
        //  1073: dup            
        //  1074: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1077: astore          9
        //  1079: aload           9
        //  1081: ldc_w           "The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: "
        //  1084: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1087: pop            
        //  1088: aload           9
        //  1090: aload_0        
        //  1091: getfield        androidx/viewpager/widget/ViewPager.mExpectedAdapterCount:I
        //  1094: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //  1097: pop            
        //  1098: aload           9
        //  1100: ldc_w           ", found: "
        //  1103: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1106: pop            
        //  1107: aload           9
        //  1109: iload           6
        //  1111: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //  1114: pop            
        //  1115: aload           9
        //  1117: ldc_w           " Pager id: "
        //  1120: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1123: pop            
        //  1124: aload           9
        //  1126: aload           8
        //  1128: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1131: pop            
        //  1132: aload           9
        //  1134: ldc_w           " Pager class: "
        //  1137: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1140: pop            
        //  1141: aload           9
        //  1143: aload_0        
        //  1144: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //  1147: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1150: pop            
        //  1151: aload           9
        //  1153: ldc_w           " Problematic adapter: "
        //  1156: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1159: pop            
        //  1160: aload           9
        //  1162: aload_0        
        //  1163: getfield        androidx/viewpager/widget/ViewPager.mAdapter:Landroidx/viewpager/widget/PagerAdapter;
        //  1166: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //  1169: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1172: pop            
        //  1173: new             Ljava/lang/IllegalStateException;
        //  1176: dup            
        //  1177: aload           9
        //  1179: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1182: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //  1185: astore          20
        //  1187: goto            1193
        //  1190: aload           20
        //  1192: athrow         
        //  1193: goto            1190
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                             
        //  -----  -----  -----  -----  -------------------------------------------------
        //  1045   1058   1061   1070   Landroid/content/res/Resources$NotFoundException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #1070 (coming from #1068).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void removeOnAdapterChangeListener(final OnAdapterChangeListener onAdapterChangeListener) {
        final List<OnAdapterChangeListener> mAdapterChangeListeners = this.mAdapterChangeListeners;
        if (mAdapterChangeListeners != null) {
            mAdapterChangeListeners.remove(onAdapterChangeListener);
        }
    }
    
    public void removeOnPageChangeListener(final OnPageChangeListener onPageChangeListener) {
        final List<OnPageChangeListener> mOnPageChangeListeners = this.mOnPageChangeListeners;
        if (mOnPageChangeListeners != null) {
            mOnPageChangeListeners.remove(onPageChangeListener);
        }
    }
    
    public void removeView(final View view) {
        if (this.mInLayout) {
            this.removeViewInLayout(view);
        }
        else {
            super.removeView(view);
        }
    }
    
    public void setAdapter(final PagerAdapter mAdapter) {
        final PagerAdapter mAdapter2 = this.mAdapter;
        int i = 0;
        if (mAdapter2 != null) {
            mAdapter2.setViewPagerObserver(null);
            this.mAdapter.startUpdate(this);
            for (int j = 0; j < this.mItems.size(); ++j) {
                final ItemInfo itemInfo = this.mItems.get(j);
                this.mAdapter.destroyItem(this, itemInfo.position, itemInfo.object);
            }
            this.mAdapter.finishUpdate(this);
            this.mItems.clear();
            this.removeNonDecorViews();
            this.scrollTo(this.mCurItem = 0, 0);
        }
        final PagerAdapter mAdapter3 = this.mAdapter;
        this.mAdapter = mAdapter;
        this.mExpectedAdapterCount = 0;
        if (mAdapter != null) {
            if (this.mObserver == null) {
                this.mObserver = new PagerObserver();
            }
            this.mAdapter.setViewPagerObserver(this.mObserver);
            this.mPopulatePending = false;
            final boolean mFirstLayout = this.mFirstLayout;
            this.mFirstLayout = true;
            this.mExpectedAdapterCount = this.mAdapter.getCount();
            if (this.mRestoredCurItem >= 0) {
                this.mAdapter.restoreState(this.mRestoredAdapterState, this.mRestoredClassLoader);
                this.setCurrentItemInternal(this.mRestoredCurItem, false, true);
                this.mRestoredCurItem = -1;
                this.mRestoredAdapterState = null;
                this.mRestoredClassLoader = null;
            }
            else if (!mFirstLayout) {
                this.populate();
            }
            else {
                this.requestLayout();
            }
        }
        final List<OnAdapterChangeListener> mAdapterChangeListeners = this.mAdapterChangeListeners;
        if (mAdapterChangeListeners != null && !mAdapterChangeListeners.isEmpty()) {
            while (i < this.mAdapterChangeListeners.size()) {
                this.mAdapterChangeListeners.get(i).onAdapterChanged(this, mAdapter3, mAdapter);
                ++i;
            }
        }
    }
    
    public void setCurrentItem(final int n) {
        this.mPopulatePending = false;
        this.setCurrentItemInternal(n, true ^ this.mFirstLayout, false);
    }
    
    public void setCurrentItem(final int n, final boolean b) {
        this.setCurrentItemInternal(n, b, this.mPopulatePending = false);
    }
    
    void setCurrentItemInternal(final int n, final boolean b, final boolean b2) {
        this.setCurrentItemInternal(n, b, b2, 0);
    }
    
    void setCurrentItemInternal(int mCurItem, final boolean b, final boolean b2, final int n) {
        final PagerAdapter mAdapter = this.mAdapter;
        if (mAdapter == null || mAdapter.getCount() <= 0) {
            this.setScrollingCacheEnabled(false);
            return;
        }
        if (!b2 && this.mCurItem == mCurItem && this.mItems.size() != 0) {
            this.setScrollingCacheEnabled(false);
            return;
        }
        if (mCurItem < 0) {
            mCurItem = 0;
        }
        else if (mCurItem >= this.mAdapter.getCount()) {
            mCurItem = this.mAdapter.getCount() - 1;
        }
        final int mOffscreenPageLimit = this.mOffscreenPageLimit;
        final int mCurItem2 = this.mCurItem;
        if (mCurItem > mCurItem2 + mOffscreenPageLimit || mCurItem < mCurItem2 - mOffscreenPageLimit) {
            for (int i = 0; i < this.mItems.size(); ++i) {
                this.mItems.get(i).scrolling = true;
            }
        }
        final int mCurItem3 = this.mCurItem;
        boolean b3 = false;
        if (mCurItem3 != mCurItem) {
            b3 = true;
        }
        if (this.mFirstLayout) {
            this.mCurItem = mCurItem;
            if (b3) {
                this.dispatchOnPageSelected(mCurItem);
            }
            this.requestLayout();
        }
        else {
            this.populate(mCurItem);
            this.scrollToItem(mCurItem, b, n, b3);
        }
    }
    
    OnPageChangeListener setInternalPageChangeListener(final OnPageChangeListener mInternalPageChangeListener) {
        final OnPageChangeListener mInternalPageChangeListener2 = this.mInternalPageChangeListener;
        this.mInternalPageChangeListener = mInternalPageChangeListener;
        return mInternalPageChangeListener2;
    }
    
    public void setOffscreenPageLimit(int n) {
        if (n < 1) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Requested offscreen page limit ");
            sb.append(n);
            sb.append(" too small; defaulting to ");
            sb.append(1);
            Log.w("ViewPager", sb.toString());
            n = 1;
        }
        if (n != this.mOffscreenPageLimit) {
            this.mOffscreenPageLimit = n;
            this.populate();
        }
    }
    
    @Deprecated
    public void setOnPageChangeListener(final OnPageChangeListener mOnPageChangeListener) {
        this.mOnPageChangeListener = mOnPageChangeListener;
    }
    
    public void setPageMargin(final int mPageMargin) {
        final int mPageMargin2 = this.mPageMargin;
        this.mPageMargin = mPageMargin;
        final int width = this.getWidth();
        this.recomputeScrollPosition(width, width, mPageMargin, mPageMargin2);
        this.requestLayout();
    }
    
    public void setPageMarginDrawable(final int n) {
        this.setPageMarginDrawable(ContextCompat.getDrawable(this.getContext(), n));
    }
    
    public void setPageMarginDrawable(final Drawable mMarginDrawable) {
        this.mMarginDrawable = mMarginDrawable;
        if (mMarginDrawable != null) {
            this.refreshDrawableState();
        }
        this.setWillNotDraw(mMarginDrawable == null);
        this.invalidate();
    }
    
    public void setPageTransformer(final boolean b, final PageTransformer pageTransformer) {
        this.setPageTransformer(b, pageTransformer, 2);
    }
    
    public void setPageTransformer(final boolean b, final PageTransformer mPageTransformer, final int mPageTransformerLayerType) {
        int mDrawingOrder = 1;
        final boolean childrenDrawingOrderEnabled = mPageTransformer != null;
        final boolean b2 = childrenDrawingOrderEnabled != (this.mPageTransformer != null);
        this.mPageTransformer = mPageTransformer;
        this.setChildrenDrawingOrderEnabled(childrenDrawingOrderEnabled);
        if (childrenDrawingOrderEnabled) {
            if (b) {
                mDrawingOrder = 2;
            }
            this.mDrawingOrder = mDrawingOrder;
            this.mPageTransformerLayerType = mPageTransformerLayerType;
        }
        else {
            this.mDrawingOrder = 0;
        }
        if (b2) {
            this.populate();
        }
    }
    
    void setScrollState(final int mScrollState) {
        if (this.mScrollState == mScrollState) {
            return;
        }
        this.mScrollState = mScrollState;
        if (this.mPageTransformer != null) {
            this.enableLayers(mScrollState != 0);
        }
        this.dispatchOnScrollStateChanged(mScrollState);
    }
    
    void smoothScrollTo(final int n, final int n2) {
        this.smoothScrollTo(n, n2, 0);
    }
    
    void smoothScrollTo(final int n, final int n2, final int a) {
        if (this.getChildCount() == 0) {
            this.setScrollingCacheEnabled(false);
            return;
        }
        final Scroller mScroller = this.mScroller;
        int n3;
        if (mScroller != null && !mScroller.isFinished()) {
            if (this.mIsScrollStarted) {
                n3 = this.mScroller.getCurrX();
            }
            else {
                n3 = this.mScroller.getStartX();
            }
            this.mScroller.abortAnimation();
            this.setScrollingCacheEnabled(false);
        }
        else {
            n3 = this.getScrollX();
        }
        final int n4 = n3;
        final int scrollY = this.getScrollY();
        final int n5 = n - n4;
        final int n6 = n2 - scrollY;
        if (n5 == 0 && n6 == 0) {
            this.completeScroll(false);
            this.populate();
            this.setScrollState(0);
            return;
        }
        this.setScrollingCacheEnabled(true);
        this.setScrollState(2);
        final int clientWidth = this.getClientWidth();
        final int n7 = clientWidth / 2;
        final float n8 = 1.0f * Math.abs(n5);
        final float n9 = (float)clientWidth;
        final float min = Math.min(1.0f, n8 / n9);
        final float n10 = (float)n7;
        final float n11 = n10 + n10 * this.distanceInfluenceForSnapDuration(min);
        final int abs = Math.abs(a);
        int a2;
        if (abs > 0) {
            a2 = 4 * Math.round(1000.0f * Math.abs(n11 / abs));
        }
        else {
            a2 = (int)(100.0f * (1.0f + Math.abs(n5) / (n9 * this.mAdapter.getPageWidth(this.mCurItem) + this.mPageMargin)));
        }
        final int min2 = Math.min(a2, 600);
        this.mIsScrollStarted = false;
        this.mScroller.startScroll(n4, scrollY, n5, n6, min2);
        ViewCompat.postInvalidateOnAnimation((View)this);
    }
    
    protected boolean verifyDrawable(final Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.mMarginDrawable;
    }
    
    @Inherited
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ ElementType.TYPE })
    public @interface DecorView {
    }
    
    static class ItemInfo
    {
        Object object;
        float offset;
        int position;
        boolean scrolling;
        float widthFactor;
    }
    
    public static class LayoutParams extends ViewGroup$LayoutParams
    {
        int childIndex;
        public int gravity;
        public boolean isDecor;
        boolean needsMeasure;
        int position;
        float widthFactor;
        
        public LayoutParams() {
            super(-1, -1);
            this.widthFactor = 0.0f;
        }
        
        public LayoutParams(final Context context, final AttributeSet set) {
            super(context, set);
            this.widthFactor = 0.0f;
            final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, ViewPager.LAYOUT_ATTRS);
            this.gravity = obtainStyledAttributes.getInteger(0, 48);
            obtainStyledAttributes.recycle();
        }
    }
    
    class MyAccessibilityDelegate extends AccessibilityDelegateCompat
    {
        private boolean canScroll() {
            final PagerAdapter mAdapter = ViewPager.this.mAdapter;
            int n = 1;
            if (mAdapter == null || ViewPager.this.mAdapter.getCount() <= n) {
                n = 0;
            }
            return n != 0;
        }
        
        @Override
        public void onInitializeAccessibilityEvent(final View view, final AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName((CharSequence)ViewPager.class.getName());
            accessibilityEvent.setScrollable(this.canScroll());
            if (accessibilityEvent.getEventType() == 4096 && ViewPager.this.mAdapter != null) {
                accessibilityEvent.setItemCount(ViewPager.this.mAdapter.getCount());
                accessibilityEvent.setFromIndex(ViewPager.this.mCurItem);
                accessibilityEvent.setToIndex(ViewPager.this.mCurItem);
            }
        }
        
        @Override
        public void onInitializeAccessibilityNodeInfo(final View view, final AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat);
            accessibilityNodeInfoCompat.setClassName(ViewPager.class.getName());
            accessibilityNodeInfoCompat.setScrollable(this.canScroll());
            if (ViewPager.this.canScrollHorizontally(1)) {
                accessibilityNodeInfoCompat.addAction(4096);
            }
            if (ViewPager.this.canScrollHorizontally(-1)) {
                accessibilityNodeInfoCompat.addAction(8192);
            }
        }
        
        @Override
        public boolean performAccessibilityAction(final View view, final int n, final Bundle bundle) {
            if (super.performAccessibilityAction(view, n, bundle)) {
                return true;
            }
            if (n != 4096) {
                if (n != 8192) {
                    return false;
                }
                if (ViewPager.this.canScrollHorizontally(-1)) {
                    final ViewPager this$0 = ViewPager.this;
                    this$0.setCurrentItem(this$0.mCurItem - 1);
                    return true;
                }
                return false;
            }
            else {
                if (ViewPager.this.canScrollHorizontally(1)) {
                    final ViewPager this$2 = ViewPager.this;
                    this$2.setCurrentItem(1 + this$2.mCurItem);
                    return true;
                }
                return false;
            }
        }
    }
    
    public interface OnAdapterChangeListener
    {
        void onAdapterChanged(final ViewPager p0, final PagerAdapter p1, final PagerAdapter p2);
    }
    
    public interface OnPageChangeListener
    {
        void onPageScrollStateChanged(final int p0);
        
        void onPageScrolled(final int p0, final float p1, final int p2);
        
        void onPageSelected(final int p0);
    }
    
    public interface PageTransformer
    {
        void transformPage(final View p0, final float p1);
    }
    
    private class PagerObserver extends DataSetObserver
    {
        PagerObserver() {
        }
        
        public void onChanged() {
            ViewPager.this.dataSetChanged();
        }
        
        public void onInvalidated() {
            ViewPager.this.dataSetChanged();
        }
    }
    
    public static class SavedState extends AbsSavedState
    {
        public static final Parcelable$Creator<SavedState> CREATOR;
        Parcelable adapterState;
        ClassLoader loader;
        int position;
        
        static {
            CREATOR = (Parcelable$Creator)new Parcelable$ClassLoaderCreator<SavedState>() {
                public SavedState createFromParcel(final Parcel parcel) {
                    return new SavedState(parcel, null);
                }
                
                public SavedState createFromParcel(final Parcel parcel, final ClassLoader classLoader) {
                    return new SavedState(parcel, classLoader);
                }
                
                public SavedState[] newArray(final int n) {
                    return new SavedState[n];
                }
            };
        }
        
        SavedState(final Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            if (classLoader == null) {
                classLoader = this.getClass().getClassLoader();
            }
            this.position = parcel.readInt();
            this.adapterState = parcel.readParcelable(classLoader);
            this.loader = classLoader;
        }
        
        public SavedState(final Parcelable parcelable) {
            super(parcelable);
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append("FragmentPager.SavedState{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" position=");
            sb.append(this.position);
            sb.append("}");
            return sb.toString();
        }
        
        @Override
        public void writeToParcel(final Parcel parcel, final int n) {
            super.writeToParcel(parcel, n);
            parcel.writeInt(this.position);
            parcel.writeParcelable(this.adapterState, n);
        }
    }
    
    public static class SimpleOnPageChangeListener implements OnPageChangeListener
    {
        @Override
        public void onPageScrollStateChanged(final int n) {
        }
        
        @Override
        public void onPageScrolled(final int n, final float n2, final int n3) {
        }
        
        @Override
        public void onPageSelected(final int n) {
        }
    }
    
    static class ViewPositionComparator implements Comparator<View>
    {
        @Override
        public int compare(final View view, final View view2) {
            final LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            final LayoutParams layoutParams2 = (LayoutParams)view2.getLayoutParams();
            if (layoutParams.isDecor != layoutParams2.isDecor) {
                int n;
                if (layoutParams.isDecor) {
                    n = 1;
                }
                else {
                    n = -1;
                }
                return n;
            }
            return layoutParams.position - layoutParams2.position;
        }
    }
}
