// 
// Decompiled by Procyon v0.5.36
// 

package androidx.collection;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Collection;

public final class ArraySet<E> implements Collection<E>, Set<E>
{
    private static final int BASE_SIZE = 4;
    private static final int CACHE_SIZE = 10;
    private static final boolean DEBUG = false;
    private static final int[] INT;
    private static final Object[] OBJECT;
    private static final String TAG = "ArraySet";
    private static Object[] sBaseCache;
    private static int sBaseCacheSize;
    private static Object[] sTwiceBaseCache;
    private static int sTwiceBaseCacheSize;
    Object[] mArray;
    private MapCollections<E, E> mCollections;
    private int[] mHashes;
    int mSize;
    
    static {
        INT = new int[0];
        OBJECT = new Object[0];
    }
    
    public ArraySet() {
        this(0);
    }
    
    public ArraySet(final int n) {
        if (n == 0) {
            this.mHashes = ArraySet.INT;
            this.mArray = ArraySet.OBJECT;
        }
        else {
            this.allocArrays(n);
        }
        this.mSize = 0;
    }
    
    public ArraySet(final ArraySet<E> set) {
        this();
        if (set != null) {
            this.addAll((ArraySet<? extends E>)set);
        }
    }
    
    public ArraySet(final Collection<E> collection) {
        this();
        if (collection != null) {
            this.addAll((Collection<? extends E>)collection);
        }
    }
    
    private void allocArrays(final int n) {
        Label_0166: {
            if (n == 8) {
                synchronized (ArraySet.class) {
                    final Object[] sTwiceBaseCache = ArraySet.sTwiceBaseCache;
                    if (sTwiceBaseCache != null) {
                        this.mArray = sTwiceBaseCache;
                        ArraySet.sTwiceBaseCache = (Object[])sTwiceBaseCache[0];
                        this.mHashes = (int[])sTwiceBaseCache[1];
                        sTwiceBaseCache[0] = (sTwiceBaseCache[1] = null);
                        --ArraySet.sTwiceBaseCacheSize;
                        return;
                    }
                    break Label_0166;
                }
            }
            if (n == 4) {
                synchronized (ArraySet.class) {
                    final Object[] sBaseCache = ArraySet.sBaseCache;
                    if (sBaseCache != null) {
                        this.mArray = sBaseCache;
                        ArraySet.sBaseCache = (Object[])sBaseCache[0];
                        this.mHashes = (int[])sBaseCache[1];
                        sBaseCache[0] = (sBaseCache[1] = null);
                        --ArraySet.sBaseCacheSize;
                        return;
                    }
                }
            }
        }
        this.mHashes = new int[n];
        this.mArray = new Object[n];
    }
    
    private static void freeArrays(final int[] array, final Object[] array2, final int n) {
        if (array.length == 8) {
            synchronized (ArraySet.class) {
                if (ArraySet.sTwiceBaseCacheSize < 10) {
                    array2[0] = ArraySet.sTwiceBaseCache;
                    array2[1] = array;
                    for (int i = n - 1; i >= 2; --i) {
                        array2[i] = null;
                    }
                    ArraySet.sTwiceBaseCache = array2;
                    ++ArraySet.sTwiceBaseCacheSize;
                }
                return;
            }
        }
        if (array.length == 4) {
            synchronized (ArraySet.class) {
                if (ArraySet.sBaseCacheSize < 10) {
                    array2[0] = ArraySet.sBaseCache;
                    array2[1] = array;
                    for (int j = n - 1; j >= 2; --j) {
                        array2[j] = null;
                    }
                    ArraySet.sBaseCache = array2;
                    ++ArraySet.sBaseCacheSize;
                }
            }
        }
    }
    
    private MapCollections<E, E> getCollection() {
        if (this.mCollections == null) {
            this.mCollections = new MapCollections<E, E>() {
                @Override
                protected void colClear() {
                    ArraySet.this.clear();
                }
                
                @Override
                protected Object colGetEntry(final int n, final int n2) {
                    return ArraySet.this.mArray[n];
                }
                
                @Override
                protected Map<E, E> colGetMap() {
                    throw new UnsupportedOperationException("not a map");
                }
                
                @Override
                protected int colGetSize() {
                    return ArraySet.this.mSize;
                }
                
                @Override
                protected int colIndexOfKey(final Object o) {
                    return ArraySet.this.indexOf(o);
                }
                
                @Override
                protected int colIndexOfValue(final Object o) {
                    return ArraySet.this.indexOf(o);
                }
                
                @Override
                protected void colPut(final E e, final E e2) {
                    ArraySet.this.add(e);
                }
                
                @Override
                protected void colRemoveAt(final int n) {
                    ArraySet.this.removeAt(n);
                }
                
                @Override
                protected E colSetValue(final int n, final E e) {
                    throw new UnsupportedOperationException("not a map");
                }
            };
        }
        return this.mCollections;
    }
    
    private int indexOf(final Object o, final int n) {
        final int mSize = this.mSize;
        if (mSize == 0) {
            return -1;
        }
        final int binarySearch = ContainerHelpers.binarySearch(this.mHashes, mSize, n);
        if (binarySearch < 0) {
            return binarySearch;
        }
        if (o.equals(this.mArray[binarySearch])) {
            return binarySearch;
        }
        int n2;
        for (n2 = binarySearch + 1; n2 < mSize && this.mHashes[n2] == n; ++n2) {
            if (o.equals(this.mArray[n2])) {
                return n2;
            }
        }
        for (int n3 = binarySearch - 1; n3 >= 0 && this.mHashes[n3] == n; --n3) {
            if (o.equals(this.mArray[n3])) {
                return n3;
            }
        }
        return ~n2;
    }
    
    private int indexOfNull() {
        final int mSize = this.mSize;
        if (mSize == 0) {
            return -1;
        }
        final int binarySearch = ContainerHelpers.binarySearch(this.mHashes, mSize, 0);
        if (binarySearch < 0) {
            return binarySearch;
        }
        if (this.mArray[binarySearch] == null) {
            return binarySearch;
        }
        int n;
        for (n = binarySearch + 1; n < mSize && this.mHashes[n] == 0; ++n) {
            if (this.mArray[n] == null) {
                return n;
            }
        }
        for (int n2 = binarySearch - 1; n2 >= 0 && this.mHashes[n2] == 0; --n2) {
            if (this.mArray[n2] == null) {
                return n2;
            }
        }
        return ~n;
    }
    
    @Override
    public boolean add(final E e) {
        int indexOfNull;
        int n;
        if (e == null) {
            indexOfNull = this.indexOfNull();
            n = 0;
        }
        else {
            final int hashCode = e.hashCode();
            final int index = this.indexOf(e, hashCode);
            n = hashCode;
            indexOfNull = index;
        }
        if (indexOfNull >= 0) {
            return false;
        }
        final int n2 = ~indexOfNull;
        final int mSize = this.mSize;
        final int[] mHashes = this.mHashes;
        if (mSize >= mHashes.length) {
            int n3 = 4;
            if (mSize >= 8) {
                n3 = mSize + (mSize >> 1);
            }
            else if (mSize >= n3) {
                n3 = 8;
            }
            final Object[] mArray = this.mArray;
            this.allocArrays(n3);
            final int[] mHashes2 = this.mHashes;
            if (mHashes2.length > 0) {
                System.arraycopy(mHashes, 0, mHashes2, 0, mHashes.length);
                System.arraycopy(mArray, 0, this.mArray, 0, mArray.length);
            }
            freeArrays(mHashes, mArray, this.mSize);
        }
        final int mSize2 = this.mSize;
        if (n2 < mSize2) {
            final int[] mHashes3 = this.mHashes;
            final int n4 = n2 + 1;
            System.arraycopy(mHashes3, n2, mHashes3, n4, mSize2 - n2);
            final Object[] mArray2 = this.mArray;
            System.arraycopy(mArray2, n2, mArray2, n4, this.mSize - n2);
        }
        this.mHashes[n2] = n;
        this.mArray[n2] = e;
        ++this.mSize;
        return true;
    }
    
    public void addAll(final ArraySet<? extends E> set) {
        final int mSize = set.mSize;
        this.ensureCapacity(mSize + this.mSize);
        final int mSize2 = this.mSize;
        int i = 0;
        if (mSize2 == 0) {
            if (mSize > 0) {
                System.arraycopy(set.mHashes, 0, this.mHashes, 0, mSize);
                System.arraycopy(set.mArray, 0, this.mArray, 0, mSize);
                this.mSize = mSize;
            }
        }
        else {
            while (i < mSize) {
                this.add(set.valueAt(i));
                ++i;
            }
        }
    }
    
    @Override
    public boolean addAll(final Collection<? extends E> collection) {
        this.ensureCapacity(this.mSize + collection.size());
        final Iterator<? extends E> iterator = collection.iterator();
        boolean b = false;
        while (iterator.hasNext()) {
            b |= this.add(iterator.next());
        }
        return b;
    }
    
    @Override
    public void clear() {
        final int mSize = this.mSize;
        if (mSize != 0) {
            freeArrays(this.mHashes, this.mArray, mSize);
            this.mHashes = ArraySet.INT;
            this.mArray = ArraySet.OBJECT;
            this.mSize = 0;
        }
    }
    
    @Override
    public boolean contains(final Object o) {
        return this.indexOf(o) >= 0;
    }
    
    @Override
    public boolean containsAll(final Collection<?> collection) {
        final Iterator<?> iterator = collection.iterator();
        while (iterator.hasNext()) {
            if (!this.contains(iterator.next())) {
                return false;
            }
        }
        return true;
    }
    
    public void ensureCapacity(final int n) {
        final int[] mHashes = this.mHashes;
        if (mHashes.length < n) {
            final Object[] mArray = this.mArray;
            this.allocArrays(n);
            final int mSize = this.mSize;
            if (mSize > 0) {
                System.arraycopy(mHashes, 0, this.mHashes, 0, mSize);
                System.arraycopy(mArray, 0, this.mArray, 0, this.mSize);
            }
            freeArrays(mHashes, mArray, this.mSize);
        }
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        Set set = null;
        int i = 0;
        if (o instanceof Set) {
            set = (Set)o;
            if (this.size() != set.size()) {
                return false;
            }
            i = 0;
        }
        try {
            while (i < this.mSize) {
                if (!set.contains(this.valueAt(i))) {
                    return false;
                }
                ++i;
            }
            return true;
        }
        catch (NullPointerException | ClassCastException ex) {
            return false;
        }
    }
    
    @Override
    public int hashCode() {
        final int[] mHashes = this.mHashes;
        final int mSize = this.mSize;
        int i = 0;
        int n = 0;
        while (i < mSize) {
            n += mHashes[i];
            ++i;
        }
        return n;
    }
    
    public int indexOf(final Object o) {
        int n;
        if (o == null) {
            n = this.indexOfNull();
        }
        else {
            n = this.indexOf(o, o.hashCode());
        }
        return n;
    }
    
    @Override
    public boolean isEmpty() {
        return this.mSize <= 0;
    }
    
    @Override
    public Iterator<E> iterator() {
        return this.getCollection().getKeySet().iterator();
    }
    
    @Override
    public boolean remove(final Object o) {
        final int index = this.indexOf(o);
        if (index >= 0) {
            this.removeAt(index);
            return true;
        }
        return false;
    }
    
    public boolean removeAll(final ArraySet<? extends E> set) {
        final int mSize = set.mSize;
        final int mSize2 = this.mSize;
        for (int i = 0; i < mSize; ++i) {
            this.remove(set.valueAt(i));
        }
        final int mSize3 = this.mSize;
        boolean b = false;
        if (mSize2 != mSize3) {
            b = true;
        }
        return b;
    }
    
    @Override
    public boolean removeAll(final Collection<?> collection) {
        final Iterator<?> iterator = collection.iterator();
        boolean b = false;
        while (iterator.hasNext()) {
            b |= this.remove(iterator.next());
        }
        return b;
    }
    
    public E removeAt(final int n) {
        final Object[] mArray = this.mArray;
        final Object o = mArray[n];
        final int mSize = this.mSize;
        if (mSize <= 1) {
            freeArrays(this.mHashes, mArray, mSize);
            this.mHashes = ArraySet.INT;
            this.mArray = ArraySet.OBJECT;
            this.mSize = 0;
        }
        else {
            final int[] mHashes = this.mHashes;
            final int length = mHashes.length;
            int n2 = 8;
            if (length > n2 && mSize < mHashes.length / 3) {
                if (mSize > n2) {
                    n2 = mSize + (mSize >> 1);
                }
                this.allocArrays(n2);
                --this.mSize;
                if (n > 0) {
                    System.arraycopy(mHashes, 0, this.mHashes, 0, n);
                    System.arraycopy(mArray, 0, this.mArray, 0, n);
                }
                final int mSize2 = this.mSize;
                if (n < mSize2) {
                    final int n3 = n + 1;
                    System.arraycopy(mHashes, n3, this.mHashes, n, mSize2 - n);
                    System.arraycopy(mArray, n3, this.mArray, n, this.mSize - n);
                }
            }
            else {
                final int mSize3 = mSize - 1;
                if (n < (this.mSize = mSize3)) {
                    final int n4 = n + 1;
                    System.arraycopy(mHashes, n4, mHashes, n, mSize3 - n);
                    final Object[] mArray2 = this.mArray;
                    System.arraycopy(mArray2, n4, mArray2, n, this.mSize - n);
                }
                this.mArray[this.mSize] = null;
            }
        }
        return (E)o;
    }
    
    @Override
    public boolean retainAll(final Collection<?> collection) {
        int i = this.mSize - 1;
        boolean b = false;
        while (i >= 0) {
            if (!collection.contains(this.mArray[i])) {
                this.removeAt(i);
                b = true;
            }
            --i;
        }
        return b;
    }
    
    @Override
    public int size() {
        return this.mSize;
    }
    
    @Override
    public Object[] toArray() {
        final int mSize = this.mSize;
        final Object[] array = new Object[mSize];
        System.arraycopy(this.mArray, 0, array, 0, mSize);
        return array;
    }
    
    @Override
    public <T> T[] toArray(T[] array) {
        if (array.length < this.mSize) {
            array = (T[])Array.newInstance(array.getClass().getComponentType(), this.mSize);
        }
        System.arraycopy(this.mArray, 0, array, 0, this.mSize);
        final int length = array.length;
        final int mSize = this.mSize;
        if (length > mSize) {
            array[mSize] = null;
        }
        return array;
    }
    
    @Override
    public String toString() {
        if (this.isEmpty()) {
            return "{}";
        }
        final StringBuilder sb = new StringBuilder(14 * this.mSize);
        sb.append('{');
        for (int i = 0; i < this.mSize; ++i) {
            if (i > 0) {
                sb.append(", ");
            }
            final E value = this.valueAt(i);
            if (value != this) {
                sb.append(value);
            }
            else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
    
    public E valueAt(final int n) {
        return (E)this.mArray[n];
    }
}
