// 
// Decompiled by Procyon v0.5.36
// 

package androidx.collection;

import java.util.Map;
import java.util.ConcurrentModificationException;

public class SimpleArrayMap<K, V>
{
    private static final int BASE_SIZE = 4;
    private static final int CACHE_SIZE = 10;
    private static final boolean CONCURRENT_MODIFICATION_EXCEPTIONS = true;
    private static final boolean DEBUG = false;
    private static final String TAG = "ArrayMap";
    static Object[] mBaseCache;
    static int mBaseCacheSize;
    static Object[] mTwiceBaseCache;
    static int mTwiceBaseCacheSize;
    Object[] mArray;
    int[] mHashes;
    int mSize;
    
    public SimpleArrayMap() {
        this.mHashes = ContainerHelpers.EMPTY_INTS;
        this.mArray = ContainerHelpers.EMPTY_OBJECTS;
        this.mSize = 0;
    }
    
    public SimpleArrayMap(final int n) {
        if (n == 0) {
            this.mHashes = ContainerHelpers.EMPTY_INTS;
            this.mArray = ContainerHelpers.EMPTY_OBJECTS;
        }
        else {
            this.allocArrays(n);
        }
        this.mSize = 0;
    }
    
    public SimpleArrayMap(final SimpleArrayMap<K, V> simpleArrayMap) {
        this();
        if (simpleArrayMap != null) {
            this.putAll((SimpleArrayMap<? extends K, ? extends V>)simpleArrayMap);
        }
    }
    
    private void allocArrays(final int n) {
        Label_0166: {
            if (n == 8) {
                synchronized (SimpleArrayMap.class) {
                    final Object[] mTwiceBaseCache = SimpleArrayMap.mTwiceBaseCache;
                    if (mTwiceBaseCache != null) {
                        this.mArray = mTwiceBaseCache;
                        SimpleArrayMap.mTwiceBaseCache = (Object[])mTwiceBaseCache[0];
                        this.mHashes = (int[])mTwiceBaseCache[1];
                        mTwiceBaseCache[0] = (mTwiceBaseCache[1] = null);
                        --SimpleArrayMap.mTwiceBaseCacheSize;
                        return;
                    }
                    break Label_0166;
                }
            }
            if (n == 4) {
                synchronized (SimpleArrayMap.class) {
                    final Object[] mBaseCache = SimpleArrayMap.mBaseCache;
                    if (mBaseCache != null) {
                        this.mArray = mBaseCache;
                        SimpleArrayMap.mBaseCache = (Object[])mBaseCache[0];
                        this.mHashes = (int[])mBaseCache[1];
                        mBaseCache[0] = (mBaseCache[1] = null);
                        --SimpleArrayMap.mBaseCacheSize;
                        return;
                    }
                }
            }
        }
        this.mHashes = new int[n];
        this.mArray = new Object[n << 1];
    }
    
    private static int binarySearchHashes(final int[] array, final int n, final int n2) {
        try {
            return ContainerHelpers.binarySearch(array, n, n2);
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            throw new ConcurrentModificationException();
        }
    }
    
    private static void freeArrays(final int[] array, final Object[] array2, final int n) {
        if (array.length == 8) {
            synchronized (SimpleArrayMap.class) {
                if (SimpleArrayMap.mTwiceBaseCacheSize < 10) {
                    array2[0] = SimpleArrayMap.mTwiceBaseCache;
                    array2[1] = array;
                    for (int i = (n << 1) - 1; i >= 2; --i) {
                        array2[i] = null;
                    }
                    SimpleArrayMap.mTwiceBaseCache = array2;
                    ++SimpleArrayMap.mTwiceBaseCacheSize;
                }
                return;
            }
        }
        if (array.length == 4) {
            synchronized (SimpleArrayMap.class) {
                if (SimpleArrayMap.mBaseCacheSize < 10) {
                    array2[0] = SimpleArrayMap.mBaseCache;
                    array2[1] = array;
                    for (int j = (n << 1) - 1; j >= 2; --j) {
                        array2[j] = null;
                    }
                    SimpleArrayMap.mBaseCache = array2;
                    ++SimpleArrayMap.mBaseCacheSize;
                }
            }
        }
    }
    
    public void clear() {
        final int mSize = this.mSize;
        if (mSize > 0) {
            final int[] mHashes = this.mHashes;
            final Object[] mArray = this.mArray;
            this.mHashes = ContainerHelpers.EMPTY_INTS;
            this.mArray = ContainerHelpers.EMPTY_OBJECTS;
            this.mSize = 0;
            freeArrays(mHashes, mArray, mSize);
        }
        if (this.mSize <= 0) {
            return;
        }
        throw new ConcurrentModificationException();
    }
    
    public boolean containsKey(final Object o) {
        return this.indexOfKey(o) >= 0;
    }
    
    public boolean containsValue(final Object o) {
        return this.indexOfValue(o) >= 0;
    }
    
    public void ensureCapacity(final int n) {
        final int mSize = this.mSize;
        final int[] mHashes = this.mHashes;
        if (mHashes.length < n) {
            final Object[] mArray = this.mArray;
            this.allocArrays(n);
            if (this.mSize > 0) {
                System.arraycopy(mHashes, 0, this.mHashes, 0, mSize);
                System.arraycopy(mArray, 0, this.mArray, 0, mSize << 1);
            }
            freeArrays(mHashes, mArray, mSize);
        }
        if (this.mSize == mSize) {
            return;
        }
        throw new ConcurrentModificationException();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o instanceof SimpleArrayMap) {
            final SimpleArrayMap simpleArrayMap = (SimpleArrayMap)o;
            if (this.size() != simpleArrayMap.size()) {
                return false;
            }
            int i = 0;
            try {
                while (i < this.mSize) {
                    final K key = this.keyAt(i);
                    final V value = this.valueAt(i);
                    final Object value2 = simpleArrayMap.get(key);
                    if (value == null) {
                        if (value2 != null) {
                            return false;
                        }
                        if (!simpleArrayMap.containsKey(key)) {
                            return false;
                        }
                    }
                    else if (!value.equals(value2)) {
                        return false;
                    }
                    ++i;
                }
                return true;
            }
            catch (NullPointerException | ClassCastException ex) {
                return false;
            }
        }
        Map map = null;
        int j = 0;
        if (o instanceof Map) {
            map = (Map)o;
            if (this.size() != map.size()) {
                return false;
            }
            j = 0;
        }
        try {
            while (j < this.mSize) {
                final K key2 = this.keyAt(j);
                final V value3 = this.valueAt(j);
                final Object value4 = map.get(key2);
                if (value3 == null) {
                    if (value4 != null || !map.containsKey(key2)) {
                        return false;
                    }
                }
                else if (!value3.equals(value4)) {
                    return false;
                }
                ++j;
            }
            return true;
        }
        catch (NullPointerException | ClassCastException ex2) {
            return false;
        }
        return false;
    }
    
    public V get(final Object o) {
        return this.getOrDefault(o, null);
    }
    
    public V getOrDefault(final Object o, V v) {
        final int indexOfKey = this.indexOfKey(o);
        if (indexOfKey >= 0) {
            v = (V)this.mArray[1 + (indexOfKey << 1)];
        }
        return v;
    }
    
    @Override
    public int hashCode() {
        final int[] mHashes = this.mHashes;
        final Object[] mArray = this.mArray;
        final int mSize = this.mSize;
        int n = 1;
        int i = 0;
        int n2 = 0;
        while (i < mSize) {
            final Object o = mArray[n];
            final int n3 = mHashes[i];
            int hashCode;
            if (o == null) {
                hashCode = 0;
            }
            else {
                hashCode = o.hashCode();
            }
            n2 += (hashCode ^ n3);
            ++i;
            n += 2;
        }
        return n2;
    }
    
    int indexOf(final Object o, final int n) {
        final int mSize = this.mSize;
        if (mSize == 0) {
            return -1;
        }
        final int binarySearchHashes = binarySearchHashes(this.mHashes, mSize, n);
        if (binarySearchHashes < 0) {
            return binarySearchHashes;
        }
        if (o.equals(this.mArray[binarySearchHashes << 1])) {
            return binarySearchHashes;
        }
        int n2;
        for (n2 = binarySearchHashes + 1; n2 < mSize && this.mHashes[n2] == n; ++n2) {
            if (o.equals(this.mArray[n2 << 1])) {
                return n2;
            }
        }
        for (int n3 = binarySearchHashes - 1; n3 >= 0 && this.mHashes[n3] == n; --n3) {
            if (o.equals(this.mArray[n3 << 1])) {
                return n3;
            }
        }
        return ~n2;
    }
    
    public int indexOfKey(final Object o) {
        int n;
        if (o == null) {
            n = this.indexOfNull();
        }
        else {
            n = this.indexOf(o, o.hashCode());
        }
        return n;
    }
    
    int indexOfNull() {
        final int mSize = this.mSize;
        if (mSize == 0) {
            return -1;
        }
        final int binarySearchHashes = binarySearchHashes(this.mHashes, mSize, 0);
        if (binarySearchHashes < 0) {
            return binarySearchHashes;
        }
        if (this.mArray[binarySearchHashes << 1] == null) {
            return binarySearchHashes;
        }
        int n;
        for (n = binarySearchHashes + 1; n < mSize && this.mHashes[n] == 0; ++n) {
            if (this.mArray[n << 1] == null) {
                return n;
            }
        }
        for (int n2 = binarySearchHashes - 1; n2 >= 0 && this.mHashes[n2] == 0; --n2) {
            if (this.mArray[n2 << 1] == null) {
                return n2;
            }
        }
        return ~n;
    }
    
    int indexOfValue(final Object o) {
        final int n = 2 * this.mSize;
        final Object[] mArray = this.mArray;
        if (o == null) {
            for (int i = 1; i < n; i += 2) {
                if (mArray[i] == null) {
                    return i >> 1;
                }
            }
        }
        else {
            for (int j = 1; j < n; j += 2) {
                if (o.equals(mArray[j])) {
                    return j >> 1;
                }
            }
        }
        return -1;
    }
    
    public boolean isEmpty() {
        return this.mSize <= 0;
    }
    
    public K keyAt(final int n) {
        return (K)this.mArray[n << 1];
    }
    
    public V put(final K k, final V v) {
        final int mSize = this.mSize;
        int indexOfNull;
        int n;
        if (k == null) {
            indexOfNull = this.indexOfNull();
            n = 0;
        }
        else {
            final int hashCode = k.hashCode();
            final int index = this.indexOf(k, hashCode);
            n = hashCode;
            indexOfNull = index;
        }
        if (indexOfNull >= 0) {
            final int n2 = 1 + (indexOfNull << 1);
            final Object[] mArray = this.mArray;
            final Object o = mArray[n2];
            mArray[n2] = v;
            return (V)o;
        }
        final int n3 = ~indexOfNull;
        final int[] mHashes = this.mHashes;
        if (mSize >= mHashes.length) {
            int n4 = 4;
            if (mSize >= 8) {
                n4 = mSize + (mSize >> 1);
            }
            else if (mSize >= n4) {
                n4 = 8;
            }
            final Object[] mArray2 = this.mArray;
            this.allocArrays(n4);
            if (mSize != this.mSize) {
                throw new ConcurrentModificationException();
            }
            final int[] mHashes2 = this.mHashes;
            if (mHashes2.length > 0) {
                System.arraycopy(mHashes, 0, mHashes2, 0, mHashes.length);
                System.arraycopy(mArray2, 0, this.mArray, 0, mArray2.length);
            }
            freeArrays(mHashes, mArray2, mSize);
        }
        if (n3 < mSize) {
            final int[] mHashes3 = this.mHashes;
            final int n5 = n3 + 1;
            System.arraycopy(mHashes3, n3, mHashes3, n5, mSize - n3);
            final Object[] mArray3 = this.mArray;
            System.arraycopy(mArray3, n3 << 1, mArray3, n5 << 1, this.mSize - n3 << 1);
        }
        final int mSize2 = this.mSize;
        if (mSize == mSize2) {
            final int[] mHashes4 = this.mHashes;
            if (n3 < mHashes4.length) {
                mHashes4[n3] = n;
                final Object[] mArray4 = this.mArray;
                final int n6 = n3 << 1;
                mArray4[n6] = k;
                mArray4[n6 + 1] = v;
                this.mSize = mSize2 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }
    
    public void putAll(final SimpleArrayMap<? extends K, ? extends V> simpleArrayMap) {
        final int mSize = simpleArrayMap.mSize;
        this.ensureCapacity(mSize + this.mSize);
        final int mSize2 = this.mSize;
        int i = 0;
        if (mSize2 == 0) {
            if (mSize > 0) {
                System.arraycopy(simpleArrayMap.mHashes, 0, this.mHashes, 0, mSize);
                System.arraycopy(simpleArrayMap.mArray, 0, this.mArray, 0, mSize << 1);
                this.mSize = mSize;
            }
        }
        else {
            while (i < mSize) {
                this.put(simpleArrayMap.keyAt(i), simpleArrayMap.valueAt(i));
                ++i;
            }
        }
    }
    
    public V putIfAbsent(final K k, final V v) {
        Object o = this.get(k);
        if (o == null) {
            o = this.put(k, v);
        }
        return (V)o;
    }
    
    public V remove(final Object o) {
        final int indexOfKey = this.indexOfKey(o);
        if (indexOfKey >= 0) {
            return this.removeAt(indexOfKey);
        }
        return null;
    }
    
    public boolean remove(final Object o, final Object o2) {
        final int indexOfKey = this.indexOfKey(o);
        if (indexOfKey >= 0) {
            final V value = this.valueAt(indexOfKey);
            if (o2 == value || (o2 != null && o2.equals(value))) {
                this.removeAt(indexOfKey);
                return true;
            }
        }
        return false;
    }
    
    public V removeAt(final int n) {
        final Object[] mArray = this.mArray;
        final int n2 = n << 1;
        final Object o = mArray[n2 + 1];
        final int mSize = this.mSize;
        int mSize2;
        if (mSize <= 1) {
            freeArrays(this.mHashes, mArray, mSize);
            this.mHashes = ContainerHelpers.EMPTY_INTS;
            this.mArray = ContainerHelpers.EMPTY_OBJECTS;
            mSize2 = 0;
        }
        else {
            final int n3 = mSize - 1;
            final int[] mHashes = this.mHashes;
            final int length = mHashes.length;
            int n4 = 8;
            if (length > n4 && mSize < mHashes.length / 3) {
                if (mSize > n4) {
                    n4 = mSize + (mSize >> 1);
                }
                this.allocArrays(n4);
                if (mSize != this.mSize) {
                    throw new ConcurrentModificationException();
                }
                if (n > 0) {
                    System.arraycopy(mHashes, 0, this.mHashes, 0, n);
                    System.arraycopy(mArray, 0, this.mArray, 0, n2);
                }
                if (n < n3) {
                    final int n5 = n + 1;
                    final int[] mHashes2 = this.mHashes;
                    final int n6 = n3 - n;
                    System.arraycopy(mHashes, n5, mHashes2, n, n6);
                    System.arraycopy(mArray, n5 << 1, this.mArray, n2, n6 << 1);
                }
            }
            else {
                if (n < n3) {
                    final int n7 = n + 1;
                    final int n8 = n3 - n;
                    System.arraycopy(mHashes, n7, mHashes, n, n8);
                    final Object[] mArray2 = this.mArray;
                    System.arraycopy(mArray2, n7 << 1, mArray2, n2, n8 << 1);
                }
                final Object[] mArray3 = this.mArray;
                final int n9 = n3 << 1;
                mArray3[n9 + 1] = (mArray3[n9] = null);
            }
            mSize2 = n3;
        }
        if (mSize == this.mSize) {
            this.mSize = mSize2;
            return (V)o;
        }
        throw new ConcurrentModificationException();
    }
    
    public V replace(final K k, final V v) {
        final int indexOfKey = this.indexOfKey(k);
        if (indexOfKey >= 0) {
            return this.setValueAt(indexOfKey, v);
        }
        return null;
    }
    
    public boolean replace(final K k, final V v, final V v2) {
        final int indexOfKey = this.indexOfKey(k);
        if (indexOfKey >= 0) {
            final V value = this.valueAt(indexOfKey);
            if (value == v || (v != null && v.equals(value))) {
                this.setValueAt(indexOfKey, v2);
                return true;
            }
        }
        return false;
    }
    
    public V setValueAt(final int n, final V v) {
        final int n2 = 1 + (n << 1);
        final Object[] mArray = this.mArray;
        final Object o = mArray[n2];
        mArray[n2] = v;
        return (V)o;
    }
    
    public int size() {
        return this.mSize;
    }
    
    @Override
    public String toString() {
        if (this.isEmpty()) {
            return "{}";
        }
        final StringBuilder sb = new StringBuilder(28 * this.mSize);
        sb.append('{');
        for (int i = 0; i < this.mSize; ++i) {
            if (i > 0) {
                sb.append(", ");
            }
            final K key = this.keyAt(i);
            if (key != this) {
                sb.append(key);
            }
            else {
                sb.append("(this Map)");
            }
            sb.append('=');
            final V value = this.valueAt(i);
            if (value != this) {
                sb.append(value);
            }
            else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
    
    public V valueAt(final int n) {
        return (V)this.mArray[1 + (n << 1)];
    }
}
