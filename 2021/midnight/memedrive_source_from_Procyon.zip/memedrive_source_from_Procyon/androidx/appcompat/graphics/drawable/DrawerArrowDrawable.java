// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.graphics.drawable;

import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Annotation;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import androidx.core.graphics.drawable.DrawableCompat;
import android.graphics.Canvas;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.appcompat.R;
import android.graphics.Paint$Cap;
import android.graphics.Paint$Join;
import android.graphics.Paint$Style;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;

public class DrawerArrowDrawable extends Drawable
{
    public static final int ARROW_DIRECTION_END = 3;
    public static final int ARROW_DIRECTION_LEFT = 0;
    public static final int ARROW_DIRECTION_RIGHT = 1;
    public static final int ARROW_DIRECTION_START = 2;
    private static final float ARROW_HEAD_ANGLE;
    private float mArrowHeadLength;
    private float mArrowShaftLength;
    private float mBarGap;
    private float mBarLength;
    private int mDirection;
    private float mMaxCutForBarSize;
    private final Paint mPaint;
    private final Path mPath;
    private float mProgress;
    private final int mSize;
    private boolean mSpin;
    private boolean mVerticalMirror;
    
    static {
        ARROW_HEAD_ANGLE = (float)Math.toRadians(45.0);
    }
    
    public DrawerArrowDrawable(final Context context) {
        final Paint mPaint = new Paint();
        this.mPaint = mPaint;
        this.mPath = new Path();
        this.mVerticalMirror = false;
        this.mDirection = 2;
        mPaint.setStyle(Paint$Style.STROKE);
        mPaint.setStrokeJoin(Paint$Join.MITER);
        mPaint.setStrokeCap(Paint$Cap.BUTT);
        mPaint.setAntiAlias(true);
        final TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet)null, R.styleable.DrawerArrowToggle, R.attr.drawerArrowStyle, R.style.Base_Widget_AppCompat_DrawerArrowToggle);
        this.setColor(obtainStyledAttributes.getColor(R.styleable.DrawerArrowToggle_color, 0));
        this.setBarThickness(obtainStyledAttributes.getDimension(R.styleable.DrawerArrowToggle_thickness, 0.0f));
        this.setSpinEnabled(obtainStyledAttributes.getBoolean(R.styleable.DrawerArrowToggle_spinBars, true));
        this.setGapSize((float)Math.round(obtainStyledAttributes.getDimension(R.styleable.DrawerArrowToggle_gapBetweenBars, 0.0f)));
        this.mSize = obtainStyledAttributes.getDimensionPixelSize(R.styleable.DrawerArrowToggle_drawableSize, 0);
        this.mBarLength = (float)Math.round(obtainStyledAttributes.getDimension(R.styleable.DrawerArrowToggle_barLength, 0.0f));
        this.mArrowHeadLength = (float)Math.round(obtainStyledAttributes.getDimension(R.styleable.DrawerArrowToggle_arrowHeadLength, 0.0f));
        this.mArrowShaftLength = obtainStyledAttributes.getDimension(R.styleable.DrawerArrowToggle_arrowShaftLength, 0.0f);
        obtainStyledAttributes.recycle();
    }
    
    private static float lerp(final float n, final float n2, final float n3) {
        return n + n3 * (n2 - n);
    }
    
    public void draw(final Canvas canvas) {
        final Rect bounds = this.getBounds();
        final int mDirection = this.mDirection;
        int n = 0;
        Label_0062: {
            if (mDirection != 0) {
                if (mDirection != 1) {
                    if (mDirection != 3) {
                        final int layoutDirection = DrawableCompat.getLayoutDirection(this);
                        n = 0;
                        if (layoutDirection != 1) {
                            break Label_0062;
                        }
                    }
                    else {
                        final int layoutDirection2 = DrawableCompat.getLayoutDirection(this);
                        n = 0;
                        if (layoutDirection2 != 0) {
                            break Label_0062;
                        }
                    }
                }
                n = 1;
            }
        }
        final float mArrowHeadLength = this.mArrowHeadLength;
        final float lerp = lerp(this.mBarLength, (float)Math.sqrt(2.0f * (mArrowHeadLength * mArrowHeadLength)), this.mProgress);
        final float lerp2 = lerp(this.mBarLength, this.mArrowShaftLength, this.mProgress);
        final float n2 = (float)Math.round(lerp(0.0f, this.mMaxCutForBarSize, this.mProgress));
        final float lerp3 = lerp(0.0f, DrawerArrowDrawable.ARROW_HEAD_ANGLE, this.mProgress);
        float n3;
        if (n != 0) {
            n3 = 0.0f;
        }
        else {
            n3 = -180.0f;
        }
        float n4;
        if (n != 0) {
            n4 = 180.0f;
        }
        else {
            n4 = 0.0f;
        }
        final float lerp4 = lerp(n3, n4, this.mProgress);
        final double n5 = lerp;
        final double n6 = lerp3;
        final double cos = Math.cos(n6);
        Double.isNaN(n5);
        final double a = cos * n5;
        final int n7 = n;
        final float n8 = (float)Math.round(a);
        final double sin = Math.sin(n6);
        Double.isNaN(n5);
        final float n9 = (float)Math.round(n5 * sin);
        this.mPath.rewind();
        final float lerp5 = lerp(this.mBarGap + this.mPaint.getStrokeWidth(), -this.mMaxCutForBarSize, this.mProgress);
        final float n10 = -lerp2 / 2.0f;
        this.mPath.moveTo(n10 + n2, 0.0f);
        this.mPath.rLineTo(lerp2 - n2 * 2.0f, 0.0f);
        this.mPath.moveTo(n10, lerp5);
        this.mPath.rLineTo(n8, n9);
        this.mPath.moveTo(n10, -lerp5);
        this.mPath.rLineTo(n8, -n9);
        this.mPath.close();
        canvas.save();
        final float strokeWidth = this.mPaint.getStrokeWidth();
        final float n11 = bounds.height() - 3.0f * strokeWidth;
        final float mBarGap = this.mBarGap;
        canvas.translate((float)bounds.centerX(), 2 * ((int)(n11 - 2.0f * mBarGap) / 4) + (mBarGap + strokeWidth * 1.5f));
        if (this.mSpin) {
            int n12;
            if ((n7 ^ (this.mVerticalMirror ? 1 : 0)) != 0x0) {
                n12 = -1;
            }
            else {
                n12 = 1;
            }
            canvas.rotate(lerp4 * n12);
        }
        else if (n7 != 0) {
            canvas.rotate(180.0f);
        }
        canvas.drawPath(this.mPath, this.mPaint);
        canvas.restore();
    }
    
    public float getArrowHeadLength() {
        return this.mArrowHeadLength;
    }
    
    public float getArrowShaftLength() {
        return this.mArrowShaftLength;
    }
    
    public float getBarLength() {
        return this.mBarLength;
    }
    
    public float getBarThickness() {
        return this.mPaint.getStrokeWidth();
    }
    
    public int getColor() {
        return this.mPaint.getColor();
    }
    
    public int getDirection() {
        return this.mDirection;
    }
    
    public float getGapSize() {
        return this.mBarGap;
    }
    
    public int getIntrinsicHeight() {
        return this.mSize;
    }
    
    public int getIntrinsicWidth() {
        return this.mSize;
    }
    
    public int getOpacity() {
        return -3;
    }
    
    public final Paint getPaint() {
        return this.mPaint;
    }
    
    public float getProgress() {
        return this.mProgress;
    }
    
    public boolean isSpinEnabled() {
        return this.mSpin;
    }
    
    public void setAlpha(final int alpha) {
        if (alpha != this.mPaint.getAlpha()) {
            this.mPaint.setAlpha(alpha);
            this.invalidateSelf();
        }
    }
    
    public void setArrowHeadLength(final float mArrowHeadLength) {
        if (this.mArrowHeadLength != mArrowHeadLength) {
            this.mArrowHeadLength = mArrowHeadLength;
            this.invalidateSelf();
        }
    }
    
    public void setArrowShaftLength(final float mArrowShaftLength) {
        if (this.mArrowShaftLength != mArrowShaftLength) {
            this.mArrowShaftLength = mArrowShaftLength;
            this.invalidateSelf();
        }
    }
    
    public void setBarLength(final float mBarLength) {
        if (this.mBarLength != mBarLength) {
            this.mBarLength = mBarLength;
            this.invalidateSelf();
        }
    }
    
    public void setBarThickness(final float strokeWidth) {
        if (this.mPaint.getStrokeWidth() != strokeWidth) {
            this.mPaint.setStrokeWidth(strokeWidth);
            final double v = strokeWidth / 2.0f;
            final double cos = Math.cos(DrawerArrowDrawable.ARROW_HEAD_ANGLE);
            Double.isNaN(v);
            this.mMaxCutForBarSize = (float)(v * cos);
            this.invalidateSelf();
        }
    }
    
    public void setColor(final int color) {
        if (color != this.mPaint.getColor()) {
            this.mPaint.setColor(color);
            this.invalidateSelf();
        }
    }
    
    public void setColorFilter(final ColorFilter colorFilter) {
        this.mPaint.setColorFilter(colorFilter);
        this.invalidateSelf();
    }
    
    public void setDirection(final int mDirection) {
        if (mDirection != this.mDirection) {
            this.mDirection = mDirection;
            this.invalidateSelf();
        }
    }
    
    public void setGapSize(final float mBarGap) {
        if (mBarGap != this.mBarGap) {
            this.mBarGap = mBarGap;
            this.invalidateSelf();
        }
    }
    
    public void setProgress(final float mProgress) {
        if (this.mProgress != mProgress) {
            this.mProgress = mProgress;
            this.invalidateSelf();
        }
    }
    
    public void setSpinEnabled(final boolean mSpin) {
        if (this.mSpin != mSpin) {
            this.mSpin = mSpin;
            this.invalidateSelf();
        }
    }
    
    public void setVerticalMirror(final boolean mVerticalMirror) {
        if (this.mVerticalMirror != mVerticalMirror) {
            this.mVerticalMirror = mVerticalMirror;
            this.invalidateSelf();
        }
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface ArrowDirection {
    }
}
