// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.view;

public interface CollapsibleActionView
{
    void onActionViewCollapsed();
    
    void onActionViewExpanded();
}
