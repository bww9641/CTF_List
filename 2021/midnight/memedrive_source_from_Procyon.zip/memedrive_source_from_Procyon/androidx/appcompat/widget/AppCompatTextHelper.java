// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import java.lang.ref.WeakReference;
import androidx.core.widget.TextViewCompat;
import androidx.core.widget.AutoSizeableTextView;
import java.util.Locale;
import android.os.LocaleList;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.graphics.PorterDuff$Mode;
import android.content.res.Resources$NotFoundException;
import androidx.core.content.res.ResourcesCompat;
import androidx.appcompat.R;
import android.os.Build$VERSION;
import android.content.res.ColorStateList;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import android.graphics.Typeface;

class AppCompatTextHelper
{
    private static final int MONOSPACE = 3;
    private static final int SANS = 1;
    private static final int SERIF = 2;
    private static final int TEXT_FONT_WEIGHT_UNSPECIFIED = -1;
    private boolean mAsyncFontPending;
    private final AppCompatTextViewAutoSizeHelper mAutoSizeTextHelper;
    private TintInfo mDrawableBottomTint;
    private TintInfo mDrawableEndTint;
    private TintInfo mDrawableLeftTint;
    private TintInfo mDrawableRightTint;
    private TintInfo mDrawableStartTint;
    private TintInfo mDrawableTint;
    private TintInfo mDrawableTopTint;
    private Typeface mFontTypeface;
    private int mFontWeight;
    private int mStyle;
    private final TextView mView;
    
    AppCompatTextHelper(final TextView mView) {
        this.mStyle = 0;
        this.mFontWeight = -1;
        this.mView = mView;
        this.mAutoSizeTextHelper = new AppCompatTextViewAutoSizeHelper(mView);
    }
    
    private void applyCompoundDrawableTint(final Drawable drawable, final TintInfo tintInfo) {
        if (drawable != null && tintInfo != null) {
            AppCompatDrawableManager.tintDrawable(drawable, tintInfo, this.mView.getDrawableState());
        }
    }
    
    private static TintInfo createTintInfo(final Context context, final AppCompatDrawableManager appCompatDrawableManager, final int n) {
        final ColorStateList tintList = appCompatDrawableManager.getTintList(context, n);
        if (tintList != null) {
            final TintInfo tintInfo = new TintInfo();
            tintInfo.mHasTintList = true;
            tintInfo.mTintList = tintList;
            return tintInfo;
        }
        return null;
    }
    
    private void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        if (Build$VERSION.SDK_INT >= 17 && (drawable5 != null || drawable6 != null)) {
            final Drawable[] compoundDrawablesRelative = this.mView.getCompoundDrawablesRelative();
            final TextView mView = this.mView;
            if (drawable5 == null) {
                drawable5 = compoundDrawablesRelative[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawablesRelative[1];
            }
            if (drawable6 == null) {
                drawable6 = compoundDrawablesRelative[2];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawablesRelative[3];
            }
            mView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable5, drawable2, drawable6, drawable4);
        }
        else if (drawable != null || drawable2 != null || drawable3 != null || drawable4 != null) {
            if (Build$VERSION.SDK_INT >= 17) {
                final Drawable[] compoundDrawablesRelative2 = this.mView.getCompoundDrawablesRelative();
                if (compoundDrawablesRelative2[0] != null || compoundDrawablesRelative2[2] != null) {
                    final TextView mView2 = this.mView;
                    final Drawable drawable7 = compoundDrawablesRelative2[0];
                    if (drawable2 == null) {
                        drawable2 = compoundDrawablesRelative2[1];
                    }
                    final Drawable drawable8 = compoundDrawablesRelative2[2];
                    if (drawable4 == null) {
                        drawable4 = compoundDrawablesRelative2[3];
                    }
                    mView2.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable7, drawable2, drawable8, drawable4);
                    return;
                }
            }
            final Drawable[] compoundDrawables = this.mView.getCompoundDrawables();
            final TextView mView3 = this.mView;
            if (drawable == null) {
                drawable = compoundDrawables[0];
            }
            if (drawable2 == null) {
                drawable2 = compoundDrawables[1];
            }
            if (drawable3 == null) {
                drawable3 = compoundDrawables[2];
            }
            if (drawable4 == null) {
                drawable4 = compoundDrawables[3];
            }
            mView3.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        }
    }
    
    private void setCompoundTints() {
        final TintInfo mDrawableTint = this.mDrawableTint;
        this.mDrawableLeftTint = mDrawableTint;
        this.mDrawableTopTint = mDrawableTint;
        this.mDrawableRightTint = mDrawableTint;
        this.mDrawableBottomTint = mDrawableTint;
        this.mDrawableStartTint = mDrawableTint;
        this.mDrawableEndTint = mDrawableTint;
    }
    
    private void setTextSizeInternal(final int n, final float n2) {
        this.mAutoSizeTextHelper.setTextSizeInternal(n, n2);
    }
    
    private void updateTypefaceAndStyle(final Context context, final TintTypedArray tintTypedArray) {
        this.mStyle = tintTypedArray.getInt(R.styleable.TextAppearance_android_textStyle, this.mStyle);
        if (Build$VERSION.SDK_INT >= 28 && (this.mFontWeight = tintTypedArray.getInt(R.styleable.TextAppearance_android_textFontWeight, -1)) != -1) {
            this.mStyle = (0x0 | (0x2 & this.mStyle));
        }
        if (!tintTypedArray.hasValue(R.styleable.TextAppearance_android_fontFamily) && !tintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
            if (tintTypedArray.hasValue(R.styleable.TextAppearance_android_typeface)) {
                this.mAsyncFontPending = false;
                final int int1 = tintTypedArray.getInt(R.styleable.TextAppearance_android_typeface, 1);
                if (int1 != 1) {
                    if (int1 != 2) {
                        if (int1 == 3) {
                            this.mFontTypeface = Typeface.MONOSPACE;
                        }
                    }
                    else {
                        this.mFontTypeface = Typeface.SERIF;
                    }
                }
                else {
                    this.mFontTypeface = Typeface.SANS_SERIF;
                }
            }
            return;
        }
        this.mFontTypeface = null;
        int n;
        if (tintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
            n = R.styleable.TextAppearance_fontFamily;
        }
        else {
            n = R.styleable.TextAppearance_android_fontFamily;
        }
        final int mFontWeight = this.mFontWeight;
        final int mStyle = this.mStyle;
        if (!context.isRestricted()) {
        Label_0311_Outer:
            while (true) {
                final ApplyTextViewCallback applyTextViewCallback = new ApplyTextViewCallback(this, mFontWeight, mStyle);
                while (true) {
                Label_0424:
                    while (true) {
                        Label_0418: {
                            try {
                                final Typeface font = tintTypedArray.getFont(n, this.mStyle, applyTextViewCallback);
                                if (font != null) {
                                    if (Build$VERSION.SDK_INT >= 28 && this.mFontWeight != -1) {
                                        final Typeface create = Typeface.create(font, 0);
                                        final int mFontWeight2 = this.mFontWeight;
                                        if ((0x2 & this.mStyle) == 0x0) {
                                            break Label_0418;
                                        }
                                        final boolean b = true;
                                        this.mFontTypeface = Typeface.create(create, mFontWeight2, b);
                                    }
                                    else {
                                        this.mFontTypeface = font;
                                    }
                                }
                                if (this.mFontTypeface != null) {
                                    break Label_0424;
                                }
                                final boolean mAsyncFontPending = true;
                                this.mAsyncFontPending = mAsyncFontPending;
                            }
                            catch (UnsupportedOperationException | Resources$NotFoundException ex) {
                                if (this.mFontTypeface == null) {
                                    final String string = tintTypedArray.getString(n);
                                    if (string != null) {
                                        if (Build$VERSION.SDK_INT >= 28 && this.mFontWeight != -1) {
                                            final Typeface create2 = Typeface.create(string, 0);
                                            final int mFontWeight3 = this.mFontWeight;
                                            final int n2 = 0x2 & this.mStyle;
                                            boolean b2 = false;
                                            if (n2 != 0) {
                                                b2 = true;
                                            }
                                            this.mFontTypeface = Typeface.create(create2, mFontWeight3, b2);
                                        }
                                        else {
                                            this.mFontTypeface = Typeface.create(string, this.mStyle);
                                        }
                                    }
                                }
                                return;
                            }
                        }
                        final boolean b = false;
                        continue Label_0311_Outer;
                    }
                    final boolean mAsyncFontPending = false;
                    continue;
                }
            }
        }
    }
    
    void applyCompoundDrawablesTints() {
        if (this.mDrawableLeftTint != null || this.mDrawableTopTint != null || this.mDrawableRightTint != null || this.mDrawableBottomTint != null) {
            final Drawable[] compoundDrawables = this.mView.getCompoundDrawables();
            this.applyCompoundDrawableTint(compoundDrawables[0], this.mDrawableLeftTint);
            this.applyCompoundDrawableTint(compoundDrawables[1], this.mDrawableTopTint);
            this.applyCompoundDrawableTint(compoundDrawables[2], this.mDrawableRightTint);
            this.applyCompoundDrawableTint(compoundDrawables[3], this.mDrawableBottomTint);
        }
        if (Build$VERSION.SDK_INT >= 17 && (this.mDrawableStartTint != null || this.mDrawableEndTint != null)) {
            final Drawable[] compoundDrawablesRelative = this.mView.getCompoundDrawablesRelative();
            this.applyCompoundDrawableTint(compoundDrawablesRelative[0], this.mDrawableStartTint);
            this.applyCompoundDrawableTint(compoundDrawablesRelative[2], this.mDrawableEndTint);
        }
    }
    
    void autoSizeText() {
        this.mAutoSizeTextHelper.autoSizeText();
    }
    
    int getAutoSizeMaxTextSize() {
        return this.mAutoSizeTextHelper.getAutoSizeMaxTextSize();
    }
    
    int getAutoSizeMinTextSize() {
        return this.mAutoSizeTextHelper.getAutoSizeMinTextSize();
    }
    
    int getAutoSizeStepGranularity() {
        return this.mAutoSizeTextHelper.getAutoSizeStepGranularity();
    }
    
    int[] getAutoSizeTextAvailableSizes() {
        return this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
    }
    
    int getAutoSizeTextType() {
        return this.mAutoSizeTextHelper.getAutoSizeTextType();
    }
    
    ColorStateList getCompoundDrawableTintList() {
        final TintInfo mDrawableTint = this.mDrawableTint;
        ColorStateList mTintList;
        if (mDrawableTint != null) {
            mTintList = mDrawableTint.mTintList;
        }
        else {
            mTintList = null;
        }
        return mTintList;
    }
    
    PorterDuff$Mode getCompoundDrawableTintMode() {
        final TintInfo mDrawableTint = this.mDrawableTint;
        PorterDuff$Mode mTintMode;
        if (mDrawableTint != null) {
            mTintMode = mDrawableTint.mTintMode;
        }
        else {
            mTintMode = null;
        }
        return mTintMode;
    }
    
    boolean isAutoSizeEnabled() {
        return this.mAutoSizeTextHelper.isAutoSizeEnabled();
    }
    
    void loadFromAttributes(final AttributeSet set, final int n) {
        final Context context = this.mView.getContext();
        final AppCompatDrawableManager value = AppCompatDrawableManager.get();
        final TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, set, R.styleable.AppCompatTextHelper, n, 0);
        final int resourceId = obtainStyledAttributes.getResourceId(R.styleable.AppCompatTextHelper_android_textAppearance, -1);
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTextHelper_android_drawableLeft)) {
            this.mDrawableLeftTint = createTintInfo(context, value, obtainStyledAttributes.getResourceId(R.styleable.AppCompatTextHelper_android_drawableLeft, 0));
        }
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTextHelper_android_drawableTop)) {
            this.mDrawableTopTint = createTintInfo(context, value, obtainStyledAttributes.getResourceId(R.styleable.AppCompatTextHelper_android_drawableTop, 0));
        }
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTextHelper_android_drawableRight)) {
            this.mDrawableRightTint = createTintInfo(context, value, obtainStyledAttributes.getResourceId(R.styleable.AppCompatTextHelper_android_drawableRight, 0));
        }
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTextHelper_android_drawableBottom)) {
            this.mDrawableBottomTint = createTintInfo(context, value, obtainStyledAttributes.getResourceId(R.styleable.AppCompatTextHelper_android_drawableBottom, 0));
        }
        if (Build$VERSION.SDK_INT >= 17) {
            if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTextHelper_android_drawableStart)) {
                this.mDrawableStartTint = createTintInfo(context, value, obtainStyledAttributes.getResourceId(R.styleable.AppCompatTextHelper_android_drawableStart, 0));
            }
            if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTextHelper_android_drawableEnd)) {
                this.mDrawableEndTint = createTintInfo(context, value, obtainStyledAttributes.getResourceId(R.styleable.AppCompatTextHelper_android_drawableEnd, 0));
            }
        }
        obtainStyledAttributes.recycle();
        final boolean b = this.mView.getTransformationMethod() instanceof PasswordTransformationMethod;
        boolean allCaps;
        boolean b2;
        ColorStateList textColor;
        ColorStateList hintTextColor;
        ColorStateList linkTextColor;
        String s;
        String fontVariationSettings;
        if (resourceId != -1) {
            final TintTypedArray obtainStyledAttributes2 = TintTypedArray.obtainStyledAttributes(context, resourceId, R.styleable.TextAppearance);
            if (!b && obtainStyledAttributes2.hasValue(R.styleable.TextAppearance_textAllCaps)) {
                allCaps = obtainStyledAttributes2.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
                b2 = true;
            }
            else {
                allCaps = false;
                b2 = false;
            }
            this.updateTypefaceAndStyle(context, obtainStyledAttributes2);
            if (Build$VERSION.SDK_INT < 23) {
                if (obtainStyledAttributes2.hasValue(R.styleable.TextAppearance_android_textColor)) {
                    textColor = obtainStyledAttributes2.getColorStateList(R.styleable.TextAppearance_android_textColor);
                }
                else {
                    textColor = null;
                }
                if (obtainStyledAttributes2.hasValue(R.styleable.TextAppearance_android_textColorHint)) {
                    hintTextColor = obtainStyledAttributes2.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
                }
                else {
                    hintTextColor = null;
                }
                if (obtainStyledAttributes2.hasValue(R.styleable.TextAppearance_android_textColorLink)) {
                    linkTextColor = obtainStyledAttributes2.getColorStateList(R.styleable.TextAppearance_android_textColorLink);
                }
                else {
                    linkTextColor = null;
                }
            }
            else {
                hintTextColor = null;
                linkTextColor = null;
                textColor = null;
            }
            if (obtainStyledAttributes2.hasValue(R.styleable.TextAppearance_textLocale)) {
                s = obtainStyledAttributes2.getString(R.styleable.TextAppearance_textLocale);
            }
            else {
                s = null;
            }
            if (Build$VERSION.SDK_INT >= 26 && obtainStyledAttributes2.hasValue(R.styleable.TextAppearance_fontVariationSettings)) {
                fontVariationSettings = obtainStyledAttributes2.getString(R.styleable.TextAppearance_fontVariationSettings);
            }
            else {
                fontVariationSettings = null;
            }
            obtainStyledAttributes2.recycle();
        }
        else {
            s = null;
            hintTextColor = null;
            fontVariationSettings = null;
            linkTextColor = null;
            allCaps = false;
            b2 = false;
            textColor = null;
        }
        final TintTypedArray obtainStyledAttributes3 = TintTypedArray.obtainStyledAttributes(context, set, R.styleable.TextAppearance, n, 0);
        if (!b && obtainStyledAttributes3.hasValue(R.styleable.TextAppearance_textAllCaps)) {
            allCaps = obtainStyledAttributes3.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
            b2 = true;
        }
        if (Build$VERSION.SDK_INT < 23) {
            if (obtainStyledAttributes3.hasValue(R.styleable.TextAppearance_android_textColor)) {
                textColor = obtainStyledAttributes3.getColorStateList(R.styleable.TextAppearance_android_textColor);
            }
            if (obtainStyledAttributes3.hasValue(R.styleable.TextAppearance_android_textColorHint)) {
                hintTextColor = obtainStyledAttributes3.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
            }
            if (obtainStyledAttributes3.hasValue(R.styleable.TextAppearance_android_textColorLink)) {
                linkTextColor = obtainStyledAttributes3.getColorStateList(R.styleable.TextAppearance_android_textColorLink);
            }
        }
        if (obtainStyledAttributes3.hasValue(R.styleable.TextAppearance_textLocale)) {
            s = obtainStyledAttributes3.getString(R.styleable.TextAppearance_textLocale);
        }
        if (Build$VERSION.SDK_INT >= 26 && obtainStyledAttributes3.hasValue(R.styleable.TextAppearance_fontVariationSettings)) {
            fontVariationSettings = obtainStyledAttributes3.getString(R.styleable.TextAppearance_fontVariationSettings);
        }
        AppCompatDrawableManager appCompatDrawableManager;
        if (Build$VERSION.SDK_INT >= 28 && obtainStyledAttributes3.hasValue(R.styleable.TextAppearance_android_textSize) && obtainStyledAttributes3.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, -1) == 0) {
            final TextView mView = this.mView;
            appCompatDrawableManager = value;
            mView.setTextSize(0, 0.0f);
        }
        else {
            appCompatDrawableManager = value;
        }
        this.updateTypefaceAndStyle(context, obtainStyledAttributes3);
        obtainStyledAttributes3.recycle();
        if (textColor != null) {
            this.mView.setTextColor(textColor);
        }
        if (hintTextColor != null) {
            this.mView.setHintTextColor(hintTextColor);
        }
        if (linkTextColor != null) {
            this.mView.setLinkTextColor(linkTextColor);
        }
        if (!b && b2) {
            this.setAllCaps(allCaps);
        }
        final Typeface mFontTypeface = this.mFontTypeface;
        if (mFontTypeface != null) {
            if (this.mFontWeight == -1) {
                this.mView.setTypeface(mFontTypeface, this.mStyle);
            }
            else {
                this.mView.setTypeface(mFontTypeface);
            }
        }
        if (fontVariationSettings != null) {
            this.mView.setFontVariationSettings(fontVariationSettings);
        }
        if (s != null) {
            if (Build$VERSION.SDK_INT >= 24) {
                this.mView.setTextLocales(LocaleList.forLanguageTags(s));
            }
            else if (Build$VERSION.SDK_INT >= 21) {
                this.mView.setTextLocale(Locale.forLanguageTag(s.substring(0, s.indexOf(44))));
            }
        }
        this.mAutoSizeTextHelper.loadFromAttributes(set, n);
        if (AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE && this.mAutoSizeTextHelper.getAutoSizeTextType() != 0) {
            final int[] autoSizeTextAvailableSizes = this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
            if (autoSizeTextAvailableSizes.length > 0) {
                if (this.mView.getAutoSizeStepGranularity() != -1.0f) {
                    this.mView.setAutoSizeTextTypeUniformWithConfiguration(this.mAutoSizeTextHelper.getAutoSizeMinTextSize(), this.mAutoSizeTextHelper.getAutoSizeMaxTextSize(), this.mAutoSizeTextHelper.getAutoSizeStepGranularity(), 0);
                }
                else {
                    this.mView.setAutoSizeTextTypeUniformWithPresetSizes(autoSizeTextAvailableSizes, 0);
                }
            }
        }
        final TintTypedArray obtainStyledAttributes4 = TintTypedArray.obtainStyledAttributes(context, set, R.styleable.AppCompatTextView);
        final int resourceId2 = obtainStyledAttributes4.getResourceId(R.styleable.AppCompatTextView_drawableLeftCompat, -1);
        final AppCompatDrawableManager appCompatDrawableManager2 = appCompatDrawableManager;
        Drawable drawable;
        if (resourceId2 != -1) {
            drawable = appCompatDrawableManager2.getDrawable(context, resourceId2);
        }
        else {
            drawable = null;
        }
        final int resourceId3 = obtainStyledAttributes4.getResourceId(R.styleable.AppCompatTextView_drawableTopCompat, -1);
        Drawable drawable2;
        if (resourceId3 != -1) {
            drawable2 = appCompatDrawableManager2.getDrawable(context, resourceId3);
        }
        else {
            drawable2 = null;
        }
        final int resourceId4 = obtainStyledAttributes4.getResourceId(R.styleable.AppCompatTextView_drawableRightCompat, -1);
        Drawable drawable3;
        if (resourceId4 != -1) {
            drawable3 = appCompatDrawableManager2.getDrawable(context, resourceId4);
        }
        else {
            drawable3 = null;
        }
        final int resourceId5 = obtainStyledAttributes4.getResourceId(R.styleable.AppCompatTextView_drawableBottomCompat, -1);
        Drawable drawable4;
        if (resourceId5 != -1) {
            drawable4 = appCompatDrawableManager2.getDrawable(context, resourceId5);
        }
        else {
            drawable4 = null;
        }
        final int resourceId6 = obtainStyledAttributes4.getResourceId(R.styleable.AppCompatTextView_drawableStartCompat, -1);
        Drawable drawable5;
        if (resourceId6 != -1) {
            drawable5 = appCompatDrawableManager2.getDrawable(context, resourceId6);
        }
        else {
            drawable5 = null;
        }
        final int resourceId7 = obtainStyledAttributes4.getResourceId(R.styleable.AppCompatTextView_drawableEndCompat, -1);
        Drawable drawable6;
        if (resourceId7 != -1) {
            drawable6 = appCompatDrawableManager2.getDrawable(context, resourceId7);
        }
        else {
            drawable6 = null;
        }
        this.setCompoundDrawables(drawable, drawable2, drawable3, drawable4, drawable5, drawable6);
        if (obtainStyledAttributes4.hasValue(R.styleable.AppCompatTextView_drawableTint)) {
            TextViewCompat.setCompoundDrawableTintList(this.mView, obtainStyledAttributes4.getColorStateList(R.styleable.AppCompatTextView_drawableTint));
        }
        int n2;
        if (obtainStyledAttributes4.hasValue(R.styleable.AppCompatTextView_drawableTintMode)) {
            final int appCompatTextView_drawableTintMode = R.styleable.AppCompatTextView_drawableTintMode;
            n2 = -1;
            TextViewCompat.setCompoundDrawableTintMode(this.mView, DrawableUtils.parseTintMode(obtainStyledAttributes4.getInt(appCompatTextView_drawableTintMode, n2), null));
        }
        else {
            n2 = -1;
        }
        final int dimensionPixelSize = obtainStyledAttributes4.getDimensionPixelSize(R.styleable.AppCompatTextView_firstBaselineToTopHeight, n2);
        final int dimensionPixelSize2 = obtainStyledAttributes4.getDimensionPixelSize(R.styleable.AppCompatTextView_lastBaselineToBottomHeight, n2);
        final int dimensionPixelSize3 = obtainStyledAttributes4.getDimensionPixelSize(R.styleable.AppCompatTextView_lineHeight, n2);
        obtainStyledAttributes4.recycle();
        if (dimensionPixelSize != n2) {
            TextViewCompat.setFirstBaselineToTopHeight(this.mView, dimensionPixelSize);
        }
        if (dimensionPixelSize2 != n2) {
            TextViewCompat.setLastBaselineToBottomHeight(this.mView, dimensionPixelSize2);
        }
        if (dimensionPixelSize3 != n2) {
            TextViewCompat.setLineHeight(this.mView, dimensionPixelSize3);
        }
    }
    
    void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        if (!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE) {
            this.autoSizeText();
        }
    }
    
    void onSetCompoundDrawables() {
        this.applyCompoundDrawablesTints();
    }
    
    void onSetTextAppearance(final Context context, final int n) {
        final TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, n, R.styleable.TextAppearance);
        if (obtainStyledAttributes.hasValue(R.styleable.TextAppearance_textAllCaps)) {
            this.setAllCaps(obtainStyledAttributes.getBoolean(R.styleable.TextAppearance_textAllCaps, false));
        }
        if (Build$VERSION.SDK_INT < 23 && obtainStyledAttributes.hasValue(R.styleable.TextAppearance_android_textColor)) {
            final ColorStateList colorStateList = obtainStyledAttributes.getColorStateList(R.styleable.TextAppearance_android_textColor);
            if (colorStateList != null) {
                this.mView.setTextColor(colorStateList);
            }
        }
        if (obtainStyledAttributes.hasValue(R.styleable.TextAppearance_android_textSize) && obtainStyledAttributes.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, -1) == 0) {
            this.mView.setTextSize(0, 0.0f);
        }
        this.updateTypefaceAndStyle(context, obtainStyledAttributes);
        if (Build$VERSION.SDK_INT >= 26 && obtainStyledAttributes.hasValue(R.styleable.TextAppearance_fontVariationSettings)) {
            final String string = obtainStyledAttributes.getString(R.styleable.TextAppearance_fontVariationSettings);
            if (string != null) {
                this.mView.setFontVariationSettings(string);
            }
        }
        obtainStyledAttributes.recycle();
        final Typeface mFontTypeface = this.mFontTypeface;
        if (mFontTypeface != null) {
            this.mView.setTypeface(mFontTypeface, this.mStyle);
        }
    }
    
    public void runOnUiThread(final Runnable runnable) {
        this.mView.post(runnable);
    }
    
    void setAllCaps(final boolean allCaps) {
        this.mView.setAllCaps(allCaps);
    }
    
    void setAutoSizeTextTypeUniformWithConfiguration(final int n, final int n2, final int n3, final int n4) throws IllegalArgumentException {
        this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithConfiguration(n, n2, n3, n4);
    }
    
    void setAutoSizeTextTypeUniformWithPresetSizes(final int[] array, final int n) throws IllegalArgumentException {
        this.mAutoSizeTextHelper.setAutoSizeTextTypeUniformWithPresetSizes(array, n);
    }
    
    void setAutoSizeTextTypeWithDefaults(final int autoSizeTextTypeWithDefaults) {
        this.mAutoSizeTextHelper.setAutoSizeTextTypeWithDefaults(autoSizeTextTypeWithDefaults);
    }
    
    void setCompoundDrawableTintList(final ColorStateList mTintList) {
        if (this.mDrawableTint == null) {
            this.mDrawableTint = new TintInfo();
        }
        this.mDrawableTint.mTintList = mTintList;
        this.mDrawableTint.mHasTintList = (mTintList != null);
        this.setCompoundTints();
    }
    
    void setCompoundDrawableTintMode(final PorterDuff$Mode mTintMode) {
        if (this.mDrawableTint == null) {
            this.mDrawableTint = new TintInfo();
        }
        this.mDrawableTint.mTintMode = mTintMode;
        this.mDrawableTint.mHasTintMode = (mTintMode != null);
        this.setCompoundTints();
    }
    
    void setTextSize(final int n, final float n2) {
        if (!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE && !this.isAutoSizeEnabled()) {
            this.setTextSizeInternal(n, n2);
        }
    }
    
    public void setTypefaceByCallback(final Typeface typeface) {
        if (this.mAsyncFontPending) {
            this.mView.setTypeface(typeface);
            this.mFontTypeface = typeface;
        }
    }
    
    private static class ApplyTextViewCallback extends FontCallback
    {
        private final int mFontWeight;
        private final WeakReference<AppCompatTextHelper> mParent;
        private final int mStyle;
        
        ApplyTextViewCallback(final AppCompatTextHelper referent, final int mFontWeight, final int mStyle) {
            this.mParent = new WeakReference<AppCompatTextHelper>(referent);
            this.mFontWeight = mFontWeight;
            this.mStyle = mStyle;
        }
        
        @Override
        public void onFontRetrievalFailed(final int n) {
        }
        
        @Override
        public void onFontRetrieved(Typeface create) {
            final AppCompatTextHelper appCompatTextHelper = this.mParent.get();
            if (appCompatTextHelper == null) {
                return;
            }
            if (Build$VERSION.SDK_INT >= 28) {
                final int mFontWeight = this.mFontWeight;
                if (mFontWeight != -1) {
                    create = Typeface.create(create, mFontWeight, (0x2 & this.mStyle) != 0x0);
                }
            }
            appCompatTextHelper.runOnUiThread(new TypefaceApplyCallback(this.mParent, create));
        }
        
        private class TypefaceApplyCallback implements Runnable
        {
            private final WeakReference<AppCompatTextHelper> mParent;
            private final Typeface mTypeface;
            
            TypefaceApplyCallback(final WeakReference<AppCompatTextHelper> mParent, final Typeface mTypeface) {
                this.mParent = mParent;
                this.mTypeface = mTypeface;
            }
            
            @Override
            public void run() {
                final AppCompatTextHelper appCompatTextHelper = this.mParent.get();
                if (appCompatTextHelper == null) {
                    return;
                }
                appCompatTextHelper.setTypefaceByCallback(this.mTypeface);
            }
        }
    }
}
