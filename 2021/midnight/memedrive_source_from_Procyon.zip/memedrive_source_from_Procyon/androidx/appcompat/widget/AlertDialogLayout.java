// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import android.graphics.drawable.Drawable;
import androidx.core.view.GravityCompat;
import androidx.appcompat.R;
import android.view.ViewGroup;
import androidx.core.view.ViewCompat;
import android.view.View;
import android.view.View$MeasureSpec;
import android.util.AttributeSet;
import android.content.Context;

public class AlertDialogLayout extends LinearLayoutCompat
{
    public AlertDialogLayout(final Context context) {
        super(context);
    }
    
    public AlertDialogLayout(final Context context, final AttributeSet set) {
        super(context, set);
    }
    
    private void forceUniformWidth(final int n, final int n2) {
        final int measureSpec = View$MeasureSpec.makeMeasureSpec(this.getMeasuredWidth(), 1073741824);
        for (int i = 0; i < n; ++i) {
            final View child = this.getChildAt(i);
            if (child.getVisibility() != 8) {
                final LayoutParams layoutParams = (LayoutParams)child.getLayoutParams();
                if (layoutParams.width == -1) {
                    final int height = layoutParams.height;
                    layoutParams.height = child.getMeasuredHeight();
                    this.measureChildWithMargins(child, measureSpec, 0, n2, 0);
                    layoutParams.height = height;
                }
            }
        }
    }
    
    private static int resolveMinimumHeight(final View view) {
        final int minimumHeight = ViewCompat.getMinimumHeight(view);
        if (minimumHeight > 0) {
            return minimumHeight;
        }
        if (view instanceof ViewGroup) {
            final ViewGroup viewGroup = (ViewGroup)view;
            if (viewGroup.getChildCount() == 1) {
                return resolveMinimumHeight(viewGroup.getChildAt(0));
            }
        }
        return 0;
    }
    
    private void setChildFrame(final View view, final int n, final int n2, final int n3, final int n4) {
        view.layout(n, n2, n3 + n, n4 + n2);
    }
    
    private boolean tryOnMeasure(final int n, final int n2) {
        final int childCount = this.getChildCount();
        View view = null;
        View view2 = null;
        View view3 = null;
        for (int i = 0; i < childCount; ++i) {
            final View child = this.getChildAt(i);
            if (child.getVisibility() != 8) {
                final int id = child.getId();
                if (id == R.id.topPanel) {
                    view = child;
                }
                else if (id == R.id.buttonPanel) {
                    view2 = child;
                }
                else {
                    if (id != R.id.contentPanel && id != R.id.customPanel) {
                        return false;
                    }
                    if (view3 != null) {
                        return false;
                    }
                    view3 = child;
                }
            }
        }
        final int mode = View$MeasureSpec.getMode(n2);
        final int size = View$MeasureSpec.getSize(n2);
        final int mode2 = View$MeasureSpec.getMode(n);
        int n3 = this.getPaddingTop() + this.getPaddingBottom();
        int n4;
        if (view != null) {
            view.measure(n, 0);
            n3 += view.getMeasuredHeight();
            n4 = View.combineMeasuredStates(0, view.getMeasuredState());
        }
        else {
            n4 = 0;
        }
        int resolveMinimumHeight;
        int b;
        if (view2 != null) {
            view2.measure(n, 0);
            resolveMinimumHeight = resolveMinimumHeight(view2);
            b = view2.getMeasuredHeight() - resolveMinimumHeight;
            n3 += resolveMinimumHeight;
            n4 = View.combineMeasuredStates(n4, view2.getMeasuredState());
        }
        else {
            resolveMinimumHeight = 0;
            b = 0;
        }
        int measuredHeight;
        if (view3 != null) {
            int measureSpec;
            if (mode == 0) {
                measureSpec = 0;
            }
            else {
                measureSpec = View$MeasureSpec.makeMeasureSpec(Math.max(0, size - n3), mode);
            }
            view3.measure(n, measureSpec);
            measuredHeight = view3.getMeasuredHeight();
            n3 += measuredHeight;
            n4 = View.combineMeasuredStates(n4, view3.getMeasuredState());
        }
        else {
            measuredHeight = 0;
        }
        int a = size - n3;
        if (view2 != null) {
            final int n5 = n3 - resolveMinimumHeight;
            final int min = Math.min(a, b);
            if (min > 0) {
                a -= min;
                resolveMinimumHeight += min;
            }
            view2.measure(n, View$MeasureSpec.makeMeasureSpec(resolveMinimumHeight, 1073741824));
            n3 = n5 + view2.getMeasuredHeight();
            n4 = View.combineMeasuredStates(n4, view2.getMeasuredState());
        }
        if (view3 != null && a > 0) {
            final int n6 = n3 - measuredHeight;
            view3.measure(n, View$MeasureSpec.makeMeasureSpec(measuredHeight + a, mode));
            n3 = n6 + view3.getMeasuredHeight();
            n4 = View.combineMeasuredStates(n4, view3.getMeasuredState());
        }
        int j = 0;
        int max = 0;
        while (j < childCount) {
            final View child2 = this.getChildAt(j);
            if (child2.getVisibility() != 8) {
                max = Math.max(max, child2.getMeasuredWidth());
            }
            ++j;
        }
        this.setMeasuredDimension(View.resolveSizeAndState(max + (this.getPaddingLeft() + this.getPaddingRight()), n, n4), View.resolveSizeAndState(n3, n2, 0));
        if (mode2 != 1073741824) {
            this.forceUniformWidth(childCount, n2);
        }
        return true;
    }
    
    @Override
    protected void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        final int paddingLeft = this.getPaddingLeft();
        final int n5 = n3 - n;
        final int n6 = n5 - this.getPaddingRight();
        final int n7 = n5 - paddingLeft - this.getPaddingRight();
        final int measuredHeight = this.getMeasuredHeight();
        final int childCount = this.getChildCount();
        final int gravity = this.getGravity();
        final int n8 = gravity & 0x70;
        final int n9 = gravity & 0x800007;
        int paddingTop;
        if (n8 != 16) {
            if (n8 != 80) {
                paddingTop = this.getPaddingTop();
            }
            else {
                paddingTop = n4 + this.getPaddingTop() - n2 - measuredHeight;
            }
        }
        else {
            paddingTop = this.getPaddingTop() + (n4 - n2 - measuredHeight) / 2;
        }
        final Drawable dividerDrawable = this.getDividerDrawable();
        int intrinsicHeight;
        if (dividerDrawable == null) {
            intrinsicHeight = 0;
        }
        else {
            intrinsicHeight = dividerDrawable.getIntrinsicHeight();
        }
        for (int i = 0; i < childCount; ++i) {
            final View child = this.getChildAt(i);
            if (child != null && child.getVisibility() != 8) {
                final int measuredWidth = child.getMeasuredWidth();
                final int measuredHeight2 = child.getMeasuredHeight();
                final LayoutParams layoutParams = (LayoutParams)child.getLayoutParams();
                int gravity2 = layoutParams.gravity;
                if (gravity2 < 0) {
                    gravity2 = n9;
                }
                final int n10 = 0x7 & GravityCompat.getAbsoluteGravity(gravity2, ViewCompat.getLayoutDirection((View)this));
                int n11 = 0;
                Label_0306: {
                    int n12;
                    int n13;
                    if (n10 != 1) {
                        if (n10 != 5) {
                            n11 = paddingLeft + layoutParams.leftMargin;
                            break Label_0306;
                        }
                        n12 = n6 - measuredWidth;
                        n13 = layoutParams.rightMargin;
                    }
                    else {
                        n12 = paddingLeft + (n7 - measuredWidth) / 2 + layoutParams.leftMargin;
                        n13 = layoutParams.rightMargin;
                    }
                    n11 = n12 - n13;
                }
                if (this.hasDividerBeforeChildAt(i)) {
                    paddingTop += intrinsicHeight;
                }
                final int n14 = paddingTop + layoutParams.topMargin;
                this.setChildFrame(child, n11, n14, measuredWidth, measuredHeight2);
                paddingTop = n14 + (measuredHeight2 + layoutParams.bottomMargin);
            }
        }
    }
    
    @Override
    protected void onMeasure(final int n, final int n2) {
        if (!this.tryOnMeasure(n, n2)) {
            super.onMeasure(n, n2);
        }
    }
}
