// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.MenuBuilder;

public interface MenuItemHoverListener
{
    void onItemHoverEnter(final MenuBuilder p0, final MenuItem p1);
    
    void onItemHoverExit(final MenuBuilder p0, final MenuItem p1);
}
