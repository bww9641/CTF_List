// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import androidx.core.view.ViewPropertyAnimatorCompat;
import android.view.View$MeasureSpec;
import android.view.accessibility.AccessibilityEvent;
import android.view.MotionEvent;
import android.graphics.drawable.Drawable;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.view.menu.MenuBuilder;
import android.view.View$OnClickListener;
import androidx.appcompat.view.ActionMode;
import android.view.ViewGroup$MarginLayoutParams;
import android.view.ViewGroup$LayoutParams;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import androidx.core.view.ViewCompat;
import androidx.appcompat.R;
import android.util.AttributeSet;
import android.content.Context;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.View;

public class ActionBarContextView extends AbsActionBarView
{
    private static final String TAG = "ActionBarContextView";
    private View mClose;
    private int mCloseItemLayout;
    private View mCustomView;
    private CharSequence mSubtitle;
    private int mSubtitleStyleRes;
    private TextView mSubtitleView;
    private CharSequence mTitle;
    private LinearLayout mTitleLayout;
    private boolean mTitleOptional;
    private int mTitleStyleRes;
    private TextView mTitleView;
    
    public ActionBarContextView(final Context context) {
        this(context, null);
    }
    
    public ActionBarContextView(final Context context, final AttributeSet set) {
        this(context, set, R.attr.actionModeStyle);
    }
    
    public ActionBarContextView(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        final TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, set, R.styleable.ActionMode, n, 0);
        ViewCompat.setBackground((View)this, obtainStyledAttributes.getDrawable(R.styleable.ActionMode_background));
        this.mTitleStyleRes = obtainStyledAttributes.getResourceId(R.styleable.ActionMode_titleTextStyle, 0);
        this.mSubtitleStyleRes = obtainStyledAttributes.getResourceId(R.styleable.ActionMode_subtitleTextStyle, 0);
        this.mContentHeight = obtainStyledAttributes.getLayoutDimension(R.styleable.ActionMode_height, 0);
        this.mCloseItemLayout = obtainStyledAttributes.getResourceId(R.styleable.ActionMode_closeItemLayout, R.layout.abc_action_mode_close_item_material);
        obtainStyledAttributes.recycle();
    }
    
    private void initTitle() {
        if (this.mTitleLayout == null) {
            LayoutInflater.from(this.getContext()).inflate(R.layout.abc_action_bar_title_item, (ViewGroup)this);
            final LinearLayout mTitleLayout = (LinearLayout)this.getChildAt(-1 + this.getChildCount());
            this.mTitleLayout = mTitleLayout;
            this.mTitleView = (TextView)mTitleLayout.findViewById(R.id.action_bar_title);
            this.mSubtitleView = (TextView)this.mTitleLayout.findViewById(R.id.action_bar_subtitle);
            if (this.mTitleStyleRes != 0) {
                this.mTitleView.setTextAppearance(this.getContext(), this.mTitleStyleRes);
            }
            if (this.mSubtitleStyleRes != 0) {
                this.mSubtitleView.setTextAppearance(this.getContext(), this.mSubtitleStyleRes);
            }
        }
        this.mTitleView.setText(this.mTitle);
        this.mSubtitleView.setText(this.mSubtitle);
        final boolean b = true ^ TextUtils.isEmpty(this.mTitle);
        final boolean b2 = true ^ TextUtils.isEmpty(this.mSubtitle);
        final TextView mSubtitleView = this.mSubtitleView;
        int visibility;
        if (b2) {
            visibility = 0;
        }
        else {
            visibility = 8;
        }
        mSubtitleView.setVisibility(visibility);
        final LinearLayout mTitleLayout2 = this.mTitleLayout;
        int visibility2 = 0;
        if (!b) {
            if (b2) {
                visibility2 = 0;
            }
            else {
                visibility2 = 8;
            }
        }
        mTitleLayout2.setVisibility(visibility2);
        if (this.mTitleLayout.getParent() == null) {
            this.addView((View)this.mTitleLayout);
        }
    }
    
    public void closeMode() {
        if (this.mClose == null) {
            this.killMode();
        }
    }
    
    protected ViewGroup$LayoutParams generateDefaultLayoutParams() {
        return (ViewGroup$LayoutParams)new ViewGroup$MarginLayoutParams(-1, -2);
    }
    
    public ViewGroup$LayoutParams generateLayoutParams(final AttributeSet set) {
        return (ViewGroup$LayoutParams)new ViewGroup$MarginLayoutParams(this.getContext(), set);
    }
    
    public CharSequence getSubtitle() {
        return this.mSubtitle;
    }
    
    public CharSequence getTitle() {
        return this.mTitle;
    }
    
    @Override
    public boolean hideOverflowMenu() {
        return this.mActionMenuPresenter != null && this.mActionMenuPresenter.hideOverflowMenu();
    }
    
    public void initForMode(final ActionMode actionMode) {
        final View mClose = this.mClose;
        if (mClose == null) {
            this.addView(this.mClose = LayoutInflater.from(this.getContext()).inflate(this.mCloseItemLayout, (ViewGroup)this, false));
        }
        else if (mClose.getParent() == null) {
            this.addView(this.mClose);
        }
        this.mClose.findViewById(R.id.action_mode_close_button).setOnClickListener((View$OnClickListener)new View$OnClickListener() {
            public void onClick(final View view) {
                actionMode.finish();
            }
        });
        final MenuBuilder menuBuilder = (MenuBuilder)actionMode.getMenu();
        if (this.mActionMenuPresenter != null) {
            this.mActionMenuPresenter.dismissPopupMenus();
        }
        (this.mActionMenuPresenter = new ActionMenuPresenter(this.getContext())).setReserveOverflow(true);
        final ViewGroup$LayoutParams viewGroup$LayoutParams = new ViewGroup$LayoutParams(-2, -1);
        menuBuilder.addMenuPresenter(this.mActionMenuPresenter, this.mPopupContext);
        ViewCompat.setBackground((View)(this.mMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this)), null);
        this.addView((View)this.mMenuView, viewGroup$LayoutParams);
    }
    
    @Override
    public boolean isOverflowMenuShowing() {
        return this.mActionMenuPresenter != null && this.mActionMenuPresenter.isOverflowMenuShowing();
    }
    
    public boolean isTitleOptional() {
        return this.mTitleOptional;
    }
    
    public void killMode() {
        this.removeAllViews();
        this.mCustomView = null;
        this.mMenuView = null;
    }
    
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.mActionMenuPresenter != null) {
            this.mActionMenuPresenter.hideOverflowMenu();
            this.mActionMenuPresenter.hideSubMenus();
        }
    }
    
    public void onInitializeAccessibilityEvent(final AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource((View)this);
            accessibilityEvent.setClassName((CharSequence)this.getClass().getName());
            accessibilityEvent.setPackageName((CharSequence)this.getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.mTitle);
        }
        else {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
        }
    }
    
    protected void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        final boolean layoutRtl = ViewUtils.isLayoutRtl((View)this);
        int n5;
        if (layoutRtl) {
            n5 = n3 - n - this.getPaddingRight();
        }
        else {
            n5 = this.getPaddingLeft();
        }
        final int paddingTop = this.getPaddingTop();
        final int n6 = n4 - n2 - this.getPaddingTop() - this.getPaddingBottom();
        final View mClose = this.mClose;
        if (mClose != null && mClose.getVisibility() != 8) {
            final ViewGroup$MarginLayoutParams viewGroup$MarginLayoutParams = (ViewGroup$MarginLayoutParams)this.mClose.getLayoutParams();
            int n7;
            if (layoutRtl) {
                n7 = viewGroup$MarginLayoutParams.rightMargin;
            }
            else {
                n7 = viewGroup$MarginLayoutParams.leftMargin;
            }
            int n8;
            if (layoutRtl) {
                n8 = viewGroup$MarginLayoutParams.leftMargin;
            }
            else {
                n8 = viewGroup$MarginLayoutParams.rightMargin;
            }
            final int next = AbsActionBarView.next(n5, n7, layoutRtl);
            n5 = AbsActionBarView.next(next + this.positionChild(this.mClose, next, paddingTop, n6, layoutRtl), n8, layoutRtl);
        }
        int n9 = n5;
        final LinearLayout mTitleLayout = this.mTitleLayout;
        if (mTitleLayout != null && this.mCustomView == null && mTitleLayout.getVisibility() != 8) {
            n9 += this.positionChild((View)this.mTitleLayout, n9, paddingTop, n6, layoutRtl);
        }
        final int n10 = n9;
        final View mCustomView = this.mCustomView;
        if (mCustomView != null) {
            this.positionChild(mCustomView, n10, paddingTop, n6, layoutRtl);
        }
        int paddingLeft;
        if (layoutRtl) {
            paddingLeft = this.getPaddingLeft();
        }
        else {
            paddingLeft = n3 - n - this.getPaddingRight();
        }
        if (this.mMenuView != null) {
            this.positionChild((View)this.mMenuView, paddingLeft, paddingTop, n6, layoutRtl ^ true);
        }
    }
    
    protected void onMeasure(final int n, final int n2) {
        final int mode = View$MeasureSpec.getMode(n);
        int n3 = 1073741824;
        if (mode != n3) {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.getClass().getSimpleName());
            sb.append(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
            throw new IllegalStateException(sb.toString());
        }
        if (View$MeasureSpec.getMode(n2) != 0) {
            final int size = View$MeasureSpec.getSize(n);
            int n4;
            if (this.mContentHeight > 0) {
                n4 = this.mContentHeight;
            }
            else {
                n4 = View$MeasureSpec.getSize(n2);
            }
            final int n5 = this.getPaddingTop() + this.getPaddingBottom();
            int b = size - this.getPaddingLeft() - this.getPaddingRight();
            int min = n4 - n5;
            final int measureSpec = View$MeasureSpec.makeMeasureSpec(min, Integer.MIN_VALUE);
            final View mClose = this.mClose;
            int i = 0;
            if (mClose != null) {
                final int measureChildView = this.measureChildView(mClose, b, measureSpec, 0);
                final ViewGroup$MarginLayoutParams viewGroup$MarginLayoutParams = (ViewGroup$MarginLayoutParams)this.mClose.getLayoutParams();
                b = measureChildView - (viewGroup$MarginLayoutParams.leftMargin + viewGroup$MarginLayoutParams.rightMargin);
            }
            if (this.mMenuView != null && this.mMenuView.getParent() == this) {
                b = this.measureChildView((View)this.mMenuView, b, measureSpec, 0);
            }
            final LinearLayout mTitleLayout = this.mTitleLayout;
            if (mTitleLayout != null && this.mCustomView == null) {
                if (this.mTitleOptional) {
                    this.mTitleLayout.measure(View$MeasureSpec.makeMeasureSpec(0, 0), measureSpec);
                    final int measuredWidth = this.mTitleLayout.getMeasuredWidth();
                    final boolean b2 = measuredWidth <= b;
                    if (b2) {
                        b -= measuredWidth;
                    }
                    final LinearLayout mTitleLayout2 = this.mTitleLayout;
                    int visibility;
                    if (b2) {
                        visibility = 0;
                    }
                    else {
                        visibility = 8;
                    }
                    mTitleLayout2.setVisibility(visibility);
                }
                else {
                    b = this.measureChildView((View)mTitleLayout, b, measureSpec, 0);
                }
            }
            final View mCustomView = this.mCustomView;
            if (mCustomView != null) {
                final ViewGroup$LayoutParams layoutParams = mCustomView.getLayoutParams();
                int n6;
                if (layoutParams.width != -2) {
                    n6 = 1073741824;
                }
                else {
                    n6 = Integer.MIN_VALUE;
                }
                if (layoutParams.width >= 0) {
                    b = Math.min(layoutParams.width, b);
                }
                if (layoutParams.height == -2) {
                    n3 = Integer.MIN_VALUE;
                }
                if (layoutParams.height >= 0) {
                    min = Math.min(layoutParams.height, min);
                }
                this.mCustomView.measure(View$MeasureSpec.makeMeasureSpec(b, n6), View$MeasureSpec.makeMeasureSpec(min, n3));
            }
            if (this.mContentHeight <= 0) {
                final int childCount = this.getChildCount();
                int n7 = 0;
                while (i < childCount) {
                    final int n8 = n5 + this.getChildAt(i).getMeasuredHeight();
                    if (n8 > n7) {
                        n7 = n8;
                    }
                    ++i;
                }
                this.setMeasuredDimension(size, n7);
            }
            else {
                this.setMeasuredDimension(size, n4);
            }
            return;
        }
        final StringBuilder sb2 = new StringBuilder();
        sb2.append(this.getClass().getSimpleName());
        sb2.append(" can only be used with android:layout_height=\"wrap_content\"");
        throw new IllegalStateException(sb2.toString());
    }
    
    @Override
    public void setContentHeight(final int mContentHeight) {
        this.mContentHeight = mContentHeight;
    }
    
    public void setCustomView(final View mCustomView) {
        final View mCustomView2 = this.mCustomView;
        if (mCustomView2 != null) {
            this.removeView(mCustomView2);
        }
        if ((this.mCustomView = mCustomView) != null) {
            final LinearLayout mTitleLayout = this.mTitleLayout;
            if (mTitleLayout != null) {
                this.removeView((View)mTitleLayout);
                this.mTitleLayout = null;
            }
        }
        if (mCustomView != null) {
            this.addView(mCustomView);
        }
        this.requestLayout();
    }
    
    public void setSubtitle(final CharSequence mSubtitle) {
        this.mSubtitle = mSubtitle;
        this.initTitle();
    }
    
    public void setTitle(final CharSequence mTitle) {
        this.mTitle = mTitle;
        this.initTitle();
    }
    
    public void setTitleOptional(final boolean mTitleOptional) {
        if (mTitleOptional != this.mTitleOptional) {
            this.requestLayout();
        }
        this.mTitleOptional = mTitleOptional;
    }
    
    public boolean shouldDelayChildPressedState() {
        return false;
    }
    
    @Override
    public boolean showOverflowMenu() {
        return this.mActionMenuPresenter != null && this.mActionMenuPresenter.showOverflowMenu();
    }
}
