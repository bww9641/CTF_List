// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import android.util.AttributeSet;
import android.os.Build$VERSION;
import android.graphics.drawable.Drawable;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.widget.CompoundButtonCompat;
import android.widget.CompoundButton;
import android.graphics.PorterDuff$Mode;
import android.content.res.ColorStateList;

class AppCompatCompoundButtonHelper
{
    private ColorStateList mButtonTintList;
    private PorterDuff$Mode mButtonTintMode;
    private boolean mHasButtonTint;
    private boolean mHasButtonTintMode;
    private boolean mSkipNextApply;
    private final CompoundButton mView;
    
    AppCompatCompoundButtonHelper(final CompoundButton mView) {
        this.mButtonTintList = null;
        this.mButtonTintMode = null;
        this.mHasButtonTint = false;
        this.mHasButtonTintMode = false;
        this.mView = mView;
    }
    
    void applyButtonTint() {
        final Drawable buttonDrawable = CompoundButtonCompat.getButtonDrawable(this.mView);
        if (buttonDrawable != null && (this.mHasButtonTint || this.mHasButtonTintMode)) {
            final Drawable mutate = DrawableCompat.wrap(buttonDrawable).mutate();
            if (this.mHasButtonTint) {
                DrawableCompat.setTintList(mutate, this.mButtonTintList);
            }
            if (this.mHasButtonTintMode) {
                DrawableCompat.setTintMode(mutate, this.mButtonTintMode);
            }
            if (mutate.isStateful()) {
                mutate.setState(this.mView.getDrawableState());
            }
            this.mView.setButtonDrawable(mutate);
        }
    }
    
    int getCompoundPaddingLeft(int n) {
        if (Build$VERSION.SDK_INT < 17) {
            final Drawable buttonDrawable = CompoundButtonCompat.getButtonDrawable(this.mView);
            if (buttonDrawable != null) {
                n += buttonDrawable.getIntrinsicWidth();
            }
        }
        return n;
    }
    
    ColorStateList getSupportButtonTintList() {
        return this.mButtonTintList;
    }
    
    PorterDuff$Mode getSupportButtonTintMode() {
        return this.mButtonTintMode;
    }
    
    void loadFromAttributes(final AttributeSet p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     4: invokevirtual   android/widget/CompoundButton.getContext:()Landroid/content/Context;
        //     7: aload_1        
        //     8: getstatic       androidx/appcompat/R$styleable.CompoundButton:[I
        //    11: iload_2        
        //    12: iconst_0       
        //    13: invokevirtual   android/content/Context.obtainStyledAttributes:(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
        //    16: astore_3       
        //    17: aload_3        
        //    18: getstatic       androidx/appcompat/R$styleable.CompoundButton_buttonCompat:I
        //    21: invokevirtual   android/content/res/TypedArray.hasValue:(I)Z
        //    24: ifeq            69
        //    27: aload_3        
        //    28: getstatic       androidx/appcompat/R$styleable.CompoundButton_buttonCompat:I
        //    31: iconst_0       
        //    32: invokevirtual   android/content/res/TypedArray.getResourceId:(II)I
        //    35: istore          8
        //    37: iload           8
        //    39: ifeq            69
        //    42: aload_0        
        //    43: getfield        androidx/appcompat/widget/AppCompatCompoundButtonHelper.mView:Landroid/widget/CompoundButton;
        //    46: astore          9
        //    48: aload           9
        //    50: aload           9
        //    52: invokevirtual   android/widget/CompoundButton.getContext:()Landroid/content/Context;
        //    55: iload           8
        //    57: invokestatic    androidx/appcompat/content/res/AppCompatResources.getDrawable:(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
        //    60: invokevirtual   android/widget/CompoundButton.setButtonDrawable:(Landroid/graphics/drawable/Drawable;)V
        //    63: iconst_1       
        //    64: istore          5
        //    66: goto            72
        //    69: iconst_0       
        //    70: istore          5
        //    72: iload           5
        //    74: ifne            123
        //    77: aload_3        
        //    78: getstatic       androidx/appcompat/R$styleable.CompoundButton_android_button:I
        //    81: invokevirtual   android/content/res/TypedArray.hasValue:(I)Z
        //    84: ifeq            123
        //    87: aload_3        
        //    88: getstatic       androidx/appcompat/R$styleable.CompoundButton_android_button:I
        //    91: iconst_0       
        //    92: invokevirtual   android/content/res/TypedArray.getResourceId:(II)I
        //    95: istore          6
        //    97: iload           6
        //    99: ifeq            123
        //   102: aload_0        
        //   103: getfield        androidx/appcompat/widget/AppCompatCompoundButtonHelper.mView:Landroid/widget/CompoundButton;
        //   106: astore          7
        //   108: aload           7
        //   110: aload           7
        //   112: invokevirtual   android/widget/CompoundButton.getContext:()Landroid/content/Context;
        //   115: iload           6
        //   117: invokestatic    androidx/appcompat/content/res/AppCompatResources.getDrawable:(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
        //   120: invokevirtual   android/widget/CompoundButton.setButtonDrawable:(Landroid/graphics/drawable/Drawable;)V
        //   123: aload_3        
        //   124: getstatic       androidx/appcompat/R$styleable.CompoundButton_buttonTint:I
        //   127: invokevirtual   android/content/res/TypedArray.hasValue:(I)Z
        //   130: ifeq            147
        //   133: aload_0        
        //   134: getfield        androidx/appcompat/widget/AppCompatCompoundButtonHelper.mView:Landroid/widget/CompoundButton;
        //   137: aload_3        
        //   138: getstatic       androidx/appcompat/R$styleable.CompoundButton_buttonTint:I
        //   141: invokevirtual   android/content/res/TypedArray.getColorStateList:(I)Landroid/content/res/ColorStateList;
        //   144: invokestatic    androidx/core/widget/CompoundButtonCompat.setButtonTintList:(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V
        //   147: aload_3        
        //   148: getstatic       androidx/appcompat/R$styleable.CompoundButton_buttonTintMode:I
        //   151: invokevirtual   android/content/res/TypedArray.hasValue:(I)Z
        //   154: ifeq            176
        //   157: aload_0        
        //   158: getfield        androidx/appcompat/widget/AppCompatCompoundButtonHelper.mView:Landroid/widget/CompoundButton;
        //   161: aload_3        
        //   162: getstatic       androidx/appcompat/R$styleable.CompoundButton_buttonTintMode:I
        //   165: iconst_m1      
        //   166: invokevirtual   android/content/res/TypedArray.getInt:(II)I
        //   169: aconst_null    
        //   170: invokestatic    androidx/appcompat/widget/DrawableUtils.parseTintMode:(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;
        //   173: invokestatic    androidx/core/widget/CompoundButtonCompat.setButtonTintMode:(Landroid/widget/CompoundButton;Landroid/graphics/PorterDuff$Mode;)V
        //   176: aload_3        
        //   177: invokevirtual   android/content/res/TypedArray.recycle:()V
        //   180: return         
        //   181: astore          4
        //   183: aload_3        
        //   184: invokevirtual   android/content/res/TypedArray.recycle:()V
        //   187: aload           4
        //   189: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                             
        //  -----  -----  -----  -----  -------------------------------------------------
        //  17     37     181    190    Any
        //  42     63     69     72     Landroid/content/res/Resources$NotFoundException;
        //  42     63     181    190    Any
        //  77     176    181    190    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0072 (coming from #0070).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    void onSetButtonDrawable() {
        if (this.mSkipNextApply) {
            this.mSkipNextApply = false;
            return;
        }
        this.mSkipNextApply = true;
        this.applyButtonTint();
    }
    
    void setSupportButtonTintList(final ColorStateList mButtonTintList) {
        this.mButtonTintList = mButtonTintList;
        this.mHasButtonTint = true;
        this.applyButtonTint();
    }
    
    void setSupportButtonTintMode(final PorterDuff$Mode mButtonTintMode) {
        this.mButtonTintMode = mButtonTintMode;
        this.mHasButtonTintMode = true;
        this.applyButtonTint();
    }
    
    interface DirectSetButtonDrawableInterface
    {
        void setButtonDrawable(final Drawable p0);
    }
}
