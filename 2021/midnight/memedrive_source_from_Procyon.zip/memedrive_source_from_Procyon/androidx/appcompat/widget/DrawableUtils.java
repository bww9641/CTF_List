// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import android.graphics.PorterDuff$Mode;
import android.graphics.drawable.Drawable$ConstantState;
import android.graphics.drawable.ScaleDrawable;
import androidx.appcompat.graphics.drawable.DrawableWrapper;
import androidx.core.graphics.drawable.WrappedDrawable;
import android.graphics.drawable.DrawableContainer$DrawableContainerState;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build$VERSION;
import android.graphics.Rect;

public class DrawableUtils
{
    private static final int[] CHECKED_STATE_SET;
    private static final int[] EMPTY_STATE_SET;
    public static final Rect INSETS_NONE;
    private static final String TAG = "DrawableUtils";
    private static final String VECTOR_DRAWABLE_CLAZZ_NAME = "android.graphics.drawable.VectorDrawable";
    private static Class<?> sInsetsClazz;
    
    static {
        CHECKED_STATE_SET = new int[] { 16842912 };
        EMPTY_STATE_SET = new int[0];
        INSETS_NONE = new Rect();
        if (Build$VERSION.SDK_INT >= 18) {
            try {
                DrawableUtils.sInsetsClazz = Class.forName("android.graphics.Insets");
            }
            catch (ClassNotFoundException ex) {}
        }
    }
    
    private DrawableUtils() {
    }
    
    public static boolean canSafelyMutateDrawable(final Drawable drawable) {
        if (Build$VERSION.SDK_INT < 15 && drawable instanceof InsetDrawable) {
            return false;
        }
        if (Build$VERSION.SDK_INT < 15 && drawable instanceof GradientDrawable) {
            return false;
        }
        if (Build$VERSION.SDK_INT < 17 && drawable instanceof LayerDrawable) {
            return false;
        }
        if (drawable instanceof DrawableContainer) {
            final Drawable$ConstantState constantState = drawable.getConstantState();
            if (constantState instanceof DrawableContainer$DrawableContainerState) {
                final Drawable[] children = ((DrawableContainer$DrawableContainerState)constantState).getChildren();
                for (int length = children.length, i = 0; i < length; ++i) {
                    if (!canSafelyMutateDrawable(children[i])) {
                        return false;
                    }
                }
            }
        }
        else {
            if (drawable instanceof WrappedDrawable) {
                return canSafelyMutateDrawable(((WrappedDrawable)drawable).getWrappedDrawable());
            }
            if (drawable instanceof DrawableWrapper) {
                return canSafelyMutateDrawable(((DrawableWrapper)drawable).getWrappedDrawable());
            }
            if (drawable instanceof ScaleDrawable) {
                return canSafelyMutateDrawable(((ScaleDrawable)drawable).getDrawable());
            }
        }
        return true;
    }
    
    static void fixDrawable(final Drawable drawable) {
        if (Build$VERSION.SDK_INT == 21 && "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName())) {
            fixVectorDrawableTinting(drawable);
        }
    }
    
    private static void fixVectorDrawableTinting(final Drawable drawable) {
        final int[] state = drawable.getState();
        if (state != null && state.length != 0) {
            drawable.setState(DrawableUtils.EMPTY_STATE_SET);
        }
        else {
            drawable.setState(DrawableUtils.CHECKED_STATE_SET);
        }
        drawable.setState(state);
    }
    
    public static Rect getOpticalBounds(final Drawable p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          29
        //     5: if_icmplt       66
        //     8: aload_0        
        //     9: invokevirtual   android/graphics/drawable/Drawable.getOpticalInsets:()Landroid/graphics/Insets;
        //    12: astore          11
        //    14: new             Landroid/graphics/Rect;
        //    17: dup            
        //    18: invokespecial   android/graphics/Rect.<init>:()V
        //    21: astore          12
        //    23: aload           12
        //    25: aload           11
        //    27: getfield        android/graphics/Insets.left:I
        //    30: putfield        android/graphics/Rect.left:I
        //    33: aload           12
        //    35: aload           11
        //    37: getfield        android/graphics/Insets.right:I
        //    40: putfield        android/graphics/Rect.right:I
        //    43: aload           12
        //    45: aload           11
        //    47: getfield        android/graphics/Insets.top:I
        //    50: putfield        android/graphics/Rect.top:I
        //    53: aload           12
        //    55: aload           11
        //    57: getfield        android/graphics/Insets.bottom:I
        //    60: putfield        android/graphics/Rect.bottom:I
        //    63: aload           12
        //    65: areturn        
        //    66: getstatic       androidx/appcompat/widget/DrawableUtils.sInsetsClazz:Ljava/lang/Class;
        //    69: ifnull          334
        //    72: aload_0        
        //    73: invokestatic    androidx/core/graphics/drawable/DrawableCompat.unwrap:(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
        //    76: astore_2       
        //    77: aload_2        
        //    78: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    81: ldc             "getOpticalInsets"
        //    83: iconst_0       
        //    84: anewarray       Ljava/lang/Class;
        //    87: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //    90: aload_2        
        //    91: iconst_0       
        //    92: anewarray       Ljava/lang/Object;
        //    95: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //    98: astore_3       
        //    99: aload_3        
        //   100: ifnull          334
        //   103: new             Landroid/graphics/Rect;
        //   106: dup            
        //   107: invokespecial   android/graphics/Rect.<init>:()V
        //   110: astore          4
        //   112: getstatic       androidx/appcompat/widget/DrawableUtils.sInsetsClazz:Ljava/lang/Class;
        //   115: invokevirtual   java/lang/Class.getFields:()[Ljava/lang/reflect/Field;
        //   118: astore          5
        //   120: aload           5
        //   122: arraylength    
        //   123: istore          6
        //   125: iconst_0       
        //   126: istore          7
        //   128: iload           7
        //   130: iload           6
        //   132: if_icmpge       323
        //   135: aload           5
        //   137: iload           7
        //   139: aaload         
        //   140: astore          8
        //   142: aload           8
        //   144: invokevirtual   java/lang/reflect/Field.getName:()Ljava/lang/String;
        //   147: astore          9
        //   149: iconst_m1      
        //   150: istore          10
        //   152: aload           9
        //   154: invokevirtual   java/lang/String.hashCode:()I
        //   157: lookupswitch {
        //          -1383228885: 248
        //           115029: 232
        //          3317767: 216
        //          108511772: 200
        //          default: 338
        //        }
        //   200: aload           9
        //   202: ldc             "right"
        //   204: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   207: ifeq            338
        //   210: iconst_2       
        //   211: istore          10
        //   213: goto            338
        //   216: aload           9
        //   218: ldc             "left"
        //   220: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   223: ifeq            338
        //   226: iconst_0       
        //   227: istore          10
        //   229: goto            338
        //   232: aload           9
        //   234: ldc             "top"
        //   236: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   239: ifeq            338
        //   242: iconst_1       
        //   243: istore          10
        //   245: goto            338
        //   248: aload           9
        //   250: ldc             "bottom"
        //   252: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //   255: ifeq            338
        //   258: iconst_3       
        //   259: istore          10
        //   261: goto            338
        //   264: aload           4
        //   266: aload           8
        //   268: aload_3        
        //   269: invokevirtual   java/lang/reflect/Field.getInt:(Ljava/lang/Object;)I
        //   272: putfield        android/graphics/Rect.bottom:I
        //   275: goto            317
        //   278: aload           4
        //   280: aload           8
        //   282: aload_3        
        //   283: invokevirtual   java/lang/reflect/Field.getInt:(Ljava/lang/Object;)I
        //   286: putfield        android/graphics/Rect.right:I
        //   289: goto            317
        //   292: aload           4
        //   294: aload           8
        //   296: aload_3        
        //   297: invokevirtual   java/lang/reflect/Field.getInt:(Ljava/lang/Object;)I
        //   300: putfield        android/graphics/Rect.top:I
        //   303: goto            317
        //   306: aload           4
        //   308: aload           8
        //   310: aload_3        
        //   311: invokevirtual   java/lang/reflect/Field.getInt:(Ljava/lang/Object;)I
        //   314: putfield        android/graphics/Rect.left:I
        //   317: iinc            7, 1
        //   320: goto            128
        //   323: aload           4
        //   325: areturn        
        //   326: ldc             "DrawableUtils"
        //   328: ldc             "Couldn't obtain the optical insets. Ignoring."
        //   330: invokestatic    android/util/Log.e:(Ljava/lang/String;Ljava/lang/String;)I
        //   333: pop            
        //   334: getstatic       androidx/appcompat/widget/DrawableUtils.INSETS_NONE:Landroid/graphics/Rect;
        //   337: areturn        
        //   338: iload           10
        //   340: ifeq            306
        //   343: iload           10
        //   345: iconst_1       
        //   346: if_icmpeq       292
        //   349: iload           10
        //   351: iconst_2       
        //   352: if_icmpeq       278
        //   355: iload           10
        //   357: iconst_3       
        //   358: if_icmpeq       264
        //   361: goto            317
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  72     317    326    334    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0334 (coming from #0333).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static PorterDuff$Mode parseTintMode(final int n, final PorterDuff$Mode porterDuff$Mode) {
        if (n == 3) {
            return PorterDuff$Mode.SRC_OVER;
        }
        if (n == 5) {
            return PorterDuff$Mode.SRC_IN;
        }
        if (n == 9) {
            return PorterDuff$Mode.SRC_ATOP;
        }
        switch (n) {
            default: {
                return porterDuff$Mode;
            }
            case 16: {
                return PorterDuff$Mode.ADD;
            }
            case 15: {
                return PorterDuff$Mode.SCREEN;
            }
            case 14: {
                return PorterDuff$Mode.MULTIPLY;
            }
        }
    }
}
