// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import androidx.collection.LruCache;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import androidx.appcompat.graphics.drawable.AnimatedStateListDrawableCompat;
import android.content.res.Resources$Theme;
import androidx.core.content.ContextCompat;
import android.graphics.ColorFilter;
import androidx.core.graphics.drawable.DrawableCompat;
import android.util.AttributeSet;
import android.content.res.XmlResourceParser;
import android.content.res.Resources;
import android.util.Log;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParser;
import android.util.Xml;
import androidx.vectordrawable.graphics.drawable.VectorDrawableCompat;
import android.os.Build$VERSION;
import android.graphics.PorterDuffColorFilter;
import androidx.appcompat.resources.R;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.content.res.ColorStateList;
import androidx.collection.SparseArrayCompat;
import android.graphics.drawable.Drawable$ConstantState;
import java.lang.ref.WeakReference;
import androidx.collection.LongSparseArray;
import android.content.Context;
import java.util.WeakHashMap;
import androidx.collection.ArrayMap;
import android.graphics.PorterDuff$Mode;

public final class ResourceManagerInternal
{
    private static final ColorFilterLruCache COLOR_FILTER_CACHE;
    private static final boolean DEBUG = false;
    private static final PorterDuff$Mode DEFAULT_MODE;
    private static ResourceManagerInternal INSTANCE;
    private static final String PLATFORM_VD_CLAZZ = "android.graphics.drawable.VectorDrawable";
    private static final String SKIP_DRAWABLE_TAG = "appcompat_skip_skip";
    private static final String TAG = "ResourceManagerInternal";
    private ArrayMap<String, InflateDelegate> mDelegates;
    private final WeakHashMap<Context, LongSparseArray<WeakReference<Drawable$ConstantState>>> mDrawableCaches;
    private boolean mHasCheckedVectorDrawableSetup;
    private ResourceManagerHooks mHooks;
    private SparseArrayCompat<String> mKnownDrawableIdTags;
    private WeakHashMap<Context, SparseArrayCompat<ColorStateList>> mTintLists;
    private TypedValue mTypedValue;
    
    static {
        DEFAULT_MODE = PorterDuff$Mode.SRC_IN;
        COLOR_FILTER_CACHE = new ColorFilterLruCache(6);
    }
    
    public ResourceManagerInternal() {
        this.mDrawableCaches = new WeakHashMap<Context, LongSparseArray<WeakReference<Drawable$ConstantState>>>(0);
    }
    
    private void addDelegate(final String s, final InflateDelegate inflateDelegate) {
        if (this.mDelegates == null) {
            this.mDelegates = new ArrayMap<String, InflateDelegate>();
        }
        this.mDelegates.put(s, inflateDelegate);
    }
    
    private boolean addDrawableToCache(final Context context, final long n, final Drawable drawable) {
        synchronized (this) {
            final Drawable$ConstantState constantState = drawable.getConstantState();
            if (constantState != null) {
                LongSparseArray<WeakReference<Drawable$ConstantState>> value = this.mDrawableCaches.get(context);
                if (value == null) {
                    value = new LongSparseArray<WeakReference<Drawable$ConstantState>>();
                    this.mDrawableCaches.put(context, value);
                }
                value.put(n, new WeakReference<Drawable$ConstantState>(constantState));
                return true;
            }
            return false;
        }
    }
    
    private void addTintListToCache(final Context context, final int n, final ColorStateList list) {
        if (this.mTintLists == null) {
            this.mTintLists = new WeakHashMap<Context, SparseArrayCompat<ColorStateList>>();
        }
        SparseArrayCompat<ColorStateList> value = this.mTintLists.get(context);
        if (value == null) {
            value = new SparseArrayCompat<ColorStateList>();
            this.mTintLists.put(context, value);
        }
        value.append(n, list);
    }
    
    private static boolean arrayContains(final int[] array, final int n) {
        for (int length = array.length, i = 0; i < length; ++i) {
            if (array[i] == n) {
                return true;
            }
        }
        return false;
    }
    
    private void checkVectorDrawableSetup(final Context context) {
        if (this.mHasCheckedVectorDrawableSetup) {
            return;
        }
        this.mHasCheckedVectorDrawableSetup = true;
        final Drawable drawable = this.getDrawable(context, R.drawable.abc_vector_test);
        if (drawable != null && isVectorDrawable(drawable)) {
            return;
        }
        this.mHasCheckedVectorDrawableSetup = false;
        throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
    }
    
    private static long createCacheKey(final TypedValue typedValue) {
        return (long)typedValue.assetCookie << 32 | (long)typedValue.data;
    }
    
    private Drawable createDrawableIfNeeded(final Context context, final int n) {
        if (this.mTypedValue == null) {
            this.mTypedValue = new TypedValue();
        }
        final TypedValue mTypedValue = this.mTypedValue;
        context.getResources().getValue(n, mTypedValue, true);
        final long cacheKey = createCacheKey(mTypedValue);
        final Drawable cachedDrawable = this.getCachedDrawable(context, cacheKey);
        if (cachedDrawable != null) {
            return cachedDrawable;
        }
        final ResourceManagerHooks mHooks = this.mHooks;
        Drawable drawable;
        if (mHooks == null) {
            drawable = null;
        }
        else {
            drawable = mHooks.createDrawableFor(this, context, n);
        }
        if (drawable != null) {
            drawable.setChangingConfigurations(mTypedValue.changingConfigurations);
            this.addDrawableToCache(context, cacheKey, drawable);
        }
        return drawable;
    }
    
    private static PorterDuffColorFilter createTintFilter(final ColorStateList list, final PorterDuff$Mode porterDuff$Mode, final int[] array) {
        if (list != null && porterDuff$Mode != null) {
            return getPorterDuffColorFilter(list.getColorForState(array, 0), porterDuff$Mode);
        }
        return null;
    }
    
    public static ResourceManagerInternal get() {
        synchronized (ResourceManagerInternal.class) {
            if (ResourceManagerInternal.INSTANCE == null) {
                installDefaultInflateDelegates(ResourceManagerInternal.INSTANCE = new ResourceManagerInternal());
            }
            return ResourceManagerInternal.INSTANCE;
        }
    }
    
    private Drawable getCachedDrawable(final Context key, final long n) {
        synchronized (this) {
            final LongSparseArray<WeakReference<Drawable$ConstantState>> longSparseArray = this.mDrawableCaches.get(key);
            if (longSparseArray == null) {
                return null;
            }
            final WeakReference<Drawable$ConstantState> weakReference = longSparseArray.get(n);
            if (weakReference != null) {
                final Drawable$ConstantState drawable$ConstantState = weakReference.get();
                if (drawable$ConstantState != null) {
                    return drawable$ConstantState.newDrawable(key.getResources());
                }
                longSparseArray.delete(n);
            }
            return null;
        }
    }
    
    public static PorterDuffColorFilter getPorterDuffColorFilter(final int n, final PorterDuff$Mode porterDuff$Mode) {
        synchronized (ResourceManagerInternal.class) {
            final ColorFilterLruCache color_FILTER_CACHE = ResourceManagerInternal.COLOR_FILTER_CACHE;
            PorterDuffColorFilter value = color_FILTER_CACHE.get(n, porterDuff$Mode);
            if (value == null) {
                value = new PorterDuffColorFilter(n, porterDuff$Mode);
                color_FILTER_CACHE.put(n, porterDuff$Mode, value);
            }
            return value;
        }
    }
    
    private ColorStateList getTintListFromCache(final Context key, final int n) {
        final WeakHashMap<Context, SparseArrayCompat<ColorStateList>> mTintLists = this.mTintLists;
        ColorStateList list = null;
        if (mTintLists != null) {
            final SparseArrayCompat<ColorStateList> sparseArrayCompat = mTintLists.get(key);
            list = null;
            if (sparseArrayCompat != null) {
                list = sparseArrayCompat.get(n);
            }
        }
        return list;
    }
    
    private static void installDefaultInflateDelegates(final ResourceManagerInternal resourceManagerInternal) {
        if (Build$VERSION.SDK_INT < 24) {
            resourceManagerInternal.addDelegate("vector", (InflateDelegate)new VdcInflateDelegate());
            resourceManagerInternal.addDelegate("animated-vector", (InflateDelegate)new AvdcInflateDelegate());
            resourceManagerInternal.addDelegate("animated-selector", (InflateDelegate)new AsldcInflateDelegate());
        }
    }
    
    private static boolean isVectorDrawable(final Drawable drawable) {
        return drawable instanceof VectorDrawableCompat || "android.graphics.drawable.VectorDrawable".equals(drawable.getClass().getName());
    }
    
    private Drawable loadDrawableFromDelegates(final Context context, final int n) {
        final ArrayMap<String, InflateDelegate> mDelegates = this.mDelegates;
        if (mDelegates == null || mDelegates.isEmpty()) {
            return null;
        }
        final SparseArrayCompat<String> mKnownDrawableIdTags = this.mKnownDrawableIdTags;
        if (mKnownDrawableIdTags != null) {
            final String anObject = mKnownDrawableIdTags.get(n);
            if ("appcompat_skip_skip".equals(anObject) || (anObject != null && this.mDelegates.get(anObject) == null)) {
                return null;
            }
        }
        else {
            this.mKnownDrawableIdTags = new SparseArrayCompat<String>();
        }
        if (this.mTypedValue == null) {
            this.mTypedValue = new TypedValue();
        }
        final TypedValue mTypedValue = this.mTypedValue;
        final Resources resources = context.getResources();
        resources.getValue(n, mTypedValue, true);
        final long cacheKey = createCacheKey(mTypedValue);
        Drawable drawable = this.getCachedDrawable(context, cacheKey);
        if (drawable != null) {
            return drawable;
        }
        if (mTypedValue.string != null && mTypedValue.string.toString().endsWith(".xml")) {
            try {
                final XmlResourceParser xml = resources.getXml(n);
                final AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xml);
                int next;
                do {
                    next = ((XmlPullParser)xml).next();
                } while (next != 2 && next != 1);
                if (next != 2) {
                    throw new XmlPullParserException("No start tag found");
                }
                final String name = ((XmlPullParser)xml).getName();
                this.mKnownDrawableIdTags.append(n, name);
                final InflateDelegate inflateDelegate = this.mDelegates.get(name);
                if (inflateDelegate != null) {
                    drawable = inflateDelegate.createFromXmlInner(context, (XmlPullParser)xml, attributeSet, context.getTheme());
                }
                if (drawable != null) {
                    drawable.setChangingConfigurations(mTypedValue.changingConfigurations);
                    this.addDrawableToCache(context, cacheKey, drawable);
                }
            }
            catch (Exception ex) {
                Log.e("ResourceManagerInternal", "Exception while inflating drawable", (Throwable)ex);
            }
        }
        if (drawable == null) {
            this.mKnownDrawableIdTags.append(n, "appcompat_skip_skip");
        }
        return drawable;
    }
    
    private void removeDelegate(final String s, final InflateDelegate inflateDelegate) {
        final ArrayMap<String, InflateDelegate> mDelegates = this.mDelegates;
        if (mDelegates != null && mDelegates.get(s) == inflateDelegate) {
            this.mDelegates.remove(s);
        }
    }
    
    private Drawable tintDrawable(final Context context, final int n, final boolean b, Drawable drawable) {
        final ColorStateList tintList = this.getTintList(context, n);
        if (tintList != null) {
            if (DrawableUtils.canSafelyMutateDrawable(drawable)) {
                drawable = drawable.mutate();
            }
            drawable = DrawableCompat.wrap(drawable);
            DrawableCompat.setTintList(drawable, tintList);
            final PorterDuff$Mode tintMode = this.getTintMode(n);
            if (tintMode != null) {
                DrawableCompat.setTintMode(drawable, tintMode);
            }
        }
        else {
            final ResourceManagerHooks mHooks = this.mHooks;
            if (mHooks == null || !mHooks.tintDrawable(context, n, drawable)) {
                if (!this.tintDrawableUsingColorFilter(context, n, drawable) && b) {
                    drawable = null;
                }
            }
        }
        return drawable;
    }
    
    static void tintDrawable(final Drawable drawable, final TintInfo tintInfo, final int[] array) {
        if (DrawableUtils.canSafelyMutateDrawable(drawable) && drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        if (!tintInfo.mHasTintList && !tintInfo.mHasTintMode) {
            drawable.clearColorFilter();
        }
        else {
            ColorStateList mTintList;
            if (tintInfo.mHasTintList) {
                mTintList = tintInfo.mTintList;
            }
            else {
                mTintList = null;
            }
            PorterDuff$Mode porterDuff$Mode;
            if (tintInfo.mHasTintMode) {
                porterDuff$Mode = tintInfo.mTintMode;
            }
            else {
                porterDuff$Mode = ResourceManagerInternal.DEFAULT_MODE;
            }
            drawable.setColorFilter((ColorFilter)createTintFilter(mTintList, porterDuff$Mode, array));
        }
        if (Build$VERSION.SDK_INT <= 23) {
            drawable.invalidateSelf();
        }
    }
    
    public Drawable getDrawable(final Context context, final int n) {
        synchronized (this) {
            return this.getDrawable(context, n, false);
        }
    }
    
    Drawable getDrawable(final Context context, final int n, final boolean b) {
        synchronized (this) {
            this.checkVectorDrawableSetup(context);
            Drawable drawable = this.loadDrawableFromDelegates(context, n);
            if (drawable == null) {
                drawable = this.createDrawableIfNeeded(context, n);
            }
            if (drawable == null) {
                drawable = ContextCompat.getDrawable(context, n);
            }
            if (drawable != null) {
                drawable = this.tintDrawable(context, n, b, drawable);
            }
            if (drawable != null) {
                DrawableUtils.fixDrawable(drawable);
            }
            return drawable;
        }
    }
    
    ColorStateList getTintList(final Context context, final int n) {
        synchronized (this) {
            ColorStateList list = this.getTintListFromCache(context, n);
            if (list == null) {
                final ResourceManagerHooks mHooks = this.mHooks;
                if (mHooks == null) {
                    list = null;
                }
                else {
                    list = mHooks.getTintListForDrawableRes(context, n);
                }
                if (list != null) {
                    this.addTintListToCache(context, n, list);
                }
            }
            return list;
        }
    }
    
    PorterDuff$Mode getTintMode(final int n) {
        final ResourceManagerHooks mHooks = this.mHooks;
        PorterDuff$Mode tintModeForDrawableRes;
        if (mHooks == null) {
            tintModeForDrawableRes = null;
        }
        else {
            tintModeForDrawableRes = mHooks.getTintModeForDrawableRes(n);
        }
        return tintModeForDrawableRes;
    }
    
    public void onConfigurationChanged(final Context key) {
        synchronized (this) {
            final LongSparseArray<WeakReference<Drawable$ConstantState>> longSparseArray = this.mDrawableCaches.get(key);
            if (longSparseArray != null) {
                longSparseArray.clear();
            }
        }
    }
    
    Drawable onDrawableLoadedFromResources(final Context context, final VectorEnabledTintResources vectorEnabledTintResources, final int n) {
        synchronized (this) {
            Drawable drawable = this.loadDrawableFromDelegates(context, n);
            if (drawable == null) {
                drawable = vectorEnabledTintResources.superGetDrawable(n);
            }
            if (drawable != null) {
                return this.tintDrawable(context, n, false, drawable);
            }
            return null;
        }
    }
    
    public void setHooks(final ResourceManagerHooks mHooks) {
        synchronized (this) {
            this.mHooks = mHooks;
        }
    }
    
    boolean tintDrawableUsingColorFilter(final Context context, final int n, final Drawable drawable) {
        final ResourceManagerHooks mHooks = this.mHooks;
        return mHooks != null && mHooks.tintDrawableUsingColorFilter(context, n, drawable);
    }
    
    static class AsldcInflateDelegate implements InflateDelegate
    {
        @Override
        public Drawable createFromXmlInner(final Context context, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
            try {
                return AnimatedStateListDrawableCompat.createFromXmlInner(context, context.getResources(), xmlPullParser, set, resources$Theme);
            }
            catch (Exception ex) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", (Throwable)ex);
                return null;
            }
        }
    }
    
    private static class AvdcInflateDelegate implements InflateDelegate
    {
        AvdcInflateDelegate() {
        }
        
        @Override
        public Drawable createFromXmlInner(final Context context, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
            try {
                return AnimatedVectorDrawableCompat.createFromXmlInner(context, context.getResources(), xmlPullParser, set, resources$Theme);
            }
            catch (Exception ex) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", (Throwable)ex);
                return null;
            }
        }
    }
    
    private static class ColorFilterLruCache extends LruCache<Integer, PorterDuffColorFilter>
    {
        public ColorFilterLruCache(final int n) {
            super(n);
        }
        
        private static int generateCacheKey(final int n, final PorterDuff$Mode porterDuff$Mode) {
            return 31 * (n + 31) + porterDuff$Mode.hashCode();
        }
        
        PorterDuffColorFilter get(final int n, final PorterDuff$Mode porterDuff$Mode) {
            return this.get(generateCacheKey(n, porterDuff$Mode));
        }
        
        PorterDuffColorFilter put(final int n, final PorterDuff$Mode porterDuff$Mode, final PorterDuffColorFilter porterDuffColorFilter) {
            return this.put(generateCacheKey(n, porterDuff$Mode), porterDuffColorFilter);
        }
    }
    
    private interface InflateDelegate
    {
        Drawable createFromXmlInner(final Context p0, final XmlPullParser p1, final AttributeSet p2, final Resources$Theme p3);
    }
    
    interface ResourceManagerHooks
    {
        Drawable createDrawableFor(final ResourceManagerInternal p0, final Context p1, final int p2);
        
        ColorStateList getTintListForDrawableRes(final Context p0, final int p1);
        
        PorterDuff$Mode getTintModeForDrawableRes(final int p0);
        
        boolean tintDrawable(final Context p0, final int p1, final Drawable p2);
        
        boolean tintDrawableUsingColorFilter(final Context p0, final int p1, final Drawable p2);
    }
    
    private static class VdcInflateDelegate implements InflateDelegate
    {
        VdcInflateDelegate() {
        }
        
        @Override
        public Drawable createFromXmlInner(final Context context, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) {
            try {
                return VectorDrawableCompat.createFromXmlInner(context.getResources(), xmlPullParser, set, resources$Theme);
            }
            catch (Exception ex) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", (Throwable)ex);
                return null;
            }
        }
    }
}
