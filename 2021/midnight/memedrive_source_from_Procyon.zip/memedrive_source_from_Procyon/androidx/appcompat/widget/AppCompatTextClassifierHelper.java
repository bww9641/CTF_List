// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import android.view.textclassifier.TextClassificationManager;
import androidx.core.util.Preconditions;
import android.widget.TextView;
import android.view.textclassifier.TextClassifier;

final class AppCompatTextClassifierHelper
{
    private TextClassifier mTextClassifier;
    private TextView mTextView;
    
    AppCompatTextClassifierHelper(final TextView textView) {
        this.mTextView = Preconditions.checkNotNull(textView);
    }
    
    public TextClassifier getTextClassifier() {
        TextClassifier textClassifier = this.mTextClassifier;
        if (textClassifier == null) {
            final TextClassificationManager textClassificationManager = (TextClassificationManager)this.mTextView.getContext().getSystemService((Class)TextClassificationManager.class);
            if (textClassificationManager != null) {
                return textClassificationManager.getTextClassifier();
            }
            textClassifier = TextClassifier.NO_OP;
        }
        return textClassifier;
    }
    
    public void setTextClassifier(final TextClassifier mTextClassifier) {
        this.mTextClassifier = mTextClassifier;
    }
}
