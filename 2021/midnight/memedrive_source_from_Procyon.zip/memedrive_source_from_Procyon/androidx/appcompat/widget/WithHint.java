// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

public interface WithHint
{
    CharSequence getHint();
}
