// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.widget;

import android.content.res.TypedArray;
import android.view.ViewGroup$MarginLayoutParams;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Annotation;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityEvent;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import android.graphics.Canvas;
import android.view.ViewGroup$LayoutParams;
import android.view.View;
import android.view.View$MeasureSpec;
import androidx.appcompat.R;
import android.util.AttributeSet;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.ViewGroup;

public class LinearLayoutCompat extends ViewGroup
{
    private static final String ACCESSIBILITY_CLASS_NAME = "androidx.appcompat.widget.LinearLayoutCompat";
    public static final int HORIZONTAL = 0;
    private static final int INDEX_BOTTOM = 2;
    private static final int INDEX_CENTER_VERTICAL = 0;
    private static final int INDEX_FILL = 3;
    private static final int INDEX_TOP = 1;
    public static final int SHOW_DIVIDER_BEGINNING = 1;
    public static final int SHOW_DIVIDER_END = 4;
    public static final int SHOW_DIVIDER_MIDDLE = 2;
    public static final int SHOW_DIVIDER_NONE = 0;
    public static final int VERTICAL = 1;
    private static final int VERTICAL_GRAVITY_COUNT = 4;
    private boolean mBaselineAligned;
    private int mBaselineAlignedChildIndex;
    private int mBaselineChildTop;
    private Drawable mDivider;
    private int mDividerHeight;
    private int mDividerPadding;
    private int mDividerWidth;
    private int mGravity;
    private int[] mMaxAscent;
    private int[] mMaxDescent;
    private int mOrientation;
    private int mShowDividers;
    private int mTotalLength;
    private boolean mUseLargestChild;
    private float mWeightSum;
    
    public LinearLayoutCompat(final Context context) {
        this(context, null);
    }
    
    public LinearLayoutCompat(final Context context, final AttributeSet set) {
        this(context, set, 0);
    }
    
    public LinearLayoutCompat(final Context context, final AttributeSet set, final int n) {
        super(context, set, n);
        this.mBaselineAligned = true;
        this.mBaselineAlignedChildIndex = -1;
        this.mBaselineChildTop = 0;
        this.mGravity = 8388659;
        final TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(context, set, R.styleable.LinearLayoutCompat, n, 0);
        final int int1 = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_android_orientation, -1);
        if (int1 >= 0) {
            this.setOrientation(int1);
        }
        final int int2 = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_android_gravity, -1);
        if (int2 >= 0) {
            this.setGravity(int2);
        }
        final boolean boolean1 = obtainStyledAttributes.getBoolean(R.styleable.LinearLayoutCompat_android_baselineAligned, true);
        if (!boolean1) {
            this.setBaselineAligned(boolean1);
        }
        this.mWeightSum = obtainStyledAttributes.getFloat(R.styleable.LinearLayoutCompat_android_weightSum, -1.0f);
        this.mBaselineAlignedChildIndex = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
        this.mUseLargestChild = obtainStyledAttributes.getBoolean(R.styleable.LinearLayoutCompat_measureWithLargestChild, false);
        this.setDividerDrawable(obtainStyledAttributes.getDrawable(R.styleable.LinearLayoutCompat_divider));
        this.mShowDividers = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_showDividers, 0);
        this.mDividerPadding = obtainStyledAttributes.getDimensionPixelSize(R.styleable.LinearLayoutCompat_dividerPadding, 0);
        obtainStyledAttributes.recycle();
    }
    
    private void forceUniformHeight(final int n, final int n2) {
        final int measureSpec = View$MeasureSpec.makeMeasureSpec(this.getMeasuredHeight(), 1073741824);
        for (int i = 0; i < n; ++i) {
            final View virtualChild = this.getVirtualChildAt(i);
            if (virtualChild.getVisibility() != 8) {
                final LayoutParams layoutParams = (LayoutParams)virtualChild.getLayoutParams();
                if (layoutParams.height == -1) {
                    final int width = layoutParams.width;
                    layoutParams.width = virtualChild.getMeasuredWidth();
                    this.measureChildWithMargins(virtualChild, n2, 0, measureSpec, 0);
                    layoutParams.width = width;
                }
            }
        }
    }
    
    private void forceUniformWidth(final int n, final int n2) {
        final int measureSpec = View$MeasureSpec.makeMeasureSpec(this.getMeasuredWidth(), 1073741824);
        for (int i = 0; i < n; ++i) {
            final View virtualChild = this.getVirtualChildAt(i);
            if (virtualChild.getVisibility() != 8) {
                final LayoutParams layoutParams = (LayoutParams)virtualChild.getLayoutParams();
                if (layoutParams.width == -1) {
                    final int height = layoutParams.height;
                    layoutParams.height = virtualChild.getMeasuredHeight();
                    this.measureChildWithMargins(virtualChild, measureSpec, 0, n2, 0);
                    layoutParams.height = height;
                }
            }
        }
    }
    
    private void setChildFrame(final View view, final int n, final int n2, final int n3, final int n4) {
        view.layout(n, n2, n3 + n, n4 + n2);
    }
    
    protected boolean checkLayoutParams(final ViewGroup$LayoutParams viewGroup$LayoutParams) {
        return viewGroup$LayoutParams instanceof LayoutParams;
    }
    
    void drawDividersHorizontal(final Canvas canvas) {
        final int virtualChildCount = this.getVirtualChildCount();
        final boolean layoutRtl = ViewUtils.isLayoutRtl((View)this);
        for (int i = 0; i < virtualChildCount; ++i) {
            final View virtualChild = this.getVirtualChildAt(i);
            if (virtualChild != null && virtualChild.getVisibility() != 8 && this.hasDividerBeforeChildAt(i)) {
                final LayoutParams layoutParams = (LayoutParams)virtualChild.getLayoutParams();
                int n;
                if (layoutRtl) {
                    n = virtualChild.getRight() + layoutParams.rightMargin;
                }
                else {
                    n = virtualChild.getLeft() - layoutParams.leftMargin - this.mDividerWidth;
                }
                this.drawVerticalDivider(canvas, n);
            }
        }
        if (this.hasDividerBeforeChildAt(virtualChildCount)) {
            final View virtualChild2 = this.getVirtualChildAt(virtualChildCount - 1);
            int paddingLeft = 0;
            Label_0223: {
                int n2;
                int n3;
                if (virtualChild2 == null) {
                    if (layoutRtl) {
                        paddingLeft = this.getPaddingLeft();
                        break Label_0223;
                    }
                    n2 = this.getWidth() - this.getPaddingRight();
                    n3 = this.mDividerWidth;
                }
                else {
                    final LayoutParams layoutParams2 = (LayoutParams)virtualChild2.getLayoutParams();
                    if (!layoutRtl) {
                        paddingLeft = virtualChild2.getRight() + layoutParams2.rightMargin;
                        break Label_0223;
                    }
                    n2 = virtualChild2.getLeft() - layoutParams2.leftMargin;
                    n3 = this.mDividerWidth;
                }
                paddingLeft = n2 - n3;
            }
            this.drawVerticalDivider(canvas, paddingLeft);
        }
    }
    
    void drawDividersVertical(final Canvas canvas) {
        final int virtualChildCount = this.getVirtualChildCount();
        for (int i = 0; i < virtualChildCount; ++i) {
            final View virtualChild = this.getVirtualChildAt(i);
            if (virtualChild != null && virtualChild.getVisibility() != 8 && this.hasDividerBeforeChildAt(i)) {
                this.drawHorizontalDivider(canvas, virtualChild.getTop() - ((LayoutParams)virtualChild.getLayoutParams()).topMargin - this.mDividerHeight);
            }
        }
        if (this.hasDividerBeforeChildAt(virtualChildCount)) {
            final View virtualChild2 = this.getVirtualChildAt(virtualChildCount - 1);
            int n;
            if (virtualChild2 == null) {
                n = this.getHeight() - this.getPaddingBottom() - this.mDividerHeight;
            }
            else {
                n = virtualChild2.getBottom() + ((LayoutParams)virtualChild2.getLayoutParams()).bottomMargin;
            }
            this.drawHorizontalDivider(canvas, n);
        }
    }
    
    void drawHorizontalDivider(final Canvas canvas, final int n) {
        this.mDivider.setBounds(this.getPaddingLeft() + this.mDividerPadding, n, this.getWidth() - this.getPaddingRight() - this.mDividerPadding, n + this.mDividerHeight);
        this.mDivider.draw(canvas);
    }
    
    void drawVerticalDivider(final Canvas canvas, final int n) {
        this.mDivider.setBounds(n, this.getPaddingTop() + this.mDividerPadding, n + this.mDividerWidth, this.getHeight() - this.getPaddingBottom() - this.mDividerPadding);
        this.mDivider.draw(canvas);
    }
    
    protected LayoutParams generateDefaultLayoutParams() {
        final int mOrientation = this.mOrientation;
        if (mOrientation == 0) {
            return new LayoutParams(-2, -2);
        }
        if (mOrientation == 1) {
            return new LayoutParams(-1, -2);
        }
        return null;
    }
    
    public LayoutParams generateLayoutParams(final AttributeSet set) {
        return new LayoutParams(this.getContext(), set);
    }
    
    protected LayoutParams generateLayoutParams(final ViewGroup$LayoutParams viewGroup$LayoutParams) {
        return new LayoutParams(viewGroup$LayoutParams);
    }
    
    public int getBaseline() {
        if (this.mBaselineAlignedChildIndex < 0) {
            return super.getBaseline();
        }
        final int childCount = this.getChildCount();
        final int mBaselineAlignedChildIndex = this.mBaselineAlignedChildIndex;
        if (childCount <= mBaselineAlignedChildIndex) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        final View child = this.getChildAt(mBaselineAlignedChildIndex);
        final int baseline = child.getBaseline();
        if (baseline != -1) {
            int mBaselineChildTop = this.mBaselineChildTop;
            if (this.mOrientation == 1) {
                final int n = 0x70 & this.mGravity;
                if (n != 48) {
                    if (n != 16) {
                        if (n == 80) {
                            mBaselineChildTop = this.getBottom() - this.getTop() - this.getPaddingBottom() - this.mTotalLength;
                        }
                    }
                    else {
                        mBaselineChildTop += (this.getBottom() - this.getTop() - this.getPaddingTop() - this.getPaddingBottom() - this.mTotalLength) / 2;
                    }
                }
            }
            return baseline + (mBaselineChildTop + ((LayoutParams)child.getLayoutParams()).topMargin);
        }
        if (this.mBaselineAlignedChildIndex == 0) {
            return -1;
        }
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
    }
    
    public int getBaselineAlignedChildIndex() {
        return this.mBaselineAlignedChildIndex;
    }
    
    int getChildrenSkipCount(final View view, final int n) {
        return 0;
    }
    
    public Drawable getDividerDrawable() {
        return this.mDivider;
    }
    
    public int getDividerPadding() {
        return this.mDividerPadding;
    }
    
    public int getDividerWidth() {
        return this.mDividerWidth;
    }
    
    public int getGravity() {
        return this.mGravity;
    }
    
    int getLocationOffset(final View view) {
        return 0;
    }
    
    int getNextLocationOffset(final View view) {
        return 0;
    }
    
    public int getOrientation() {
        return this.mOrientation;
    }
    
    public int getShowDividers() {
        return this.mShowDividers;
    }
    
    View getVirtualChildAt(final int n) {
        return this.getChildAt(n);
    }
    
    int getVirtualChildCount() {
        return this.getChildCount();
    }
    
    public float getWeightSum() {
        return this.mWeightSum;
    }
    
    protected boolean hasDividerBeforeChildAt(final int n) {
        if (n == 0) {
            final int n2 = 0x1 & this.mShowDividers;
            boolean b = false;
            if (n2 != 0) {
                b = true;
            }
            return b;
        }
        if (n == this.getChildCount()) {
            final int n3 = 0x4 & this.mShowDividers;
            boolean b2 = false;
            if (n3 != 0) {
                b2 = true;
            }
            return b2;
        }
        final int n4 = 0x2 & this.mShowDividers;
        boolean b3 = false;
        if (n4 != 0) {
            int n5 = n - 1;
            while (true) {
                b3 = false;
                if (n5 < 0) {
                    break;
                }
                if (this.getChildAt(n5).getVisibility() != 8) {
                    b3 = true;
                    break;
                }
                --n5;
            }
        }
        return b3;
    }
    
    public boolean isBaselineAligned() {
        return this.mBaselineAligned;
    }
    
    public boolean isMeasureWithLargestChildEnabled() {
        return this.mUseLargestChild;
    }
    
    void layoutHorizontal(final int n, final int n2, final int n3, final int n4) {
        final boolean layoutRtl = ViewUtils.isLayoutRtl((View)this);
        int paddingTop = this.getPaddingTop();
        final int n5 = n4 - n2;
        final int n6 = n5 - this.getPaddingBottom();
        final int n7 = n5 - paddingTop - this.getPaddingBottom();
        int virtualChildCount = this.getVirtualChildCount();
        final int mGravity = this.mGravity;
        final int n8 = 0x800007 & mGravity;
        int n9 = mGravity & 0x70;
        final boolean mBaselineAligned = this.mBaselineAligned;
        final int[] mMaxAscent = this.mMaxAscent;
        final int[] mMaxDescent = this.mMaxDescent;
        final int absoluteGravity = GravityCompat.getAbsoluteGravity(n8, ViewCompat.getLayoutDirection((View)this));
        int paddingLeft;
        if (absoluteGravity != 1) {
            if (absoluteGravity != 5) {
                paddingLeft = this.getPaddingLeft();
            }
            else {
                paddingLeft = n3 + this.getPaddingLeft() - n - this.mTotalLength;
            }
        }
        else {
            paddingLeft = this.getPaddingLeft() + (n3 - n - this.mTotalLength) / 2;
        }
        int n10;
        int n11;
        if (layoutRtl) {
            n10 = virtualChildCount - 1;
            n11 = -1;
        }
        else {
            n10 = 0;
            n11 = 1;
        }
        int n14;
        int n16;
        int n20;
        for (int i = 0; i < virtualChildCount; ++i, virtualChildCount = n14, n9 = n16, paddingTop = n20) {
            final int n12 = n10 + n11 * i;
            final View virtualChild = this.getVirtualChildAt(n12);
            if (virtualChild == null) {
                paddingLeft += this.measureNullChild(n12);
            }
            else if (virtualChild.getVisibility() != 8) {
                final int measuredWidth = virtualChild.getMeasuredWidth();
                final int measuredHeight = virtualChild.getMeasuredHeight();
                final LayoutParams layoutParams = (LayoutParams)virtualChild.getLayoutParams();
                final int n13 = i;
                int baseline = 0;
                Label_0298: {
                    if (mBaselineAligned) {
                        final int height = layoutParams.height;
                        n14 = virtualChildCount;
                        if (height != -1) {
                            baseline = virtualChild.getBaseline();
                            break Label_0298;
                        }
                    }
                    else {
                        n14 = virtualChildCount;
                    }
                    baseline = -1;
                }
                int gravity = layoutParams.gravity;
                if (gravity < 0) {
                    gravity = n9;
                }
                final int n15 = gravity & 0x70;
                n16 = n9;
                int n17;
                if (n15 != 16) {
                    if (n15 != 48) {
                        if (n15 != 80) {
                            n17 = paddingTop;
                        }
                        else {
                            n17 = n6 - measuredHeight - layoutParams.bottomMargin;
                            if (baseline != -1) {
                                n17 -= mMaxDescent[2] - (virtualChild.getMeasuredHeight() - baseline);
                            }
                        }
                    }
                    else {
                        n17 = paddingTop + layoutParams.topMargin;
                        if (baseline != -1) {
                            n17 += mMaxAscent[1] - baseline;
                        }
                    }
                }
                else {
                    n17 = paddingTop + (n7 - measuredHeight) / 2 + layoutParams.topMargin - layoutParams.bottomMargin;
                }
                if (this.hasDividerBeforeChildAt(n12)) {
                    paddingLeft += this.mDividerWidth;
                }
                final int n18 = paddingLeft + layoutParams.leftMargin;
                final int n19 = n18 + this.getLocationOffset(virtualChild);
                n20 = paddingTop;
                this.setChildFrame(virtualChild, n19, n17, measuredWidth, measuredHeight);
                final int n21 = n18 + (measuredWidth + layoutParams.rightMargin + this.getNextLocationOffset(virtualChild));
                i = n13 + this.getChildrenSkipCount(virtualChild, n12);
                paddingLeft = n21;
                continue;
            }
            n20 = paddingTop;
            n14 = virtualChildCount;
            n16 = n9;
        }
    }
    
    void layoutVertical(final int n, final int n2, final int n3, final int n4) {
        final int paddingLeft = this.getPaddingLeft();
        final int n5 = n3 - n;
        final int n6 = n5 - this.getPaddingRight();
        final int n7 = n5 - paddingLeft - this.getPaddingRight();
        final int virtualChildCount = this.getVirtualChildCount();
        final int mGravity = this.mGravity;
        final int n8 = mGravity & 0x70;
        final int n9 = mGravity & 0x800007;
        int paddingTop;
        if (n8 != 16) {
            if (n8 != 80) {
                paddingTop = this.getPaddingTop();
            }
            else {
                paddingTop = n4 + this.getPaddingTop() - n2 - this.mTotalLength;
            }
        }
        else {
            paddingTop = this.getPaddingTop() + (n4 - n2 - this.mTotalLength) / 2;
        }
        for (int i = 0; i < virtualChildCount; ++i) {
            final View virtualChild = this.getVirtualChildAt(i);
            if (virtualChild == null) {
                paddingTop += this.measureNullChild(i);
            }
            else if (virtualChild.getVisibility() != 8) {
                final int measuredWidth = virtualChild.getMeasuredWidth();
                final int measuredHeight = virtualChild.getMeasuredHeight();
                final LayoutParams layoutParams = (LayoutParams)virtualChild.getLayoutParams();
                int gravity = layoutParams.gravity;
                if (gravity < 0) {
                    gravity = n9;
                }
                final int n10 = 0x7 & GravityCompat.getAbsoluteGravity(gravity, ViewCompat.getLayoutDirection((View)this));
                int n11 = 0;
                Label_0294: {
                    int n12;
                    int n13;
                    if (n10 != 1) {
                        if (n10 != 5) {
                            n11 = paddingLeft + layoutParams.leftMargin;
                            break Label_0294;
                        }
                        n12 = n6 - measuredWidth;
                        n13 = layoutParams.rightMargin;
                    }
                    else {
                        n12 = paddingLeft + (n7 - measuredWidth) / 2 + layoutParams.leftMargin;
                        n13 = layoutParams.rightMargin;
                    }
                    n11 = n12 - n13;
                }
                final int n14 = n11;
                if (this.hasDividerBeforeChildAt(i)) {
                    paddingTop += this.mDividerHeight;
                }
                final int n15 = paddingTop + layoutParams.topMargin;
                this.setChildFrame(virtualChild, n14, n15 + this.getLocationOffset(virtualChild), measuredWidth, measuredHeight);
                final int n16 = n15 + (measuredHeight + layoutParams.bottomMargin + this.getNextLocationOffset(virtualChild));
                i += this.getChildrenSkipCount(virtualChild, i);
                paddingTop = n16;
            }
        }
    }
    
    void measureChildBeforeLayout(final View view, final int n, final int n2, final int n3, final int n4, final int n5) {
        this.measureChildWithMargins(view, n2, n3, n4, n5);
    }
    
    void measureHorizontal(final int n, final int n2) {
        this.mTotalLength = 0;
        int virtualChildCount = this.getVirtualChildCount();
        final int mode = View$MeasureSpec.getMode(n);
        final int mode2 = View$MeasureSpec.getMode(n2);
        if (this.mMaxAscent == null || this.mMaxDescent == null) {
            this.mMaxAscent = new int[4];
            this.mMaxDescent = new int[4];
        }
        final int[] mMaxAscent = this.mMaxAscent;
        int[] mMaxDescent = this.mMaxDescent;
        mMaxAscent[2] = (mMaxAscent[3] = -1);
        mMaxAscent[0] = (mMaxAscent[1] = -1);
        mMaxDescent[2] = (mMaxDescent[3] = -1);
        mMaxDescent[0] = (mMaxDescent[1] = -1);
        int mBaselineAligned = this.mBaselineAligned ? 1 : 0;
        int mUseLargestChild = this.mUseLargestChild ? 1 : 0;
        int n3 = 1073741824;
        final boolean b = mode == n3;
        float n4 = 0.0f;
        int n5 = 0;
        int max = 0;
        int max2 = 0;
        int max3 = 0;
        int max4 = 0;
        boolean b2 = false;
        int combineMeasuredStates = 0;
        int n6 = 1;
        boolean b3 = false;
        int[] array;
        while (true) {
            array = mMaxDescent;
            if (n5 >= virtualChildCount) {
                break;
            }
            final View virtualChild = this.getVirtualChildAt(n5);
            int n9 = 0;
            int n10 = 0;
            int n20 = 0;
            Label_0926: {
                if (virtualChild == null) {
                    this.mTotalLength += this.measureNullChild(n5);
                }
                else {
                    if (virtualChild.getVisibility() != 8) {
                        if (this.hasDividerBeforeChildAt(n5)) {
                            this.mTotalLength += this.mDividerWidth;
                        }
                        final LayoutParams layoutParams = (LayoutParams)virtualChild.getLayoutParams();
                        final float n7 = n4 + layoutParams.weight;
                        int n8 = 0;
                        View view = null;
                        int n11 = 0;
                        Label_0654: {
                            if (mode == n3 && layoutParams.width == 0 && layoutParams.weight > 0.0f) {
                                if (b) {
                                    this.mTotalLength += layoutParams.leftMargin + layoutParams.rightMargin;
                                }
                                else {
                                    final int mTotalLength = this.mTotalLength;
                                    this.mTotalLength = Math.max(mTotalLength, mTotalLength + layoutParams.leftMargin + layoutParams.rightMargin);
                                }
                                if (mBaselineAligned == 0) {
                                    n8 = n5;
                                    n9 = mUseLargestChild;
                                    n10 = mBaselineAligned;
                                    view = virtualChild;
                                    n11 = 1073741824;
                                    b2 = true;
                                    break Label_0654;
                                }
                                final int measureSpec = View$MeasureSpec.makeMeasureSpec(0, 0);
                                virtualChild.measure(measureSpec, measureSpec);
                                n8 = n5;
                                n9 = mUseLargestChild;
                                n10 = mBaselineAligned;
                                view = virtualChild;
                            }
                            else {
                                int n12;
                                if (layoutParams.width == 0 && layoutParams.weight > 0.0f) {
                                    layoutParams.width = -2;
                                    n12 = 0;
                                }
                                else {
                                    n12 = Integer.MIN_VALUE;
                                }
                                int mTotalLength2;
                                if (n7 == 0.0f) {
                                    mTotalLength2 = this.mTotalLength;
                                }
                                else {
                                    mTotalLength2 = 0;
                                }
                                n8 = n5;
                                final int width = n12;
                                final int n13 = n8;
                                n9 = mUseLargestChild;
                                n10 = mBaselineAligned;
                                this.measureChildBeforeLayout(virtualChild, n13, n, mTotalLength2, n2, 0);
                                if (width != Integer.MIN_VALUE) {
                                    layoutParams.width = width;
                                }
                                final int measuredWidth = virtualChild.getMeasuredWidth();
                                if (b) {
                                    final int mTotalLength3 = this.mTotalLength;
                                    final int n14 = measuredWidth + layoutParams.leftMargin + layoutParams.rightMargin;
                                    view = virtualChild;
                                    this.mTotalLength = mTotalLength3 + (n14 + this.getNextLocationOffset(view));
                                }
                                else {
                                    view = virtualChild;
                                    final int mTotalLength4 = this.mTotalLength;
                                    this.mTotalLength = Math.max(mTotalLength4, mTotalLength4 + measuredWidth + layoutParams.leftMargin + layoutParams.rightMargin + this.getNextLocationOffset(view));
                                }
                                if (n9 != 0) {
                                    max = Math.max(measuredWidth, max);
                                }
                            }
                            n11 = 1073741824;
                        }
                        boolean b4;
                        if (mode2 != n11 && layoutParams.height == -1) {
                            b4 = true;
                            b3 = true;
                        }
                        else {
                            b4 = false;
                        }
                        int n15 = layoutParams.topMargin + layoutParams.bottomMargin;
                        final int b5 = n15 + view.getMeasuredHeight();
                        combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, view.getMeasuredState());
                        if (n10 != 0) {
                            final int baseline = view.getBaseline();
                            if (baseline != -1) {
                                int n16;
                                if (layoutParams.gravity < 0) {
                                    n16 = this.mGravity;
                                }
                                else {
                                    n16 = layoutParams.gravity;
                                }
                                final int n17 = (0xFFFFFFFE & (n16 & 0x70) >> 4) >> 1;
                                mMaxAscent[n17] = Math.max(mMaxAscent[n17], baseline);
                                array[n17] = Math.max(array[n17], b5 - baseline);
                            }
                        }
                        max2 = Math.max(max2, b5);
                        if (n6 != 0 && layoutParams.height == -1) {
                            n6 = 1;
                        }
                        else {
                            n6 = 0;
                        }
                        if (layoutParams.weight > 0.0f) {
                            if (!b4) {
                                n15 = b5;
                            }
                            max4 = Math.max(max4, n15);
                        }
                        else {
                            final int n18 = max4;
                            if (!b4) {
                                n15 = b5;
                            }
                            max3 = Math.max(max3, n15);
                            max4 = n18;
                        }
                        final int n19 = n8;
                        n20 = n19 + this.getChildrenSkipCount(view, n19);
                        n4 = n7;
                        break Label_0926;
                    }
                    n5 += this.getChildrenSkipCount(virtualChild, n5);
                }
                n20 = n5;
                n9 = mUseLargestChild;
                n10 = mBaselineAligned;
            }
            n5 = n20 + 1;
            mMaxDescent = array;
            mUseLargestChild = n9;
            mBaselineAligned = n10;
            n3 = 1073741824;
        }
        final int n21 = mUseLargestChild;
        final int n22 = mBaselineAligned;
        final int a = max2;
        final int a2 = max3;
        final int b6 = max4;
        final int n23 = combineMeasuredStates;
        if (this.mTotalLength > 0 && this.hasDividerBeforeChildAt(virtualChildCount)) {
            this.mTotalLength += this.mDividerWidth;
        }
        int max5;
        int n24;
        if (mMaxAscent[1] == -1 && mMaxAscent[0] == -1 && mMaxAscent[2] == -1 && mMaxAscent[3] == -1) {
            max5 = a;
            n24 = n23;
        }
        else {
            final int max6 = Math.max(mMaxAscent[3], Math.max(mMaxAscent[0], Math.max(mMaxAscent[1], mMaxAscent[2])));
            final int a3 = array[3];
            final int a4 = array[0];
            final int a5 = array[1];
            n24 = n23;
            max5 = Math.max(a, max6 + Math.max(a3, Math.max(a4, Math.max(a5, array[2]))));
        }
        if (n21 != 0 && (mode == Integer.MIN_VALUE || mode == 0)) {
            this.mTotalLength = 0;
            int n26;
            for (int i = 0; i < virtualChildCount; ++i, max5 = n26) {
                final View virtualChild2 = this.getVirtualChildAt(i);
                if (virtualChild2 == null) {
                    this.mTotalLength += this.measureNullChild(i);
                }
                else if (virtualChild2.getVisibility() == 8) {
                    i += this.getChildrenSkipCount(virtualChild2, i);
                }
                else {
                    final LayoutParams layoutParams2 = (LayoutParams)virtualChild2.getLayoutParams();
                    if (!b) {
                        final int mTotalLength5 = this.mTotalLength;
                        final int n25 = mTotalLength5 + max;
                        n26 = max5;
                        this.mTotalLength = Math.max(mTotalLength5, n25 + layoutParams2.leftMargin + layoutParams2.rightMargin + this.getNextLocationOffset(virtualChild2));
                        continue;
                    }
                    this.mTotalLength += max + layoutParams2.leftMargin + layoutParams2.rightMargin + this.getNextLocationOffset(virtualChild2);
                }
                n26 = max5;
            }
        }
        final int n27 = max5;
        final int n28 = this.mTotalLength + (this.getPaddingLeft() + this.getPaddingRight());
        this.mTotalLength = n28;
        final int resolveSizeAndState = View.resolveSizeAndState(Math.max(n28, this.getSuggestedMinimumWidth()), n, 0);
        int n29 = (0xFFFFFF & resolveSizeAndState) - this.mTotalLength;
        int max7;
        int n30;
        int n31;
        int n32;
        if (!b2 && (n29 == 0 || n4 <= 0.0f)) {
            max7 = Math.max(a2, b6);
            if (n21 != 0 && mode != 1073741824) {
                for (int j = 0; j < virtualChildCount; ++j) {
                    final View virtualChild3 = this.getVirtualChildAt(j);
                    if (virtualChild3 != null) {
                        if (virtualChild3.getVisibility() != 8) {
                            if (((LayoutParams)virtualChild3.getLayoutParams()).weight > 0.0f) {
                                virtualChild3.measure(View$MeasureSpec.makeMeasureSpec(max, 1073741824), View$MeasureSpec.makeMeasureSpec(virtualChild3.getMeasuredHeight(), 1073741824));
                            }
                        }
                    }
                }
            }
            n30 = n2;
            n31 = virtualChildCount;
            n32 = n27;
        }
        else {
            final float mWeightSum = this.mWeightSum;
            if (mWeightSum > 0.0f) {
                n4 = mWeightSum;
            }
            mMaxAscent[2] = (mMaxAscent[3] = -1);
            mMaxAscent[0] = (mMaxAscent[1] = -1);
            array[2] = (array[3] = -1);
            array[0] = (array[1] = -1);
            this.mTotalLength = 0;
            int a6 = a2;
            int combineMeasuredStates2 = n24;
            int max8 = -1;
            int n37;
            int n40;
            for (int k = 0; k < virtualChildCount; ++k, n29 = n40, virtualChildCount = n37) {
                final View virtualChild4 = this.getVirtualChildAt(k);
                if (virtualChild4 != null && virtualChild4.getVisibility() != 8) {
                    final LayoutParams layoutParams3 = (LayoutParams)virtualChild4.getLayoutParams();
                    final float weight = layoutParams3.weight;
                    if (weight > 0.0f) {
                        int n33 = (int)(weight * n29 / n4);
                        final float n34 = n4 - weight;
                        final int n35 = n29 - n33;
                        final int n36 = this.getPaddingTop() + this.getPaddingBottom() + layoutParams3.topMargin + layoutParams3.bottomMargin;
                        final int height = layoutParams3.height;
                        n37 = virtualChildCount;
                        final int childMeasureSpec = getChildMeasureSpec(n2, n36, height);
                        Label_1800: {
                            int n38;
                            if (layoutParams3.width == 0) {
                                n38 = 1073741824;
                                if (mode == n38) {
                                    if (n33 <= 0) {
                                        n33 = 0;
                                    }
                                    virtualChild4.measure(View$MeasureSpec.makeMeasureSpec(n33, n38), childMeasureSpec);
                                    break Label_1800;
                                }
                            }
                            else {
                                n38 = 1073741824;
                            }
                            int n39 = n33 + virtualChild4.getMeasuredWidth();
                            if (n39 < 0) {
                                n39 = 0;
                            }
                            virtualChild4.measure(View$MeasureSpec.makeMeasureSpec(n39, n38), childMeasureSpec);
                        }
                        combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates2, 0xFF000000 & virtualChild4.getMeasuredState());
                        n4 = n34;
                        n40 = n35;
                    }
                    else {
                        n40 = n29;
                        n37 = virtualChildCount;
                    }
                    float n41;
                    if (b) {
                        this.mTotalLength += virtualChild4.getMeasuredWidth() + layoutParams3.leftMargin + layoutParams3.rightMargin + this.getNextLocationOffset(virtualChild4);
                        n41 = n4;
                    }
                    else {
                        final int mTotalLength6 = this.mTotalLength;
                        final int n42 = mTotalLength6 + virtualChild4.getMeasuredWidth();
                        n41 = n4;
                        this.mTotalLength = Math.max(mTotalLength6, n42 + layoutParams3.leftMargin + layoutParams3.rightMargin + this.getNextLocationOffset(virtualChild4));
                    }
                    final boolean b7 = mode2 != 1073741824 && layoutParams3.height == -1;
                    int b8 = layoutParams3.topMargin + layoutParams3.bottomMargin;
                    final int b9 = b8 + virtualChild4.getMeasuredHeight();
                    max8 = Math.max(max8, b9);
                    if (!b7) {
                        b8 = b9;
                    }
                    final int max9 = Math.max(a6, b8);
                    int n43 = 0;
                    int n44 = 0;
                    Label_2041: {
                        if (n6 != 0) {
                            final int height2 = layoutParams3.height;
                            n43 = -1;
                            if (height2 == n43) {
                                n44 = 1;
                                break Label_2041;
                            }
                        }
                        else {
                            n43 = -1;
                        }
                        n44 = 0;
                    }
                    if (n22 != 0) {
                        final int baseline2 = virtualChild4.getBaseline();
                        if (baseline2 != n43) {
                            int n45;
                            if (layoutParams3.gravity < 0) {
                                n45 = this.mGravity;
                            }
                            else {
                                n45 = layoutParams3.gravity;
                            }
                            final int n46 = (0xFFFFFFFE & (n45 & 0x70) >> 4) >> 1;
                            mMaxAscent[n46] = Math.max(mMaxAscent[n46], baseline2);
                            array[n46] = Math.max(array[n46], b9 - baseline2);
                        }
                    }
                    n6 = n44;
                    a6 = max9;
                    n4 = n41;
                }
                else {
                    n40 = n29;
                    n37 = virtualChildCount;
                }
            }
            n30 = n2;
            n31 = virtualChildCount;
            this.mTotalLength += this.getPaddingLeft() + this.getPaddingRight();
            int max10;
            if (mMaxAscent[1] == -1 && mMaxAscent[0] == -1 && mMaxAscent[2] == -1 && mMaxAscent[3] == -1) {
                max10 = max8;
            }
            else {
                max10 = Math.max(max8, Math.max(mMaxAscent[3], Math.max(mMaxAscent[0], Math.max(mMaxAscent[1], mMaxAscent[2]))) + Math.max(array[3], Math.max(array[0], Math.max(array[1], array[2]))));
            }
            n32 = max10;
            max7 = a6;
            n24 = combineMeasuredStates2;
        }
        if (n6 != 0 || mode2 == 1073741824) {
            max7 = n32;
        }
        this.setMeasuredDimension(resolveSizeAndState | (n24 & 0xFF000000), View.resolveSizeAndState(Math.max(max7 + (this.getPaddingTop() + this.getPaddingBottom()), this.getSuggestedMinimumHeight()), n30, n24 << 16));
        if (b3) {
            this.forceUniformHeight(n31, n);
        }
    }
    
    int measureNullChild(final int n) {
        return 0;
    }
    
    void measureVertical(final int n, final int n2) {
        this.mTotalLength = 0;
        int virtualChildCount = this.getVirtualChildCount();
        final int mode = View$MeasureSpec.getMode(n);
        int mode2 = View$MeasureSpec.getMode(n2);
        final int mBaselineAlignedChildIndex = this.mBaselineAlignedChildIndex;
        final boolean mUseLargestChild = this.mUseLargestChild;
        float n3 = 0.0f;
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        int max = 0;
        int n7 = 0;
        int n8 = 0;
        boolean b = false;
        int n9 = 1;
        boolean b2 = false;
        while (true) {
            int n10 = 8;
            final int b3 = max;
            if (n8 >= virtualChildCount) {
                final int n11 = n4;
                final int n12 = n6;
                final int a = n7;
                final int n13 = virtualChildCount;
                final int n14 = mode2;
                int max2 = n5;
                int n15;
                if (this.mTotalLength > 0) {
                    n15 = n13;
                    if (this.hasDividerBeforeChildAt(n15)) {
                        this.mTotalLength += this.mDividerHeight;
                    }
                }
                else {
                    n15 = n13;
                }
                if (mUseLargestChild && (n14 == Integer.MIN_VALUE || n14 == 0)) {
                    this.mTotalLength = 0;
                    for (int i = 0; i < n15; ++i, n10 = 8) {
                        final View virtualChild = this.getVirtualChildAt(i);
                        if (virtualChild == null) {
                            this.mTotalLength += this.measureNullChild(i);
                        }
                        else if (virtualChild.getVisibility() == n10) {
                            i += this.getChildrenSkipCount(virtualChild, i);
                        }
                        else {
                            final LayoutParams layoutParams = (LayoutParams)virtualChild.getLayoutParams();
                            final int mTotalLength = this.mTotalLength;
                            this.mTotalLength = Math.max(mTotalLength, mTotalLength + n12 + layoutParams.topMargin + layoutParams.bottomMargin + this.getNextLocationOffset(virtualChild));
                        }
                    }
                }
                final int n16 = this.mTotalLength + (this.getPaddingTop() + this.getPaddingBottom());
                this.mTotalLength = n16;
                final int resolveSizeAndState = View.resolveSizeAndState(Math.max(n16, this.getSuggestedMinimumHeight()), n2, 0);
                final int n17 = (0xFFFFFF & resolveSizeAndState) - this.mTotalLength;
                int max3;
                int n18;
                int combineMeasuredStates;
                if (!b && (n17 == 0 || n3 <= 0.0f)) {
                    max3 = Math.max(a, b3);
                    if (mUseLargestChild && n14 != 1073741824) {
                        for (int j = 0; j < n15; ++j) {
                            final View virtualChild2 = this.getVirtualChildAt(j);
                            if (virtualChild2 != null) {
                                if (virtualChild2.getVisibility() != 8) {
                                    if (((LayoutParams)virtualChild2.getLayoutParams()).weight > 0.0f) {
                                        virtualChild2.measure(View$MeasureSpec.makeMeasureSpec(virtualChild2.getMeasuredWidth(), 1073741824), View$MeasureSpec.makeMeasureSpec(n12, 1073741824));
                                    }
                                }
                            }
                        }
                    }
                    n18 = n;
                    combineMeasuredStates = n11;
                }
                else {
                    final float mWeightSum = this.mWeightSum;
                    if (mWeightSum > 0.0f) {
                        n3 = mWeightSum;
                    }
                    this.mTotalLength = 0;
                    int n19 = n17;
                    int a2 = a;
                    combineMeasuredStates = n11;
                    int n20;
                    for (int k = 0; k < n15; ++k, n19 = n20) {
                        final View virtualChild3 = this.getVirtualChildAt(k);
                        if (virtualChild3.getVisibility() == 8) {
                            n20 = n19;
                        }
                        else {
                            final LayoutParams layoutParams2 = (LayoutParams)virtualChild3.getLayoutParams();
                            final float weight = layoutParams2.weight;
                            if (weight > 0.0f) {
                                int n21 = (int)(weight * n19 / n3);
                                final float n22 = n3 - weight;
                                final int n23 = n19 - n21;
                                final int n24 = this.getPaddingLeft() + this.getPaddingRight() + layoutParams2.leftMargin + layoutParams2.rightMargin;
                                final int width = layoutParams2.width;
                                n20 = n23;
                                final int childMeasureSpec = getChildMeasureSpec(n, n24, width);
                                Label_1415: {
                                    int n25;
                                    if (layoutParams2.height == 0) {
                                        n25 = 1073741824;
                                        if (n14 == n25) {
                                            if (n21 <= 0) {
                                                n21 = 0;
                                            }
                                            virtualChild3.measure(childMeasureSpec, View$MeasureSpec.makeMeasureSpec(n21, n25));
                                            break Label_1415;
                                        }
                                    }
                                    else {
                                        n25 = 1073741824;
                                    }
                                    int n26 = n21 + virtualChild3.getMeasuredHeight();
                                    if (n26 < 0) {
                                        n26 = 0;
                                    }
                                    virtualChild3.measure(childMeasureSpec, View$MeasureSpec.makeMeasureSpec(n26, n25));
                                }
                                combineMeasuredStates = View.combineMeasuredStates(combineMeasuredStates, 0xFFFFFF00 & virtualChild3.getMeasuredState());
                                n3 = n22;
                            }
                            else {
                                n20 = n19;
                            }
                            int b4 = layoutParams2.leftMargin + layoutParams2.rightMargin;
                            final int b5 = b4 + virtualChild3.getMeasuredWidth();
                            max2 = Math.max(max2, b5);
                            final float n27 = n3;
                            int n28 = 0;
                            int n29 = 0;
                            boolean b6 = false;
                            Label_1522: {
                                if (mode != 1073741824) {
                                    final int width2 = layoutParams2.width;
                                    n28 = combineMeasuredStates;
                                    n29 = -1;
                                    if (width2 == n29) {
                                        b6 = true;
                                        break Label_1522;
                                    }
                                }
                                else {
                                    n28 = combineMeasuredStates;
                                    n29 = -1;
                                }
                                b6 = false;
                            }
                            if (!b6) {
                                b4 = b5;
                            }
                            final int max4 = Math.max(a2, b4);
                            int n30;
                            if (n9 != 0 && layoutParams2.width == n29) {
                                n30 = 1;
                            }
                            else {
                                n30 = 0;
                            }
                            final int mTotalLength2 = this.mTotalLength;
                            this.mTotalLength = Math.max(mTotalLength2, mTotalLength2 + virtualChild3.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin + this.getNextLocationOffset(virtualChild3));
                            n9 = n30;
                            combineMeasuredStates = n28;
                            a2 = max4;
                            n3 = n27;
                        }
                    }
                    n18 = n;
                    this.mTotalLength += this.getPaddingTop() + this.getPaddingBottom();
                    max3 = a2;
                }
                if (n9 != 0 || mode == 1073741824) {
                    max3 = max2;
                }
                this.setMeasuredDimension(View.resolveSizeAndState(Math.max(max3 + (this.getPaddingLeft() + this.getPaddingRight()), this.getSuggestedMinimumWidth()), n18, combineMeasuredStates), resolveSizeAndState);
                if (b2) {
                    this.forceUniformWidth(n15, n2);
                }
                return;
            }
            final View virtualChild4 = this.getVirtualChildAt(n8);
            int n31;
            int n32;
            if (virtualChild4 == null) {
                this.mTotalLength += this.measureNullChild(n8);
                n31 = virtualChildCount;
                n32 = mode2;
                max = b3;
            }
            else {
                final int n33 = n4;
                if (virtualChild4.getVisibility() == n10) {
                    n8 += this.getChildrenSkipCount(virtualChild4, n8);
                    n31 = virtualChildCount;
                    max = b3;
                    n4 = n33;
                    n32 = mode2;
                }
                else {
                    if (this.hasDividerBeforeChildAt(n8)) {
                        this.mTotalLength += this.mDividerHeight;
                    }
                    final LayoutParams layoutParams3 = (LayoutParams)virtualChild4.getLayoutParams();
                    final float n34 = n3 + layoutParams3.weight;
                    int max5;
                    View view;
                    int a3;
                    int n37;
                    int a4;
                    int n38;
                    int a5;
                    if (mode2 == 1073741824 && layoutParams3.height == 0 && layoutParams3.weight > 0.0f) {
                        final int mTotalLength3 = this.mTotalLength;
                        final int n35 = mTotalLength3 + layoutParams3.topMargin;
                        final int n36 = n5;
                        this.mTotalLength = Math.max(mTotalLength3, n35 + layoutParams3.bottomMargin);
                        max5 = n6;
                        view = virtualChild4;
                        a3 = n7;
                        n31 = virtualChildCount;
                        n37 = n33;
                        a4 = n36;
                        b = true;
                        n38 = n8;
                        n32 = mode2;
                        a5 = b3;
                    }
                    else {
                        final int n39 = n5;
                        int n40;
                        if (layoutParams3.height == 0 && layoutParams3.weight > 0.0f) {
                            layoutParams3.height = -2;
                            n40 = 0;
                        }
                        else {
                            n40 = Integer.MIN_VALUE;
                        }
                        int mTotalLength4;
                        if (n34 == 0.0f) {
                            mTotalLength4 = this.mTotalLength;
                        }
                        else {
                            mTotalLength4 = 0;
                        }
                        n37 = n33;
                        final int height = n40;
                        a4 = n39;
                        final int n41 = n8;
                        final int b7 = n6;
                        n31 = virtualChildCount;
                        n32 = mode2;
                        a5 = b3;
                        a3 = n7;
                        n38 = n8;
                        this.measureChildBeforeLayout(virtualChild4, n41, n, 0, n2, mTotalLength4);
                        if (height != Integer.MIN_VALUE) {
                            layoutParams3.height = height;
                        }
                        final int measuredHeight = virtualChild4.getMeasuredHeight();
                        final int mTotalLength5 = this.mTotalLength;
                        final int n42 = mTotalLength5 + measuredHeight + layoutParams3.topMargin + layoutParams3.bottomMargin;
                        view = virtualChild4;
                        this.mTotalLength = Math.max(mTotalLength5, n42 + this.getNextLocationOffset(view));
                        if (mUseLargestChild) {
                            max5 = Math.max(measuredHeight, b7);
                        }
                        else {
                            max5 = b7;
                        }
                    }
                    if (mBaselineAlignedChildIndex >= 0 && mBaselineAlignedChildIndex == n38 + 1) {
                        this.mBaselineChildTop = this.mTotalLength;
                    }
                    if (n38 < mBaselineAlignedChildIndex && layoutParams3.weight > 0.0f) {
                        throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                    }
                    boolean b8;
                    if (mode != 1073741824 && layoutParams3.width == -1) {
                        b8 = true;
                        b2 = true;
                    }
                    else {
                        b8 = false;
                    }
                    int n43 = layoutParams3.leftMargin + layoutParams3.rightMargin;
                    final int b9 = n43 + view.getMeasuredWidth();
                    final int max6 = Math.max(a4, b9);
                    final int combineMeasuredStates2 = View.combineMeasuredStates(n37, view.getMeasuredState());
                    if (n9 != 0 && layoutParams3.width == -1) {
                        n9 = 1;
                    }
                    else {
                        n9 = 0;
                    }
                    int max7;
                    if (layoutParams3.weight > 0.0f) {
                        if (!b8) {
                            n43 = b9;
                        }
                        max = Math.max(a5, n43);
                        max7 = a3;
                    }
                    else {
                        if (!b8) {
                            n43 = b9;
                        }
                        max7 = Math.max(a3, n43);
                        max = a5;
                    }
                    final int n44 = n38 + this.getChildrenSkipCount(view, n38);
                    n6 = max5;
                    n3 = n34;
                    n7 = max7;
                    n4 = combineMeasuredStates2;
                    n8 = n44;
                    n5 = max6;
                }
            }
            ++n8;
            virtualChildCount = n31;
            mode2 = n32;
        }
    }
    
    protected void onDraw(final Canvas canvas) {
        if (this.mDivider == null) {
            return;
        }
        if (this.mOrientation == 1) {
            this.drawDividersVertical(canvas);
        }
        else {
            this.drawDividersHorizontal(canvas);
        }
    }
    
    public void onInitializeAccessibilityEvent(final AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName((CharSequence)"androidx.appcompat.widget.LinearLayoutCompat");
    }
    
    public void onInitializeAccessibilityNodeInfo(final AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName((CharSequence)"androidx.appcompat.widget.LinearLayoutCompat");
    }
    
    protected void onLayout(final boolean b, final int n, final int n2, final int n3, final int n4) {
        if (this.mOrientation == 1) {
            this.layoutVertical(n, n2, n3, n4);
        }
        else {
            this.layoutHorizontal(n, n2, n3, n4);
        }
    }
    
    protected void onMeasure(final int n, final int n2) {
        if (this.mOrientation == 1) {
            this.measureVertical(n, n2);
        }
        else {
            this.measureHorizontal(n, n2);
        }
    }
    
    public void setBaselineAligned(final boolean mBaselineAligned) {
        this.mBaselineAligned = mBaselineAligned;
    }
    
    public void setBaselineAlignedChildIndex(final int mBaselineAlignedChildIndex) {
        if (mBaselineAlignedChildIndex >= 0 && mBaselineAlignedChildIndex < this.getChildCount()) {
            this.mBaselineAlignedChildIndex = mBaselineAlignedChildIndex;
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("base aligned child index out of range (0, ");
        sb.append(this.getChildCount());
        sb.append(")");
        throw new IllegalArgumentException(sb.toString());
    }
    
    public void setDividerDrawable(final Drawable mDivider) {
        if (mDivider == this.mDivider) {
            return;
        }
        if ((this.mDivider = mDivider) != null) {
            this.mDividerWidth = mDivider.getIntrinsicWidth();
            this.mDividerHeight = mDivider.getIntrinsicHeight();
        }
        else {
            this.mDividerWidth = 0;
            this.mDividerHeight = 0;
        }
        boolean willNotDraw = false;
        if (mDivider == null) {
            willNotDraw = true;
        }
        this.setWillNotDraw(willNotDraw);
        this.requestLayout();
    }
    
    public void setDividerPadding(final int mDividerPadding) {
        this.mDividerPadding = mDividerPadding;
    }
    
    public void setGravity(int mGravity) {
        if (this.mGravity != mGravity) {
            if ((0x800007 & mGravity) == 0x0) {
                mGravity |= 0x800003;
            }
            if ((mGravity & 0x70) == 0x0) {
                mGravity |= 0x30;
            }
            this.mGravity = mGravity;
            this.requestLayout();
        }
    }
    
    public void setHorizontalGravity(final int n) {
        final int n2 = n & 0x800007;
        final int mGravity = this.mGravity;
        if ((0x800007 & mGravity) != n2) {
            this.mGravity = (n2 | (0xFF7FFFF8 & mGravity));
            this.requestLayout();
        }
    }
    
    public void setMeasureWithLargestChildEnabled(final boolean mUseLargestChild) {
        this.mUseLargestChild = mUseLargestChild;
    }
    
    public void setOrientation(final int mOrientation) {
        if (this.mOrientation != mOrientation) {
            this.mOrientation = mOrientation;
            this.requestLayout();
        }
    }
    
    public void setShowDividers(final int mShowDividers) {
        if (mShowDividers != this.mShowDividers) {
            this.requestLayout();
        }
        this.mShowDividers = mShowDividers;
    }
    
    public void setVerticalGravity(final int n) {
        final int n2 = n & 0x70;
        final int mGravity = this.mGravity;
        if ((mGravity & 0x70) != n2) {
            this.mGravity = (n2 | (mGravity & 0xFFFFFF8F));
            this.requestLayout();
        }
    }
    
    public void setWeightSum(final float b) {
        this.mWeightSum = Math.max(0.0f, b);
    }
    
    public boolean shouldDelayChildPressedState() {
        return false;
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface DividerMode {
    }
    
    public static class LayoutParams extends ViewGroup$MarginLayoutParams
    {
        public int gravity;
        public float weight;
        
        public LayoutParams(final int n, final int n2) {
            super(n, n2);
            this.gravity = -1;
            this.weight = 0.0f;
        }
        
        public LayoutParams(final int n, final int n2, final float weight) {
            super(n, n2);
            this.gravity = -1;
            this.weight = weight;
        }
        
        public LayoutParams(final Context context, final AttributeSet set) {
            super(context, set);
            this.gravity = -1;
            final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, R.styleable.LinearLayoutCompat_Layout);
            this.weight = obtainStyledAttributes.getFloat(R.styleable.LinearLayoutCompat_Layout_android_layout_weight, 0.0f);
            this.gravity = obtainStyledAttributes.getInt(R.styleable.LinearLayoutCompat_Layout_android_layout_gravity, -1);
            obtainStyledAttributes.recycle();
        }
        
        public LayoutParams(final ViewGroup$LayoutParams viewGroup$LayoutParams) {
            super(viewGroup$LayoutParams);
            this.gravity = -1;
        }
        
        public LayoutParams(final ViewGroup$MarginLayoutParams viewGroup$MarginLayoutParams) {
            super(viewGroup$MarginLayoutParams);
            this.gravity = -1;
        }
        
        public LayoutParams(final LayoutParams layoutParams) {
            super((ViewGroup$MarginLayoutParams)layoutParams);
            this.gravity = -1;
            this.weight = layoutParams.weight;
            this.gravity = layoutParams.gravity;
        }
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface OrientationMode {
    }
}
