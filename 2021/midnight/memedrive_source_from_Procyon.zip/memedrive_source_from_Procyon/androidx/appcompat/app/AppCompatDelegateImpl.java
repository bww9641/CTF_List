// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.app;

import android.os.Parcel;
import android.os.Parcelable$ClassLoaderCreator;
import android.os.Parcelable$Creator;
import android.os.Parcelable;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.view.menu.ListMenuPresenter;
import androidx.appcompat.content.res.AppCompatResources;
import android.view.MotionEvent;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.PowerManager;
import androidx.appcompat.view.SupportActionModeWrapper;
import android.view.ActionMode$Callback;
import android.view.KeyboardShortcutGroup;
import java.util.List;
import androidx.appcompat.view.WindowCallbackWrapper;
import androidx.core.view.ViewPropertyAnimatorListener;
import androidx.core.view.ViewPropertyAnimatorListenerAdapter;
import android.view.ViewGroup$MarginLayoutParams;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.app.UiModeManager;
import androidx.core.view.LayoutInflaterCompat;
import androidx.appcompat.view.SupportMenuInflater;
import android.os.Bundle;
import androidx.core.view.KeyEventDispatcher;
import androidx.appcompat.widget.VectorEnabledTintResources;
import org.xmlpull.v1.XmlPullParser;
import android.content.res.Resources;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import android.util.DisplayMetrics;
import androidx.core.app.ActivityCompat;
import android.content.res.Configuration;
import android.content.ContextWrapper;
import android.util.AndroidRuntimeException;
import android.view.KeyCharacterMap;
import android.view.ViewParent;
import android.view.WindowManager$LayoutParams;
import android.view.ViewGroup$LayoutParams;
import android.view.WindowManager;
import android.view.Menu;
import android.media.AudioManager;
import android.view.ViewConfiguration;
import android.view.KeyEvent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager$NameNotFoundException;
import android.util.Log;
import android.content.ComponentName;
import android.content.res.Resources$Theme;
import androidx.appcompat.view.menu.MenuPresenter;
import android.text.TextUtils;
import android.widget.FrameLayout;
import androidx.appcompat.widget.ViewUtils;
import androidx.appcompat.widget.FitWindowsViewGroup;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.appcompat.view.ContextThemeWrapper;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import androidx.appcompat.widget.TintTypedArray;
import android.view.Window$Callback;
import android.content.res.TypedArray;
import androidx.appcompat.R;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.AppCompatDrawableManager;
import android.app.Dialog;
import android.app.Activity;
import android.content.res.Resources$NotFoundException;
import android.os.Build$VERSION;
import androidx.collection.ArrayMap;
import android.view.Window;
import android.widget.TextView;
import android.graphics.Rect;
import android.view.ViewGroup;
import android.view.View;
import android.view.MenuInflater;
import androidx.core.view.ViewPropertyAnimatorCompat;
import androidx.appcompat.widget.DecorContentParent;
import android.content.Context;
import androidx.appcompat.widget.ActionBarContextView;
import android.widget.PopupWindow;
import androidx.appcompat.view.ActionMode;
import java.util.Map;
import android.view.LayoutInflater$Factory2;
import androidx.appcompat.view.menu.MenuBuilder;

class AppCompatDelegateImpl extends AppCompatDelegate implements Callback, LayoutInflater$Factory2
{
    private static final boolean DEBUG = false;
    static final String EXCEPTION_HANDLER_MESSAGE_SUFFIX = ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.";
    private static final boolean IS_PRE_LOLLIPOP;
    private static final boolean sAlwaysOverrideConfiguration;
    private static boolean sInstalledExceptionHandler;
    private static final Map<Class<?>, Integer> sLocalNightModes;
    private static final int[] sWindowBackgroundStyleable;
    ActionBar mActionBar;
    private ActionMenuPresenterCallback mActionMenuPresenterCallback;
    ActionMode mActionMode;
    PopupWindow mActionModePopup;
    ActionBarContextView mActionModeView;
    private boolean mActivityHandlesUiMode;
    private boolean mActivityHandlesUiModeChecked;
    final AppCompatCallback mAppCompatCallback;
    private AppCompatViewInflater mAppCompatViewInflater;
    private AppCompatWindowCallback mAppCompatWindowCallback;
    private AutoNightModeManager mAutoBatteryNightModeManager;
    private AutoNightModeManager mAutoTimeNightModeManager;
    private boolean mBaseContextAttached;
    private boolean mClosingActionMenu;
    final Context mContext;
    private boolean mCreated;
    private DecorContentParent mDecorContentParent;
    private boolean mEnableDefaultActionBarUp;
    ViewPropertyAnimatorCompat mFadeAnim;
    private boolean mFeatureIndeterminateProgress;
    private boolean mFeatureProgress;
    private boolean mHandleNativeActionModes;
    boolean mHasActionBar;
    final Object mHost;
    int mInvalidatePanelMenuFeatures;
    boolean mInvalidatePanelMenuPosted;
    private final Runnable mInvalidatePanelMenuRunnable;
    boolean mIsDestroyed;
    boolean mIsFloating;
    private int mLocalNightMode;
    private boolean mLongPressBackDown;
    MenuInflater mMenuInflater;
    boolean mOverlayActionBar;
    boolean mOverlayActionMode;
    private PanelMenuPresenterCallback mPanelMenuPresenterCallback;
    private PanelFeatureState[] mPanels;
    private PanelFeatureState mPreparedPanel;
    Runnable mShowActionModePopup;
    private boolean mStarted;
    private View mStatusGuard;
    private ViewGroup mSubDecor;
    private boolean mSubDecorInstalled;
    private Rect mTempRect1;
    private Rect mTempRect2;
    private int mThemeResId;
    private CharSequence mTitle;
    private TextView mTitleView;
    Window mWindow;
    boolean mWindowNoTitle;
    
    static {
        sLocalNightModes = new ArrayMap<Class<?>, Integer>();
        final boolean b = IS_PRE_LOLLIPOP = (Build$VERSION.SDK_INT < 21);
        sWindowBackgroundStyleable = new int[] { 16842836 };
        final int sdk_INT = Build$VERSION.SDK_INT;
        boolean sAlwaysOverrideConfiguration2 = false;
        if (sdk_INT >= 21) {
            final int sdk_INT2 = Build$VERSION.SDK_INT;
            sAlwaysOverrideConfiguration2 = false;
            if (sdk_INT2 <= 25) {
                sAlwaysOverrideConfiguration2 = true;
            }
        }
        sAlwaysOverrideConfiguration = sAlwaysOverrideConfiguration2;
        if (b && !AppCompatDelegateImpl.sInstalledExceptionHandler) {
            Thread.setDefaultUncaughtExceptionHandler((Thread.UncaughtExceptionHandler)new Thread.UncaughtExceptionHandler() {
                final /* synthetic */ UncaughtExceptionHandler val$defHandler = Thread.getDefaultUncaughtExceptionHandler();
                
                private boolean shouldWrapException(final Throwable t) {
                    final boolean b = t instanceof Resources$NotFoundException;
                    boolean b2 = false;
                    if (b) {
                        final String message = t.getMessage();
                        b2 = false;
                        if (message != null) {
                            if (!message.contains("drawable")) {
                                final boolean contains = message.contains("Drawable");
                                b2 = false;
                                if (!contains) {
                                    return b2;
                                }
                            }
                            b2 = true;
                        }
                    }
                    return b2;
                }
                
                @Override
                public void uncaughtException(final Thread thread, final Throwable t) {
                    if (this.shouldWrapException(t)) {
                        final StringBuilder sb = new StringBuilder();
                        sb.append(t.getMessage());
                        sb.append(". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
                        final Resources$NotFoundException ex = new Resources$NotFoundException(sb.toString());
                        ((Throwable)ex).initCause(t.getCause());
                        ((Throwable)ex).setStackTrace(t.getStackTrace());
                        this.val$defHandler.uncaughtException(thread, (Throwable)ex);
                    }
                    else {
                        this.val$defHandler.uncaughtException(thread, t);
                    }
                }
            });
            AppCompatDelegateImpl.sInstalledExceptionHandler = true;
        }
    }
    
    AppCompatDelegateImpl(final Activity activity, final AppCompatCallback appCompatCallback) {
        this((Context)activity, null, appCompatCallback, activity);
    }
    
    AppCompatDelegateImpl(final Dialog dialog, final AppCompatCallback appCompatCallback) {
        this(dialog.getContext(), dialog.getWindow(), appCompatCallback, dialog);
    }
    
    AppCompatDelegateImpl(final Context context, final Activity activity, final AppCompatCallback appCompatCallback) {
        this(context, null, appCompatCallback, activity);
    }
    
    AppCompatDelegateImpl(final Context context, final Window window, final AppCompatCallback appCompatCallback) {
        this(context, window, appCompatCallback, context);
    }
    
    private AppCompatDelegateImpl(final Context mContext, final Window window, final AppCompatCallback mAppCompatCallback, final Object mHost) {
        this.mFadeAnim = null;
        this.mHandleNativeActionModes = true;
        this.mLocalNightMode = -100;
        this.mInvalidatePanelMenuRunnable = new Runnable() {
            @Override
            public void run() {
                if ((0x1 & AppCompatDelegateImpl.this.mInvalidatePanelMenuFeatures) != 0x0) {
                    AppCompatDelegateImpl.this.doInvalidatePanelMenu(0);
                }
                if ((0x1000 & AppCompatDelegateImpl.this.mInvalidatePanelMenuFeatures) != 0x0) {
                    AppCompatDelegateImpl.this.doInvalidatePanelMenu(108);
                }
                AppCompatDelegateImpl.this.mInvalidatePanelMenuPosted = false;
                AppCompatDelegateImpl.this.mInvalidatePanelMenuFeatures = 0;
            }
        };
        this.mContext = mContext;
        this.mAppCompatCallback = mAppCompatCallback;
        this.mHost = mHost;
        if (this.mLocalNightMode == -100 && mHost instanceof Dialog) {
            final AppCompatActivity tryUnwrapContext = this.tryUnwrapContext();
            if (tryUnwrapContext != null) {
                this.mLocalNightMode = tryUnwrapContext.getDelegate().getLocalNightMode();
            }
        }
        if (this.mLocalNightMode == -100) {
            final Map<Class<?>, Integer> sLocalNightModes = AppCompatDelegateImpl.sLocalNightModes;
            final Integer n = sLocalNightModes.get(mHost.getClass());
            if (n != null) {
                this.mLocalNightMode = n;
                sLocalNightModes.remove(mHost.getClass());
            }
        }
        if (window != null) {
            this.attachToWindow(window);
        }
        AppCompatDrawableManager.preload();
    }
    
    private boolean applyDayNight(final boolean b) {
        if (this.mIsDestroyed) {
            return false;
        }
        final int calculateNightMode = this.calculateNightMode();
        final boolean updateForNightMode = this.updateForNightMode(this.mapNightMode(calculateNightMode), b);
        if (calculateNightMode == 0) {
            this.getAutoTimeNightModeManager().setup();
        }
        else {
            final AutoNightModeManager mAutoTimeNightModeManager = this.mAutoTimeNightModeManager;
            if (mAutoTimeNightModeManager != null) {
                mAutoTimeNightModeManager.cleanup();
            }
        }
        if (calculateNightMode == 3) {
            this.getAutoBatteryNightModeManager().setup();
        }
        else {
            final AutoNightModeManager mAutoBatteryNightModeManager = this.mAutoBatteryNightModeManager;
            if (mAutoBatteryNightModeManager != null) {
                mAutoBatteryNightModeManager.cleanup();
            }
        }
        return updateForNightMode;
    }
    
    private void applyFixedSizeWindow() {
        final ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.mSubDecor.findViewById(16908290);
        final View decorView = this.mWindow.getDecorView();
        contentFrameLayout.setDecorPadding(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        final TypedArray obtainStyledAttributes = this.mContext.obtainStyledAttributes(R.styleable.AppCompatTheme);
        obtainStyledAttributes.getValue(R.styleable.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
        obtainStyledAttributes.getValue(R.styleable.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTheme_windowFixedWidthMajor)) {
            obtainStyledAttributes.getValue(R.styleable.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor());
        }
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTheme_windowFixedWidthMinor)) {
            obtainStyledAttributes.getValue(R.styleable.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor());
        }
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTheme_windowFixedHeightMajor)) {
            obtainStyledAttributes.getValue(R.styleable.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor());
        }
        if (obtainStyledAttributes.hasValue(R.styleable.AppCompatTheme_windowFixedHeightMinor)) {
            obtainStyledAttributes.getValue(R.styleable.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor());
        }
        obtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }
    
    private void attachToWindow(final Window mWindow) {
        if (this.mWindow != null) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        final Window$Callback callback = mWindow.getCallback();
        if (!(callback instanceof AppCompatWindowCallback)) {
            mWindow.setCallback((Window$Callback)(this.mAppCompatWindowCallback = new AppCompatWindowCallback(callback)));
            final TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(this.mContext, null, AppCompatDelegateImpl.sWindowBackgroundStyleable);
            final Drawable drawableIfKnown = obtainStyledAttributes.getDrawableIfKnown(0);
            if (drawableIfKnown != null) {
                mWindow.setBackgroundDrawable(drawableIfKnown);
            }
            obtainStyledAttributes.recycle();
            this.mWindow = mWindow;
            return;
        }
        throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }
    
    private int calculateNightMode() {
        int n = this.mLocalNightMode;
        if (n == -100) {
            n = AppCompatDelegate.getDefaultNightMode();
        }
        return n;
    }
    
    private void cleanupAutoManagers() {
        final AutoNightModeManager mAutoTimeNightModeManager = this.mAutoTimeNightModeManager;
        if (mAutoTimeNightModeManager != null) {
            mAutoTimeNightModeManager.cleanup();
        }
        final AutoNightModeManager mAutoBatteryNightModeManager = this.mAutoBatteryNightModeManager;
        if (mAutoBatteryNightModeManager != null) {
            mAutoBatteryNightModeManager.cleanup();
        }
    }
    
    private ViewGroup createSubDecor() {
        final TypedArray obtainStyledAttributes = this.mContext.obtainStyledAttributes(R.styleable.AppCompatTheme);
        if (!obtainStyledAttributes.hasValue(R.styleable.AppCompatTheme_windowActionBar)) {
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (obtainStyledAttributes.getBoolean(R.styleable.AppCompatTheme_windowNoTitle, false)) {
            this.requestWindowFeature(1);
        }
        else if (obtainStyledAttributes.getBoolean(R.styleable.AppCompatTheme_windowActionBar, false)) {
            this.requestWindowFeature(108);
        }
        if (obtainStyledAttributes.getBoolean(R.styleable.AppCompatTheme_windowActionBarOverlay, false)) {
            this.requestWindowFeature(109);
        }
        if (obtainStyledAttributes.getBoolean(R.styleable.AppCompatTheme_windowActionModeOverlay, false)) {
            this.requestWindowFeature(10);
        }
        this.mIsFloating = obtainStyledAttributes.getBoolean(R.styleable.AppCompatTheme_android_windowIsFloating, false);
        obtainStyledAttributes.recycle();
        this.ensureWindow();
        this.mWindow.getDecorView();
        final LayoutInflater from = LayoutInflater.from(this.mContext);
        ViewGroup contentView;
        if (!this.mWindowNoTitle) {
            if (this.mIsFloating) {
                contentView = (ViewGroup)from.inflate(R.layout.abc_dialog_title_material, (ViewGroup)null);
                this.mOverlayActionBar = false;
                this.mHasActionBar = false;
            }
            else if (this.mHasActionBar) {
                final TypedValue typedValue = new TypedValue();
                this.mContext.getTheme().resolveAttribute(R.attr.actionBarTheme, typedValue, true);
                Object mContext;
                if (typedValue.resourceId != 0) {
                    mContext = new ContextThemeWrapper(this.mContext, typedValue.resourceId);
                }
                else {
                    mContext = this.mContext;
                }
                contentView = (ViewGroup)LayoutInflater.from((Context)mContext).inflate(R.layout.abc_screen_toolbar, (ViewGroup)null);
                (this.mDecorContentParent = (DecorContentParent)contentView.findViewById(R.id.decor_content_parent)).setWindowCallback(this.getWindowCallback());
                if (this.mOverlayActionBar) {
                    this.mDecorContentParent.initFeature(109);
                }
                if (this.mFeatureProgress) {
                    this.mDecorContentParent.initFeature(2);
                }
                if (this.mFeatureIndeterminateProgress) {
                    this.mDecorContentParent.initFeature(5);
                }
            }
            else {
                contentView = null;
            }
        }
        else {
            if (this.mOverlayActionMode) {
                contentView = (ViewGroup)from.inflate(R.layout.abc_screen_simple_overlay_action_mode, (ViewGroup)null);
            }
            else {
                contentView = (ViewGroup)from.inflate(R.layout.abc_screen_simple, (ViewGroup)null);
            }
            if (Build$VERSION.SDK_INT >= 21) {
                ViewCompat.setOnApplyWindowInsetsListener((View)contentView, new OnApplyWindowInsetsListener() {
                    @Override
                    public WindowInsetsCompat onApplyWindowInsets(final View view, WindowInsetsCompat replaceSystemWindowInsets) {
                        final int systemWindowInsetTop = replaceSystemWindowInsets.getSystemWindowInsetTop();
                        final int updateStatusGuard = AppCompatDelegateImpl.this.updateStatusGuard(systemWindowInsetTop);
                        if (systemWindowInsetTop != updateStatusGuard) {
                            replaceSystemWindowInsets = replaceSystemWindowInsets.replaceSystemWindowInsets(replaceSystemWindowInsets.getSystemWindowInsetLeft(), updateStatusGuard, replaceSystemWindowInsets.getSystemWindowInsetRight(), replaceSystemWindowInsets.getSystemWindowInsetBottom());
                        }
                        return ViewCompat.onApplyWindowInsets(view, replaceSystemWindowInsets);
                    }
                });
            }
            else {
                ((FitWindowsViewGroup)contentView).setOnFitSystemWindowsListener((FitWindowsViewGroup.OnFitSystemWindowsListener)new FitWindowsViewGroup.OnFitSystemWindowsListener() {
                    @Override
                    public void onFitSystemWindows(final Rect rect) {
                        rect.top = AppCompatDelegateImpl.this.updateStatusGuard(rect.top);
                    }
                });
            }
        }
        if (contentView != null) {
            if (this.mDecorContentParent == null) {
                this.mTitleView = (TextView)contentView.findViewById(R.id.title);
            }
            ViewUtils.makeOptionalFitsSystemWindows((View)contentView);
            final ContentFrameLayout contentFrameLayout = (ContentFrameLayout)contentView.findViewById(R.id.action_bar_activity_content);
            final ViewGroup viewGroup = (ViewGroup)this.mWindow.findViewById(16908290);
            if (viewGroup != null) {
                while (viewGroup.getChildCount() > 0) {
                    final View child = viewGroup.getChildAt(0);
                    viewGroup.removeViewAt(0);
                    contentFrameLayout.addView(child);
                }
                viewGroup.setId(-1);
                contentFrameLayout.setId(16908290);
                if (viewGroup instanceof FrameLayout) {
                    ((FrameLayout)viewGroup).setForeground((Drawable)null);
                }
            }
            this.mWindow.setContentView((View)contentView);
            contentFrameLayout.setAttachListener((ContentFrameLayout.OnAttachListener)new ContentFrameLayout.OnAttachListener() {
                @Override
                public void onAttachedFromWindow() {
                }
                
                @Override
                public void onDetachedFromWindow() {
                    AppCompatDelegateImpl.this.dismissPopups();
                }
            });
            return contentView;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("AppCompat does not support the current theme features: { windowActionBar: ");
        sb.append(this.mHasActionBar);
        sb.append(", windowActionBarOverlay: ");
        sb.append(this.mOverlayActionBar);
        sb.append(", android:windowIsFloating: ");
        sb.append(this.mIsFloating);
        sb.append(", windowActionModeOverlay: ");
        sb.append(this.mOverlayActionMode);
        sb.append(", windowNoTitle: ");
        sb.append(this.mWindowNoTitle);
        sb.append(" }");
        throw new IllegalArgumentException(sb.toString());
    }
    
    private void ensureSubDecor() {
        if (!this.mSubDecorInstalled) {
            this.mSubDecor = this.createSubDecor();
            final CharSequence title = this.getTitle();
            if (!TextUtils.isEmpty(title)) {
                final DecorContentParent mDecorContentParent = this.mDecorContentParent;
                if (mDecorContentParent != null) {
                    mDecorContentParent.setWindowTitle(title);
                }
                else if (this.peekSupportActionBar() != null) {
                    this.peekSupportActionBar().setWindowTitle(title);
                }
                else {
                    final TextView mTitleView = this.mTitleView;
                    if (mTitleView != null) {
                        mTitleView.setText(title);
                    }
                }
            }
            this.applyFixedSizeWindow();
            this.onSubDecorInstalled(this.mSubDecor);
            this.mSubDecorInstalled = true;
            final PanelFeatureState panelState = this.getPanelState(0, false);
            if (!this.mIsDestroyed && (panelState == null || panelState.menu == null)) {
                this.invalidatePanelMenu(108);
            }
        }
    }
    
    private void ensureWindow() {
        if (this.mWindow == null) {
            final Object mHost = this.mHost;
            if (mHost instanceof Activity) {
                this.attachToWindow(((Activity)mHost).getWindow());
            }
        }
        if (this.mWindow != null) {
            return;
        }
        throw new IllegalStateException("We have not been given a Window");
    }
    
    private AutoNightModeManager getAutoBatteryNightModeManager() {
        if (this.mAutoBatteryNightModeManager == null) {
            this.mAutoBatteryNightModeManager = (AutoNightModeManager)new AutoBatteryNightModeManager(this.mContext);
        }
        return this.mAutoBatteryNightModeManager;
    }
    
    private void initWindowDecorActionBar() {
        this.ensureSubDecor();
        if (this.mHasActionBar) {
            if (this.mActionBar == null) {
                final Object mHost = this.mHost;
                if (mHost instanceof Activity) {
                    this.mActionBar = new WindowDecorActionBar((Activity)this.mHost, this.mOverlayActionBar);
                }
                else if (mHost instanceof Dialog) {
                    this.mActionBar = new WindowDecorActionBar((Dialog)this.mHost);
                }
                final ActionBar mActionBar = this.mActionBar;
                if (mActionBar != null) {
                    mActionBar.setDefaultDisplayHomeAsUpEnabled(this.mEnableDefaultActionBarUp);
                }
            }
        }
    }
    
    private boolean initializePanelContent(final PanelFeatureState panelFeatureState) {
        final View createdPanelView = panelFeatureState.createdPanelView;
        boolean b = true;
        if (createdPanelView != null) {
            panelFeatureState.shownPanelView = panelFeatureState.createdPanelView;
            return b;
        }
        if (panelFeatureState.menu == null) {
            return false;
        }
        if (this.mPanelMenuPresenterCallback == null) {
            this.mPanelMenuPresenterCallback = new PanelMenuPresenterCallback();
        }
        panelFeatureState.shownPanelView = (View)panelFeatureState.getListMenuView(this.mPanelMenuPresenterCallback);
        if (panelFeatureState.shownPanelView == null) {
            b = false;
        }
        return b;
    }
    
    private boolean initializePanelDecor(final PanelFeatureState panelFeatureState) {
        panelFeatureState.setStyle(this.getActionBarThemedContext());
        panelFeatureState.decorView = (ViewGroup)new ListMenuDecorView(panelFeatureState.listPresenterContext);
        panelFeatureState.gravity = 81;
        return true;
    }
    
    private boolean initializePanelMenu(final PanelFeatureState panelFeatureState) {
        Context mContext = this.mContext;
        if ((panelFeatureState.featureId == 0 || panelFeatureState.featureId == 108) && this.mDecorContentParent != null) {
            final TypedValue typedValue = new TypedValue();
            final Resources$Theme theme = mContext.getTheme();
            theme.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
            Resources$Theme to = null;
            if (typedValue.resourceId != 0) {
                to = mContext.getResources().newTheme();
                to.setTo(theme);
                to.applyStyle(typedValue.resourceId, true);
                to.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
            }
            else {
                theme.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
            }
            if (typedValue.resourceId != 0) {
                if (to == null) {
                    to = mContext.getResources().newTheme();
                    to.setTo(theme);
                }
                to.applyStyle(typedValue.resourceId, true);
            }
            if (to != null) {
                final ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(mContext, 0);
                ((Context)contextThemeWrapper).getTheme().setTo(to);
                mContext = (Context)contextThemeWrapper;
            }
        }
        final MenuBuilder menu = new MenuBuilder(mContext);
        menu.setCallback((MenuBuilder.Callback)this);
        panelFeatureState.setMenu(menu);
        return true;
    }
    
    private void invalidatePanelMenu(final int n) {
        this.mInvalidatePanelMenuFeatures |= 1 << n;
        if (!this.mInvalidatePanelMenuPosted) {
            ViewCompat.postOnAnimation(this.mWindow.getDecorView(), this.mInvalidatePanelMenuRunnable);
            this.mInvalidatePanelMenuPosted = true;
        }
    }
    
    private boolean isActivityManifestHandlingUiMode() {
        if (!this.mActivityHandlesUiModeChecked && this.mHost instanceof Activity) {
            final PackageManager packageManager = this.mContext.getPackageManager();
            if (packageManager == null) {
                return false;
            }
            while (true) {
                while (true) {
                    Label_0115: {
                        try {
                            final ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(this.mContext, (Class)this.mHost.getClass()), 0);
                            if (activityInfo == null || (0x200 & activityInfo.configChanges) == 0x0) {
                                break Label_0115;
                            }
                            final boolean mActivityHandlesUiMode = true;
                            this.mActivityHandlesUiMode = mActivityHandlesUiMode;
                        }
                        catch (PackageManager$NameNotFoundException ex) {
                            Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)ex);
                            this.mActivityHandlesUiMode = false;
                        }
                        break;
                    }
                    final boolean mActivityHandlesUiMode = false;
                    continue;
                }
            }
        }
        this.mActivityHandlesUiModeChecked = true;
        return this.mActivityHandlesUiMode;
    }
    
    private boolean onKeyDownPanel(final int n, final KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() == 0) {
            final PanelFeatureState panelState = this.getPanelState(n, true);
            if (!panelState.isOpen) {
                return this.preparePanel(panelState, keyEvent);
            }
        }
        return false;
    }
    
    private boolean onKeyUpPanel(final int n, final KeyEvent keyEvent) {
        if (this.mActionMode != null) {
            return false;
        }
        boolean b = true;
        final PanelFeatureState panelState = this.getPanelState(n, b);
        Label_0205: {
            Label_0183: {
                if (n == 0) {
                    final DecorContentParent mDecorContentParent = this.mDecorContentParent;
                    if (mDecorContentParent != null && mDecorContentParent.canShowOverflowMenu() && !ViewConfiguration.get(this.mContext).hasPermanentMenuKey()) {
                        if (this.mDecorContentParent.isOverflowMenuShowing()) {
                            b = this.mDecorContentParent.hideOverflowMenu();
                            break Label_0205;
                        }
                        if (!this.mIsDestroyed && this.preparePanel(panelState, keyEvent)) {
                            b = this.mDecorContentParent.showOverflowMenu();
                            break Label_0205;
                        }
                        break Label_0183;
                    }
                }
                if (panelState.isOpen || panelState.isHandled) {
                    final boolean isOpen = panelState.isOpen;
                    this.closePanel(panelState, b);
                    b = isOpen;
                    break Label_0205;
                }
                if (panelState.isPrepared) {
                    boolean preparePanel;
                    if (panelState.refreshMenuContent) {
                        panelState.isPrepared = false;
                        preparePanel = this.preparePanel(panelState, keyEvent);
                    }
                    else {
                        preparePanel = true;
                    }
                    if (preparePanel) {
                        this.openPanel(panelState, keyEvent);
                        break Label_0205;
                    }
                }
            }
            b = false;
        }
        if (b) {
            final AudioManager audioManager = (AudioManager)this.mContext.getSystemService("audio");
            if (audioManager != null) {
                audioManager.playSoundEffect(0);
            }
            else {
                Log.w("AppCompatDelegate", "Couldn't get audio manager");
            }
        }
        return b;
    }
    
    private void openPanel(final PanelFeatureState panelFeatureState, final KeyEvent keyEvent) {
        if (!panelFeatureState.isOpen) {
            if (!this.mIsDestroyed) {
                if (panelFeatureState.featureId == 0 && (0xF & this.mContext.getResources().getConfiguration().screenLayout) == 0x4) {
                    return;
                }
                final Window$Callback windowCallback = this.getWindowCallback();
                if (windowCallback != null && !windowCallback.onMenuOpened(panelFeatureState.featureId, (Menu)panelFeatureState.menu)) {
                    this.closePanel(panelFeatureState, true);
                    return;
                }
                final WindowManager windowManager = (WindowManager)this.mContext.getSystemService("window");
                if (windowManager == null) {
                    return;
                }
                if (!this.preparePanel(panelFeatureState, keyEvent)) {
                    return;
                }
                int n = 0;
                Label_0347: {
                    if (panelFeatureState.decorView != null && !panelFeatureState.refreshDecorView) {
                        if (panelFeatureState.createdPanelView != null) {
                            final ViewGroup$LayoutParams layoutParams = panelFeatureState.createdPanelView.getLayoutParams();
                            if (layoutParams != null && layoutParams.width == -1) {
                                n = -1;
                                break Label_0347;
                            }
                        }
                    }
                    else {
                        if (panelFeatureState.decorView == null) {
                            if (!this.initializePanelDecor(panelFeatureState) || panelFeatureState.decorView == null) {
                                return;
                            }
                        }
                        else if (panelFeatureState.refreshDecorView && panelFeatureState.decorView.getChildCount() > 0) {
                            panelFeatureState.decorView.removeAllViews();
                        }
                        if (!this.initializePanelContent(panelFeatureState)) {
                            return;
                        }
                        if (!panelFeatureState.hasPanelItems()) {
                            return;
                        }
                        ViewGroup$LayoutParams layoutParams2 = panelFeatureState.shownPanelView.getLayoutParams();
                        if (layoutParams2 == null) {
                            layoutParams2 = new ViewGroup$LayoutParams(-2, -2);
                        }
                        panelFeatureState.decorView.setBackgroundResource(panelFeatureState.background);
                        final ViewParent parent = panelFeatureState.shownPanelView.getParent();
                        if (parent instanceof ViewGroup) {
                            ((ViewGroup)parent).removeView(panelFeatureState.shownPanelView);
                        }
                        panelFeatureState.decorView.addView(panelFeatureState.shownPanelView, layoutParams2);
                        if (!panelFeatureState.shownPanelView.hasFocus()) {
                            panelFeatureState.shownPanelView.requestFocus();
                        }
                    }
                    n = -2;
                }
                panelFeatureState.isHandled = false;
                final WindowManager$LayoutParams windowManager$LayoutParams = new WindowManager$LayoutParams(n, -2, panelFeatureState.x, panelFeatureState.y, 1002, 8519680, -3);
                windowManager$LayoutParams.gravity = panelFeatureState.gravity;
                windowManager$LayoutParams.windowAnimations = panelFeatureState.windowAnimations;
                windowManager.addView((View)panelFeatureState.decorView, (ViewGroup$LayoutParams)windowManager$LayoutParams);
                panelFeatureState.isOpen = true;
            }
        }
    }
    
    private boolean performPanelShortcut(final PanelFeatureState panelFeatureState, final int n, final KeyEvent keyEvent, final int n2) {
        if (keyEvent.isSystem()) {
            return false;
        }
        boolean performShortcut = false;
        Label_0059: {
            if (!panelFeatureState.isPrepared) {
                final boolean preparePanel = this.preparePanel(panelFeatureState, keyEvent);
                performShortcut = false;
                if (!preparePanel) {
                    break Label_0059;
                }
            }
            final MenuBuilder menu = panelFeatureState.menu;
            performShortcut = false;
            if (menu != null) {
                performShortcut = panelFeatureState.menu.performShortcut(n, keyEvent, n2);
            }
        }
        if (performShortcut && (n2 & 0x1) == 0x0 && this.mDecorContentParent == null) {
            this.closePanel(panelFeatureState, true);
        }
        return performShortcut;
    }
    
    private boolean preparePanel(final PanelFeatureState mPreparedPanel, final KeyEvent keyEvent) {
        if (this.mIsDestroyed) {
            return false;
        }
        if (mPreparedPanel.isPrepared) {
            return true;
        }
        final PanelFeatureState mPreparedPanel2 = this.mPreparedPanel;
        if (mPreparedPanel2 != null && mPreparedPanel2 != mPreparedPanel) {
            this.closePanel(mPreparedPanel2, false);
        }
        final Window$Callback windowCallback = this.getWindowCallback();
        if (windowCallback != null) {
            mPreparedPanel.createdPanelView = windowCallback.onCreatePanelView(mPreparedPanel.featureId);
        }
        final boolean b = mPreparedPanel.featureId == 0 || mPreparedPanel.featureId == 108;
        if (b) {
            final DecorContentParent mDecorContentParent = this.mDecorContentParent;
            if (mDecorContentParent != null) {
                mDecorContentParent.setMenuPrepared();
            }
        }
        if (mPreparedPanel.createdPanelView == null && (!b || !(this.peekSupportActionBar() instanceof ToolbarActionBar))) {
            if (mPreparedPanel.menu == null || mPreparedPanel.refreshMenuContent) {
                if (mPreparedPanel.menu == null && (!this.initializePanelMenu(mPreparedPanel) || mPreparedPanel.menu == null)) {
                    return false;
                }
                if (b && this.mDecorContentParent != null) {
                    if (this.mActionMenuPresenterCallback == null) {
                        this.mActionMenuPresenterCallback = new ActionMenuPresenterCallback();
                    }
                    this.mDecorContentParent.setMenu((Menu)mPreparedPanel.menu, this.mActionMenuPresenterCallback);
                }
                mPreparedPanel.menu.stopDispatchingItemsChanged();
                if (!windowCallback.onCreatePanelMenu(mPreparedPanel.featureId, (Menu)mPreparedPanel.menu)) {
                    mPreparedPanel.setMenu(null);
                    if (b) {
                        final DecorContentParent mDecorContentParent2 = this.mDecorContentParent;
                        if (mDecorContentParent2 != null) {
                            mDecorContentParent2.setMenu(null, this.mActionMenuPresenterCallback);
                        }
                    }
                    return false;
                }
                mPreparedPanel.refreshMenuContent = false;
            }
            mPreparedPanel.menu.stopDispatchingItemsChanged();
            if (mPreparedPanel.frozenActionViewState != null) {
                mPreparedPanel.menu.restoreActionViewStates(mPreparedPanel.frozenActionViewState);
                mPreparedPanel.frozenActionViewState = null;
            }
            if (!windowCallback.onPreparePanel(0, mPreparedPanel.createdPanelView, (Menu)mPreparedPanel.menu)) {
                if (b) {
                    final DecorContentParent mDecorContentParent3 = this.mDecorContentParent;
                    if (mDecorContentParent3 != null) {
                        mDecorContentParent3.setMenu(null, this.mActionMenuPresenterCallback);
                    }
                }
                mPreparedPanel.menu.startDispatchingItemsChanged();
                return false;
            }
            int deviceId;
            if (keyEvent != null) {
                deviceId = keyEvent.getDeviceId();
            }
            else {
                deviceId = -1;
            }
            mPreparedPanel.qwertyMode = (KeyCharacterMap.load(deviceId).getKeyboardType() != 1);
            mPreparedPanel.menu.setQwertyMode(mPreparedPanel.qwertyMode);
            mPreparedPanel.menu.startDispatchingItemsChanged();
        }
        mPreparedPanel.isPrepared = true;
        mPreparedPanel.isHandled = false;
        this.mPreparedPanel = mPreparedPanel;
        return true;
    }
    
    private void reopenMenu(final MenuBuilder menuBuilder, final boolean b) {
        final DecorContentParent mDecorContentParent = this.mDecorContentParent;
        if (mDecorContentParent != null && mDecorContentParent.canShowOverflowMenu() && (!ViewConfiguration.get(this.mContext).hasPermanentMenuKey() || this.mDecorContentParent.isOverflowMenuShowPending())) {
            final Window$Callback windowCallback = this.getWindowCallback();
            if (this.mDecorContentParent.isOverflowMenuShowing() && b) {
                this.mDecorContentParent.hideOverflowMenu();
                if (!this.mIsDestroyed) {
                    windowCallback.onPanelClosed(108, (Menu)this.getPanelState(0, true).menu);
                }
            }
            else if (windowCallback != null && !this.mIsDestroyed) {
                if (this.mInvalidatePanelMenuPosted && (0x1 & this.mInvalidatePanelMenuFeatures) != 0x0) {
                    this.mWindow.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
                    this.mInvalidatePanelMenuRunnable.run();
                }
                final PanelFeatureState panelState = this.getPanelState(0, true);
                if (panelState.menu != null && !panelState.refreshMenuContent && windowCallback.onPreparePanel(0, panelState.createdPanelView, (Menu)panelState.menu)) {
                    windowCallback.onMenuOpened(108, (Menu)panelState.menu);
                    this.mDecorContentParent.showOverflowMenu();
                }
            }
            return;
        }
        final PanelFeatureState panelState2 = this.getPanelState(0, true);
        panelState2.refreshDecorView = true;
        this.closePanel(panelState2, false);
        this.openPanel(panelState2, null);
    }
    
    private int sanitizeWindowFeatureId(int n) {
        if (n == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            return 108;
        }
        if (n == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            n = 109;
        }
        return n;
    }
    
    private boolean shouldInheritContext(ViewParent parent) {
        if (parent == null) {
            return false;
        }
        final View decorView = this.mWindow.getDecorView();
        while (parent != null) {
            if (parent == decorView || !(parent instanceof View) || ViewCompat.isAttachedToWindow((View)parent)) {
                return false;
            }
            parent = parent.getParent();
        }
        return true;
    }
    
    private void throwFeatureRequestIfSubDecorInstalled() {
        if (!this.mSubDecorInstalled) {
            return;
        }
        throw new AndroidRuntimeException("Window feature must be requested before adding content");
    }
    
    private AppCompatActivity tryUnwrapContext() {
        for (Context context = this.mContext; context != null; context = ((ContextWrapper)context).getBaseContext()) {
            if (context instanceof AppCompatActivity) {
                return (AppCompatActivity)context;
            }
            if (!(context instanceof ContextWrapper)) {
                break;
            }
        }
        return null;
    }
    
    private boolean updateForNightMode(final int n, final boolean b) {
        final int n2 = 0x30 & this.mContext.getApplicationContext().getResources().getConfiguration().uiMode;
        int n3 = 1;
        int n4;
        if (n != n3) {
            if (n != 2) {
                n4 = n2;
            }
            else {
                n4 = 32;
            }
        }
        else {
            n4 = 16;
        }
        final boolean activityManifestHandlingUiMode = this.isActivityManifestHandlingUiMode();
        int n5 = 0;
        Label_0183: {
            if (!AppCompatDelegateImpl.sAlwaysOverrideConfiguration) {
                n5 = 0;
                if (n4 == n2) {
                    break Label_0183;
                }
            }
            n5 = 0;
            if (!activityManifestHandlingUiMode) {
                final int sdk_INT = Build$VERSION.SDK_INT;
                n5 = 0;
                if (sdk_INT >= 17) {
                    final boolean mBaseContextAttached = this.mBaseContextAttached;
                    n5 = 0;
                    if (!mBaseContextAttached) {
                        final boolean b2 = this.mHost instanceof android.view.ContextThemeWrapper;
                        n5 = 0;
                        if (b2) {
                            final Configuration configuration = new Configuration();
                            configuration.uiMode = (n4 | (0xFFFFFFCF & configuration.uiMode));
                            try {
                                ((android.view.ContextThemeWrapper)this.mHost).applyOverrideConfiguration(configuration);
                                n5 = 1;
                            }
                            catch (IllegalStateException ex) {
                                Log.e("AppCompatDelegate", "updateForNightMode. Calling applyOverrideConfiguration() failed with an exception. Will fall back to using Resources.updateConfiguration()", (Throwable)ex);
                            }
                        }
                    }
                }
            }
        }
        final int n6 = 0x30 & this.mContext.getResources().getConfiguration().uiMode;
        if (n5 == 0 && n6 != n4 && b && !activityManifestHandlingUiMode && this.mBaseContextAttached && (Build$VERSION.SDK_INT >= 17 || this.mCreated)) {
            final Object mHost = this.mHost;
            if (mHost instanceof Activity) {
                ActivityCompat.recreate((Activity)mHost);
                n5 = 1;
            }
        }
        if (n5 == 0 && n6 != n4) {
            this.updateResourcesConfigurationForNightMode(n4, activityManifestHandlingUiMode);
        }
        else {
            n3 = n5;
        }
        if (n3 != 0) {
            final Object mHost2 = this.mHost;
            if (mHost2 instanceof AppCompatActivity) {
                ((AppCompatActivity)mHost2).onNightModeChanged(n);
            }
        }
        return n3 != 0;
    }
    
    private void updateResourcesConfigurationForNightMode(final int n, final boolean b) {
        final Resources resources = this.mContext.getResources();
        final Configuration configuration = new Configuration(resources.getConfiguration());
        configuration.uiMode = (n | (0xFFFFFFCF & resources.getConfiguration().uiMode));
        resources.updateConfiguration(configuration, (DisplayMetrics)null);
        if (Build$VERSION.SDK_INT < 26) {
            ResourcesFlusher.flush(resources);
        }
        final int mThemeResId = this.mThemeResId;
        if (mThemeResId != 0) {
            this.mContext.setTheme(mThemeResId);
            if (Build$VERSION.SDK_INT >= 23) {
                this.mContext.getTheme().applyStyle(this.mThemeResId, true);
            }
        }
        if (b) {
            final Object mHost = this.mHost;
            if (mHost instanceof Activity) {
                final Activity activity = (Activity)mHost;
                if (activity instanceof LifecycleOwner) {
                    if (((LifecycleOwner)activity).getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                        activity.onConfigurationChanged(configuration);
                    }
                }
                else if (this.mStarted) {
                    activity.onConfigurationChanged(configuration);
                }
            }
        }
    }
    
    @Override
    public void addContentView(final View view, final ViewGroup$LayoutParams viewGroup$LayoutParams) {
        this.ensureSubDecor();
        ((ViewGroup)this.mSubDecor.findViewById(16908290)).addView(view, viewGroup$LayoutParams);
        this.mAppCompatWindowCallback.getWrapped().onContentChanged();
    }
    
    @Override
    public boolean applyDayNight() {
        return this.applyDayNight(true);
    }
    
    @Override
    public void attachBaseContext(final Context context) {
        this.applyDayNight(false);
        this.mBaseContextAttached = true;
    }
    
    void callOnPanelClosed(final int n, PanelFeatureState panelFeatureState, Menu menu) {
        if (menu == null) {
            if (panelFeatureState == null && n >= 0) {
                final PanelFeatureState[] mPanels = this.mPanels;
                if (n < mPanels.length) {
                    panelFeatureState = mPanels[n];
                }
            }
            if (panelFeatureState != null) {
                menu = (Menu)panelFeatureState.menu;
            }
        }
        if (panelFeatureState != null && !panelFeatureState.isOpen) {
            return;
        }
        if (!this.mIsDestroyed) {
            this.mAppCompatWindowCallback.getWrapped().onPanelClosed(n, menu);
        }
    }
    
    void checkCloseActionMenu(final MenuBuilder menuBuilder) {
        if (this.mClosingActionMenu) {
            return;
        }
        this.mClosingActionMenu = true;
        this.mDecorContentParent.dismissPopups();
        final Window$Callback windowCallback = this.getWindowCallback();
        if (windowCallback != null && !this.mIsDestroyed) {
            windowCallback.onPanelClosed(108, (Menu)menuBuilder);
        }
        this.mClosingActionMenu = false;
    }
    
    void closePanel(final int n) {
        this.closePanel(this.getPanelState(n, true), true);
    }
    
    void closePanel(final PanelFeatureState panelFeatureState, final boolean b) {
        if (b && panelFeatureState.featureId == 0) {
            final DecorContentParent mDecorContentParent = this.mDecorContentParent;
            if (mDecorContentParent != null && mDecorContentParent.isOverflowMenuShowing()) {
                this.checkCloseActionMenu(panelFeatureState.menu);
                return;
            }
        }
        final WindowManager windowManager = (WindowManager)this.mContext.getSystemService("window");
        if (windowManager != null && panelFeatureState.isOpen && panelFeatureState.decorView != null) {
            windowManager.removeView((View)panelFeatureState.decorView);
            if (b) {
                this.callOnPanelClosed(panelFeatureState.featureId, panelFeatureState, null);
            }
        }
        panelFeatureState.isPrepared = false;
        panelFeatureState.isHandled = false;
        panelFeatureState.isOpen = false;
        panelFeatureState.shownPanelView = null;
        panelFeatureState.refreshDecorView = true;
        if (this.mPreparedPanel == panelFeatureState) {
            this.mPreparedPanel = null;
        }
    }
    
    @Override
    public View createView(final View view, final String s, final Context context, final AttributeSet set) {
        if (this.mAppCompatViewInflater == null) {
            final String string = this.mContext.obtainStyledAttributes(R.styleable.AppCompatTheme).getString(R.styleable.AppCompatTheme_viewInflaterClass);
            if (string != null && !AppCompatViewInflater.class.getName().equals(string)) {
                try {
                    this.mAppCompatViewInflater = (AppCompatViewInflater)Class.forName(string).getDeclaredConstructor((Class<?>[])new Class[0]).newInstance(new Object[0]);
                }
                finally {
                    final StringBuilder sb = new StringBuilder();
                    sb.append("Failed to instantiate custom view inflater ");
                    sb.append(string);
                    sb.append(". Falling back to default.");
                    final Throwable t;
                    Log.i("AppCompatDelegate", sb.toString(), t);
                    this.mAppCompatViewInflater = new AppCompatViewInflater();
                }
            }
            else {
                this.mAppCompatViewInflater = new AppCompatViewInflater();
            }
        }
        final boolean is_PRE_LOLLIPOP = AppCompatDelegateImpl.IS_PRE_LOLLIPOP;
        boolean b;
        if (is_PRE_LOLLIPOP) {
            boolean shouldInheritContext;
            if (set instanceof XmlPullParser) {
                final int depth = ((XmlPullParser)set).getDepth();
                shouldInheritContext = false;
                if (depth > 1) {
                    shouldInheritContext = true;
                }
            }
            else {
                shouldInheritContext = this.shouldInheritContext((ViewParent)view);
            }
            b = shouldInheritContext;
        }
        else {
            b = false;
        }
        return this.mAppCompatViewInflater.createView(view, s, context, set, b, is_PRE_LOLLIPOP, true, VectorEnabledTintResources.shouldBeUsed());
    }
    
    void dismissPopups() {
        final DecorContentParent mDecorContentParent = this.mDecorContentParent;
        if (mDecorContentParent != null) {
            mDecorContentParent.dismissPopups();
        }
        if (this.mActionModePopup != null) {
            this.mWindow.getDecorView().removeCallbacks(this.mShowActionModePopup);
            if (this.mActionModePopup.isShowing()) {
                try {
                    this.mActionModePopup.dismiss();
                }
                catch (IllegalArgumentException ex) {}
                this.mActionModePopup = null;
            }
        }
        this.endOnGoingFadeAnimation();
        final PanelFeatureState panelState = this.getPanelState(0, false);
        if (panelState != null && panelState.menu != null) {
            panelState.menu.close();
        }
    }
    
    boolean dispatchKeyEvent(final KeyEvent keyEvent) {
        final Object mHost = this.mHost;
        final boolean b = mHost instanceof KeyEventDispatcher.Component;
        boolean b2 = true;
        if (b || mHost instanceof AppCompatDialog) {
            final View decorView = this.mWindow.getDecorView();
            if (decorView != null && KeyEventDispatcher.dispatchBeforeHierarchy(decorView, keyEvent)) {
                return b2;
            }
        }
        if (keyEvent.getKeyCode() == 82 && this.mAppCompatWindowCallback.getWrapped().dispatchKeyEvent(keyEvent)) {
            return b2;
        }
        final int keyCode = keyEvent.getKeyCode();
        if (keyEvent.getAction() != 0) {
            b2 = false;
        }
        boolean b3;
        if (b2) {
            b3 = this.onKeyDown(keyCode, keyEvent);
        }
        else {
            b3 = this.onKeyUp(keyCode, keyEvent);
        }
        return b3;
    }
    
    void doInvalidatePanelMenu(final int n) {
        final PanelFeatureState panelState = this.getPanelState(n, true);
        if (panelState.menu != null) {
            final Bundle frozenActionViewState = new Bundle();
            panelState.menu.saveActionViewStates(frozenActionViewState);
            if (frozenActionViewState.size() > 0) {
                panelState.frozenActionViewState = frozenActionViewState;
            }
            panelState.menu.stopDispatchingItemsChanged();
            panelState.menu.clear();
        }
        panelState.refreshMenuContent = true;
        panelState.refreshDecorView = true;
        if ((n == 108 || n == 0) && this.mDecorContentParent != null) {
            final PanelFeatureState panelState2 = this.getPanelState(0, false);
            if (panelState2 != null) {
                panelState2.isPrepared = false;
                this.preparePanel(panelState2, null);
            }
        }
    }
    
    void endOnGoingFadeAnimation() {
        final ViewPropertyAnimatorCompat mFadeAnim = this.mFadeAnim;
        if (mFadeAnim != null) {
            mFadeAnim.cancel();
        }
    }
    
    PanelFeatureState findMenuPanel(final Menu menu) {
        final PanelFeatureState[] mPanels = this.mPanels;
        int i = 0;
        int length;
        if (mPanels != null) {
            length = mPanels.length;
            i = 0;
        }
        else {
            length = 0;
        }
        while (i < length) {
            final PanelFeatureState panelFeatureState = mPanels[i];
            if (panelFeatureState != null && panelFeatureState.menu == menu) {
                return panelFeatureState;
            }
            ++i;
        }
        return null;
    }
    
    @Override
    public <T extends View> T findViewById(final int n) {
        this.ensureSubDecor();
        return (T)this.mWindow.findViewById(n);
    }
    
    final Context getActionBarThemedContext() {
        final ActionBar supportActionBar = this.getSupportActionBar();
        Context context;
        if (supportActionBar != null) {
            context = supportActionBar.getThemedContext();
        }
        else {
            context = null;
        }
        if (context == null) {
            context = this.mContext;
        }
        return context;
    }
    
    final AutoNightModeManager getAutoTimeNightModeManager() {
        if (this.mAutoTimeNightModeManager == null) {
            this.mAutoTimeNightModeManager = (AutoNightModeManager)new AutoTimeNightModeManager(TwilightManager.getInstance(this.mContext));
        }
        return this.mAutoTimeNightModeManager;
    }
    
    @Override
    public final ActionBarDrawerToggle.Delegate getDrawerToggleDelegate() {
        return new ActionBarDrawableToggleImpl();
    }
    
    @Override
    public int getLocalNightMode() {
        return this.mLocalNightMode;
    }
    
    @Override
    public MenuInflater getMenuInflater() {
        if (this.mMenuInflater == null) {
            this.initWindowDecorActionBar();
            final ActionBar mActionBar = this.mActionBar;
            Context context;
            if (mActionBar != null) {
                context = mActionBar.getThemedContext();
            }
            else {
                context = this.mContext;
            }
            this.mMenuInflater = new SupportMenuInflater(context);
        }
        return this.mMenuInflater;
    }
    
    protected PanelFeatureState getPanelState(final int n, final boolean b) {
        PanelFeatureState[] mPanels = this.mPanels;
        if (mPanels == null || mPanels.length <= n) {
            final PanelFeatureState[] mPanels2 = new PanelFeatureState[n + 1];
            if (mPanels != null) {
                System.arraycopy(mPanels, 0, mPanels2, 0, mPanels.length);
            }
            this.mPanels = mPanels2;
            mPanels = mPanels2;
        }
        PanelFeatureState panelFeatureState = mPanels[n];
        if (panelFeatureState == null) {
            panelFeatureState = new PanelFeatureState(n);
            mPanels[n] = panelFeatureState;
        }
        return panelFeatureState;
    }
    
    ViewGroup getSubDecor() {
        return this.mSubDecor;
    }
    
    @Override
    public ActionBar getSupportActionBar() {
        this.initWindowDecorActionBar();
        return this.mActionBar;
    }
    
    final CharSequence getTitle() {
        final Object mHost = this.mHost;
        if (mHost instanceof Activity) {
            return ((Activity)mHost).getTitle();
        }
        return this.mTitle;
    }
    
    final Window$Callback getWindowCallback() {
        return this.mWindow.getCallback();
    }
    
    @Override
    public boolean hasWindowFeature(final int n) {
        final int sanitizeWindowFeatureId = this.sanitizeWindowFeatureId(n);
        int n2 = 1;
        boolean b;
        if (sanitizeWindowFeatureId != n2) {
            if (sanitizeWindowFeatureId != 2) {
                if (sanitizeWindowFeatureId != 5) {
                    if (sanitizeWindowFeatureId != 10) {
                        if (sanitizeWindowFeatureId != 108) {
                            b = (sanitizeWindowFeatureId == 109 && this.mOverlayActionBar);
                        }
                        else {
                            b = this.mHasActionBar;
                        }
                    }
                    else {
                        b = this.mOverlayActionMode;
                    }
                }
                else {
                    b = this.mFeatureIndeterminateProgress;
                }
            }
            else {
                b = this.mFeatureProgress;
            }
        }
        else {
            b = this.mWindowNoTitle;
        }
        if (!b) {
            if (!this.mWindow.hasFeature(n)) {
                n2 = 0;
            }
        }
        return n2 != 0;
    }
    
    @Override
    public void installViewFactory() {
        final LayoutInflater from = LayoutInflater.from(this.mContext);
        if (from.getFactory() == null) {
            LayoutInflaterCompat.setFactory2(from, (LayoutInflater$Factory2)this);
        }
        else if (!(from.getFactory2() instanceof AppCompatDelegateImpl)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }
    
    @Override
    public void invalidateOptionsMenu() {
        final ActionBar supportActionBar = this.getSupportActionBar();
        if (supportActionBar != null && supportActionBar.invalidateOptionsMenu()) {
            return;
        }
        this.invalidatePanelMenu(0);
    }
    
    @Override
    public boolean isHandleNativeActionModesEnabled() {
        return this.mHandleNativeActionModes;
    }
    
    int mapNightMode(int applyableNightMode) {
        if (applyableNightMode != -100) {
            if (applyableNightMode != -1) {
                if (applyableNightMode != 0) {
                    if (applyableNightMode != 1 && applyableNightMode != 2) {
                        if (applyableNightMode == 3) {
                            return this.getAutoBatteryNightModeManager().getApplyableNightMode();
                        }
                        throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
                    }
                }
                else {
                    if (Build$VERSION.SDK_INT >= 23 && ((UiModeManager)this.mContext.getSystemService((Class)UiModeManager.class)).getNightMode() == 0) {
                        return -1;
                    }
                    applyableNightMode = this.getAutoTimeNightModeManager().getApplyableNightMode();
                }
            }
            return applyableNightMode;
        }
        return -1;
    }
    
    boolean onBackPressed() {
        final ActionMode mActionMode = this.mActionMode;
        if (mActionMode != null) {
            mActionMode.finish();
            return true;
        }
        final ActionBar supportActionBar = this.getSupportActionBar();
        return supportActionBar != null && supportActionBar.collapseActionView();
    }
    
    @Override
    public void onConfigurationChanged(final Configuration configuration) {
        if (this.mHasActionBar && this.mSubDecorInstalled) {
            final ActionBar supportActionBar = this.getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.onConfigurationChanged(configuration);
            }
        }
        AppCompatDrawableManager.get().onConfigurationChanged(this.mContext);
        this.applyDayNight(false);
    }
    
    @Override
    public void onCreate(final Bundle p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: iconst_1       
        //     2: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mBaseContextAttached:Z
        //     5: aload_0        
        //     6: iconst_0       
        //     7: invokespecial   androidx/appcompat/app/AppCompatDelegateImpl.applyDayNight:(Z)Z
        //    10: pop            
        //    11: aload_0        
        //    12: invokespecial   androidx/appcompat/app/AppCompatDelegateImpl.ensureWindow:()V
        //    15: aload_0        
        //    16: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mHost:Ljava/lang/Object;
        //    19: astore_3       
        //    20: aload_3        
        //    21: instanceof      Landroid/app/Activity;
        //    24: ifeq            72
        //    27: aconst_null    
        //    28: astore          4
        //    30: aload_3        
        //    31: checkcast       Landroid/app/Activity;
        //    34: invokestatic    androidx/core/app/NavUtils.getParentActivityName:(Landroid/app/Activity;)Ljava/lang/String;
        //    37: astore          4
        //    39: goto            42
        //    42: aload           4
        //    44: ifnull          72
        //    47: aload_0        
        //    48: invokevirtual   androidx/appcompat/app/AppCompatDelegateImpl.peekSupportActionBar:()Landroidx/appcompat/app/ActionBar;
        //    51: astore          5
        //    53: aload           5
        //    55: ifnonnull       66
        //    58: aload_0        
        //    59: iconst_1       
        //    60: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mEnableDefaultActionBarUp:Z
        //    63: goto            72
        //    66: aload           5
        //    68: iconst_1       
        //    69: invokevirtual   androidx/appcompat/app/ActionBar.setDefaultDisplayHomeAsUpEnabled:(Z)V
        //    72: aload_0        
        //    73: iconst_1       
        //    74: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mCreated:Z
        //    77: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  30     39     42     72     Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0072 (coming from #0044).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final View onCreateView(final View view, final String s, final Context context, final AttributeSet set) {
        return this.createView(view, s, context, set);
    }
    
    public View onCreateView(final String s, final Context context, final AttributeSet set) {
        return this.onCreateView(null, s, context, set);
    }
    
    @Override
    public void onDestroy() {
        AppCompatDelegate.markStopped(this);
        if (this.mInvalidatePanelMenuPosted) {
            this.mWindow.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
        }
        this.mStarted = false;
        this.mIsDestroyed = true;
        final ActionBar mActionBar = this.mActionBar;
        if (mActionBar != null) {
            mActionBar.onDestroy();
        }
        this.cleanupAutoManagers();
    }
    
    boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        boolean mLongPressBackDown = true;
        if (n != 4) {
            if (n == 82) {
                this.onKeyDownPanel(0, keyEvent);
                return mLongPressBackDown;
            }
        }
        else {
            if ((0x80 & keyEvent.getFlags()) == 0x0) {
                mLongPressBackDown = false;
            }
            this.mLongPressBackDown = mLongPressBackDown;
        }
        return false;
    }
    
    boolean onKeyShortcut(final int n, final KeyEvent keyEvent) {
        final ActionBar supportActionBar = this.getSupportActionBar();
        if (supportActionBar != null && supportActionBar.onKeyShortcut(n, keyEvent)) {
            return true;
        }
        final PanelFeatureState mPreparedPanel = this.mPreparedPanel;
        if (mPreparedPanel != null && this.performPanelShortcut(mPreparedPanel, keyEvent.getKeyCode(), keyEvent, 1)) {
            final PanelFeatureState mPreparedPanel2 = this.mPreparedPanel;
            if (mPreparedPanel2 != null) {
                mPreparedPanel2.isHandled = true;
            }
            return true;
        }
        if (this.mPreparedPanel == null) {
            final PanelFeatureState panelState = this.getPanelState(0, true);
            this.preparePanel(panelState, keyEvent);
            final boolean performPanelShortcut = this.performPanelShortcut(panelState, keyEvent.getKeyCode(), keyEvent, 1);
            panelState.isPrepared = false;
            if (performPanelShortcut) {
                return true;
            }
        }
        return false;
    }
    
    boolean onKeyUp(final int n, final KeyEvent keyEvent) {
        if (n != 4) {
            if (n == 82) {
                this.onKeyUpPanel(0, keyEvent);
                return true;
            }
        }
        else {
            final boolean mLongPressBackDown = this.mLongPressBackDown;
            this.mLongPressBackDown = false;
            final PanelFeatureState panelState = this.getPanelState(0, false);
            if (panelState != null && panelState.isOpen) {
                if (!mLongPressBackDown) {
                    this.closePanel(panelState, true);
                }
                return true;
            }
            if (this.onBackPressed()) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean onMenuItemSelected(final MenuBuilder menuBuilder, final MenuItem menuItem) {
        final Window$Callback windowCallback = this.getWindowCallback();
        if (windowCallback != null && !this.mIsDestroyed) {
            final PanelFeatureState menuPanel = this.findMenuPanel((Menu)menuBuilder.getRootMenu());
            if (menuPanel != null) {
                return windowCallback.onMenuItemSelected(menuPanel.featureId, menuItem);
            }
        }
        return false;
    }
    
    @Override
    public void onMenuModeChange(final MenuBuilder menuBuilder) {
        this.reopenMenu(menuBuilder, true);
    }
    
    void onMenuOpened(final int n) {
        if (n == 108) {
            final ActionBar supportActionBar = this.getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.dispatchMenuVisibilityChanged(true);
            }
        }
    }
    
    void onPanelClosed(final int n) {
        if (n == 108) {
            final ActionBar supportActionBar = this.getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.dispatchMenuVisibilityChanged(false);
            }
        }
        else if (n == 0) {
            final PanelFeatureState panelState = this.getPanelState(n, true);
            if (panelState.isOpen) {
                this.closePanel(panelState, false);
            }
        }
    }
    
    @Override
    public void onPostCreate(final Bundle bundle) {
        this.ensureSubDecor();
    }
    
    @Override
    public void onPostResume() {
        final ActionBar supportActionBar = this.getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.setShowHideAnimationEnabled(true);
        }
    }
    
    @Override
    public void onSaveInstanceState(final Bundle bundle) {
        if (this.mLocalNightMode != -100) {
            AppCompatDelegateImpl.sLocalNightModes.put(this.mHost.getClass(), this.mLocalNightMode);
        }
    }
    
    @Override
    public void onStart() {
        this.mStarted = true;
        this.applyDayNight();
        AppCompatDelegate.markStarted(this);
    }
    
    @Override
    public void onStop() {
        this.mStarted = false;
        AppCompatDelegate.markStopped(this);
        final ActionBar supportActionBar = this.getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.setShowHideAnimationEnabled(false);
        }
        if (this.mHost instanceof Dialog) {
            this.cleanupAutoManagers();
        }
    }
    
    void onSubDecorInstalled(final ViewGroup viewGroup) {
    }
    
    final ActionBar peekSupportActionBar() {
        return this.mActionBar;
    }
    
    @Override
    public boolean requestWindowFeature(final int n) {
        final int sanitizeWindowFeatureId = this.sanitizeWindowFeatureId(n);
        if (this.mWindowNoTitle && sanitizeWindowFeatureId == 108) {
            return false;
        }
        if (this.mHasActionBar && sanitizeWindowFeatureId == 1) {
            this.mHasActionBar = false;
        }
        if (sanitizeWindowFeatureId == 1) {
            this.throwFeatureRequestIfSubDecorInstalled();
            return this.mWindowNoTitle = true;
        }
        if (sanitizeWindowFeatureId == 2) {
            this.throwFeatureRequestIfSubDecorInstalled();
            return this.mFeatureProgress = true;
        }
        if (sanitizeWindowFeatureId == 5) {
            this.throwFeatureRequestIfSubDecorInstalled();
            return this.mFeatureIndeterminateProgress = true;
        }
        if (sanitizeWindowFeatureId == 10) {
            this.throwFeatureRequestIfSubDecorInstalled();
            return this.mOverlayActionMode = true;
        }
        if (sanitizeWindowFeatureId == 108) {
            this.throwFeatureRequestIfSubDecorInstalled();
            return this.mHasActionBar = true;
        }
        if (sanitizeWindowFeatureId != 109) {
            return this.mWindow.requestFeature(sanitizeWindowFeatureId);
        }
        this.throwFeatureRequestIfSubDecorInstalled();
        return this.mOverlayActionBar = true;
    }
    
    @Override
    public void setContentView(final int n) {
        this.ensureSubDecor();
        final ViewGroup viewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.mContext).inflate(n, viewGroup);
        this.mAppCompatWindowCallback.getWrapped().onContentChanged();
    }
    
    @Override
    public void setContentView(final View view) {
        this.ensureSubDecor();
        final ViewGroup viewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.mAppCompatWindowCallback.getWrapped().onContentChanged();
    }
    
    @Override
    public void setContentView(final View view, final ViewGroup$LayoutParams viewGroup$LayoutParams) {
        this.ensureSubDecor();
        final ViewGroup viewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, viewGroup$LayoutParams);
        this.mAppCompatWindowCallback.getWrapped().onContentChanged();
    }
    
    @Override
    public void setHandleNativeActionModesEnabled(final boolean mHandleNativeActionModes) {
        this.mHandleNativeActionModes = mHandleNativeActionModes;
    }
    
    @Override
    public void setLocalNightMode(final int mLocalNightMode) {
        if (this.mLocalNightMode != mLocalNightMode) {
            this.mLocalNightMode = mLocalNightMode;
            this.applyDayNight();
        }
    }
    
    @Override
    public void setSupportActionBar(final Toolbar toolbar) {
        if (!(this.mHost instanceof Activity)) {
            return;
        }
        final ActionBar supportActionBar = this.getSupportActionBar();
        if (!(supportActionBar instanceof WindowDecorActionBar)) {
            this.mMenuInflater = null;
            if (supportActionBar != null) {
                supportActionBar.onDestroy();
            }
            if (toolbar != null) {
                final ToolbarActionBar mActionBar = new ToolbarActionBar(toolbar, this.getTitle(), (Window$Callback)this.mAppCompatWindowCallback);
                this.mActionBar = mActionBar;
                this.mWindow.setCallback(mActionBar.getWrappedWindowCallback());
            }
            else {
                this.mActionBar = null;
                this.mWindow.setCallback((Window$Callback)this.mAppCompatWindowCallback);
            }
            this.invalidateOptionsMenu();
            return;
        }
        throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
    }
    
    @Override
    public void setTheme(final int mThemeResId) {
        this.mThemeResId = mThemeResId;
    }
    
    @Override
    public final void setTitle(final CharSequence charSequence) {
        this.mTitle = charSequence;
        final DecorContentParent mDecorContentParent = this.mDecorContentParent;
        if (mDecorContentParent != null) {
            mDecorContentParent.setWindowTitle(charSequence);
        }
        else if (this.peekSupportActionBar() != null) {
            this.peekSupportActionBar().setWindowTitle(charSequence);
        }
        else {
            final TextView mTitleView = this.mTitleView;
            if (mTitleView != null) {
                mTitleView.setText(charSequence);
            }
        }
    }
    
    final boolean shouldAnimateActionModeView() {
        if (this.mSubDecorInstalled) {
            final ViewGroup mSubDecor = this.mSubDecor;
            if (mSubDecor != null && ViewCompat.isLaidOut((View)mSubDecor)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public ActionMode startSupportActionMode(final ActionMode.Callback callback) {
        if (callback != null) {
            final ActionMode mActionMode = this.mActionMode;
            if (mActionMode != null) {
                mActionMode.finish();
            }
            final ActionModeCallbackWrapperV9 actionModeCallbackWrapperV9 = new ActionModeCallbackWrapperV9(callback);
            final ActionBar supportActionBar = this.getSupportActionBar();
            if (supportActionBar != null) {
                final ActionMode startActionMode = supportActionBar.startActionMode(actionModeCallbackWrapperV9);
                if ((this.mActionMode = startActionMode) != null) {
                    final AppCompatCallback mAppCompatCallback = this.mAppCompatCallback;
                    if (mAppCompatCallback != null) {
                        mAppCompatCallback.onSupportActionModeStarted(startActionMode);
                    }
                }
            }
            if (this.mActionMode == null) {
                this.mActionMode = this.startSupportActionModeFromWindow(actionModeCallbackWrapperV9);
            }
            return this.mActionMode;
        }
        throw new IllegalArgumentException("ActionMode callback can not be null.");
    }
    
    ActionMode startSupportActionModeFromWindow(final ActionMode.Callback p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     4: aload_0        
        //     5: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionMode:Landroidx/appcompat/view/ActionMode;
        //     8: astore_2       
        //     9: aload_2        
        //    10: ifnull          17
        //    13: aload_2        
        //    14: invokevirtual   androidx/appcompat/view/ActionMode.finish:()V
        //    17: aload_1        
        //    18: instanceof      Landroidx/appcompat/app/AppCompatDelegateImpl$ActionModeCallbackWrapperV9;
        //    21: ifne            34
        //    24: new             Landroidx/appcompat/app/AppCompatDelegateImpl$ActionModeCallbackWrapperV9;
        //    27: dup            
        //    28: aload_0        
        //    29: aload_1        
        //    30: invokespecial   androidx/appcompat/app/AppCompatDelegateImpl$ActionModeCallbackWrapperV9.<init>:(Landroidx/appcompat/app/AppCompatDelegateImpl;Landroidx/appcompat/view/ActionMode$Callback;)V
        //    33: astore_1       
        //    34: aload_0        
        //    35: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mAppCompatCallback:Landroidx/appcompat/app/AppCompatCallback;
        //    38: astore_3       
        //    39: aload_3        
        //    40: ifnull          62
        //    43: aload_0        
        //    44: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mIsDestroyed:Z
        //    47: ifne            62
        //    50: aload_3        
        //    51: aload_1        
        //    52: invokeinterface androidx/appcompat/app/AppCompatCallback.onWindowStartingSupportActionMode:(Landroidx/appcompat/view/ActionMode$Callback;)Landroidx/appcompat/view/ActionMode;
        //    57: astore          4
        //    59: goto            65
        //    62: aconst_null    
        //    63: astore          4
        //    65: aload           4
        //    67: ifnull          79
        //    70: aload_0        
        //    71: aload           4
        //    73: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionMode:Landroidx/appcompat/view/ActionMode;
        //    76: goto            603
        //    79: aload_0        
        //    80: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //    83: astore          5
        //    85: iconst_1       
        //    86: istore          6
        //    88: aload           5
        //    90: ifnonnull       373
        //    93: aload_0        
        //    94: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mIsFloating:Z
        //    97: ifeq            329
        //   100: new             Landroid/util/TypedValue;
        //   103: dup            
        //   104: invokespecial   android/util/TypedValue.<init>:()V
        //   107: astore          15
        //   109: aload_0        
        //   110: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mContext:Landroid/content/Context;
        //   113: invokevirtual   android/content/Context.getTheme:()Landroid/content/res/Resources$Theme;
        //   116: astore          16
        //   118: aload           16
        //   120: getstatic       androidx/appcompat/R$attr.actionBarTheme:I
        //   123: aload           15
        //   125: iload           6
        //   127: invokevirtual   android/content/res/Resources$Theme.resolveAttribute:(ILandroid/util/TypedValue;Z)Z
        //   130: pop            
        //   131: aload           15
        //   133: getfield        android/util/TypedValue.resourceId:I
        //   136: ifeq            197
        //   139: aload_0        
        //   140: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mContext:Landroid/content/Context;
        //   143: invokevirtual   android/content/Context.getResources:()Landroid/content/res/Resources;
        //   146: invokevirtual   android/content/res/Resources.newTheme:()Landroid/content/res/Resources$Theme;
        //   149: astore          22
        //   151: aload           22
        //   153: aload           16
        //   155: invokevirtual   android/content/res/Resources$Theme.setTo:(Landroid/content/res/Resources$Theme;)V
        //   158: aload           22
        //   160: aload           15
        //   162: getfield        android/util/TypedValue.resourceId:I
        //   165: iload           6
        //   167: invokevirtual   android/content/res/Resources$Theme.applyStyle:(IZ)V
        //   170: new             Landroidx/appcompat/view/ContextThemeWrapper;
        //   173: dup            
        //   174: aload_0        
        //   175: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mContext:Landroid/content/Context;
        //   178: iconst_0       
        //   179: invokespecial   androidx/appcompat/view/ContextThemeWrapper.<init>:(Landroid/content/Context;I)V
        //   182: astore          18
        //   184: aload           18
        //   186: invokevirtual   android/content/Context.getTheme:()Landroid/content/res/Resources$Theme;
        //   189: aload           22
        //   191: invokevirtual   android/content/res/Resources$Theme.setTo:(Landroid/content/res/Resources$Theme;)V
        //   194: goto            203
        //   197: aload_0        
        //   198: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mContext:Landroid/content/Context;
        //   201: astore          18
        //   203: aload_0        
        //   204: new             Landroidx/appcompat/widget/ActionBarContextView;
        //   207: dup            
        //   208: aload           18
        //   210: invokespecial   androidx/appcompat/widget/ActionBarContextView.<init>:(Landroid/content/Context;)V
        //   213: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   216: new             Landroid/widget/PopupWindow;
        //   219: dup            
        //   220: aload           18
        //   222: aconst_null    
        //   223: getstatic       androidx/appcompat/R$attr.actionModePopupWindowStyle:I
        //   226: invokespecial   android/widget/PopupWindow.<init>:(Landroid/content/Context;Landroid/util/AttributeSet;I)V
        //   229: astore          19
        //   231: aload_0        
        //   232: aload           19
        //   234: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModePopup:Landroid/widget/PopupWindow;
        //   237: aload           19
        //   239: iconst_2       
        //   240: invokestatic    androidx/core/widget/PopupWindowCompat.setWindowLayoutType:(Landroid/widget/PopupWindow;I)V
        //   243: aload_0        
        //   244: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModePopup:Landroid/widget/PopupWindow;
        //   247: aload_0        
        //   248: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   251: invokevirtual   android/widget/PopupWindow.setContentView:(Landroid/view/View;)V
        //   254: aload_0        
        //   255: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModePopup:Landroid/widget/PopupWindow;
        //   258: iconst_m1      
        //   259: invokevirtual   android/widget/PopupWindow.setWidth:(I)V
        //   262: aload           18
        //   264: invokevirtual   android/content/Context.getTheme:()Landroid/content/res/Resources$Theme;
        //   267: getstatic       androidx/appcompat/R$attr.actionBarSize:I
        //   270: aload           15
        //   272: iload           6
        //   274: invokevirtual   android/content/res/Resources$Theme.resolveAttribute:(ILandroid/util/TypedValue;Z)Z
        //   277: pop            
        //   278: aload           15
        //   280: getfield        android/util/TypedValue.data:I
        //   283: aload           18
        //   285: invokevirtual   android/content/Context.getResources:()Landroid/content/res/Resources;
        //   288: invokevirtual   android/content/res/Resources.getDisplayMetrics:()Landroid/util/DisplayMetrics;
        //   291: invokestatic    android/util/TypedValue.complexToDimensionPixelSize:(ILandroid/util/DisplayMetrics;)I
        //   294: istore          21
        //   296: aload_0        
        //   297: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   300: iload           21
        //   302: invokevirtual   androidx/appcompat/widget/ActionBarContextView.setContentHeight:(I)V
        //   305: aload_0        
        //   306: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModePopup:Landroid/widget/PopupWindow;
        //   309: bipush          -2
        //   311: invokevirtual   android/widget/PopupWindow.setHeight:(I)V
        //   314: aload_0        
        //   315: new             Landroidx/appcompat/app/AppCompatDelegateImpl$6;
        //   318: dup            
        //   319: aload_0        
        //   320: invokespecial   androidx/appcompat/app/AppCompatDelegateImpl$6.<init>:(Landroidx/appcompat/app/AppCompatDelegateImpl;)V
        //   323: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mShowActionModePopup:Ljava/lang/Runnable;
        //   326: goto            373
        //   329: aload_0        
        //   330: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mSubDecor:Landroid/view/ViewGroup;
        //   333: getstatic       androidx/appcompat/R$id.action_mode_bar_stub:I
        //   336: invokevirtual   android/view/ViewGroup.findViewById:(I)Landroid/view/View;
        //   339: checkcast       Landroidx/appcompat/widget/ViewStubCompat;
        //   342: astore          23
        //   344: aload           23
        //   346: ifnull          373
        //   349: aload           23
        //   351: aload_0        
        //   352: invokevirtual   androidx/appcompat/app/AppCompatDelegateImpl.getActionBarThemedContext:()Landroid/content/Context;
        //   355: invokestatic    android/view/LayoutInflater.from:(Landroid/content/Context;)Landroid/view/LayoutInflater;
        //   358: invokevirtual   androidx/appcompat/widget/ViewStubCompat.setLayoutInflater:(Landroid/view/LayoutInflater;)V
        //   361: aload_0        
        //   362: aload           23
        //   364: invokevirtual   androidx/appcompat/widget/ViewStubCompat.inflate:()Landroid/view/View;
        //   367: checkcast       Landroidx/appcompat/widget/ActionBarContextView;
        //   370: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   373: aload_0        
        //   374: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   377: ifnull          603
        //   380: aload_0        
        //   381: invokevirtual   androidx/appcompat/app/AppCompatDelegateImpl.endOnGoingFadeAnimation:()V
        //   384: aload_0        
        //   385: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   388: invokevirtual   androidx/appcompat/widget/ActionBarContextView.killMode:()V
        //   391: aload_0        
        //   392: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   395: invokevirtual   androidx/appcompat/widget/ActionBarContextView.getContext:()Landroid/content/Context;
        //   398: astore          9
        //   400: aload_0        
        //   401: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   404: astore          10
        //   406: aload_0        
        //   407: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModePopup:Landroid/widget/PopupWindow;
        //   410: ifnonnull       416
        //   413: goto            419
        //   416: iconst_0       
        //   417: istore          6
        //   419: new             Landroidx/appcompat/view/StandaloneActionMode;
        //   422: dup            
        //   423: aload           9
        //   425: aload           10
        //   427: aload_1        
        //   428: iload           6
        //   430: invokespecial   androidx/appcompat/view/StandaloneActionMode.<init>:(Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Landroidx/appcompat/view/ActionMode$Callback;Z)V
        //   433: astore          11
        //   435: aload_1        
        //   436: aload           11
        //   438: aload           11
        //   440: invokevirtual   androidx/appcompat/view/ActionMode.getMenu:()Landroid/view/Menu;
        //   443: invokeinterface androidx/appcompat/view/ActionMode$Callback.onCreateActionMode:(Landroidx/appcompat/view/ActionMode;Landroid/view/Menu;)Z
        //   448: ifeq            598
        //   451: aload           11
        //   453: invokevirtual   androidx/appcompat/view/ActionMode.invalidate:()V
        //   456: aload_0        
        //   457: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   460: aload           11
        //   462: invokevirtual   androidx/appcompat/widget/ActionBarContextView.initForMode:(Landroidx/appcompat/view/ActionMode;)V
        //   465: aload_0        
        //   466: aload           11
        //   468: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionMode:Landroidx/appcompat/view/ActionMode;
        //   471: aload_0        
        //   472: invokevirtual   androidx/appcompat/app/AppCompatDelegateImpl.shouldAnimateActionModeView:()Z
        //   475: ifeq            522
        //   478: aload_0        
        //   479: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   482: fconst_0       
        //   483: invokevirtual   androidx/appcompat/widget/ActionBarContextView.setAlpha:(F)V
        //   486: aload_0        
        //   487: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   490: invokestatic    androidx/core/view/ViewCompat.animate:(Landroid/view/View;)Landroidx/core/view/ViewPropertyAnimatorCompat;
        //   493: fconst_1       
        //   494: invokevirtual   androidx/core/view/ViewPropertyAnimatorCompat.alpha:(F)Landroidx/core/view/ViewPropertyAnimatorCompat;
        //   497: astore          13
        //   499: aload_0        
        //   500: aload           13
        //   502: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mFadeAnim:Landroidx/core/view/ViewPropertyAnimatorCompat;
        //   505: aload           13
        //   507: new             Landroidx/appcompat/app/AppCompatDelegateImpl$7;
        //   510: dup            
        //   511: aload_0        
        //   512: invokespecial   androidx/appcompat/app/AppCompatDelegateImpl$7.<init>:(Landroidx/appcompat/app/AppCompatDelegateImpl;)V
        //   515: invokevirtual   androidx/core/view/ViewPropertyAnimatorCompat.setListener:(Landroidx/core/view/ViewPropertyAnimatorListener;)Landroidx/core/view/ViewPropertyAnimatorCompat;
        //   518: pop            
        //   519: goto            573
        //   522: aload_0        
        //   523: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   526: fconst_1       
        //   527: invokevirtual   androidx/appcompat/widget/ActionBarContextView.setAlpha:(F)V
        //   530: aload_0        
        //   531: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   534: iconst_0       
        //   535: invokevirtual   androidx/appcompat/widget/ActionBarContextView.setVisibility:(I)V
        //   538: aload_0        
        //   539: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   542: bipush          32
        //   544: invokevirtual   androidx/appcompat/widget/ActionBarContextView.sendAccessibilityEvent:(I)V
        //   547: aload_0        
        //   548: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   551: invokevirtual   androidx/appcompat/widget/ActionBarContextView.getParent:()Landroid/view/ViewParent;
        //   554: instanceof      Landroid/view/View;
        //   557: ifeq            573
        //   560: aload_0        
        //   561: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModeView:Landroidx/appcompat/widget/ActionBarContextView;
        //   564: invokevirtual   androidx/appcompat/widget/ActionBarContextView.getParent:()Landroid/view/ViewParent;
        //   567: checkcast       Landroid/view/View;
        //   570: invokestatic    androidx/core/view/ViewCompat.requestApplyInsets:(Landroid/view/View;)V
        //   573: aload_0        
        //   574: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionModePopup:Landroid/widget/PopupWindow;
        //   577: ifnull          603
        //   580: aload_0        
        //   581: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mWindow:Landroid/view/Window;
        //   584: invokevirtual   android/view/Window.getDecorView:()Landroid/view/View;
        //   587: aload_0        
        //   588: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mShowActionModePopup:Ljava/lang/Runnable;
        //   591: invokevirtual   android/view/View.post:(Ljava/lang/Runnable;)Z
        //   594: pop            
        //   595: goto            603
        //   598: aload_0        
        //   599: aconst_null    
        //   600: putfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionMode:Landroidx/appcompat/view/ActionMode;
        //   603: aload_0        
        //   604: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionMode:Landroidx/appcompat/view/ActionMode;
        //   607: astore          7
        //   609: aload           7
        //   611: ifnull          634
        //   614: aload_0        
        //   615: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mAppCompatCallback:Landroidx/appcompat/app/AppCompatCallback;
        //   618: astore          8
        //   620: aload           8
        //   622: ifnull          634
        //   625: aload           8
        //   627: aload           7
        //   629: invokeinterface androidx/appcompat/app/AppCompatCallback.onSupportActionModeStarted:(Landroidx/appcompat/view/ActionMode;)V
        //   634: aload_0        
        //   635: getfield        androidx/appcompat/app/AppCompatDelegateImpl.mActionMode:Landroidx/appcompat/view/ActionMode;
        //   638: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                           
        //  -----  -----  -----  -----  -------------------------------
        //  50     59     62     65     Ljava/lang/AbstractMethodError;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0065 (coming from #0063).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    int updateStatusGuard(int n) {
        final ActionBarContextView mActionModeView = this.mActionModeView;
        int n6;
        if (mActionModeView != null && mActionModeView.getLayoutParams() instanceof ViewGroup$MarginLayoutParams) {
            final ViewGroup$MarginLayoutParams layoutParams = (ViewGroup$MarginLayoutParams)this.mActionModeView.getLayoutParams();
            final boolean shown = this.mActionModeView.isShown();
            int n2 = 1;
            if (shown) {
                if (this.mTempRect1 == null) {
                    this.mTempRect1 = new Rect();
                    this.mTempRect2 = new Rect();
                }
                final Rect mTempRect1 = this.mTempRect1;
                final Rect mTempRect2 = this.mTempRect2;
                mTempRect1.set(0, n, 0, 0);
                ViewUtils.computeFitSystemWindows((View)this.mSubDecor, mTempRect1, mTempRect2);
                int n3;
                if (mTempRect2.top == 0) {
                    n3 = n;
                }
                else {
                    n3 = 0;
                }
                int n4;
                if (layoutParams.topMargin != n3) {
                    layoutParams.topMargin = n;
                    final View mStatusGuard = this.mStatusGuard;
                    if (mStatusGuard == null) {
                        (this.mStatusGuard = new View(this.mContext)).setBackgroundColor(this.mContext.getResources().getColor(R.color.abc_input_method_navigation_guard));
                        this.mSubDecor.addView(this.mStatusGuard, -1, new ViewGroup$LayoutParams(-1, n));
                    }
                    else {
                        final ViewGroup$LayoutParams layoutParams2 = mStatusGuard.getLayoutParams();
                        if (layoutParams2.height != n) {
                            layoutParams2.height = n;
                            this.mStatusGuard.setLayoutParams(layoutParams2);
                        }
                    }
                    n4 = 1;
                }
                else {
                    n4 = 0;
                }
                if (this.mStatusGuard == null) {
                    n2 = 0;
                }
                if (!this.mOverlayActionMode && n2 != 0) {
                    n = 0;
                }
                final int n5 = n2;
                n2 = n4;
                n6 = n5;
            }
            else if (layoutParams.topMargin != 0) {
                layoutParams.topMargin = 0;
                n6 = 0;
            }
            else {
                n6 = 0;
                n2 = 0;
            }
            if (n2 != 0) {
                this.mActionModeView.setLayoutParams((ViewGroup$LayoutParams)layoutParams);
            }
        }
        else {
            n6 = 0;
        }
        final View mStatusGuard2 = this.mStatusGuard;
        if (mStatusGuard2 != null) {
            int visibility;
            if (n6 != 0) {
                visibility = 0;
            }
            else {
                visibility = 8;
            }
            mStatusGuard2.setVisibility(visibility);
        }
        return n;
    }
    
    private class ActionBarDrawableToggleImpl implements Delegate
    {
        ActionBarDrawableToggleImpl() {
        }
        
        @Override
        public Context getActionBarThemedContext() {
            return AppCompatDelegateImpl.this.getActionBarThemedContext();
        }
        
        @Override
        public Drawable getThemeUpIndicator() {
            final TintTypedArray obtainStyledAttributes = TintTypedArray.obtainStyledAttributes(this.getActionBarThemedContext(), null, new int[] { R.attr.homeAsUpIndicator });
            final Drawable drawable = obtainStyledAttributes.getDrawable(0);
            obtainStyledAttributes.recycle();
            return drawable;
        }
        
        @Override
        public boolean isNavigationVisible() {
            final ActionBar supportActionBar = AppCompatDelegateImpl.this.getSupportActionBar();
            return supportActionBar != null && (0x4 & supportActionBar.getDisplayOptions()) != 0x0;
        }
        
        @Override
        public void setActionBarDescription(final int homeActionContentDescription) {
            final ActionBar supportActionBar = AppCompatDelegateImpl.this.getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.setHomeActionContentDescription(homeActionContentDescription);
            }
        }
        
        @Override
        public void setActionBarUpIndicator(final Drawable homeAsUpIndicator, final int homeActionContentDescription) {
            final ActionBar supportActionBar = AppCompatDelegateImpl.this.getSupportActionBar();
            if (supportActionBar != null) {
                supportActionBar.setHomeAsUpIndicator(homeAsUpIndicator);
                supportActionBar.setHomeActionContentDescription(homeActionContentDescription);
            }
        }
    }
    
    private final class ActionMenuPresenterCallback implements MenuPresenter.Callback
    {
        ActionMenuPresenterCallback() {
        }
        
        @Override
        public void onCloseMenu(final MenuBuilder menuBuilder, final boolean b) {
            AppCompatDelegateImpl.this.checkCloseActionMenu(menuBuilder);
        }
        
        @Override
        public boolean onOpenSubMenu(final MenuBuilder menuBuilder) {
            final Window$Callback windowCallback = AppCompatDelegateImpl.this.getWindowCallback();
            if (windowCallback != null) {
                windowCallback.onMenuOpened(108, (Menu)menuBuilder);
            }
            return true;
        }
    }
    
    class ActionModeCallbackWrapperV9 implements ActionMode.Callback
    {
        private ActionMode.Callback mWrapped;
        
        public ActionModeCallbackWrapperV9(final ActionMode.Callback mWrapped) {
            this.mWrapped = mWrapped;
        }
        
        @Override
        public boolean onActionItemClicked(final ActionMode actionMode, final MenuItem menuItem) {
            return this.mWrapped.onActionItemClicked(actionMode, menuItem);
        }
        
        @Override
        public boolean onCreateActionMode(final ActionMode actionMode, final Menu menu) {
            return this.mWrapped.onCreateActionMode(actionMode, menu);
        }
        
        @Override
        public void onDestroyActionMode(final ActionMode actionMode) {
            this.mWrapped.onDestroyActionMode(actionMode);
            if (AppCompatDelegateImpl.this.mActionModePopup != null) {
                AppCompatDelegateImpl.this.mWindow.getDecorView().removeCallbacks(AppCompatDelegateImpl.this.mShowActionModePopup);
            }
            if (AppCompatDelegateImpl.this.mActionModeView != null) {
                AppCompatDelegateImpl.this.endOnGoingFadeAnimation();
                final AppCompatDelegateImpl this$0 = AppCompatDelegateImpl.this;
                this$0.mFadeAnim = ViewCompat.animate((View)this$0.mActionModeView).alpha(0.0f);
                AppCompatDelegateImpl.this.mFadeAnim.setListener(new ViewPropertyAnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(final View view) {
                        AppCompatDelegateImpl.this.mActionModeView.setVisibility(8);
                        if (AppCompatDelegateImpl.this.mActionModePopup != null) {
                            AppCompatDelegateImpl.this.mActionModePopup.dismiss();
                        }
                        else if (AppCompatDelegateImpl.this.mActionModeView.getParent() instanceof View) {
                            ViewCompat.requestApplyInsets((View)AppCompatDelegateImpl.this.mActionModeView.getParent());
                        }
                        AppCompatDelegateImpl.this.mActionModeView.removeAllViews();
                        AppCompatDelegateImpl.this.mFadeAnim.setListener(null);
                        AppCompatDelegateImpl.this.mFadeAnim = null;
                    }
                });
            }
            if (AppCompatDelegateImpl.this.mAppCompatCallback != null) {
                AppCompatDelegateImpl.this.mAppCompatCallback.onSupportActionModeFinished(AppCompatDelegateImpl.this.mActionMode);
            }
            AppCompatDelegateImpl.this.mActionMode = null;
        }
        
        @Override
        public boolean onPrepareActionMode(final ActionMode actionMode, final Menu menu) {
            return this.mWrapped.onPrepareActionMode(actionMode, menu);
        }
    }
    
    class AppCompatWindowCallback extends WindowCallbackWrapper
    {
        AppCompatWindowCallback(final Window$Callback window$Callback) {
            super(window$Callback);
        }
        
        @Override
        public boolean dispatchKeyEvent(final KeyEvent keyEvent) {
            return AppCompatDelegateImpl.this.dispatchKeyEvent(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }
        
        @Override
        public boolean dispatchKeyShortcutEvent(final KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || AppCompatDelegateImpl.this.onKeyShortcut(keyEvent.getKeyCode(), keyEvent);
        }
        
        @Override
        public void onContentChanged() {
        }
        
        @Override
        public boolean onCreatePanelMenu(final int n, final Menu menu) {
            return (n != 0 || menu instanceof MenuBuilder) && super.onCreatePanelMenu(n, menu);
        }
        
        @Override
        public boolean onMenuOpened(final int n, final Menu menu) {
            super.onMenuOpened(n, menu);
            AppCompatDelegateImpl.this.onMenuOpened(n);
            return true;
        }
        
        @Override
        public void onPanelClosed(final int n, final Menu menu) {
            super.onPanelClosed(n, menu);
            AppCompatDelegateImpl.this.onPanelClosed(n);
        }
        
        @Override
        public boolean onPreparePanel(final int n, final View view, final Menu menu) {
            MenuBuilder menuBuilder;
            if (menu instanceof MenuBuilder) {
                menuBuilder = (MenuBuilder)menu;
            }
            else {
                menuBuilder = null;
            }
            if (n == 0 && menuBuilder == null) {
                return false;
            }
            if (menuBuilder != null) {
                menuBuilder.setOverrideVisibleItems(true);
            }
            final boolean onPreparePanel = super.onPreparePanel(n, view, menu);
            if (menuBuilder != null) {
                menuBuilder.setOverrideVisibleItems(false);
            }
            return onPreparePanel;
        }
        
        @Override
        public void onProvideKeyboardShortcuts(final List<KeyboardShortcutGroup> list, final Menu menu, final int n) {
            final PanelFeatureState panelState = AppCompatDelegateImpl.this.getPanelState(0, true);
            if (panelState != null && panelState.menu != null) {
                super.onProvideKeyboardShortcuts(list, (Menu)panelState.menu, n);
            }
            else {
                super.onProvideKeyboardShortcuts(list, menu, n);
            }
        }
        
        @Override
        public android.view.ActionMode onWindowStartingActionMode(final ActionMode$Callback actionMode$Callback) {
            if (Build$VERSION.SDK_INT >= 23) {
                return null;
            }
            if (AppCompatDelegateImpl.this.isHandleNativeActionModesEnabled()) {
                return this.startAsSupportActionMode(actionMode$Callback);
            }
            return super.onWindowStartingActionMode(actionMode$Callback);
        }
        
        @Override
        public android.view.ActionMode onWindowStartingActionMode(final ActionMode$Callback actionMode$Callback, final int n) {
            if (AppCompatDelegateImpl.this.isHandleNativeActionModesEnabled() && n == 0) {
                return this.startAsSupportActionMode(actionMode$Callback);
            }
            return super.onWindowStartingActionMode(actionMode$Callback, n);
        }
        
        final android.view.ActionMode startAsSupportActionMode(final ActionMode$Callback actionMode$Callback) {
            final SupportActionModeWrapper.CallbackWrapper callbackWrapper = new SupportActionModeWrapper.CallbackWrapper(AppCompatDelegateImpl.this.mContext, actionMode$Callback);
            final ActionMode startSupportActionMode = AppCompatDelegateImpl.this.startSupportActionMode(callbackWrapper);
            if (startSupportActionMode != null) {
                return callbackWrapper.getActionModeWrapper(startSupportActionMode);
            }
            return null;
        }
    }
    
    private class AutoBatteryNightModeManager extends AutoNightModeManager
    {
        private final PowerManager mPowerManager;
        
        AutoBatteryNightModeManager(final Context context) {
            this.mPowerManager = (PowerManager)context.getSystemService("power");
        }
        
        @Override
        IntentFilter createIntentFilterForBroadcastReceiver() {
            if (Build$VERSION.SDK_INT >= 21) {
                final IntentFilter intentFilter = new IntentFilter();
                intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
                return intentFilter;
            }
            return null;
        }
        
        public int getApplyableNightMode() {
            final int sdk_INT = Build$VERSION.SDK_INT;
            int n = 1;
            if (sdk_INT >= 21 && this.mPowerManager.isPowerSaveMode()) {
                n = 2;
            }
            return n;
        }
        
        public void onChange() {
            AppCompatDelegateImpl.this.applyDayNight();
        }
    }
    
    abstract class AutoNightModeManager
    {
        private BroadcastReceiver mReceiver;
        
        void cleanup() {
            if (this.mReceiver != null) {
                try {
                    AppCompatDelegateImpl.this.mContext.unregisterReceiver(this.mReceiver);
                }
                catch (IllegalArgumentException ex) {}
                this.mReceiver = null;
            }
        }
        
        abstract IntentFilter createIntentFilterForBroadcastReceiver();
        
        abstract int getApplyableNightMode();
        
        boolean isListening() {
            return this.mReceiver != null;
        }
        
        abstract void onChange();
        
        void setup() {
            this.cleanup();
            final IntentFilter intentFilterForBroadcastReceiver = this.createIntentFilterForBroadcastReceiver();
            if (intentFilterForBroadcastReceiver != null) {
                if (intentFilterForBroadcastReceiver.countActions() != 0) {
                    if (this.mReceiver == null) {
                        this.mReceiver = new BroadcastReceiver() {
                            public void onReceive(final Context context, final Intent intent) {
                                AutoNightModeManager.this.onChange();
                            }
                        };
                    }
                    AppCompatDelegateImpl.this.mContext.registerReceiver(this.mReceiver, intentFilterForBroadcastReceiver);
                }
            }
        }
    }
    
    private class AutoTimeNightModeManager extends AutoNightModeManager
    {
        private final TwilightManager mTwilightManager;
        
        AutoTimeNightModeManager(final TwilightManager mTwilightManager) {
            this.mTwilightManager = mTwilightManager;
        }
        
        @Override
        IntentFilter createIntentFilterForBroadcastReceiver() {
            final IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }
        
        public int getApplyableNightMode() {
            int n;
            if (this.mTwilightManager.isNight()) {
                n = 2;
            }
            else {
                n = 1;
            }
            return n;
        }
        
        public void onChange() {
            AppCompatDelegateImpl.this.applyDayNight();
        }
    }
    
    private class ListMenuDecorView extends ContentFrameLayout
    {
        public ListMenuDecorView(final Context context) {
            super(context);
        }
        
        private boolean isOutOfBounds(final int n, final int n2) {
            return n < -5 || n2 < -5 || n > 5 + this.getWidth() || n2 > 5 + this.getHeight();
        }
        
        public boolean dispatchKeyEvent(final KeyEvent keyEvent) {
            return AppCompatDelegateImpl.this.dispatchKeyEvent(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }
        
        public boolean onInterceptTouchEvent(final MotionEvent motionEvent) {
            if (motionEvent.getAction() == 0 && this.isOutOfBounds((int)motionEvent.getX(), (int)motionEvent.getY())) {
                AppCompatDelegateImpl.this.closePanel(0);
                return true;
            }
            return super.onInterceptTouchEvent(motionEvent);
        }
        
        public void setBackgroundResource(final int n) {
            this.setBackgroundDrawable(AppCompatResources.getDrawable(this.getContext(), n));
        }
    }
    
    protected static final class PanelFeatureState
    {
        int background;
        View createdPanelView;
        ViewGroup decorView;
        int featureId;
        Bundle frozenActionViewState;
        Bundle frozenMenuState;
        int gravity;
        boolean isHandled;
        boolean isOpen;
        boolean isPrepared;
        ListMenuPresenter listMenuPresenter;
        Context listPresenterContext;
        MenuBuilder menu;
        public boolean qwertyMode;
        boolean refreshDecorView;
        boolean refreshMenuContent;
        View shownPanelView;
        boolean wasLastOpen;
        int windowAnimations;
        int x;
        int y;
        
        PanelFeatureState(final int featureId) {
            this.featureId = featureId;
            this.refreshDecorView = false;
        }
        
        void applyFrozenState() {
            final MenuBuilder menu = this.menu;
            if (menu != null) {
                final Bundle frozenMenuState = this.frozenMenuState;
                if (frozenMenuState != null) {
                    menu.restorePresenterStates(frozenMenuState);
                    this.frozenMenuState = null;
                }
            }
        }
        
        public void clearMenuPresenters() {
            final MenuBuilder menu = this.menu;
            if (menu != null) {
                menu.removeMenuPresenter(this.listMenuPresenter);
            }
            this.listMenuPresenter = null;
        }
        
        MenuView getListMenuView(final MenuPresenter.Callback callback) {
            if (this.menu == null) {
                return null;
            }
            if (this.listMenuPresenter == null) {
                (this.listMenuPresenter = new ListMenuPresenter(this.listPresenterContext, R.layout.abc_list_menu_item_layout)).setCallback(callback);
                this.menu.addMenuPresenter(this.listMenuPresenter);
            }
            return this.listMenuPresenter.getMenuView(this.decorView);
        }
        
        public boolean hasPanelItems() {
            if (this.shownPanelView == null) {
                return false;
            }
            if (this.createdPanelView != null) {
                return true;
            }
            final int count = this.listMenuPresenter.getAdapter().getCount();
            boolean b = false;
            if (count > 0) {
                b = true;
            }
            return b;
        }
        
        void onRestoreInstanceState(final Parcelable parcelable) {
            final SavedState savedState = (SavedState)parcelable;
            this.featureId = savedState.featureId;
            this.wasLastOpen = savedState.isOpen;
            this.frozenMenuState = savedState.menuState;
            this.shownPanelView = null;
            this.decorView = null;
        }
        
        Parcelable onSaveInstanceState() {
            final SavedState savedState = new SavedState();
            savedState.featureId = this.featureId;
            savedState.isOpen = this.isOpen;
            if (this.menu != null) {
                savedState.menuState = new Bundle();
                this.menu.savePresenterStates(savedState.menuState);
            }
            return (Parcelable)savedState;
        }
        
        void setMenu(final MenuBuilder menu) {
            final MenuBuilder menu2 = this.menu;
            if (menu == menu2) {
                return;
            }
            if (menu2 != null) {
                menu2.removeMenuPresenter(this.listMenuPresenter);
            }
            if ((this.menu = menu) != null) {
                final ListMenuPresenter listMenuPresenter = this.listMenuPresenter;
                if (listMenuPresenter != null) {
                    menu.addMenuPresenter(listMenuPresenter);
                }
            }
        }
        
        void setStyle(final Context context) {
            final TypedValue typedValue = new TypedValue();
            final Resources$Theme theme = context.getResources().newTheme();
            theme.setTo(context.getTheme());
            theme.resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                theme.applyStyle(typedValue.resourceId, true);
            }
            theme.resolveAttribute(R.attr.panelMenuListTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                theme.applyStyle(typedValue.resourceId, true);
            }
            else {
                theme.applyStyle(R.style.Theme_AppCompat_CompactMenu, true);
            }
            final ContextThemeWrapper listPresenterContext = new ContextThemeWrapper(context, 0);
            ((Context)listPresenterContext).getTheme().setTo(theme);
            this.listPresenterContext = (Context)listPresenterContext;
            final TypedArray obtainStyledAttributes = ((Context)listPresenterContext).obtainStyledAttributes(R.styleable.AppCompatTheme);
            this.background = obtainStyledAttributes.getResourceId(R.styleable.AppCompatTheme_panelBackground, 0);
            this.windowAnimations = obtainStyledAttributes.getResourceId(R.styleable.AppCompatTheme_android_windowAnimationStyle, 0);
            obtainStyledAttributes.recycle();
        }
        
        private static class SavedState implements Parcelable
        {
            public static final Parcelable$Creator<SavedState> CREATOR;
            int featureId;
            boolean isOpen;
            Bundle menuState;
            
            static {
                CREATOR = (Parcelable$Creator)new Parcelable$ClassLoaderCreator<SavedState>() {
                    public SavedState createFromParcel(final Parcel parcel) {
                        return SavedState.readFromParcel(parcel, null);
                    }
                    
                    public SavedState createFromParcel(final Parcel parcel, final ClassLoader classLoader) {
                        return SavedState.readFromParcel(parcel, classLoader);
                    }
                    
                    public SavedState[] newArray(final int n) {
                        return new SavedState[n];
                    }
                };
            }
            
            SavedState() {
            }
            
            static SavedState readFromParcel(final Parcel parcel, final ClassLoader classLoader) {
                final SavedState savedState = new SavedState();
                savedState.featureId = parcel.readInt();
                final int int1 = parcel.readInt();
                int isOpen = 1;
                if (int1 != isOpen) {
                    isOpen = 0;
                }
                savedState.isOpen = (isOpen != 0);
                if (isOpen != 0) {
                    savedState.menuState = parcel.readBundle(classLoader);
                }
                return savedState;
            }
            
            public int describeContents() {
                return 0;
            }
            
            public void writeToParcel(final Parcel parcel, final int n) {
                parcel.writeInt(this.featureId);
                parcel.writeInt((int)(this.isOpen ? 1 : 0));
                if (this.isOpen) {
                    parcel.writeBundle(this.menuState);
                }
            }
        }
    }
    
    private final class PanelMenuPresenterCallback implements MenuPresenter.Callback
    {
        PanelMenuPresenterCallback() {
        }
        
        @Override
        public void onCloseMenu(MenuBuilder menuBuilder, final boolean b) {
            final Object rootMenu = menuBuilder.getRootMenu();
            final boolean b2 = rootMenu != menuBuilder;
            final AppCompatDelegateImpl this$0 = AppCompatDelegateImpl.this;
            if (b2) {
                menuBuilder = (MenuBuilder)rootMenu;
            }
            final PanelFeatureState menuPanel = this$0.findMenuPanel((Menu)menuBuilder);
            if (menuPanel != null) {
                if (b2) {
                    AppCompatDelegateImpl.this.callOnPanelClosed(menuPanel.featureId, menuPanel, (Menu)rootMenu);
                    AppCompatDelegateImpl.this.closePanel(menuPanel, true);
                }
                else {
                    AppCompatDelegateImpl.this.closePanel(menuPanel, b);
                }
            }
        }
        
        @Override
        public boolean onOpenSubMenu(final MenuBuilder menuBuilder) {
            if (menuBuilder == null && AppCompatDelegateImpl.this.mHasActionBar) {
                final Window$Callback windowCallback = AppCompatDelegateImpl.this.getWindowCallback();
                if (windowCallback != null && !AppCompatDelegateImpl.this.mIsDestroyed) {
                    windowCallback.onMenuOpened(108, (Menu)menuBuilder);
                }
            }
            return true;
        }
    }
}
