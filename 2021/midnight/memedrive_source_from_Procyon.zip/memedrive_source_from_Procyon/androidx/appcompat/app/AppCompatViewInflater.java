// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.app;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import androidx.appcompat.widget.TintContextWrapper;
import androidx.appcompat.widget.AppCompatToggleButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatRatingBar;
import androidx.appcompat.widget.AppCompatRadioButton;
import androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatCheckedTextView;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;
import androidx.appcompat.view.ContextThemeWrapper;
import android.util.Log;
import androidx.appcompat.R;
import android.view.InflateException;
import android.content.res.TypedArray;
import android.view.View$OnClickListener;
import androidx.core.view.ViewCompat;
import android.os.Build$VERSION;
import android.content.ContextWrapper;
import androidx.collection.ArrayMap;
import android.util.AttributeSet;
import android.content.Context;
import android.view.View;
import java.lang.reflect.Constructor;
import java.util.Map;

public class AppCompatViewInflater
{
    private static final String LOG_TAG = "AppCompatViewInflater";
    private static final String[] sClassPrefixList;
    private static final Map<String, Constructor<? extends View>> sConstructorMap;
    private static final Class<?>[] sConstructorSignature;
    private static final int[] sOnClickAttrs;
    private final Object[] mConstructorArgs;
    
    static {
        sConstructorSignature = new Class[] { Context.class, AttributeSet.class };
        sOnClickAttrs = new int[] { 16843375 };
        sClassPrefixList = new String[] { "android.widget.", "android.view.", "android.webkit." };
        sConstructorMap = new ArrayMap<String, Constructor<? extends View>>();
    }
    
    public AppCompatViewInflater() {
        this.mConstructorArgs = new Object[2];
    }
    
    private void checkOnClickListener(final View view, final AttributeSet set) {
        final Context context = view.getContext();
        if (context instanceof ContextWrapper) {
            if (Build$VERSION.SDK_INT < 15 || ViewCompat.hasOnClickListeners(view)) {
                final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, AppCompatViewInflater.sOnClickAttrs);
                final String string = obtainStyledAttributes.getString(0);
                if (string != null) {
                    view.setOnClickListener((View$OnClickListener)new DeclaredOnClickListener(view, string));
                }
                obtainStyledAttributes.recycle();
            }
        }
    }
    
    private View createViewByPrefix(final Context context, final String str, final String str2) throws ClassNotFoundException, InflateException {
        final Map<String, Constructor<? extends View>> sConstructorMap = AppCompatViewInflater.sConstructorMap;
        Constructor<? extends View> constructor = sConstructorMap.get(str);
        while (true) {
            Label_0094: {
                if (constructor != null) {
                    break Label_0094;
                }
                if (str2 == null) {
                    break Label_0094;
                }
                try {
                    final StringBuilder sb = new StringBuilder();
                    sb.append(str2);
                    sb.append(str);
                    final String string = sb.toString();
                    constructor = Class.forName(string, false, context.getClassLoader()).asSubclass(View.class).getConstructor(AppCompatViewInflater.sConstructorSignature);
                    sConstructorMap.put(str, constructor);
                    constructor.setAccessible(true);
                    return constructor.newInstance(this.mConstructorArgs);
                }
                catch (Exception ex) {
                    return null;
                }
            }
            final String string = str;
            continue;
        }
    }
    
    private View createViewFromTag(final Context context, String attributeValue, final AttributeSet set) {
        if (attributeValue.equals("view")) {
            attributeValue = set.getAttributeValue((String)null, "class");
        }
        try {
            final Object[] mConstructorArgs = this.mConstructorArgs;
            mConstructorArgs[0] = context;
            mConstructorArgs[1] = set;
            if (-1 != attributeValue.indexOf(46)) {
                return this.createViewByPrefix(context, attributeValue, null);
            }
            int n = 0;
            while (true) {
                final String[] sClassPrefixList = AppCompatViewInflater.sClassPrefixList;
                if (n >= sClassPrefixList.length) {
                    return null;
                }
                final View viewByPrefix = this.createViewByPrefix(context, attributeValue, sClassPrefixList[n]);
                if (viewByPrefix != null) {
                    return viewByPrefix;
                }
                ++n;
            }
        }
        catch (Exception ex) {
            return null;
        }
        finally {
            final Object[] mConstructorArgs2 = this.mConstructorArgs;
            mConstructorArgs2[1] = (mConstructorArgs2[0] = null);
        }
    }
    
    private static Context themifyContext(Context context, final AttributeSet set, final boolean b, final boolean b2) {
        final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, R.styleable.View, 0, 0);
        int n;
        if (b) {
            n = obtainStyledAttributes.getResourceId(R.styleable.View_android_theme, 0);
        }
        else {
            n = 0;
        }
        if (b2 && n == 0) {
            n = obtainStyledAttributes.getResourceId(R.styleable.View_theme, 0);
            if (n != 0) {
                Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
            }
        }
        obtainStyledAttributes.recycle();
        if (n != 0 && (!(context instanceof ContextThemeWrapper) || ((ContextThemeWrapper)context).getThemeResId() != n)) {
            context = (Context)new ContextThemeWrapper(context, n);
        }
        return context;
    }
    
    private void verifyNotNull(final View view, final String str) {
        if (view != null) {
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(this.getClass().getName());
        sb.append(" asked to inflate view for <");
        sb.append(str);
        sb.append(">, but returned null");
        throw new IllegalStateException(sb.toString());
    }
    
    protected AppCompatAutoCompleteTextView createAutoCompleteTextView(final Context context, final AttributeSet set) {
        return new AppCompatAutoCompleteTextView(context, set);
    }
    
    protected AppCompatButton createButton(final Context context, final AttributeSet set) {
        return new AppCompatButton(context, set);
    }
    
    protected AppCompatCheckBox createCheckBox(final Context context, final AttributeSet set) {
        return new AppCompatCheckBox(context, set);
    }
    
    protected AppCompatCheckedTextView createCheckedTextView(final Context context, final AttributeSet set) {
        return new AppCompatCheckedTextView(context, set);
    }
    
    protected AppCompatEditText createEditText(final Context context, final AttributeSet set) {
        return new AppCompatEditText(context, set);
    }
    
    protected AppCompatImageButton createImageButton(final Context context, final AttributeSet set) {
        return new AppCompatImageButton(context, set);
    }
    
    protected AppCompatImageView createImageView(final Context context, final AttributeSet set) {
        return new AppCompatImageView(context, set);
    }
    
    protected AppCompatMultiAutoCompleteTextView createMultiAutoCompleteTextView(final Context context, final AttributeSet set) {
        return new AppCompatMultiAutoCompleteTextView(context, set);
    }
    
    protected AppCompatRadioButton createRadioButton(final Context context, final AttributeSet set) {
        return new AppCompatRadioButton(context, set);
    }
    
    protected AppCompatRatingBar createRatingBar(final Context context, final AttributeSet set) {
        return new AppCompatRatingBar(context, set);
    }
    
    protected AppCompatSeekBar createSeekBar(final Context context, final AttributeSet set) {
        return new AppCompatSeekBar(context, set);
    }
    
    protected AppCompatSpinner createSpinner(final Context context, final AttributeSet set) {
        return new AppCompatSpinner(context, set);
    }
    
    protected AppCompatTextView createTextView(final Context context, final AttributeSet set) {
        return new AppCompatTextView(context, set);
    }
    
    protected AppCompatToggleButton createToggleButton(final Context context, final AttributeSet set) {
        return new AppCompatToggleButton(context, set);
    }
    
    protected View createView(final Context context, final String s, final AttributeSet set) {
        return null;
    }
    
    final View createView(final View view, final String s, final Context context, final AttributeSet set, final boolean b, final boolean b2, final boolean b3, final boolean b4) {
        Context context2;
        if (b && view != null) {
            context2 = view.getContext();
        }
        else {
            context2 = context;
        }
        if (b2 || b3) {
            context2 = themifyContext(context2, set, b2, b3);
        }
        if (b4) {
            context2 = TintContextWrapper.wrap(context2);
        }
        s.hashCode();
        int n = -1;
        switch (s) {
            case "Button": {
                n = 13;
                break;
            }
            case "EditText": {
                n = 12;
                break;
            }
            case "CheckBox": {
                n = 11;
                break;
            }
            case "AutoCompleteTextView": {
                n = 10;
                break;
            }
            case "ImageView": {
                n = 9;
                break;
            }
            case "ToggleButton": {
                n = 8;
                break;
            }
            case "RadioButton": {
                n = 7;
                break;
            }
            case "Spinner": {
                n = 6;
                break;
            }
            case "SeekBar": {
                n = 5;
                break;
            }
            case "ImageButton": {
                n = 4;
                break;
            }
            case "TextView": {
                n = 3;
                break;
            }
            case "MultiAutoCompleteTextView": {
                n = 2;
                break;
            }
            case "CheckedTextView": {
                n = 1;
                break;
            }
            case "RatingBar": {
                n = 0;
                break;
            }
            default:
                break;
        }
        Object o = null;
        switch (n) {
            default: {
                o = this.createView(context2, s, set);
                break;
            }
            case 13: {
                o = this.createButton(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 12: {
                o = this.createEditText(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 11: {
                o = this.createCheckBox(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 10: {
                o = this.createAutoCompleteTextView(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 9: {
                o = this.createImageView(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 8: {
                o = this.createToggleButton(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 7: {
                o = this.createRadioButton(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 6: {
                o = this.createSpinner(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 5: {
                o = this.createSeekBar(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 4: {
                o = this.createImageButton(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 3: {
                o = this.createTextView(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 2: {
                o = this.createMultiAutoCompleteTextView(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 1: {
                o = this.createCheckedTextView(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
            case 0: {
                o = this.createRatingBar(context2, set);
                this.verifyNotNull((View)o, s);
                break;
            }
        }
        if (o == null && context != context2) {
            o = this.createViewFromTag(context2, s, set);
        }
        if (o != null) {
            this.checkOnClickListener((View)o, set);
        }
        return (View)o;
    }
    
    private static class DeclaredOnClickListener implements View$OnClickListener
    {
        private final View mHostView;
        private final String mMethodName;
        private Context mResolvedContext;
        private Method mResolvedMethod;
        
        public DeclaredOnClickListener(final View mHostView, final String mMethodName) {
            this.mHostView = mHostView;
            this.mMethodName = mMethodName;
        }
        
        private void resolveMethod(final Context p0, final String p1) {
            // 
            // This method could not be decompiled.
            // 
            // Original Bytecode:
            // 
            //     1: ifnull          73
            //     4: aload_1        
            //     5: invokevirtual   android/content/Context.isRestricted:()Z
            //     8: ifne            50
            //    11: aload_1        
            //    12: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
            //    15: aload_0        
            //    16: getfield        androidx/appcompat/app/AppCompatViewInflater$DeclaredOnClickListener.mMethodName:Ljava/lang/String;
            //    19: iconst_1       
            //    20: anewarray       Ljava/lang/Class;
            //    23: dup            
            //    24: iconst_0       
            //    25: ldc             Landroid/view/View;.class
            //    27: aastore        
            //    28: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
            //    31: astore          16
            //    33: aload           16
            //    35: ifnull          50
            //    38: aload_0        
            //    39: aload           16
            //    41: putfield        androidx/appcompat/app/AppCompatViewInflater$DeclaredOnClickListener.mResolvedMethod:Ljava/lang/reflect/Method;
            //    44: aload_0        
            //    45: aload_1        
            //    46: putfield        androidx/appcompat/app/AppCompatViewInflater$DeclaredOnClickListener.mResolvedContext:Landroid/content/Context;
            //    49: return         
            //    50: aload_1        
            //    51: instanceof      Landroid/content/ContextWrapper;
            //    54: ifeq            68
            //    57: aload_1        
            //    58: checkcast       Landroid/content/ContextWrapper;
            //    61: invokevirtual   android/content/ContextWrapper.getBaseContext:()Landroid/content/Context;
            //    64: astore_1       
            //    65: goto            0
            //    68: aconst_null    
            //    69: astore_1       
            //    70: goto            0
            //    73: aload_0        
            //    74: getfield        androidx/appcompat/app/AppCompatViewInflater$DeclaredOnClickListener.mHostView:Landroid/view/View;
            //    77: invokevirtual   android/view/View.getId:()I
            //    80: istore_3       
            //    81: iload_3        
            //    82: iconst_m1      
            //    83: if_icmpne       93
            //    86: ldc             ""
            //    88: astore          8
            //    90: goto            145
            //    93: new             Ljava/lang/StringBuilder;
            //    96: dup            
            //    97: invokespecial   java/lang/StringBuilder.<init>:()V
            //   100: astore          4
            //   102: aload           4
            //   104: ldc             " with id '"
            //   106: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   109: pop            
            //   110: aload           4
            //   112: aload_0        
            //   113: getfield        androidx/appcompat/app/AppCompatViewInflater$DeclaredOnClickListener.mHostView:Landroid/view/View;
            //   116: invokevirtual   android/view/View.getContext:()Landroid/content/Context;
            //   119: invokevirtual   android/content/Context.getResources:()Landroid/content/res/Resources;
            //   122: iload_3        
            //   123: invokevirtual   android/content/res/Resources.getResourceEntryName:(I)Ljava/lang/String;
            //   126: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   129: pop            
            //   130: aload           4
            //   132: ldc             "'"
            //   134: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   137: pop            
            //   138: aload           4
            //   140: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
            //   143: astore          8
            //   145: new             Ljava/lang/StringBuilder;
            //   148: dup            
            //   149: invokespecial   java/lang/StringBuilder.<init>:()V
            //   152: astore          9
            //   154: aload           9
            //   156: ldc             "Could not find method "
            //   158: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   161: pop            
            //   162: aload           9
            //   164: aload_0        
            //   165: getfield        androidx/appcompat/app/AppCompatViewInflater$DeclaredOnClickListener.mMethodName:Ljava/lang/String;
            //   168: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   171: pop            
            //   172: aload           9
            //   174: ldc             "(View) in a parent or ancestor Context for android:onClick attribute defined on view "
            //   176: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   179: pop            
            //   180: aload           9
            //   182: aload_0        
            //   183: getfield        androidx/appcompat/app/AppCompatViewInflater$DeclaredOnClickListener.mHostView:Landroid/view/View;
            //   186: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
            //   189: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
            //   192: pop            
            //   193: aload           9
            //   195: aload           8
            //   197: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
            //   200: pop            
            //   201: new             Ljava/lang/IllegalStateException;
            //   204: dup            
            //   205: aload           9
            //   207: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
            //   210: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
            //   213: astore          15
            //   215: goto            221
            //   218: aload           15
            //   220: athrow         
            //   221: goto            218
            //    Exceptions:
            //  Try           Handler
            //  Start  End    Start  End    Type                             
            //  -----  -----  -----  -----  ---------------------------------
            //  4      49     50     73     Ljava/lang/NoSuchMethodException;
            // 
            // The error that occurred was:
            // 
            // java.lang.IllegalStateException: Inconsistent stack size at #0000 (coming from #0070).
            //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
            //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
            //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
            //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:576)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
            //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
            //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
            //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
            //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
            //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
            // 
            throw new IllegalStateException("An error occurred while decompiling this method.");
        }
        
        public void onClick(final View view) {
            if (this.mResolvedMethod == null) {
                this.resolveMethod(this.mHostView.getContext(), this.mMethodName);
            }
            try {
                this.mResolvedMethod.invoke(this.mResolvedContext, view);
            }
            catch (InvocationTargetException cause) {
                throw new IllegalStateException("Could not execute method for android:onClick", cause);
            }
            catch (IllegalAccessException cause2) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", cause2);
            }
        }
    }
}
