// 
// Decompiled by Procyon v0.5.36
// 

package androidx.appcompat.app;

import java.util.Calendar;
import android.util.Log;
import androidx.core.content.PermissionChecker;
import android.location.Location;
import android.location.LocationManager;
import android.content.Context;

class TwilightManager
{
    private static final int SUNRISE = 6;
    private static final int SUNSET = 22;
    private static final String TAG = "TwilightManager";
    private static TwilightManager sInstance;
    private final Context mContext;
    private final LocationManager mLocationManager;
    private final TwilightState mTwilightState;
    
    TwilightManager(final Context mContext, final LocationManager mLocationManager) {
        this.mTwilightState = new TwilightState();
        this.mContext = mContext;
        this.mLocationManager = mLocationManager;
    }
    
    static TwilightManager getInstance(final Context context) {
        if (TwilightManager.sInstance == null) {
            final Context applicationContext = context.getApplicationContext();
            TwilightManager.sInstance = new TwilightManager(applicationContext, (LocationManager)applicationContext.getSystemService("location"));
        }
        return TwilightManager.sInstance;
    }
    
    private Location getLastKnownLocation() {
        Location lastKnownLocationForProvider;
        if (PermissionChecker.checkSelfPermission(this.mContext, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            lastKnownLocationForProvider = this.getLastKnownLocationForProvider("network");
        }
        else {
            lastKnownLocationForProvider = null;
        }
        final int checkSelfPermission = PermissionChecker.checkSelfPermission(this.mContext, "android.permission.ACCESS_FINE_LOCATION");
        Location lastKnownLocationForProvider2 = null;
        if (checkSelfPermission == 0) {
            lastKnownLocationForProvider2 = this.getLastKnownLocationForProvider("gps");
        }
        if (lastKnownLocationForProvider2 != null && lastKnownLocationForProvider != null) {
            if (lastKnownLocationForProvider2.getTime() > lastKnownLocationForProvider.getTime()) {
                lastKnownLocationForProvider = lastKnownLocationForProvider2;
            }
            return lastKnownLocationForProvider;
        }
        if (lastKnownLocationForProvider2 != null) {
            lastKnownLocationForProvider = lastKnownLocationForProvider2;
        }
        return lastKnownLocationForProvider;
    }
    
    private Location getLastKnownLocationForProvider(final String s) {
        try {
            if (this.mLocationManager.isProviderEnabled(s)) {
                return this.mLocationManager.getLastKnownLocation(s);
            }
        }
        catch (Exception ex) {
            Log.d("TwilightManager", "Failed to get last known location", (Throwable)ex);
        }
        return null;
    }
    
    private boolean isStateValid() {
        return this.mTwilightState.nextUpdate > System.currentTimeMillis();
    }
    
    static void setInstance(final TwilightManager sInstance) {
        TwilightManager.sInstance = sInstance;
    }
    
    private void updateState(final Location location) {
        final TwilightState mTwilightState = this.mTwilightState;
        final long currentTimeMillis = System.currentTimeMillis();
        final TwilightCalculator instance = TwilightCalculator.getInstance();
        instance.calculateTwilight(currentTimeMillis - 86400000L, location.getLatitude(), location.getLongitude());
        final long sunset = instance.sunset;
        instance.calculateTwilight(currentTimeMillis, location.getLatitude(), location.getLongitude());
        final boolean b = instance.state == 1;
        final long sunrise = instance.sunrise;
        final long sunset2 = instance.sunset;
        final long n = 86400000L + currentTimeMillis;
        final double latitude = location.getLatitude();
        final double longitude = location.getLongitude();
        final boolean isNight = b;
        instance.calculateTwilight(n, latitude, longitude);
        final long sunrise2 = instance.sunrise;
        long nextUpdate;
        if (sunrise != -1L && sunset2 != -1L) {
            long n2;
            if (currentTimeMillis > sunset2) {
                n2 = 0L + sunrise2;
            }
            else if (currentTimeMillis > sunrise) {
                n2 = 0L + sunset2;
            }
            else {
                n2 = 0L + sunrise;
            }
            nextUpdate = n2 + 60000L;
        }
        else {
            nextUpdate = 43200000L + currentTimeMillis;
        }
        mTwilightState.isNight = isNight;
        mTwilightState.yesterdaySunset = sunset;
        mTwilightState.todaySunrise = sunrise;
        mTwilightState.todaySunset = sunset2;
        mTwilightState.tomorrowSunrise = sunrise2;
        mTwilightState.nextUpdate = nextUpdate;
    }
    
    boolean isNight() {
        final TwilightState mTwilightState = this.mTwilightState;
        if (this.isStateValid()) {
            return mTwilightState.isNight;
        }
        final Location lastKnownLocation = this.getLastKnownLocation();
        if (lastKnownLocation != null) {
            this.updateState(lastKnownLocation);
            return mTwilightState.isNight;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        final int value = Calendar.getInstance().get(11);
        return value < 6 || value >= 22;
    }
    
    private static class TwilightState
    {
        boolean isNight;
        long nextUpdate;
        long todaySunrise;
        long todaySunset;
        long tomorrowSunrise;
        long yesterdaySunset;
        
        TwilightState() {
        }
    }
}
