// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.util;

import java.util.Arrays;
import android.os.Build$VERSION;

public class ObjectsCompat
{
    private ObjectsCompat() {
    }
    
    public static boolean equals(final Object o, final Object obj) {
        if (Build$VERSION.SDK_INT >= 19) {
            return $r8$backportedMethods$utility$Objects$2$equals.equals(o, obj);
        }
        return o == obj || (o != null && o.equals(obj));
    }
    
    public static int hash(final Object... array) {
        if (Build$VERSION.SDK_INT >= 19) {
            return Arrays.hashCode(array);
        }
        return Arrays.hashCode(array);
    }
    
    public static int hashCode(final Object o) {
        int hashCode;
        if (o != null) {
            hashCode = o.hashCode();
        }
        else {
            hashCode = 0;
        }
        return hashCode;
    }
}
