// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.util;

public class DebugUtils
{
    private DebugUtils() {
    }
    
    public static void buildShortClassTag(final Object o, final StringBuilder sb) {
        if (o == null) {
            sb.append("null");
        }
        else {
            String str = o.getClass().getSimpleName();
            if (str == null || str.length() <= 0) {
                str = o.getClass().getName();
                final int lastIndex = str.lastIndexOf(46);
                if (lastIndex > 0) {
                    str = str.substring(lastIndex + 1);
                }
            }
            sb.append(str);
            sb.append('{');
            sb.append(Integer.toHexString(System.identityHashCode(o)));
        }
    }
}
