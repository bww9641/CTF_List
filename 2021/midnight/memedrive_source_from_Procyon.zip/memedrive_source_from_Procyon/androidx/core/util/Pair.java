// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.util;

public class Pair<F, S>
{
    public final F first;
    public final S second;
    
    public Pair(final F first, final S second) {
        this.first = first;
        this.second = second;
    }
    
    public static <A, B> Pair<A, B> create(final A a, final B b) {
        return new Pair<A, B>(a, b);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof Pair)) {
            return false;
        }
        final Pair pair = (Pair)o;
        final boolean equals = ObjectsCompat.equals(pair.first, this.first);
        boolean b = false;
        if (equals) {
            final boolean equals2 = ObjectsCompat.equals(pair.second, this.second);
            b = false;
            if (equals2) {
                b = true;
            }
        }
        return b;
    }
    
    @Override
    public int hashCode() {
        final F first = this.first;
        int hashCode;
        if (first == null) {
            hashCode = 0;
        }
        else {
            hashCode = first.hashCode();
        }
        final S second = this.second;
        int hashCode2;
        if (second == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = second.hashCode();
        }
        return hashCode ^ hashCode2;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Pair{");
        sb.append(String.valueOf(this.first));
        sb.append(" ");
        sb.append(String.valueOf(this.second));
        sb.append("}");
        return sb.toString();
    }
}
