// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.util;

public interface Consumer<T>
{
    void accept(final T p0);
}
