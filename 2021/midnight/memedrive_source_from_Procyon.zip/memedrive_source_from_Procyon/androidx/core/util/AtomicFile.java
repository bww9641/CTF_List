// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.util;

import java.io.FileNotFoundException;
import java.io.FileInputStream;
import android.util.Log;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.File;

public class AtomicFile
{
    private final File mBackupName;
    private final File mBaseName;
    
    public AtomicFile(final File mBaseName) {
        this.mBaseName = mBaseName;
        final StringBuilder sb = new StringBuilder();
        sb.append(mBaseName.getPath());
        sb.append(".bak");
        this.mBackupName = new File(sb.toString());
    }
    
    private static boolean sync(final FileOutputStream fileOutputStream) {
        try {
            fileOutputStream.getFD().sync();
            return true;
        }
        catch (IOException ex) {
            return false;
        }
    }
    
    public void delete() {
        this.mBaseName.delete();
        this.mBackupName.delete();
    }
    
    public void failWrite(final FileOutputStream fileOutputStream) {
        if (fileOutputStream != null) {
            sync(fileOutputStream);
            try {
                fileOutputStream.close();
                this.mBaseName.delete();
                this.mBackupName.renameTo(this.mBaseName);
            }
            catch (IOException ex) {
                Log.w("AtomicFile", "failWrite: Got exception:", (Throwable)ex);
            }
        }
    }
    
    public void finishWrite(final FileOutputStream fileOutputStream) {
        if (fileOutputStream != null) {
            sync(fileOutputStream);
            try {
                fileOutputStream.close();
                this.mBackupName.delete();
            }
            catch (IOException ex) {
                Log.w("AtomicFile", "finishWrite: Got exception:", (Throwable)ex);
            }
        }
    }
    
    public File getBaseFile() {
        return this.mBaseName;
    }
    
    public FileInputStream openRead() throws FileNotFoundException {
        if (this.mBackupName.exists()) {
            this.mBaseName.delete();
            this.mBackupName.renameTo(this.mBaseName);
        }
        return new FileInputStream(this.mBaseName);
    }
    
    public byte[] readFully() throws IOException {
        final FileInputStream openRead = this.openRead();
        try {
            byte[] b = new byte[openRead.available()];
            int off = 0;
            while (true) {
                final int read = openRead.read(b, off, b.length - off);
                if (read <= 0) {
                    break;
                }
                off += read;
                final int available = openRead.available();
                if (available <= b.length - off) {
                    continue;
                }
                final byte[] array = new byte[available + off];
                System.arraycopy(b, 0, array, 0, off);
                b = array;
            }
            openRead.close();
            return b;
        }
        finally {
            openRead.close();
            while (true) {}
        }
    }
    
    public FileOutputStream startWrite() throws IOException {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //     4: invokevirtual   java/io/File.exists:()Z
        //     7: ifeq            101
        //    10: aload_0        
        //    11: getfield        androidx/core/util/AtomicFile.mBackupName:Ljava/io/File;
        //    14: invokevirtual   java/io/File.exists:()Z
        //    17: ifne            93
        //    20: aload_0        
        //    21: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //    24: aload_0        
        //    25: getfield        androidx/core/util/AtomicFile.mBackupName:Ljava/io/File;
        //    28: invokevirtual   java/io/File.renameTo:(Ljava/io/File;)Z
        //    31: ifne            101
        //    34: new             Ljava/lang/StringBuilder;
        //    37: dup            
        //    38: invokespecial   java/lang/StringBuilder.<init>:()V
        //    41: astore          9
        //    43: aload           9
        //    45: ldc             "Couldn't rename file "
        //    47: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    50: pop            
        //    51: aload           9
        //    53: aload_0        
        //    54: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //    57: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    60: pop            
        //    61: aload           9
        //    63: ldc             " to backup file "
        //    65: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    68: pop            
        //    69: aload           9
        //    71: aload_0        
        //    72: getfield        androidx/core/util/AtomicFile.mBackupName:Ljava/io/File;
        //    75: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //    78: pop            
        //    79: ldc             "AtomicFile"
        //    81: aload           9
        //    83: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    86: invokestatic    android/util/Log.w:(Ljava/lang/String;Ljava/lang/String;)I
        //    89: pop            
        //    90: goto            101
        //    93: aload_0        
        //    94: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //    97: invokevirtual   java/io/File.delete:()Z
        //   100: pop            
        //   101: new             Ljava/io/FileOutputStream;
        //   104: dup            
        //   105: aload_0        
        //   106: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //   109: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/File;)V
        //   112: astore_1       
        //   113: goto            141
        //   116: aload_0        
        //   117: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //   120: invokevirtual   java/io/File.getParentFile:()Ljava/io/File;
        //   123: invokevirtual   java/io/File.mkdirs:()Z
        //   126: ifeq            183
        //   129: new             Ljava/io/FileOutputStream;
        //   132: dup            
        //   133: aload_0        
        //   134: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //   137: invokespecial   java/io/FileOutputStream.<init>:(Ljava/io/File;)V
        //   140: astore_1       
        //   141: aload_1        
        //   142: areturn        
        //   143: new             Ljava/lang/StringBuilder;
        //   146: dup            
        //   147: invokespecial   java/lang/StringBuilder.<init>:()V
        //   150: astore          5
        //   152: aload           5
        //   154: ldc             "Couldn't create "
        //   156: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   159: pop            
        //   160: aload           5
        //   162: aload_0        
        //   163: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //   166: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   169: pop            
        //   170: new             Ljava/io/IOException;
        //   173: dup            
        //   174: aload           5
        //   176: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   179: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   182: athrow         
        //   183: new             Ljava/lang/StringBuilder;
        //   186: dup            
        //   187: invokespecial   java/lang/StringBuilder.<init>:()V
        //   190: astore_2       
        //   191: aload_2        
        //   192: ldc             "Couldn't create directory "
        //   194: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   197: pop            
        //   198: aload_2        
        //   199: aload_0        
        //   200: getfield        androidx/core/util/AtomicFile.mBaseName:Ljava/io/File;
        //   203: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //   206: pop            
        //   207: new             Ljava/io/IOException;
        //   210: dup            
        //   211: aload_2        
        //   212: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   215: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   218: athrow         
        //    Exceptions:
        //  throws java.io.IOException
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                           
        //  -----  -----  -----  -----  -------------------------------
        //  101    113    116    219    Ljava/io/FileNotFoundException;
        //  129    141    143    183    Ljava/io/FileNotFoundException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0141 (coming from #0140).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
