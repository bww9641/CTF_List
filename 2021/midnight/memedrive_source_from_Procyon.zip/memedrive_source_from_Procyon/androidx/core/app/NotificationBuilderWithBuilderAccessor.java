// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.app;

import android.app.Notification$Builder;

public interface NotificationBuilderWithBuilderAccessor
{
    Notification$Builder getBuilder();
}
