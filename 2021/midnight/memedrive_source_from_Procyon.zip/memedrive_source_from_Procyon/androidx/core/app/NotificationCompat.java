// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.app;

import android.graphics.drawable.Icon;
import android.app.Notification$Action$Builder;
import java.util.Collections;
import android.os.SystemClock;
import java.text.NumberFormat;
import android.graphics.drawable.Drawable;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuff$Mode;
import android.graphics.Bitmap$Config;
import android.app.Notification$Builder;
import android.app.Notification$MessagingStyle$Message;
import android.app.Notification$MessagingStyle;
import android.text.SpannableStringBuilder;
import androidx.core.text.BidiFormatter;
import android.content.res.ColorStateList;
import android.text.style.TextAppearanceSpan;
import android.text.TextUtils;
import android.app.Notification$InboxStyle;
import android.app.Notification$Style;
import android.app.Notification$DecoratedCustomViewStyle;
import android.app.RemoteInput$Builder;
import android.media.AudioAttributes$Builder;
import android.net.Uri;
import androidx.core.R;
import android.content.Context;
import android.widget.RemoteViews;
import android.app.Notification$BubbleMetadata$Builder;
import android.app.Notification$BubbleMetadata;
import android.app.Notification$BigTextStyle;
import android.app.Notification$BigPictureStyle;
import android.graphics.Bitmap;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Annotation;
import java.util.Iterator;
import java.util.Collection;
import java.util.Arrays;
import android.content.res.Resources;
import android.app.PendingIntent;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;
import androidx.core.graphics.drawable.IconCompat;
import java.util.Set;
import android.util.SparseArray;
import android.app.Notification$Action;
import android.os.Bundle;
import android.os.Build$VERSION;
import android.app.Notification;

public class NotificationCompat
{
    public static final int BADGE_ICON_LARGE = 2;
    public static final int BADGE_ICON_NONE = 0;
    public static final int BADGE_ICON_SMALL = 1;
    public static final String CATEGORY_ALARM = "alarm";
    public static final String CATEGORY_CALL = "call";
    public static final String CATEGORY_EMAIL = "email";
    public static final String CATEGORY_ERROR = "err";
    public static final String CATEGORY_EVENT = "event";
    public static final String CATEGORY_MESSAGE = "msg";
    public static final String CATEGORY_NAVIGATION = "navigation";
    public static final String CATEGORY_PROGRESS = "progress";
    public static final String CATEGORY_PROMO = "promo";
    public static final String CATEGORY_RECOMMENDATION = "recommendation";
    public static final String CATEGORY_REMINDER = "reminder";
    public static final String CATEGORY_SERVICE = "service";
    public static final String CATEGORY_SOCIAL = "social";
    public static final String CATEGORY_STATUS = "status";
    public static final String CATEGORY_SYSTEM = "sys";
    public static final String CATEGORY_TRANSPORT = "transport";
    public static final int COLOR_DEFAULT = 0;
    public static final int DEFAULT_ALL = -1;
    public static final int DEFAULT_LIGHTS = 4;
    public static final int DEFAULT_SOUND = 1;
    public static final int DEFAULT_VIBRATE = 2;
    public static final String EXTRA_AUDIO_CONTENTS_URI = "android.audioContents";
    public static final String EXTRA_BACKGROUND_IMAGE_URI = "android.backgroundImageUri";
    public static final String EXTRA_BIG_TEXT = "android.bigText";
    public static final String EXTRA_CHRONOMETER_COUNT_DOWN = "android.chronometerCountDown";
    public static final String EXTRA_COMPACT_ACTIONS = "android.compactActions";
    public static final String EXTRA_CONVERSATION_TITLE = "android.conversationTitle";
    public static final String EXTRA_HIDDEN_CONVERSATION_TITLE = "android.hiddenConversationTitle";
    public static final String EXTRA_INFO_TEXT = "android.infoText";
    public static final String EXTRA_IS_GROUP_CONVERSATION = "android.isGroupConversation";
    public static final String EXTRA_LARGE_ICON = "android.largeIcon";
    public static final String EXTRA_LARGE_ICON_BIG = "android.largeIcon.big";
    public static final String EXTRA_MEDIA_SESSION = "android.mediaSession";
    public static final String EXTRA_MESSAGES = "android.messages";
    public static final String EXTRA_MESSAGING_STYLE_USER = "android.messagingStyleUser";
    public static final String EXTRA_PEOPLE = "android.people";
    public static final String EXTRA_PICTURE = "android.picture";
    public static final String EXTRA_PROGRESS = "android.progress";
    public static final String EXTRA_PROGRESS_INDETERMINATE = "android.progressIndeterminate";
    public static final String EXTRA_PROGRESS_MAX = "android.progressMax";
    public static final String EXTRA_REMOTE_INPUT_HISTORY = "android.remoteInputHistory";
    public static final String EXTRA_SELF_DISPLAY_NAME = "android.selfDisplayName";
    public static final String EXTRA_SHOW_CHRONOMETER = "android.showChronometer";
    public static final String EXTRA_SHOW_WHEN = "android.showWhen";
    public static final String EXTRA_SMALL_ICON = "android.icon";
    public static final String EXTRA_SUB_TEXT = "android.subText";
    public static final String EXTRA_SUMMARY_TEXT = "android.summaryText";
    public static final String EXTRA_TEMPLATE = "android.template";
    public static final String EXTRA_TEXT = "android.text";
    public static final String EXTRA_TEXT_LINES = "android.textLines";
    public static final String EXTRA_TITLE = "android.title";
    public static final String EXTRA_TITLE_BIG = "android.title.big";
    public static final int FLAG_AUTO_CANCEL = 16;
    public static final int FLAG_BUBBLE = 4096;
    public static final int FLAG_FOREGROUND_SERVICE = 64;
    public static final int FLAG_GROUP_SUMMARY = 512;
    @Deprecated
    public static final int FLAG_HIGH_PRIORITY = 128;
    public static final int FLAG_INSISTENT = 4;
    public static final int FLAG_LOCAL_ONLY = 256;
    public static final int FLAG_NO_CLEAR = 32;
    public static final int FLAG_ONGOING_EVENT = 2;
    public static final int FLAG_ONLY_ALERT_ONCE = 8;
    public static final int FLAG_SHOW_LIGHTS = 1;
    public static final int GROUP_ALERT_ALL = 0;
    public static final int GROUP_ALERT_CHILDREN = 2;
    public static final int GROUP_ALERT_SUMMARY = 1;
    public static final String GROUP_KEY_SILENT = "silent";
    public static final int PRIORITY_DEFAULT = 0;
    public static final int PRIORITY_HIGH = 1;
    public static final int PRIORITY_LOW = -1;
    public static final int PRIORITY_MAX = 2;
    public static final int PRIORITY_MIN = -2;
    public static final int STREAM_DEFAULT = -1;
    public static final int VISIBILITY_PRIVATE = 0;
    public static final int VISIBILITY_PUBLIC = 1;
    public static final int VISIBILITY_SECRET = -1;
    
    @Deprecated
    public NotificationCompat() {
    }
    
    public static Action getAction(final Notification notification, final int n) {
        if (Build$VERSION.SDK_INT >= 20) {
            return getActionCompatFromAction(notification.actions[n]);
        }
        if (Build$VERSION.SDK_INT >= 19) {
            final Notification$Action notification$Action = notification.actions[n];
            final SparseArray sparseParcelableArray = notification.extras.getSparseParcelableArray("android.support.actionExtras");
            Bundle bundle = null;
            if (sparseParcelableArray != null) {
                bundle = (Bundle)sparseParcelableArray.get(n);
            }
            return NotificationCompatJellybean.readAction(notification$Action.icon, notification$Action.title, notification$Action.actionIntent, bundle);
        }
        if (Build$VERSION.SDK_INT >= 16) {
            return NotificationCompatJellybean.getAction(notification, n);
        }
        return null;
    }
    
    static Action getActionCompatFromAction(final Notification$Action notification$Action) {
        final android.app.RemoteInput[] remoteInputs = notification$Action.getRemoteInputs();
        RemoteInput[] array;
        if (remoteInputs == null) {
            array = null;
        }
        else {
            final RemoteInput[] array2 = new RemoteInput[remoteInputs.length];
            for (int i = 0; i < remoteInputs.length; ++i) {
                final android.app.RemoteInput remoteInput = remoteInputs[i];
                final String resultKey = remoteInput.getResultKey();
                final CharSequence label = remoteInput.getLabel();
                final CharSequence[] choices = remoteInput.getChoices();
                final boolean allowFreeFormInput = remoteInput.getAllowFreeFormInput();
                int editChoicesBeforeSending;
                if (Build$VERSION.SDK_INT >= 29) {
                    editChoicesBeforeSending = remoteInput.getEditChoicesBeforeSending();
                }
                else {
                    editChoicesBeforeSending = 0;
                }
                array2[i] = new RemoteInput(resultKey, label, choices, allowFreeFormInput, editChoicesBeforeSending, remoteInput.getExtras(), null);
            }
            array = array2;
        }
        boolean boolean1;
        if (Build$VERSION.SDK_INT >= 24) {
            boolean1 = (notification$Action.getExtras().getBoolean("android.support.allowGeneratedReplies") || notification$Action.getAllowGeneratedReplies());
        }
        else {
            boolean1 = notification$Action.getExtras().getBoolean("android.support.allowGeneratedReplies");
        }
        final boolean b = boolean1;
        final boolean boolean2 = notification$Action.getExtras().getBoolean("android.support.action.showsUserInterface", true);
        int n;
        if (Build$VERSION.SDK_INT >= 28) {
            n = notification$Action.getSemanticAction();
        }
        else {
            n = notification$Action.getExtras().getInt("android.support.action.semanticAction", 0);
        }
        final int n2 = n;
        final boolean b2 = Build$VERSION.SDK_INT >= 29 && notification$Action.isContextual();
        if (Build$VERSION.SDK_INT < 23) {
            return new Action(notification$Action.icon, notification$Action.title, notification$Action.actionIntent, notification$Action.getExtras(), array, null, b, n2, boolean2, b2);
        }
        if (notification$Action.getIcon() == null && notification$Action.icon != 0) {
            return new Action(notification$Action.icon, notification$Action.title, notification$Action.actionIntent, notification$Action.getExtras(), array, null, b, n2, boolean2, b2);
        }
        IconCompat fromIconOrNullIfZeroResId;
        if (notification$Action.getIcon() == null) {
            fromIconOrNullIfZeroResId = null;
        }
        else {
            fromIconOrNullIfZeroResId = IconCompat.createFromIconOrNullIfZeroResId(notification$Action.getIcon());
        }
        return new Action(fromIconOrNullIfZeroResId, notification$Action.title, notification$Action.actionIntent, notification$Action.getExtras(), array, null, b, n2, boolean2, b2);
    }
    
    public static int getActionCount(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 19) {
            final Notification$Action[] actions = notification.actions;
            int length = 0;
            if (actions != null) {
                length = notification.actions.length;
            }
            return length;
        }
        if (Build$VERSION.SDK_INT >= 16) {
            return NotificationCompatJellybean.getActionCount(notification);
        }
        return 0;
    }
    
    public static boolean getAllowSystemGeneratedContextualActions(final Notification notification) {
        return Build$VERSION.SDK_INT >= 29 && notification.getAllowSystemGeneratedContextualActions();
    }
    
    public static int getBadgeIconType(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 26) {
            return notification.getBadgeIconType();
        }
        return 0;
    }
    
    public static BubbleMetadata getBubbleMetadata(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 29) {
            return BubbleMetadata.fromPlatform(notification.getBubbleMetadata());
        }
        return null;
    }
    
    public static String getCategory(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 21) {
            return notification.category;
        }
        return null;
    }
    
    public static String getChannelId(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 26) {
            return notification.getChannelId();
        }
        return null;
    }
    
    public static CharSequence getContentTitle(final Notification notification) {
        return notification.extras.getCharSequence("android.title");
    }
    
    public static Bundle getExtras(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 19) {
            return notification.extras;
        }
        if (Build$VERSION.SDK_INT >= 16) {
            return NotificationCompatJellybean.getExtras(notification);
        }
        return null;
    }
    
    public static String getGroup(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 20) {
            return notification.getGroup();
        }
        if (Build$VERSION.SDK_INT >= 19) {
            return notification.extras.getString("android.support.groupKey");
        }
        if (Build$VERSION.SDK_INT >= 16) {
            return NotificationCompatJellybean.getExtras(notification).getString("android.support.groupKey");
        }
        return null;
    }
    
    public static int getGroupAlertBehavior(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 26) {
            return notification.getGroupAlertBehavior();
        }
        return 0;
    }
    
    public static List<Action> getInvisibleActions(final Notification notification) {
        final ArrayList<Action> list = new ArrayList<Action>();
        final Bundle bundle = notification.extras.getBundle("android.car.EXTENSIONS");
        if (bundle == null) {
            return list;
        }
        final Bundle bundle2 = bundle.getBundle("invisible_actions");
        if (bundle2 != null) {
            for (int i = 0; i < bundle2.size(); ++i) {
                list.add(NotificationCompatJellybean.getActionFromBundle(bundle2.getBundle(Integer.toString(i))));
            }
        }
        return list;
    }
    
    public static boolean getLocalOnly(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 20) {
            final int n = 0x100 & notification.flags;
            boolean b = false;
            if (n != 0) {
                b = true;
            }
            return b;
        }
        if (Build$VERSION.SDK_INT >= 19) {
            return notification.extras.getBoolean("android.support.localOnly");
        }
        return Build$VERSION.SDK_INT >= 16 && NotificationCompatJellybean.getExtras(notification).getBoolean("android.support.localOnly");
    }
    
    static Notification[] getNotificationArrayFromBundle(final Bundle bundle, final String s) {
        final Parcelable[] parcelableArray = bundle.getParcelableArray(s);
        if (!(parcelableArray instanceof Notification[]) && parcelableArray != null) {
            final Notification[] array = new Notification[parcelableArray.length];
            for (int i = 0; i < parcelableArray.length; ++i) {
                array[i] = (Notification)parcelableArray[i];
            }
            bundle.putParcelableArray(s, (Parcelable[])array);
            return array;
        }
        return (Notification[])parcelableArray;
    }
    
    public static String getShortcutId(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 26) {
            return notification.getShortcutId();
        }
        return null;
    }
    
    public static String getSortKey(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 20) {
            return notification.getSortKey();
        }
        if (Build$VERSION.SDK_INT >= 19) {
            return notification.extras.getString("android.support.sortKey");
        }
        if (Build$VERSION.SDK_INT >= 16) {
            return NotificationCompatJellybean.getExtras(notification).getString("android.support.sortKey");
        }
        return null;
    }
    
    public static long getTimeoutAfter(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 26) {
            return notification.getTimeoutAfter();
        }
        return 0L;
    }
    
    public static boolean isGroupSummary(final Notification notification) {
        if (Build$VERSION.SDK_INT >= 20) {
            final int n = 0x200 & notification.flags;
            boolean b = false;
            if (n != 0) {
                b = true;
            }
            return b;
        }
        if (Build$VERSION.SDK_INT >= 19) {
            return notification.extras.getBoolean("android.support.isGroupSummary");
        }
        return Build$VERSION.SDK_INT >= 16 && NotificationCompatJellybean.getExtras(notification).getBoolean("android.support.isGroupSummary");
    }
    
    public static class Action
    {
        static final String EXTRA_SEMANTIC_ACTION = "android.support.action.semanticAction";
        static final String EXTRA_SHOWS_USER_INTERFACE = "android.support.action.showsUserInterface";
        public static final int SEMANTIC_ACTION_ARCHIVE = 5;
        public static final int SEMANTIC_ACTION_CALL = 10;
        public static final int SEMANTIC_ACTION_DELETE = 4;
        public static final int SEMANTIC_ACTION_MARK_AS_READ = 2;
        public static final int SEMANTIC_ACTION_MARK_AS_UNREAD = 3;
        public static final int SEMANTIC_ACTION_MUTE = 6;
        public static final int SEMANTIC_ACTION_NONE = 0;
        public static final int SEMANTIC_ACTION_REPLY = 1;
        public static final int SEMANTIC_ACTION_THUMBS_DOWN = 9;
        public static final int SEMANTIC_ACTION_THUMBS_UP = 8;
        public static final int SEMANTIC_ACTION_UNMUTE = 7;
        public PendingIntent actionIntent;
        @Deprecated
        public int icon;
        private boolean mAllowGeneratedReplies;
        private final RemoteInput[] mDataOnlyRemoteInputs;
        final Bundle mExtras;
        private IconCompat mIcon;
        private final boolean mIsContextual;
        private final RemoteInput[] mRemoteInputs;
        private final int mSemanticAction;
        boolean mShowsUserInterface;
        public CharSequence title;
        
        public Action(final int n, final CharSequence charSequence, final PendingIntent pendingIntent) {
            IconCompat withResource;
            if (n == 0) {
                withResource = null;
            }
            else {
                withResource = IconCompat.createWithResource(null, "", n);
            }
            this(withResource, charSequence, pendingIntent);
        }
        
        Action(final int n, final CharSequence charSequence, final PendingIntent pendingIntent, final Bundle bundle, final RemoteInput[] array, final RemoteInput[] array2, final boolean b, final int n2, final boolean b2, final boolean b3) {
            IconCompat withResource;
            if (n == 0) {
                withResource = null;
            }
            else {
                withResource = IconCompat.createWithResource(null, "", n);
            }
            this(withResource, charSequence, pendingIntent, bundle, array, array2, b, n2, b2, b3);
        }
        
        public Action(final IconCompat iconCompat, final CharSequence charSequence, final PendingIntent pendingIntent) {
            this(iconCompat, charSequence, pendingIntent, new Bundle(), null, null, true, 0, true, false);
        }
        
        Action(final IconCompat mIcon, final CharSequence charSequence, final PendingIntent actionIntent, Bundle mExtras, final RemoteInput[] mRemoteInputs, final RemoteInput[] mDataOnlyRemoteInputs, final boolean mAllowGeneratedReplies, final int mSemanticAction, final boolean mShowsUserInterface, final boolean mIsContextual) {
            this.mShowsUserInterface = true;
            this.mIcon = mIcon;
            if (mIcon != null && mIcon.getType() == 2) {
                this.icon = mIcon.getResId();
            }
            this.title = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            this.actionIntent = actionIntent;
            if (mExtras == null) {
                mExtras = new Bundle();
            }
            this.mExtras = mExtras;
            this.mRemoteInputs = mRemoteInputs;
            this.mDataOnlyRemoteInputs = mDataOnlyRemoteInputs;
            this.mAllowGeneratedReplies = mAllowGeneratedReplies;
            this.mSemanticAction = mSemanticAction;
            this.mShowsUserInterface = mShowsUserInterface;
            this.mIsContextual = mIsContextual;
        }
        
        public PendingIntent getActionIntent() {
            return this.actionIntent;
        }
        
        public boolean getAllowGeneratedReplies() {
            return this.mAllowGeneratedReplies;
        }
        
        public RemoteInput[] getDataOnlyRemoteInputs() {
            return this.mDataOnlyRemoteInputs;
        }
        
        public Bundle getExtras() {
            return this.mExtras;
        }
        
        @Deprecated
        public int getIcon() {
            return this.icon;
        }
        
        public IconCompat getIconCompat() {
            if (this.mIcon == null) {
                final int icon = this.icon;
                if (icon != 0) {
                    this.mIcon = IconCompat.createWithResource(null, "", icon);
                }
            }
            return this.mIcon;
        }
        
        public RemoteInput[] getRemoteInputs() {
            return this.mRemoteInputs;
        }
        
        public int getSemanticAction() {
            return this.mSemanticAction;
        }
        
        public boolean getShowsUserInterface() {
            return this.mShowsUserInterface;
        }
        
        public CharSequence getTitle() {
            return this.title;
        }
        
        public boolean isContextual() {
            return this.mIsContextual;
        }
        
        public static final class Builder
        {
            private boolean mAllowGeneratedReplies;
            private final Bundle mExtras;
            private final IconCompat mIcon;
            private final PendingIntent mIntent;
            private boolean mIsContextual;
            private ArrayList<RemoteInput> mRemoteInputs;
            private int mSemanticAction;
            private boolean mShowsUserInterface;
            private final CharSequence mTitle;
            
            public Builder(final int n, final CharSequence charSequence, final PendingIntent pendingIntent) {
                IconCompat withResource;
                if (n == 0) {
                    withResource = null;
                }
                else {
                    withResource = IconCompat.createWithResource(null, "", n);
                }
                this(withResource, charSequence, pendingIntent, new Bundle(), null, true, 0, true, false);
            }
            
            public Builder(final Action action) {
                this(action.getIconCompat(), action.title, action.actionIntent, new Bundle(action.mExtras), action.getRemoteInputs(), action.getAllowGeneratedReplies(), action.getSemanticAction(), action.mShowsUserInterface, action.isContextual());
            }
            
            public Builder(final IconCompat iconCompat, final CharSequence charSequence, final PendingIntent pendingIntent) {
                this(iconCompat, charSequence, pendingIntent, new Bundle(), null, true, 0, true, false);
            }
            
            private Builder(final IconCompat mIcon, final CharSequence charSequence, final PendingIntent mIntent, final Bundle mExtras, final RemoteInput[] a, final boolean mAllowGeneratedReplies, final int mSemanticAction, final boolean mShowsUserInterface, final boolean mIsContextual) {
                this.mAllowGeneratedReplies = true;
                this.mShowsUserInterface = true;
                this.mIcon = mIcon;
                this.mTitle = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
                this.mIntent = mIntent;
                this.mExtras = mExtras;
                ArrayList<RemoteInput> mRemoteInputs;
                if (a == null) {
                    mRemoteInputs = null;
                }
                else {
                    mRemoteInputs = new ArrayList<RemoteInput>(Arrays.asList(a));
                }
                this.mRemoteInputs = mRemoteInputs;
                this.mAllowGeneratedReplies = mAllowGeneratedReplies;
                this.mSemanticAction = mSemanticAction;
                this.mShowsUserInterface = mShowsUserInterface;
                this.mIsContextual = mIsContextual;
            }
            
            private void checkContextualActionNullFields() {
                if (!this.mIsContextual) {
                    return;
                }
                if (this.mIntent != null) {
                    return;
                }
                throw new NullPointerException("Contextual Actions must contain a valid PendingIntent");
            }
            
            public Builder addExtras(final Bundle bundle) {
                if (bundle != null) {
                    this.mExtras.putAll(bundle);
                }
                return this;
            }
            
            public Builder addRemoteInput(final RemoteInput e) {
                if (this.mRemoteInputs == null) {
                    this.mRemoteInputs = new ArrayList<RemoteInput>();
                }
                this.mRemoteInputs.add(e);
                return this;
            }
            
            public Action build() {
                this.checkContextualActionNullFields();
                final ArrayList<RemoteInput> list = new ArrayList<RemoteInput>();
                final ArrayList<RemoteInput> list2 = new ArrayList<RemoteInput>();
                final ArrayList<RemoteInput> mRemoteInputs = this.mRemoteInputs;
                if (mRemoteInputs != null) {
                    for (final RemoteInput remoteInput : mRemoteInputs) {
                        if (remoteInput.isDataOnly()) {
                            list.add(remoteInput);
                        }
                        else {
                            list2.add(remoteInput);
                        }
                    }
                }
                RemoteInput[] array;
                if (list.isEmpty()) {
                    array = null;
                }
                else {
                    array = list.toArray(new RemoteInput[list.size()]);
                }
                RemoteInput[] array2;
                if (list2.isEmpty()) {
                    array2 = null;
                }
                else {
                    array2 = list2.toArray(new RemoteInput[list2.size()]);
                }
                return new Action(this.mIcon, this.mTitle, this.mIntent, this.mExtras, array2, array, this.mAllowGeneratedReplies, this.mSemanticAction, this.mShowsUserInterface, this.mIsContextual);
            }
            
            public Builder extend(final Extender extender) {
                extender.extend(this);
                return this;
            }
            
            public Bundle getExtras() {
                return this.mExtras;
            }
            
            public Builder setAllowGeneratedReplies(final boolean mAllowGeneratedReplies) {
                this.mAllowGeneratedReplies = mAllowGeneratedReplies;
                return this;
            }
            
            public Builder setContextual(final boolean mIsContextual) {
                this.mIsContextual = mIsContextual;
                return this;
            }
            
            public Builder setSemanticAction(final int mSemanticAction) {
                this.mSemanticAction = mSemanticAction;
                return this;
            }
            
            public Builder setShowsUserInterface(final boolean mShowsUserInterface) {
                this.mShowsUserInterface = mShowsUserInterface;
                return this;
            }
        }
        
        public interface Extender
        {
            Builder extend(final Builder p0);
        }
        
        @Retention(RetentionPolicy.SOURCE)
        public @interface SemanticAction {
        }
        
        public static final class WearableExtender implements Extender
        {
            private static final int DEFAULT_FLAGS = 1;
            private static final String EXTRA_WEARABLE_EXTENSIONS = "android.wearable.EXTENSIONS";
            private static final int FLAG_AVAILABLE_OFFLINE = 1;
            private static final int FLAG_HINT_DISPLAY_INLINE = 4;
            private static final int FLAG_HINT_LAUNCHES_ACTIVITY = 2;
            private static final String KEY_CANCEL_LABEL = "cancelLabel";
            private static final String KEY_CONFIRM_LABEL = "confirmLabel";
            private static final String KEY_FLAGS = "flags";
            private static final String KEY_IN_PROGRESS_LABEL = "inProgressLabel";
            private CharSequence mCancelLabel;
            private CharSequence mConfirmLabel;
            private int mFlags;
            private CharSequence mInProgressLabel;
            
            public WearableExtender() {
                this.mFlags = 1;
            }
            
            public WearableExtender(final Action action) {
                this.mFlags = 1;
                final Bundle bundle = action.getExtras().getBundle("android.wearable.EXTENSIONS");
                if (bundle != null) {
                    this.mFlags = bundle.getInt("flags", 1);
                    this.mInProgressLabel = bundle.getCharSequence("inProgressLabel");
                    this.mConfirmLabel = bundle.getCharSequence("confirmLabel");
                    this.mCancelLabel = bundle.getCharSequence("cancelLabel");
                }
            }
            
            private void setFlag(final int n, final boolean b) {
                if (b) {
                    this.mFlags |= n;
                }
                else {
                    this.mFlags &= ~n;
                }
            }
            
            public WearableExtender clone() {
                final WearableExtender wearableExtender = new WearableExtender();
                wearableExtender.mFlags = this.mFlags;
                wearableExtender.mInProgressLabel = this.mInProgressLabel;
                wearableExtender.mConfirmLabel = this.mConfirmLabel;
                wearableExtender.mCancelLabel = this.mCancelLabel;
                return wearableExtender;
            }
            
            @Override
            public Builder extend(final Builder builder) {
                final Bundle bundle = new Bundle();
                final int mFlags = this.mFlags;
                if (mFlags != 1) {
                    bundle.putInt("flags", mFlags);
                }
                final CharSequence mInProgressLabel = this.mInProgressLabel;
                if (mInProgressLabel != null) {
                    bundle.putCharSequence("inProgressLabel", mInProgressLabel);
                }
                final CharSequence mConfirmLabel = this.mConfirmLabel;
                if (mConfirmLabel != null) {
                    bundle.putCharSequence("confirmLabel", mConfirmLabel);
                }
                final CharSequence mCancelLabel = this.mCancelLabel;
                if (mCancelLabel != null) {
                    bundle.putCharSequence("cancelLabel", mCancelLabel);
                }
                builder.getExtras().putBundle("android.wearable.EXTENSIONS", bundle);
                return builder;
            }
            
            @Deprecated
            public CharSequence getCancelLabel() {
                return this.mCancelLabel;
            }
            
            @Deprecated
            public CharSequence getConfirmLabel() {
                return this.mConfirmLabel;
            }
            
            public boolean getHintDisplayActionInline() {
                return (0x4 & this.mFlags) != 0x0;
            }
            
            public boolean getHintLaunchesActivity() {
                return (0x2 & this.mFlags) != 0x0;
            }
            
            @Deprecated
            public CharSequence getInProgressLabel() {
                return this.mInProgressLabel;
            }
            
            public boolean isAvailableOffline() {
                final int mFlags = this.mFlags;
                int n = 1;
                if ((mFlags & n) == 0x0) {
                    n = 0;
                }
                return n != 0;
            }
            
            public WearableExtender setAvailableOffline(final boolean b) {
                this.setFlag(1, b);
                return this;
            }
            
            @Deprecated
            public WearableExtender setCancelLabel(final CharSequence mCancelLabel) {
                this.mCancelLabel = mCancelLabel;
                return this;
            }
            
            @Deprecated
            public WearableExtender setConfirmLabel(final CharSequence mConfirmLabel) {
                this.mConfirmLabel = mConfirmLabel;
                return this;
            }
            
            public WearableExtender setHintDisplayActionInline(final boolean b) {
                this.setFlag(4, b);
                return this;
            }
            
            public WearableExtender setHintLaunchesActivity(final boolean b) {
                this.setFlag(2, b);
                return this;
            }
            
            @Deprecated
            public WearableExtender setInProgressLabel(final CharSequence mInProgressLabel) {
                this.mInProgressLabel = mInProgressLabel;
                return this;
            }
        }
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface BadgeIconType {
    }
    
    public static class BigPictureStyle extends Style
    {
        private Bitmap mBigLargeIcon;
        private boolean mBigLargeIconSet;
        private Bitmap mPicture;
        
        public BigPictureStyle() {
        }
        
        public BigPictureStyle(final NotificationCompat.Builder builder) {
            ((Style)this).setBuilder(builder);
        }
        
        @Override
        public void apply(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            if (Build$VERSION.SDK_INT >= 16) {
                final Notification$BigPictureStyle bigPicture = new Notification$BigPictureStyle(notificationBuilderWithBuilderAccessor.getBuilder()).setBigContentTitle(this.mBigContentTitle).bigPicture(this.mPicture);
                if (this.mBigLargeIconSet) {
                    bigPicture.bigLargeIcon(this.mBigLargeIcon);
                }
                if (this.mSummaryTextSet) {
                    bigPicture.setSummaryText(this.mSummaryText);
                }
            }
        }
        
        public BigPictureStyle bigLargeIcon(final Bitmap mBigLargeIcon) {
            this.mBigLargeIcon = mBigLargeIcon;
            this.mBigLargeIconSet = true;
            return this;
        }
        
        public BigPictureStyle bigPicture(final Bitmap mPicture) {
            this.mPicture = mPicture;
            return this;
        }
        
        public BigPictureStyle setBigContentTitle(final CharSequence charSequence) {
            this.mBigContentTitle = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            return this;
        }
        
        public BigPictureStyle setSummaryText(final CharSequence charSequence) {
            this.mSummaryText = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            this.mSummaryTextSet = true;
            return this;
        }
    }
    
    public static class BigTextStyle extends Style
    {
        private CharSequence mBigText;
        
        public BigTextStyle() {
        }
        
        public BigTextStyle(final NotificationCompat.Builder builder) {
            ((Style)this).setBuilder(builder);
        }
        
        @Override
        public void apply(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            if (Build$VERSION.SDK_INT >= 16) {
                final Notification$BigTextStyle bigText = new Notification$BigTextStyle(notificationBuilderWithBuilderAccessor.getBuilder()).setBigContentTitle(this.mBigContentTitle).bigText(this.mBigText);
                if (this.mSummaryTextSet) {
                    bigText.setSummaryText(this.mSummaryText);
                }
            }
        }
        
        public BigTextStyle bigText(final CharSequence charSequence) {
            this.mBigText = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            return this;
        }
        
        public BigTextStyle setBigContentTitle(final CharSequence charSequence) {
            this.mBigContentTitle = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            return this;
        }
        
        public BigTextStyle setSummaryText(final CharSequence charSequence) {
            this.mSummaryText = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            this.mSummaryTextSet = true;
            return this;
        }
    }
    
    public static final class BubbleMetadata
    {
        private static final int FLAG_AUTO_EXPAND_BUBBLE = 1;
        private static final int FLAG_SUPPRESS_NOTIFICATION = 2;
        private PendingIntent mDeleteIntent;
        private int mDesiredHeight;
        private int mDesiredHeightResId;
        private int mFlags;
        private IconCompat mIcon;
        private PendingIntent mPendingIntent;
        
        private BubbleMetadata(final PendingIntent mPendingIntent, final PendingIntent mDeleteIntent, final IconCompat mIcon, final int mDesiredHeight, final int mDesiredHeightResId, final int mFlags) {
            this.mPendingIntent = mPendingIntent;
            this.mIcon = mIcon;
            this.mDesiredHeight = mDesiredHeight;
            this.mDesiredHeightResId = mDesiredHeightResId;
            this.mDeleteIntent = mDeleteIntent;
            this.mFlags = mFlags;
        }
        
        public static BubbleMetadata fromPlatform(final Notification$BubbleMetadata notification$BubbleMetadata) {
            if (notification$BubbleMetadata == null) {
                return null;
            }
            final Builder setSuppressNotification = new Builder().setAutoExpandBubble(notification$BubbleMetadata.getAutoExpandBubble()).setDeleteIntent(notification$BubbleMetadata.getDeleteIntent()).setIcon(IconCompat.createFromIcon(notification$BubbleMetadata.getIcon())).setIntent(notification$BubbleMetadata.getIntent()).setSuppressNotification(notification$BubbleMetadata.isNotificationSuppressed());
            if (notification$BubbleMetadata.getDesiredHeight() != 0) {
                setSuppressNotification.setDesiredHeight(notification$BubbleMetadata.getDesiredHeight());
            }
            if (notification$BubbleMetadata.getDesiredHeightResId() != 0) {
                setSuppressNotification.setDesiredHeightResId(notification$BubbleMetadata.getDesiredHeightResId());
            }
            return setSuppressNotification.build();
        }
        
        public static Notification$BubbleMetadata toPlatform(final BubbleMetadata bubbleMetadata) {
            if (bubbleMetadata == null) {
                return null;
            }
            final Notification$BubbleMetadata$Builder setSuppressNotification = new Notification$BubbleMetadata$Builder().setAutoExpandBubble(bubbleMetadata.getAutoExpandBubble()).setDeleteIntent(bubbleMetadata.getDeleteIntent()).setIcon(bubbleMetadata.getIcon().toIcon()).setIntent(bubbleMetadata.getIntent()).setSuppressNotification(bubbleMetadata.isNotificationSuppressed());
            if (bubbleMetadata.getDesiredHeight() != 0) {
                setSuppressNotification.setDesiredHeight(bubbleMetadata.getDesiredHeight());
            }
            if (bubbleMetadata.getDesiredHeightResId() != 0) {
                setSuppressNotification.setDesiredHeightResId(bubbleMetadata.getDesiredHeightResId());
            }
            return setSuppressNotification.build();
        }
        
        public boolean getAutoExpandBubble() {
            final int mFlags = this.mFlags;
            int n = 1;
            if ((mFlags & n) == 0x0) {
                n = 0;
            }
            return n != 0;
        }
        
        public PendingIntent getDeleteIntent() {
            return this.mDeleteIntent;
        }
        
        public int getDesiredHeight() {
            return this.mDesiredHeight;
        }
        
        public int getDesiredHeightResId() {
            return this.mDesiredHeightResId;
        }
        
        public IconCompat getIcon() {
            return this.mIcon;
        }
        
        public PendingIntent getIntent() {
            return this.mPendingIntent;
        }
        
        public boolean isNotificationSuppressed() {
            return (0x2 & this.mFlags) != 0x0;
        }
        
        public static final class Builder
        {
            private PendingIntent mDeleteIntent;
            private int mDesiredHeight;
            private int mDesiredHeightResId;
            private int mFlags;
            private IconCompat mIcon;
            private PendingIntent mPendingIntent;
            
            private Builder setFlag(final int n, final boolean b) {
                if (b) {
                    this.mFlags |= n;
                }
                else {
                    this.mFlags &= ~n;
                }
                return this;
            }
            
            public BubbleMetadata build() {
                final PendingIntent mPendingIntent = this.mPendingIntent;
                if (mPendingIntent == null) {
                    throw new IllegalStateException("Must supply pending intent to bubble");
                }
                final IconCompat mIcon = this.mIcon;
                if (mIcon != null) {
                    return new BubbleMetadata(mPendingIntent, this.mDeleteIntent, mIcon, this.mDesiredHeight, this.mDesiredHeightResId, this.mFlags);
                }
                throw new IllegalStateException("Must supply an icon for the bubble");
            }
            
            public Builder setAutoExpandBubble(final boolean b) {
                this.setFlag(1, b);
                return this;
            }
            
            public Builder setDeleteIntent(final PendingIntent mDeleteIntent) {
                this.mDeleteIntent = mDeleteIntent;
                return this;
            }
            
            public Builder setDesiredHeight(final int a) {
                this.mDesiredHeight = Math.max(a, 0);
                this.mDesiredHeightResId = 0;
                return this;
            }
            
            public Builder setDesiredHeightResId(final int mDesiredHeightResId) {
                this.mDesiredHeightResId = mDesiredHeightResId;
                this.mDesiredHeight = 0;
                return this;
            }
            
            public Builder setIcon(final IconCompat mIcon) {
                if (mIcon == null) {
                    throw new IllegalArgumentException("Bubbles require non-null icon");
                }
                if (mIcon.getType() != 1) {
                    this.mIcon = mIcon;
                    return this;
                }
                throw new IllegalArgumentException("When using bitmap based icons, Bubbles require TYPE_ADAPTIVE_BITMAP, please use IconCompat#createWithAdaptiveBitmap instead");
            }
            
            public Builder setIntent(final PendingIntent mPendingIntent) {
                if (mPendingIntent != null) {
                    this.mPendingIntent = mPendingIntent;
                    return this;
                }
                throw new IllegalArgumentException("Bubble requires non-null pending intent");
            }
            
            public Builder setSuppressNotification(final boolean b) {
                this.setFlag(2, b);
                return this;
            }
        }
    }
    
    public static class Builder
    {
        private static final int MAX_CHARSEQUENCE_LENGTH = 5120;
        public ArrayList<Action> mActions;
        boolean mAllowSystemGeneratedContextualActions;
        int mBadgeIcon;
        RemoteViews mBigContentView;
        BubbleMetadata mBubbleMetadata;
        String mCategory;
        String mChannelId;
        boolean mChronometerCountDown;
        int mColor;
        boolean mColorized;
        boolean mColorizedSet;
        CharSequence mContentInfo;
        PendingIntent mContentIntent;
        CharSequence mContentText;
        CharSequence mContentTitle;
        RemoteViews mContentView;
        public Context mContext;
        Bundle mExtras;
        PendingIntent mFullScreenIntent;
        int mGroupAlertBehavior;
        String mGroupKey;
        boolean mGroupSummary;
        RemoteViews mHeadsUpContentView;
        ArrayList<Action> mInvisibleActions;
        Bitmap mLargeIcon;
        boolean mLocalOnly;
        Notification mNotification;
        int mNumber;
        @Deprecated
        public ArrayList<String> mPeople;
        int mPriority;
        int mProgress;
        boolean mProgressIndeterminate;
        int mProgressMax;
        Notification mPublicVersion;
        CharSequence[] mRemoteInputHistory;
        String mShortcutId;
        boolean mShowWhen;
        boolean mSilent;
        String mSortKey;
        Style mStyle;
        CharSequence mSubText;
        RemoteViews mTickerView;
        long mTimeout;
        boolean mUseChronometer;
        int mVisibility;
        
        @Deprecated
        public Builder(final Context context) {
            this(context, null);
        }
        
        public Builder(final Context mContext, final String mChannelId) {
            this.mActions = new ArrayList<Action>();
            this.mInvisibleActions = new ArrayList<Action>();
            this.mShowWhen = true;
            this.mLocalOnly = false;
            this.mColor = 0;
            this.mVisibility = 0;
            this.mBadgeIcon = 0;
            this.mGroupAlertBehavior = 0;
            final Notification mNotification = new Notification();
            this.mNotification = mNotification;
            this.mContext = mContext;
            this.mChannelId = mChannelId;
            mNotification.when = System.currentTimeMillis();
            this.mNotification.audioStreamType = -1;
            this.mPriority = 0;
            this.mPeople = new ArrayList<String>();
            this.mAllowSystemGeneratedContextualActions = true;
        }
        
        protected static CharSequence limitCharSequenceLength(CharSequence subSequence) {
            if (subSequence == null) {
                return subSequence;
            }
            if (subSequence.length() > 5120) {
                subSequence = subSequence.subSequence(0, 5120);
            }
            return subSequence;
        }
        
        private Bitmap reduceLargeIconSize(Bitmap scaledBitmap) {
            if (scaledBitmap != null) {
                if (Build$VERSION.SDK_INT < 27) {
                    final Resources resources = this.mContext.getResources();
                    final int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_width);
                    final int dimensionPixelSize2 = resources.getDimensionPixelSize(R.dimen.compat_notification_large_icon_max_height);
                    if (scaledBitmap.getWidth() <= dimensionPixelSize && scaledBitmap.getHeight() <= dimensionPixelSize2) {
                        return scaledBitmap;
                    }
                    final double v = dimensionPixelSize;
                    final double v2 = Math.max(1, scaledBitmap.getWidth());
                    Double.isNaN(v);
                    Double.isNaN(v2);
                    final double a = v / v2;
                    final double v3 = dimensionPixelSize2;
                    final double v4 = Math.max(1, scaledBitmap.getHeight());
                    Double.isNaN(v3);
                    Double.isNaN(v4);
                    final double min = Math.min(a, v3 / v4);
                    final double v5 = scaledBitmap.getWidth();
                    Double.isNaN(v5);
                    final int n = (int)Math.ceil(v5 * min);
                    final double v6 = scaledBitmap.getHeight();
                    Double.isNaN(v6);
                    scaledBitmap = Bitmap.createScaledBitmap(scaledBitmap, n, (int)Math.ceil(v6 * min), true);
                }
            }
            return scaledBitmap;
        }
        
        private void setFlag(final int n, final boolean b) {
            if (b) {
                final Notification mNotification = this.mNotification;
                mNotification.flags |= n;
            }
            else {
                final Notification mNotification2 = this.mNotification;
                mNotification2.flags &= ~n;
            }
        }
        
        public Builder addAction(final int n, final CharSequence charSequence, final PendingIntent pendingIntent) {
            this.mActions.add(new Action(n, charSequence, pendingIntent));
            return this;
        }
        
        public Builder addAction(final Action e) {
            this.mActions.add(e);
            return this;
        }
        
        public Builder addExtras(final Bundle bundle) {
            if (bundle != null) {
                final Bundle mExtras = this.mExtras;
                if (mExtras == null) {
                    this.mExtras = new Bundle(bundle);
                }
                else {
                    mExtras.putAll(bundle);
                }
            }
            return this;
        }
        
        public Builder addInvisibleAction(final int n, final CharSequence charSequence, final PendingIntent pendingIntent) {
            return this.addInvisibleAction(new Action(n, charSequence, pendingIntent));
        }
        
        public Builder addInvisibleAction(final Action e) {
            this.mInvisibleActions.add(e);
            return this;
        }
        
        public Builder addPerson(final String e) {
            this.mPeople.add(e);
            return this;
        }
        
        public Notification build() {
            return new NotificationCompatBuilder(this).build();
        }
        
        public Builder extend(final NotificationCompat.Extender extender) {
            extender.extend(this);
            return this;
        }
        
        public RemoteViews getBigContentView() {
            return this.mBigContentView;
        }
        
        public BubbleMetadata getBubbleMetadata() {
            return this.mBubbleMetadata;
        }
        
        public int getColor() {
            return this.mColor;
        }
        
        public RemoteViews getContentView() {
            return this.mContentView;
        }
        
        public Bundle getExtras() {
            if (this.mExtras == null) {
                this.mExtras = new Bundle();
            }
            return this.mExtras;
        }
        
        public RemoteViews getHeadsUpContentView() {
            return this.mHeadsUpContentView;
        }
        
        @Deprecated
        public Notification getNotification() {
            return this.build();
        }
        
        public int getPriority() {
            return this.mPriority;
        }
        
        public long getWhenIfShowing() {
            long when;
            if (this.mShowWhen) {
                when = this.mNotification.when;
            }
            else {
                when = 0L;
            }
            return when;
        }
        
        public Builder setAllowSystemGeneratedContextualActions(final boolean mAllowSystemGeneratedContextualActions) {
            this.mAllowSystemGeneratedContextualActions = mAllowSystemGeneratedContextualActions;
            return this;
        }
        
        public Builder setAutoCancel(final boolean b) {
            this.setFlag(16, b);
            return this;
        }
        
        public Builder setBadgeIconType(final int mBadgeIcon) {
            this.mBadgeIcon = mBadgeIcon;
            return this;
        }
        
        public Builder setBubbleMetadata(final BubbleMetadata mBubbleMetadata) {
            this.mBubbleMetadata = mBubbleMetadata;
            return this;
        }
        
        public Builder setCategory(final String mCategory) {
            this.mCategory = mCategory;
            return this;
        }
        
        public Builder setChannelId(final String mChannelId) {
            this.mChannelId = mChannelId;
            return this;
        }
        
        public Builder setChronometerCountDown(final boolean mChronometerCountDown) {
            this.mChronometerCountDown = mChronometerCountDown;
            this.mExtras.putBoolean("android.chronometerCountDown", mChronometerCountDown);
            return this;
        }
        
        public Builder setColor(final int mColor) {
            this.mColor = mColor;
            return this;
        }
        
        public Builder setColorized(final boolean mColorized) {
            this.mColorized = mColorized;
            this.mColorizedSet = true;
            return this;
        }
        
        public Builder setContent(final RemoteViews contentView) {
            this.mNotification.contentView = contentView;
            return this;
        }
        
        public Builder setContentInfo(final CharSequence charSequence) {
            this.mContentInfo = limitCharSequenceLength(charSequence);
            return this;
        }
        
        public Builder setContentIntent(final PendingIntent mContentIntent) {
            this.mContentIntent = mContentIntent;
            return this;
        }
        
        public Builder setContentText(final CharSequence charSequence) {
            this.mContentText = limitCharSequenceLength(charSequence);
            return this;
        }
        
        public Builder setContentTitle(final CharSequence charSequence) {
            this.mContentTitle = limitCharSequenceLength(charSequence);
            return this;
        }
        
        public Builder setCustomBigContentView(final RemoteViews mBigContentView) {
            this.mBigContentView = mBigContentView;
            return this;
        }
        
        public Builder setCustomContentView(final RemoteViews mContentView) {
            this.mContentView = mContentView;
            return this;
        }
        
        public Builder setCustomHeadsUpContentView(final RemoteViews mHeadsUpContentView) {
            this.mHeadsUpContentView = mHeadsUpContentView;
            return this;
        }
        
        public Builder setDefaults(final int defaults) {
            this.mNotification.defaults = defaults;
            if ((defaults & 0x4) != 0x0) {
                final Notification mNotification = this.mNotification;
                mNotification.flags |= 0x1;
            }
            return this;
        }
        
        public Builder setDeleteIntent(final PendingIntent deleteIntent) {
            this.mNotification.deleteIntent = deleteIntent;
            return this;
        }
        
        public Builder setExtras(final Bundle mExtras) {
            this.mExtras = mExtras;
            return this;
        }
        
        public Builder setFullScreenIntent(final PendingIntent mFullScreenIntent, final boolean b) {
            this.mFullScreenIntent = mFullScreenIntent;
            this.setFlag(128, b);
            return this;
        }
        
        public Builder setGroup(final String mGroupKey) {
            this.mGroupKey = mGroupKey;
            return this;
        }
        
        public Builder setGroupAlertBehavior(final int mGroupAlertBehavior) {
            this.mGroupAlertBehavior = mGroupAlertBehavior;
            return this;
        }
        
        public Builder setGroupSummary(final boolean mGroupSummary) {
            this.mGroupSummary = mGroupSummary;
            return this;
        }
        
        public Builder setLargeIcon(final Bitmap bitmap) {
            this.mLargeIcon = this.reduceLargeIconSize(bitmap);
            return this;
        }
        
        public Builder setLights(final int ledARGB, final int ledOnMS, final int ledOffMS) {
            this.mNotification.ledARGB = ledARGB;
            this.mNotification.ledOnMS = ledOnMS;
            this.mNotification.ledOffMS = ledOffMS;
            final boolean b = this.mNotification.ledOnMS != 0 && this.mNotification.ledOffMS != 0;
            final Notification mNotification = this.mNotification;
            mNotification.flags = ((b ? 1 : 0) | (0xFFFFFFFE & mNotification.flags));
            return this;
        }
        
        public Builder setLocalOnly(final boolean mLocalOnly) {
            this.mLocalOnly = mLocalOnly;
            return this;
        }
        
        public Builder setNotificationSilent() {
            this.mSilent = true;
            return this;
        }
        
        public Builder setNumber(final int mNumber) {
            this.mNumber = mNumber;
            return this;
        }
        
        public Builder setOngoing(final boolean b) {
            this.setFlag(2, b);
            return this;
        }
        
        public Builder setOnlyAlertOnce(final boolean b) {
            this.setFlag(8, b);
            return this;
        }
        
        public Builder setPriority(final int mPriority) {
            this.mPriority = mPriority;
            return this;
        }
        
        public Builder setProgress(final int mProgressMax, final int mProgress, final boolean mProgressIndeterminate) {
            this.mProgressMax = mProgressMax;
            this.mProgress = mProgress;
            this.mProgressIndeterminate = mProgressIndeterminate;
            return this;
        }
        
        public Builder setPublicVersion(final Notification mPublicVersion) {
            this.mPublicVersion = mPublicVersion;
            return this;
        }
        
        public Builder setRemoteInputHistory(final CharSequence[] mRemoteInputHistory) {
            this.mRemoteInputHistory = mRemoteInputHistory;
            return this;
        }
        
        public Builder setShortcutId(final String mShortcutId) {
            this.mShortcutId = mShortcutId;
            return this;
        }
        
        public Builder setShowWhen(final boolean mShowWhen) {
            this.mShowWhen = mShowWhen;
            return this;
        }
        
        public Builder setSmallIcon(final int icon) {
            this.mNotification.icon = icon;
            return this;
        }
        
        public Builder setSmallIcon(final int icon, final int iconLevel) {
            this.mNotification.icon = icon;
            this.mNotification.iconLevel = iconLevel;
            return this;
        }
        
        public Builder setSortKey(final String mSortKey) {
            this.mSortKey = mSortKey;
            return this;
        }
        
        public Builder setSound(final Uri sound) {
            this.mNotification.sound = sound;
            this.mNotification.audioStreamType = -1;
            if (Build$VERSION.SDK_INT >= 21) {
                this.mNotification.audioAttributes = new AudioAttributes$Builder().setContentType(4).setUsage(5).build();
            }
            return this;
        }
        
        public Builder setSound(final Uri sound, final int n) {
            this.mNotification.sound = sound;
            this.mNotification.audioStreamType = n;
            if (Build$VERSION.SDK_INT >= 21) {
                this.mNotification.audioAttributes = new AudioAttributes$Builder().setContentType(4).setLegacyStreamType(n).build();
            }
            return this;
        }
        
        public Builder setStyle(final Style mStyle) {
            if (this.mStyle != mStyle && (this.mStyle = mStyle) != null) {
                mStyle.setBuilder(this);
            }
            return this;
        }
        
        public Builder setSubText(final CharSequence charSequence) {
            this.mSubText = limitCharSequenceLength(charSequence);
            return this;
        }
        
        public Builder setTicker(final CharSequence charSequence) {
            this.mNotification.tickerText = limitCharSequenceLength(charSequence);
            return this;
        }
        
        public Builder setTicker(final CharSequence charSequence, final RemoteViews mTickerView) {
            this.mNotification.tickerText = limitCharSequenceLength(charSequence);
            this.mTickerView = mTickerView;
            return this;
        }
        
        public Builder setTimeoutAfter(final long mTimeout) {
            this.mTimeout = mTimeout;
            return this;
        }
        
        public Builder setUsesChronometer(final boolean mUseChronometer) {
            this.mUseChronometer = mUseChronometer;
            return this;
        }
        
        public Builder setVibrate(final long[] vibrate) {
            this.mNotification.vibrate = vibrate;
            return this;
        }
        
        public Builder setVisibility(final int mVisibility) {
            this.mVisibility = mVisibility;
            return this;
        }
        
        public Builder setWhen(final long when) {
            this.mNotification.when = when;
            return this;
        }
    }
    
    public static final class CarExtender implements NotificationCompat.Extender
    {
        static final String EXTRA_CAR_EXTENDER = "android.car.EXTENSIONS";
        private static final String EXTRA_COLOR = "app_color";
        private static final String EXTRA_CONVERSATION = "car_conversation";
        static final String EXTRA_INVISIBLE_ACTIONS = "invisible_actions";
        private static final String EXTRA_LARGE_ICON = "large_icon";
        private static final String KEY_AUTHOR = "author";
        private static final String KEY_MESSAGES = "messages";
        private static final String KEY_ON_READ = "on_read";
        private static final String KEY_ON_REPLY = "on_reply";
        private static final String KEY_PARTICIPANTS = "participants";
        private static final String KEY_REMOTE_INPUT = "remote_input";
        private static final String KEY_TEXT = "text";
        private static final String KEY_TIMESTAMP = "timestamp";
        private int mColor;
        private Bitmap mLargeIcon;
        private UnreadConversation mUnreadConversation;
        
        public CarExtender() {
            this.mColor = 0;
        }
        
        public CarExtender(final Notification notification) {
            this.mColor = 0;
            if (Build$VERSION.SDK_INT < 21) {
                return;
            }
            Bundle bundle;
            if (NotificationCompat.getExtras(notification) == null) {
                bundle = null;
            }
            else {
                bundle = NotificationCompat.getExtras(notification).getBundle("android.car.EXTENSIONS");
            }
            if (bundle != null) {
                this.mLargeIcon = (Bitmap)bundle.getParcelable("large_icon");
                this.mColor = bundle.getInt("app_color", 0);
                this.mUnreadConversation = getUnreadConversationFromBundle(bundle.getBundle("car_conversation"));
            }
        }
        
        private static Bundle getBundleForUnreadConversation(final UnreadConversation unreadConversation) {
            final Bundle bundle = new Bundle();
            final String[] participants = unreadConversation.getParticipants();
            int i = 0;
            String s;
            if (participants != null && unreadConversation.getParticipants().length > 1) {
                s = unreadConversation.getParticipants()[0];
            }
            else {
                s = null;
            }
            final int length = unreadConversation.getMessages().length;
            final Parcelable[] array = new Parcelable[length];
            while (i < length) {
                final Bundle bundle2 = new Bundle();
                bundle2.putString("text", unreadConversation.getMessages()[i]);
                bundle2.putString("author", s);
                array[i] = (Parcelable)bundle2;
                ++i;
            }
            bundle.putParcelableArray("messages", array);
            final RemoteInput remoteInput = unreadConversation.getRemoteInput();
            if (remoteInput != null) {
                bundle.putParcelable("remote_input", (Parcelable)new RemoteInput$Builder(remoteInput.getResultKey()).setLabel(remoteInput.getLabel()).setChoices(remoteInput.getChoices()).setAllowFreeFormInput(remoteInput.getAllowFreeFormInput()).addExtras(remoteInput.getExtras()).build());
            }
            bundle.putParcelable("on_reply", (Parcelable)unreadConversation.getReplyPendingIntent());
            bundle.putParcelable("on_read", (Parcelable)unreadConversation.getReadPendingIntent());
            bundle.putStringArray("participants", unreadConversation.getParticipants());
            bundle.putLong("timestamp", unreadConversation.getLatestTimestamp());
            return bundle;
        }
        
        private static UnreadConversation getUnreadConversationFromBundle(final Bundle bundle) {
            if (bundle == null) {
                return null;
            }
            final Parcelable[] parcelableArray = bundle.getParcelableArray("messages");
            String[] array2 = null;
            Label_0106: {
                if (parcelableArray != null) {
                    final int length = parcelableArray.length;
                    final String[] array = new String[length];
                    int i = 0;
                    while (true) {
                        while (i < length) {
                            if (parcelableArray[i] instanceof Bundle) {
                                array[i] = ((Bundle)parcelableArray[i]).getString("text");
                                if (array[i] != null) {
                                    ++i;
                                    continue;
                                }
                            }
                            final boolean b = false;
                            if (b) {
                                array2 = array;
                                break Label_0106;
                            }
                            return null;
                        }
                        final boolean b = true;
                        continue;
                    }
                }
                array2 = null;
            }
            final PendingIntent pendingIntent = (PendingIntent)bundle.getParcelable("on_read");
            final PendingIntent pendingIntent2 = (PendingIntent)bundle.getParcelable("on_reply");
            final android.app.RemoteInput remoteInput = (android.app.RemoteInput)bundle.getParcelable("remote_input");
            final String[] stringArray = bundle.getStringArray("participants");
            UnreadConversation unreadConversation = null;
            if (stringArray != null) {
                if (stringArray.length != 1) {
                    unreadConversation = null;
                }
                else {
                    RemoteInput remoteInput2 = null;
                    if (remoteInput != null) {
                        final String resultKey = remoteInput.getResultKey();
                        final CharSequence label = remoteInput.getLabel();
                        final CharSequence[] choices = remoteInput.getChoices();
                        final boolean allowFreeFormInput = remoteInput.getAllowFreeFormInput();
                        int editChoicesBeforeSending;
                        if (Build$VERSION.SDK_INT >= 29) {
                            editChoicesBeforeSending = remoteInput.getEditChoicesBeforeSending();
                        }
                        else {
                            editChoicesBeforeSending = 0;
                        }
                        remoteInput2 = new RemoteInput(resultKey, label, choices, allowFreeFormInput, editChoicesBeforeSending, remoteInput.getExtras(), null);
                    }
                    unreadConversation = new UnreadConversation(array2, remoteInput2, pendingIntent2, pendingIntent, stringArray, bundle.getLong("timestamp"));
                }
            }
            return unreadConversation;
        }
        
        @Override
        public NotificationCompat.Builder extend(final NotificationCompat.Builder builder) {
            if (Build$VERSION.SDK_INT < 21) {
                return builder;
            }
            final Bundle bundle = new Bundle();
            final Bitmap mLargeIcon = this.mLargeIcon;
            if (mLargeIcon != null) {
                bundle.putParcelable("large_icon", (Parcelable)mLargeIcon);
            }
            final int mColor = this.mColor;
            if (mColor != 0) {
                bundle.putInt("app_color", mColor);
            }
            final UnreadConversation mUnreadConversation = this.mUnreadConversation;
            if (mUnreadConversation != null) {
                bundle.putBundle("car_conversation", getBundleForUnreadConversation(mUnreadConversation));
            }
            builder.getExtras().putBundle("android.car.EXTENSIONS", bundle);
            return builder;
        }
        
        public int getColor() {
            return this.mColor;
        }
        
        public Bitmap getLargeIcon() {
            return this.mLargeIcon;
        }
        
        @Deprecated
        public UnreadConversation getUnreadConversation() {
            return this.mUnreadConversation;
        }
        
        public CarExtender setColor(final int mColor) {
            this.mColor = mColor;
            return this;
        }
        
        public CarExtender setLargeIcon(final Bitmap mLargeIcon) {
            this.mLargeIcon = mLargeIcon;
            return this;
        }
        
        @Deprecated
        public CarExtender setUnreadConversation(final UnreadConversation mUnreadConversation) {
            this.mUnreadConversation = mUnreadConversation;
            return this;
        }
        
        @Deprecated
        public static class UnreadConversation
        {
            private final long mLatestTimestamp;
            private final String[] mMessages;
            private final String[] mParticipants;
            private final PendingIntent mReadPendingIntent;
            private final RemoteInput mRemoteInput;
            private final PendingIntent mReplyPendingIntent;
            
            UnreadConversation(final String[] mMessages, final RemoteInput mRemoteInput, final PendingIntent mReplyPendingIntent, final PendingIntent mReadPendingIntent, final String[] mParticipants, final long mLatestTimestamp) {
                this.mMessages = mMessages;
                this.mRemoteInput = mRemoteInput;
                this.mReadPendingIntent = mReadPendingIntent;
                this.mReplyPendingIntent = mReplyPendingIntent;
                this.mParticipants = mParticipants;
                this.mLatestTimestamp = mLatestTimestamp;
            }
            
            public long getLatestTimestamp() {
                return this.mLatestTimestamp;
            }
            
            public String[] getMessages() {
                return this.mMessages;
            }
            
            public String getParticipant() {
                final String[] mParticipants = this.mParticipants;
                String s;
                if (mParticipants.length > 0) {
                    s = mParticipants[0];
                }
                else {
                    s = null;
                }
                return s;
            }
            
            public String[] getParticipants() {
                return this.mParticipants;
            }
            
            public PendingIntent getReadPendingIntent() {
                return this.mReadPendingIntent;
            }
            
            public RemoteInput getRemoteInput() {
                return this.mRemoteInput;
            }
            
            public PendingIntent getReplyPendingIntent() {
                return this.mReplyPendingIntent;
            }
            
            public static class Builder
            {
                private long mLatestTimestamp;
                private final List<String> mMessages;
                private final String mParticipant;
                private PendingIntent mReadPendingIntent;
                private RemoteInput mRemoteInput;
                private PendingIntent mReplyPendingIntent;
                
                public Builder(final String mParticipant) {
                    this.mMessages = new ArrayList<String>();
                    this.mParticipant = mParticipant;
                }
                
                public Builder addMessage(final String s) {
                    this.mMessages.add(s);
                    return this;
                }
                
                public UnreadConversation build() {
                    final List<String> mMessages = this.mMessages;
                    return new UnreadConversation(mMessages.toArray(new String[mMessages.size()]), this.mRemoteInput, this.mReplyPendingIntent, this.mReadPendingIntent, new String[] { this.mParticipant }, this.mLatestTimestamp);
                }
                
                public Builder setLatestTimestamp(final long mLatestTimestamp) {
                    this.mLatestTimestamp = mLatestTimestamp;
                    return this;
                }
                
                public Builder setReadPendingIntent(final PendingIntent mReadPendingIntent) {
                    this.mReadPendingIntent = mReadPendingIntent;
                    return this;
                }
                
                public Builder setReplyAction(final PendingIntent mReplyPendingIntent, final RemoteInput mRemoteInput) {
                    this.mRemoteInput = mRemoteInput;
                    this.mReplyPendingIntent = mReplyPendingIntent;
                    return this;
                }
            }
        }
    }
    
    public static class DecoratedCustomViewStyle extends Style
    {
        private static final int MAX_ACTION_BUTTONS = 3;
        
        private RemoteViews createRemoteViews(final RemoteViews remoteViews, final boolean b) {
            final int notification_template_custom_big = R.layout.notification_template_custom_big;
            boolean b2 = true;
            final RemoteViews applyStandardTemplate = ((Style)this).applyStandardTemplate(b2, notification_template_custom_big, false);
            applyStandardTemplate.removeAllViews(R.id.actions);
            final List<Action> nonContextualActions = getNonContextualActions(this.mBuilder.mActions);
            Label_0111: {
                if (b && nonContextualActions != null) {
                    final int min = Math.min(nonContextualActions.size(), 3);
                    if (min > 0) {
                        for (int i = 0; i < min; ++i) {
                            applyStandardTemplate.addView(R.id.actions, this.generateActionButton(nonContextualActions.get(i)));
                        }
                        break Label_0111;
                    }
                }
                b2 = false;
            }
            int n;
            if (b2) {
                n = 0;
            }
            else {
                n = 8;
            }
            applyStandardTemplate.setViewVisibility(R.id.actions, n);
            applyStandardTemplate.setViewVisibility(R.id.action_divider, n);
            ((Style)this).buildIntoRemoteViews(applyStandardTemplate, remoteViews);
            return applyStandardTemplate;
        }
        
        private RemoteViews generateActionButton(final Action action) {
            final boolean b = action.actionIntent == null;
            final String packageName = this.mBuilder.mContext.getPackageName();
            int n;
            if (b) {
                n = R.layout.notification_action_tombstone;
            }
            else {
                n = R.layout.notification_action;
            }
            final RemoteViews remoteViews = new RemoteViews(packageName, n);
            remoteViews.setImageViewBitmap(R.id.action_image, ((Style)this).createColoredBitmap(action.getIconCompat(), this.mBuilder.mContext.getResources().getColor(R.color.notification_action_color_filter)));
            remoteViews.setTextViewText(R.id.action_text, action.title);
            if (!b) {
                remoteViews.setOnClickPendingIntent(R.id.action_container, action.actionIntent);
            }
            if (Build$VERSION.SDK_INT >= 15) {
                remoteViews.setContentDescription(R.id.action_container, action.title);
            }
            return remoteViews;
        }
        
        private static List<Action> getNonContextualActions(final List<Action> list) {
            if (list == null) {
                return null;
            }
            final ArrayList<Action> list2 = new ArrayList<Action>();
            for (final Action action : list) {
                if (!action.isContextual()) {
                    list2.add(action);
                }
            }
            return list2;
        }
        
        @Override
        public void apply(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            if (Build$VERSION.SDK_INT >= 24) {
                notificationBuilderWithBuilderAccessor.getBuilder().setStyle((Notification$Style)new Notification$DecoratedCustomViewStyle());
            }
        }
        
        @Override
        public RemoteViews makeBigContentView(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            if (Build$VERSION.SDK_INT >= 24) {
                return null;
            }
            RemoteViews remoteViews = this.mBuilder.getBigContentView();
            if (remoteViews == null) {
                remoteViews = this.mBuilder.getContentView();
            }
            if (remoteViews == null) {
                return null;
            }
            return this.createRemoteViews(remoteViews, true);
        }
        
        @Override
        public RemoteViews makeContentView(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            if (Build$VERSION.SDK_INT >= 24) {
                return null;
            }
            if (this.mBuilder.getContentView() == null) {
                return null;
            }
            return this.createRemoteViews(this.mBuilder.getContentView(), false);
        }
        
        @Override
        public RemoteViews makeHeadsUpContentView(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            if (Build$VERSION.SDK_INT >= 24) {
                return null;
            }
            final RemoteViews headsUpContentView = this.mBuilder.getHeadsUpContentView();
            RemoteViews contentView;
            if (headsUpContentView != null) {
                contentView = headsUpContentView;
            }
            else {
                contentView = this.mBuilder.getContentView();
            }
            if (headsUpContentView == null) {
                return null;
            }
            return this.createRemoteViews(contentView, true);
        }
    }
    
    public interface Extender
    {
        NotificationCompat.Builder extend(final NotificationCompat.Builder p0);
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface GroupAlertBehavior {
    }
    
    public static class InboxStyle extends Style
    {
        private ArrayList<CharSequence> mTexts;
        
        public InboxStyle() {
            this.mTexts = new ArrayList<CharSequence>();
        }
        
        public InboxStyle(final NotificationCompat.Builder builder) {
            this.mTexts = new ArrayList<CharSequence>();
            ((Style)this).setBuilder(builder);
        }
        
        public InboxStyle addLine(final CharSequence charSequence) {
            this.mTexts.add(NotificationCompat.Builder.limitCharSequenceLength(charSequence));
            return this;
        }
        
        @Override
        public void apply(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            if (Build$VERSION.SDK_INT >= 16) {
                final Notification$InboxStyle setBigContentTitle = new Notification$InboxStyle(notificationBuilderWithBuilderAccessor.getBuilder()).setBigContentTitle(this.mBigContentTitle);
                if (this.mSummaryTextSet) {
                    setBigContentTitle.setSummaryText(this.mSummaryText);
                }
                final Iterator<CharSequence> iterator = this.mTexts.iterator();
                while (iterator.hasNext()) {
                    setBigContentTitle.addLine((CharSequence)iterator.next());
                }
            }
        }
        
        public InboxStyle setBigContentTitle(final CharSequence charSequence) {
            this.mBigContentTitle = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            return this;
        }
        
        public InboxStyle setSummaryText(final CharSequence charSequence) {
            this.mSummaryText = NotificationCompat.Builder.limitCharSequenceLength(charSequence);
            this.mSummaryTextSet = true;
            return this;
        }
    }
    
    public static class MessagingStyle extends Style
    {
        public static final int MAXIMUM_RETAINED_MESSAGES = 25;
        private CharSequence mConversationTitle;
        private Boolean mIsGroupConversation;
        private final List<Message> mMessages;
        private Person mUser;
        
        private MessagingStyle() {
            this.mMessages = new ArrayList<Message>();
        }
        
        public MessagingStyle(final Person mUser) {
            this.mMessages = new ArrayList<Message>();
            if (!TextUtils.isEmpty(mUser.getName())) {
                this.mUser = mUser;
                return;
            }
            throw new IllegalArgumentException("User's name must not be empty.");
        }
        
        @Deprecated
        public MessagingStyle(final CharSequence name) {
            this.mMessages = new ArrayList<Message>();
            this.mUser = new Person.Builder().setName(name).build();
        }
        
        public static MessagingStyle extractMessagingStyleFromNotification(final Notification notification) {
            final Bundle extras = NotificationCompat.getExtras(notification);
            if (extras != null && !extras.containsKey("android.selfDisplayName") && !extras.containsKey("android.messagingStyleUser")) {
                return null;
            }
            try {
                final MessagingStyle messagingStyle = new MessagingStyle();
                messagingStyle.restoreFromCompatExtras(extras);
                return messagingStyle;
            }
            catch (ClassCastException ex) {
                return null;
            }
        }
        
        private Message findLatestIncomingMessage() {
            for (int i = -1 + this.mMessages.size(); i >= 0; --i) {
                final Message message = this.mMessages.get(i);
                if (message.getPerson() != null && !TextUtils.isEmpty(message.getPerson().getName())) {
                    return message;
                }
            }
            if (!this.mMessages.isEmpty()) {
                final List<Message> mMessages = this.mMessages;
                return mMessages.get(-1 + mMessages.size());
            }
            return null;
        }
        
        private boolean hasMessagesWithoutSender() {
            for (int i = this.mMessages.size() - 1; i >= 0; --i) {
                final Message message = this.mMessages.get(i);
                if (message.getPerson() != null && message.getPerson().getName() == null) {
                    return true;
                }
            }
            return false;
        }
        
        private TextAppearanceSpan makeFontColorSpan(final int n) {
            return new TextAppearanceSpan((String)null, 0, 0, ColorStateList.valueOf(n), (ColorStateList)null);
        }
        
        private CharSequence makeMessageLine(final Message message) {
            final BidiFormatter instance = BidiFormatter.getInstance();
            final SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
            final boolean b = Build$VERSION.SDK_INT >= 21;
            int color;
            if (b) {
                color = -16777216;
            }
            else {
                color = -1;
            }
            final Person person = message.getPerson();
            CharSequence text = "";
            CharSequence charSequence;
            if (person == null) {
                charSequence = text;
            }
            else {
                charSequence = message.getPerson().getName();
            }
            if (TextUtils.isEmpty(charSequence)) {
                charSequence = this.mUser.getName();
                if (b && this.mBuilder.getColor() != 0) {
                    color = this.mBuilder.getColor();
                }
            }
            final CharSequence unicodeWrap = instance.unicodeWrap(charSequence);
            spannableStringBuilder.append(unicodeWrap);
            spannableStringBuilder.setSpan((Object)this.makeFontColorSpan(color), spannableStringBuilder.length() - unicodeWrap.length(), spannableStringBuilder.length(), 33);
            if (message.getText() != null) {
                text = message.getText();
            }
            spannableStringBuilder.append((CharSequence)"  ").append(instance.unicodeWrap(text));
            return (CharSequence)spannableStringBuilder;
        }
        
        @Override
        public void addCompatExtras(final Bundle bundle) {
            super.addCompatExtras(bundle);
            bundle.putCharSequence("android.selfDisplayName", this.mUser.getName());
            bundle.putBundle("android.messagingStyleUser", this.mUser.toBundle());
            bundle.putCharSequence("android.hiddenConversationTitle", this.mConversationTitle);
            if (this.mConversationTitle != null && this.mIsGroupConversation) {
                bundle.putCharSequence("android.conversationTitle", this.mConversationTitle);
            }
            if (!this.mMessages.isEmpty()) {
                bundle.putParcelableArray("android.messages", (Parcelable[])Message.getBundleArrayForMessages(this.mMessages));
            }
            final Boolean mIsGroupConversation = this.mIsGroupConversation;
            if (mIsGroupConversation != null) {
                bundle.putBoolean("android.isGroupConversation", (boolean)mIsGroupConversation);
            }
        }
        
        public MessagingStyle addMessage(final Message message) {
            this.mMessages.add(message);
            if (this.mMessages.size() > 25) {
                this.mMessages.remove(0);
            }
            return this;
        }
        
        public MessagingStyle addMessage(final CharSequence charSequence, final long n, final Person person) {
            this.addMessage(new Message(charSequence, n, person));
            return this;
        }
        
        @Deprecated
        public MessagingStyle addMessage(final CharSequence charSequence, final long n, final CharSequence name) {
            this.mMessages.add(new Message(charSequence, n, new Person.Builder().setName(name).build()));
            if (this.mMessages.size() > 25) {
                this.mMessages.remove(0);
            }
            return this;
        }
        
        @Override
        public void apply(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            this.setGroupConversation(this.isGroupConversation());
            if (Build$VERSION.SDK_INT >= 24) {
                Notification$MessagingStyle notification$MessagingStyle;
                if (Build$VERSION.SDK_INT >= 28) {
                    notification$MessagingStyle = new Notification$MessagingStyle(this.mUser.toAndroidPerson());
                }
                else {
                    notification$MessagingStyle = new Notification$MessagingStyle(this.mUser.getName());
                }
                if (this.mIsGroupConversation || Build$VERSION.SDK_INT >= 28) {
                    notification$MessagingStyle.setConversationTitle(this.mConversationTitle);
                }
                if (Build$VERSION.SDK_INT >= 28) {
                    notification$MessagingStyle.setGroupConversation((boolean)this.mIsGroupConversation);
                }
                for (final Message message : this.mMessages) {
                    Notification$MessagingStyle$Message notification$MessagingStyle$Message;
                    if (Build$VERSION.SDK_INT >= 28) {
                        final Person person = message.getPerson();
                        final CharSequence text = message.getText();
                        final long timestamp = message.getTimestamp();
                        android.app.Person androidPerson;
                        if (person == null) {
                            androidPerson = null;
                        }
                        else {
                            androidPerson = person.toAndroidPerson();
                        }
                        notification$MessagingStyle$Message = new Notification$MessagingStyle$Message(text, timestamp, androidPerson);
                    }
                    else {
                        CharSequence name;
                        if (message.getPerson() != null) {
                            name = message.getPerson().getName();
                        }
                        else {
                            name = null;
                        }
                        notification$MessagingStyle$Message = new Notification$MessagingStyle$Message(message.getText(), message.getTimestamp(), name);
                    }
                    if (message.getDataMimeType() != null) {
                        notification$MessagingStyle$Message.setData(message.getDataMimeType(), message.getDataUri());
                    }
                    notification$MessagingStyle.addMessage(notification$MessagingStyle$Message);
                }
                notification$MessagingStyle.setBuilder(notificationBuilderWithBuilderAccessor.getBuilder());
            }
            else {
                final Message latestIncomingMessage = this.findLatestIncomingMessage();
                if (this.mConversationTitle != null && this.mIsGroupConversation) {
                    notificationBuilderWithBuilderAccessor.getBuilder().setContentTitle(this.mConversationTitle);
                }
                else if (latestIncomingMessage != null) {
                    notificationBuilderWithBuilderAccessor.getBuilder().setContentTitle((CharSequence)"");
                    if (latestIncomingMessage.getPerson() != null) {
                        notificationBuilderWithBuilderAccessor.getBuilder().setContentTitle(latestIncomingMessage.getPerson().getName());
                    }
                }
                if (latestIncomingMessage != null) {
                    final Notification$Builder builder = notificationBuilderWithBuilderAccessor.getBuilder();
                    CharSequence contentText;
                    if (this.mConversationTitle != null) {
                        contentText = this.makeMessageLine(latestIncomingMessage);
                    }
                    else {
                        contentText = latestIncomingMessage.getText();
                    }
                    builder.setContentText(contentText);
                }
                if (Build$VERSION.SDK_INT >= 16) {
                    final SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
                    final boolean b = this.mConversationTitle != null || this.hasMessagesWithoutSender();
                    for (int i = this.mMessages.size() - 1; i >= 0; --i) {
                        final Message message2 = this.mMessages.get(i);
                        CharSequence charSequence;
                        if (b) {
                            charSequence = this.makeMessageLine(message2);
                        }
                        else {
                            charSequence = message2.getText();
                        }
                        if (i != this.mMessages.size() - 1) {
                            spannableStringBuilder.insert(0, (CharSequence)"\n");
                        }
                        spannableStringBuilder.insert(0, charSequence);
                    }
                    new Notification$BigTextStyle(notificationBuilderWithBuilderAccessor.getBuilder()).setBigContentTitle((CharSequence)null).bigText((CharSequence)spannableStringBuilder);
                }
            }
        }
        
        public CharSequence getConversationTitle() {
            return this.mConversationTitle;
        }
        
        public List<Message> getMessages() {
            return this.mMessages;
        }
        
        public Person getUser() {
            return this.mUser;
        }
        
        @Deprecated
        public CharSequence getUserDisplayName() {
            return this.mUser.getName();
        }
        
        public boolean isGroupConversation() {
            if (this.mBuilder != null && this.mBuilder.mContext.getApplicationInfo().targetSdkVersion < 28 && this.mIsGroupConversation == null) {
                final CharSequence mConversationTitle = this.mConversationTitle;
                boolean b = false;
                if (mConversationTitle != null) {
                    b = true;
                }
                return b;
            }
            final Boolean mIsGroupConversation = this.mIsGroupConversation;
            boolean booleanValue = false;
            if (mIsGroupConversation != null) {
                booleanValue = mIsGroupConversation;
            }
            return booleanValue;
        }
        
        @Override
        protected void restoreFromCompatExtras(final Bundle bundle) {
            this.mMessages.clear();
            if (bundle.containsKey("android.messagingStyleUser")) {
                this.mUser = Person.fromBundle(bundle.getBundle("android.messagingStyleUser"));
            }
            else {
                this.mUser = new Person.Builder().setName(bundle.getString("android.selfDisplayName")).build();
            }
            final CharSequence charSequence = bundle.getCharSequence("android.conversationTitle");
            this.mConversationTitle = charSequence;
            if (charSequence == null) {
                this.mConversationTitle = bundle.getCharSequence("android.hiddenConversationTitle");
            }
            final Parcelable[] parcelableArray = bundle.getParcelableArray("android.messages");
            if (parcelableArray != null) {
                this.mMessages.addAll(Message.getMessagesFromBundleArray(parcelableArray));
            }
            if (bundle.containsKey("android.isGroupConversation")) {
                this.mIsGroupConversation = bundle.getBoolean("android.isGroupConversation");
            }
        }
        
        public MessagingStyle setConversationTitle(final CharSequence mConversationTitle) {
            this.mConversationTitle = mConversationTitle;
            return this;
        }
        
        public MessagingStyle setGroupConversation(final boolean b) {
            this.mIsGroupConversation = b;
            return this;
        }
        
        public static final class Message
        {
            static final String KEY_DATA_MIME_TYPE = "type";
            static final String KEY_DATA_URI = "uri";
            static final String KEY_EXTRAS_BUNDLE = "extras";
            static final String KEY_NOTIFICATION_PERSON = "sender_person";
            static final String KEY_PERSON = "person";
            static final String KEY_SENDER = "sender";
            static final String KEY_TEXT = "text";
            static final String KEY_TIMESTAMP = "time";
            private String mDataMimeType;
            private Uri mDataUri;
            private Bundle mExtras;
            private final Person mPerson;
            private final CharSequence mText;
            private final long mTimestamp;
            
            public Message(final CharSequence mText, final long mTimestamp, final Person mPerson) {
                this.mExtras = new Bundle();
                this.mText = mText;
                this.mTimestamp = mTimestamp;
                this.mPerson = mPerson;
            }
            
            @Deprecated
            public Message(final CharSequence charSequence, final long n, final CharSequence name) {
                this(charSequence, n, new Person.Builder().setName(name).build());
            }
            
            static Bundle[] getBundleArrayForMessages(final List<Message> list) {
                final Bundle[] array = new Bundle[list.size()];
                for (int size = list.size(), i = 0; i < size; ++i) {
                    array[i] = list.get(i).toBundle();
                }
                return array;
            }
            
            static Message getMessageFromBundle(final Bundle bundle) {
                while (true) {
                    while (true) {
                        Label_0193: {
                            try {
                                if (!bundle.containsKey("text")) {
                                    return null;
                                }
                                if (!bundle.containsKey("time")) {
                                    return null;
                                }
                                Person person;
                                if (bundle.containsKey("person")) {
                                    person = Person.fromBundle(bundle.getBundle("person"));
                                }
                                else if (bundle.containsKey("sender_person") && Build$VERSION.SDK_INT >= 28) {
                                    person = Person.fromAndroidPerson((android.app.Person)bundle.getParcelable("sender_person"));
                                }
                                else {
                                    if (!bundle.containsKey("sender")) {
                                        break Label_0193;
                                    }
                                    person = new Person.Builder().setName(bundle.getCharSequence("sender")).build();
                                }
                                final Message message = new Message(bundle.getCharSequence("text"), bundle.getLong("time"), person);
                                if (bundle.containsKey("type") && bundle.containsKey("uri")) {
                                    message.setData(bundle.getString("type"), (Uri)bundle.getParcelable("uri"));
                                }
                                if (bundle.containsKey("extras")) {
                                    message.getExtras().putAll(bundle.getBundle("extras"));
                                }
                                return message;
                            }
                            catch (ClassCastException ex) {
                                return null;
                            }
                        }
                        Person person = null;
                        continue;
                    }
                }
            }
            
            static List<Message> getMessagesFromBundleArray(final Parcelable[] array) {
                final ArrayList<Message> list = new ArrayList<Message>(array.length);
                for (int i = 0; i < array.length; ++i) {
                    if (array[i] instanceof Bundle) {
                        final Message messageFromBundle = getMessageFromBundle((Bundle)array[i]);
                        if (messageFromBundle != null) {
                            list.add(messageFromBundle);
                        }
                    }
                }
                return list;
            }
            
            private Bundle toBundle() {
                final Bundle bundle = new Bundle();
                final CharSequence mText = this.mText;
                if (mText != null) {
                    bundle.putCharSequence("text", mText);
                }
                bundle.putLong("time", this.mTimestamp);
                final Person mPerson = this.mPerson;
                if (mPerson != null) {
                    bundle.putCharSequence("sender", mPerson.getName());
                    if (Build$VERSION.SDK_INT >= 28) {
                        bundle.putParcelable("sender_person", (Parcelable)this.mPerson.toAndroidPerson());
                    }
                    else {
                        bundle.putBundle("person", this.mPerson.toBundle());
                    }
                }
                final String mDataMimeType = this.mDataMimeType;
                if (mDataMimeType != null) {
                    bundle.putString("type", mDataMimeType);
                }
                final Uri mDataUri = this.mDataUri;
                if (mDataUri != null) {
                    bundle.putParcelable("uri", (Parcelable)mDataUri);
                }
                final Bundle mExtras = this.mExtras;
                if (mExtras != null) {
                    bundle.putBundle("extras", mExtras);
                }
                return bundle;
            }
            
            public String getDataMimeType() {
                return this.mDataMimeType;
            }
            
            public Uri getDataUri() {
                return this.mDataUri;
            }
            
            public Bundle getExtras() {
                return this.mExtras;
            }
            
            public Person getPerson() {
                return this.mPerson;
            }
            
            @Deprecated
            public CharSequence getSender() {
                final Person mPerson = this.mPerson;
                CharSequence name;
                if (mPerson == null) {
                    name = null;
                }
                else {
                    name = mPerson.getName();
                }
                return name;
            }
            
            public CharSequence getText() {
                return this.mText;
            }
            
            public long getTimestamp() {
                return this.mTimestamp;
            }
            
            public Message setData(final String mDataMimeType, final Uri mDataUri) {
                this.mDataMimeType = mDataMimeType;
                this.mDataUri = mDataUri;
                return this;
            }
        }
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface NotificationVisibility {
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface StreamType {
    }
    
    public abstract static class Style
    {
        CharSequence mBigContentTitle;
        protected NotificationCompat.Builder mBuilder;
        CharSequence mSummaryText;
        boolean mSummaryTextSet;
        
        public Style() {
            this.mSummaryTextSet = false;
        }
        
        private int calculateTopPadding() {
            final Resources resources = this.mBuilder.mContext.getResources();
            final int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.notification_top_pad);
            final int dimensionPixelSize2 = resources.getDimensionPixelSize(R.dimen.notification_top_pad_large_text);
            final float n = (constrain(resources.getConfiguration().fontScale, 1.0f, 1.3f) - 1.0f) / 0.29999995f;
            return Math.round((1.0f - n) * dimensionPixelSize + n * dimensionPixelSize2);
        }
        
        private static float constrain(float n, final float n2, final float n3) {
            if (n < n2) {
                n = n2;
            }
            else if (n > n3) {
                n = n3;
            }
            return n;
        }
        
        private Bitmap createColoredBitmap(final int n, final int n2, final int n3) {
            return this.createColoredBitmap(IconCompat.createWithResource(this.mBuilder.mContext, n), n2, n3);
        }
        
        private Bitmap createColoredBitmap(final IconCompat iconCompat, final int n, int intrinsicHeight) {
            final Drawable loadDrawable = iconCompat.loadDrawable(this.mBuilder.mContext);
            int intrinsicWidth;
            if (intrinsicHeight == 0) {
                intrinsicWidth = loadDrawable.getIntrinsicWidth();
            }
            else {
                intrinsicWidth = intrinsicHeight;
            }
            if (intrinsicHeight == 0) {
                intrinsicHeight = loadDrawable.getIntrinsicHeight();
            }
            final Bitmap bitmap = Bitmap.createBitmap(intrinsicWidth, intrinsicHeight, Bitmap$Config.ARGB_8888);
            loadDrawable.setBounds(0, 0, intrinsicWidth, intrinsicHeight);
            if (n != 0) {
                loadDrawable.mutate().setColorFilter((ColorFilter)new PorterDuffColorFilter(n, PorterDuff$Mode.SRC_IN));
            }
            loadDrawable.draw(new Canvas(bitmap));
            return bitmap;
        }
        
        private Bitmap createIconWithBackground(final int n, final int n2, final int n3, int n4) {
            final int notification_icon_background = R.drawable.notification_icon_background;
            if (n4 == 0) {
                n4 = 0;
            }
            final Bitmap coloredBitmap = this.createColoredBitmap(notification_icon_background, n4, n2);
            final Canvas canvas = new Canvas(coloredBitmap);
            final Drawable mutate = this.mBuilder.mContext.getResources().getDrawable(n).mutate();
            mutate.setFilterBitmap(true);
            final int n5 = (n2 - n3) / 2;
            final int n6 = n3 + n5;
            mutate.setBounds(n5, n5, n6, n6);
            mutate.setColorFilter((ColorFilter)new PorterDuffColorFilter(-1, PorterDuff$Mode.SRC_ATOP));
            mutate.draw(canvas);
            return coloredBitmap;
        }
        
        private void hideNormalContent(final RemoteViews remoteViews) {
            remoteViews.setViewVisibility(R.id.title, 8);
            remoteViews.setViewVisibility(R.id.text2, 8);
            remoteViews.setViewVisibility(R.id.text, 8);
        }
        
        public void addCompatExtras(final Bundle bundle) {
        }
        
        public void apply(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
        }
        
        public RemoteViews applyStandardTemplate(final boolean b, final int n, final boolean b2) {
            final Resources resources = this.mBuilder.mContext.getResources();
            final RemoteViews remoteViews = new RemoteViews(this.mBuilder.mContext.getPackageName(), n);
            final int priority = this.mBuilder.getPriority();
            boolean b3 = true;
            final boolean b4 = priority < -1;
            if (Build$VERSION.SDK_INT >= 16 && Build$VERSION.SDK_INT < 21) {
                if (b4) {
                    remoteViews.setInt(R.id.notification_background, "setBackgroundResource", R.drawable.notification_bg_low);
                    remoteViews.setInt(R.id.icon, "setBackgroundResource", R.drawable.notification_template_icon_low_bg);
                }
                else {
                    remoteViews.setInt(R.id.notification_background, "setBackgroundResource", R.drawable.notification_bg);
                    remoteViews.setInt(R.id.icon, "setBackgroundResource", R.drawable.notification_template_icon_bg);
                }
            }
            if (this.mBuilder.mLargeIcon != null) {
                if (Build$VERSION.SDK_INT >= 16) {
                    remoteViews.setViewVisibility(R.id.icon, 0);
                    remoteViews.setImageViewBitmap(R.id.icon, this.mBuilder.mLargeIcon);
                }
                else {
                    remoteViews.setViewVisibility(R.id.icon, 8);
                }
                if (b && this.mBuilder.mNotification.icon != 0) {
                    final int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.notification_right_icon_size);
                    final int n2 = dimensionPixelSize - 2 * resources.getDimensionPixelSize(R.dimen.notification_small_icon_background_padding);
                    if (Build$VERSION.SDK_INT >= 21) {
                        remoteViews.setImageViewBitmap(R.id.right_icon, this.createIconWithBackground(this.mBuilder.mNotification.icon, dimensionPixelSize, n2, this.mBuilder.getColor()));
                    }
                    else {
                        remoteViews.setImageViewBitmap(R.id.right_icon, this.createColoredBitmap(this.mBuilder.mNotification.icon, -1));
                    }
                    remoteViews.setViewVisibility(R.id.right_icon, 0);
                }
            }
            else if (b && this.mBuilder.mNotification.icon != 0) {
                remoteViews.setViewVisibility(R.id.icon, 0);
                if (Build$VERSION.SDK_INT >= 21) {
                    remoteViews.setImageViewBitmap(R.id.icon, this.createIconWithBackground(this.mBuilder.mNotification.icon, resources.getDimensionPixelSize(R.dimen.notification_large_icon_width) - resources.getDimensionPixelSize(R.dimen.notification_big_circle_margin), resources.getDimensionPixelSize(R.dimen.notification_small_icon_size_as_large), this.mBuilder.getColor()));
                }
                else {
                    remoteViews.setImageViewBitmap(R.id.icon, this.createColoredBitmap(this.mBuilder.mNotification.icon, -1));
                }
            }
            if (this.mBuilder.mContentTitle != null) {
                remoteViews.setTextViewText(R.id.title, this.mBuilder.mContentTitle);
            }
            boolean b5;
            if (this.mBuilder.mContentText != null) {
                remoteViews.setTextViewText(R.id.text, this.mBuilder.mContentText);
                b5 = true;
            }
            else {
                b5 = false;
            }
            boolean b6 = Build$VERSION.SDK_INT < 21 && this.mBuilder.mLargeIcon != null;
            Label_0669: {
                if (this.mBuilder.mContentInfo != null) {
                    remoteViews.setTextViewText(R.id.info, this.mBuilder.mContentInfo);
                    remoteViews.setViewVisibility(R.id.info, 0);
                }
                else {
                    if (this.mBuilder.mNumber <= 0) {
                        remoteViews.setViewVisibility(R.id.info, 8);
                        break Label_0669;
                    }
                    if (this.mBuilder.mNumber > resources.getInteger(R.integer.status_bar_notification_info_maxnum)) {
                        remoteViews.setTextViewText(R.id.info, (CharSequence)resources.getString(R.string.status_bar_notification_info_overflow));
                    }
                    else {
                        remoteViews.setTextViewText(R.id.info, (CharSequence)NumberFormat.getIntegerInstance().format(this.mBuilder.mNumber));
                    }
                    remoteViews.setViewVisibility(R.id.info, 0);
                }
                b5 = true;
                b6 = true;
            }
            boolean b7 = false;
            Label_0755: {
                if (this.mBuilder.mSubText != null && Build$VERSION.SDK_INT >= 16) {
                    remoteViews.setTextViewText(R.id.text, this.mBuilder.mSubText);
                    if (this.mBuilder.mContentText != null) {
                        remoteViews.setTextViewText(R.id.text2, this.mBuilder.mContentText);
                        remoteViews.setViewVisibility(R.id.text2, 0);
                        b7 = true;
                        break Label_0755;
                    }
                    remoteViews.setViewVisibility(R.id.text2, 8);
                }
                b7 = false;
            }
            if (b7 && Build$VERSION.SDK_INT >= 16) {
                if (b2) {
                    remoteViews.setTextViewTextSize(R.id.text, 0, (float)resources.getDimensionPixelSize(R.dimen.notification_subtext_size));
                }
                remoteViews.setViewPadding(R.id.line1, 0, 0, 0, 0);
            }
            if (this.mBuilder.getWhenIfShowing() != 0L) {
                if (this.mBuilder.mUseChronometer && Build$VERSION.SDK_INT >= 16) {
                    remoteViews.setViewVisibility(R.id.chronometer, 0);
                    remoteViews.setLong(R.id.chronometer, "setBase", this.mBuilder.getWhenIfShowing() + (SystemClock.elapsedRealtime() - System.currentTimeMillis()));
                    remoteViews.setBoolean(R.id.chronometer, "setStarted", b3);
                    if (this.mBuilder.mChronometerCountDown && Build$VERSION.SDK_INT >= 24) {
                        remoteViews.setChronometerCountDown(R.id.chronometer, this.mBuilder.mChronometerCountDown);
                    }
                }
                else {
                    remoteViews.setViewVisibility(R.id.time, 0);
                    remoteViews.setLong(R.id.time, "setTime", this.mBuilder.getWhenIfShowing());
                }
            }
            else {
                b3 = b6;
            }
            final int right_side = R.id.right_side;
            int n3;
            if (b3) {
                n3 = 0;
            }
            else {
                n3 = 8;
            }
            remoteViews.setViewVisibility(right_side, n3);
            final int line3 = R.id.line3;
            int n4;
            if (b5) {
                n4 = 0;
            }
            else {
                n4 = 8;
            }
            remoteViews.setViewVisibility(line3, n4);
            return remoteViews;
        }
        
        public Notification build() {
            final NotificationCompat.Builder mBuilder = this.mBuilder;
            Notification build;
            if (mBuilder != null) {
                build = mBuilder.build();
            }
            else {
                build = null;
            }
            return build;
        }
        
        public void buildIntoRemoteViews(final RemoteViews remoteViews, final RemoteViews remoteViews2) {
            this.hideNormalContent(remoteViews);
            remoteViews.removeAllViews(R.id.notification_main_column);
            remoteViews.addView(R.id.notification_main_column, remoteViews2.clone());
            remoteViews.setViewVisibility(R.id.notification_main_column, 0);
            if (Build$VERSION.SDK_INT >= 21) {
                remoteViews.setViewPadding(R.id.notification_main_column_container, 0, this.calculateTopPadding(), 0, 0);
            }
        }
        
        public Bitmap createColoredBitmap(final int n, final int n2) {
            return this.createColoredBitmap(n, n2, 0);
        }
        
        Bitmap createColoredBitmap(final IconCompat iconCompat, final int n) {
            return this.createColoredBitmap(iconCompat, n, 0);
        }
        
        public RemoteViews makeBigContentView(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            return null;
        }
        
        public RemoteViews makeContentView(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            return null;
        }
        
        public RemoteViews makeHeadsUpContentView(final NotificationBuilderWithBuilderAccessor notificationBuilderWithBuilderAccessor) {
            return null;
        }
        
        protected void restoreFromCompatExtras(final Bundle bundle) {
        }
        
        public void setBuilder(final NotificationCompat.Builder mBuilder) {
            if (this.mBuilder != mBuilder && (this.mBuilder = mBuilder) != null) {
                mBuilder.setStyle(this);
            }
        }
    }
    
    public static final class WearableExtender implements NotificationCompat.Extender
    {
        private static final int DEFAULT_CONTENT_ICON_GRAVITY = 8388613;
        private static final int DEFAULT_FLAGS = 1;
        private static final int DEFAULT_GRAVITY = 80;
        private static final String EXTRA_WEARABLE_EXTENSIONS = "android.wearable.EXTENSIONS";
        private static final int FLAG_BIG_PICTURE_AMBIENT = 32;
        private static final int FLAG_CONTENT_INTENT_AVAILABLE_OFFLINE = 1;
        private static final int FLAG_HINT_AVOID_BACKGROUND_CLIPPING = 16;
        private static final int FLAG_HINT_CONTENT_INTENT_LAUNCHES_ACTIVITY = 64;
        private static final int FLAG_HINT_HIDE_ICON = 2;
        private static final int FLAG_HINT_SHOW_BACKGROUND_ONLY = 4;
        private static final int FLAG_START_SCROLL_BOTTOM = 8;
        private static final String KEY_ACTIONS = "actions";
        private static final String KEY_BACKGROUND = "background";
        private static final String KEY_BRIDGE_TAG = "bridgeTag";
        private static final String KEY_CONTENT_ACTION_INDEX = "contentActionIndex";
        private static final String KEY_CONTENT_ICON = "contentIcon";
        private static final String KEY_CONTENT_ICON_GRAVITY = "contentIconGravity";
        private static final String KEY_CUSTOM_CONTENT_HEIGHT = "customContentHeight";
        private static final String KEY_CUSTOM_SIZE_PRESET = "customSizePreset";
        private static final String KEY_DISMISSAL_ID = "dismissalId";
        private static final String KEY_DISPLAY_INTENT = "displayIntent";
        private static final String KEY_FLAGS = "flags";
        private static final String KEY_GRAVITY = "gravity";
        private static final String KEY_HINT_SCREEN_TIMEOUT = "hintScreenTimeout";
        private static final String KEY_PAGES = "pages";
        @Deprecated
        public static final int SCREEN_TIMEOUT_LONG = -1;
        @Deprecated
        public static final int SCREEN_TIMEOUT_SHORT = 0;
        @Deprecated
        public static final int SIZE_DEFAULT = 0;
        @Deprecated
        public static final int SIZE_FULL_SCREEN = 5;
        @Deprecated
        public static final int SIZE_LARGE = 4;
        @Deprecated
        public static final int SIZE_MEDIUM = 3;
        @Deprecated
        public static final int SIZE_SMALL = 2;
        @Deprecated
        public static final int SIZE_XSMALL = 1;
        public static final int UNSET_ACTION_INDEX = -1;
        private ArrayList<Action> mActions;
        private Bitmap mBackground;
        private String mBridgeTag;
        private int mContentActionIndex;
        private int mContentIcon;
        private int mContentIconGravity;
        private int mCustomContentHeight;
        private int mCustomSizePreset;
        private String mDismissalId;
        private PendingIntent mDisplayIntent;
        private int mFlags;
        private int mGravity;
        private int mHintScreenTimeout;
        private ArrayList<Notification> mPages;
        
        public WearableExtender() {
            this.mActions = new ArrayList<Action>();
            this.mFlags = 1;
            this.mPages = new ArrayList<Notification>();
            this.mContentIconGravity = 8388613;
            this.mContentActionIndex = -1;
            this.mCustomSizePreset = 0;
            this.mGravity = 80;
        }
        
        public WearableExtender(final Notification notification) {
            this.mActions = new ArrayList<Action>();
            this.mFlags = 1;
            this.mPages = new ArrayList<Notification>();
            this.mContentIconGravity = 8388613;
            this.mContentActionIndex = -1;
            this.mCustomSizePreset = 0;
            this.mGravity = 80;
            final Bundle extras = NotificationCompat.getExtras(notification);
            Bundle bundle;
            if (extras != null) {
                bundle = extras.getBundle("android.wearable.EXTENSIONS");
            }
            else {
                bundle = null;
            }
            if (bundle != null) {
                final ArrayList parcelableArrayList = bundle.getParcelableArrayList("actions");
                if (Build$VERSION.SDK_INT >= 16 && parcelableArrayList != null) {
                    final int size = parcelableArrayList.size();
                    final Action[] elements = new Action[size];
                    for (int i = 0; i < size; ++i) {
                        if (Build$VERSION.SDK_INT >= 20) {
                            elements[i] = NotificationCompat.getActionCompatFromAction(parcelableArrayList.get(i));
                        }
                        else if (Build$VERSION.SDK_INT >= 16) {
                            elements[i] = NotificationCompatJellybean.getActionFromBundle((Bundle)parcelableArrayList.get(i));
                        }
                    }
                    Collections.addAll(this.mActions, elements);
                }
                this.mFlags = bundle.getInt("flags", 1);
                this.mDisplayIntent = (PendingIntent)bundle.getParcelable("displayIntent");
                final Notification[] notificationArrayFromBundle = NotificationCompat.getNotificationArrayFromBundle(bundle, "pages");
                if (notificationArrayFromBundle != null) {
                    Collections.addAll(this.mPages, notificationArrayFromBundle);
                }
                this.mBackground = (Bitmap)bundle.getParcelable("background");
                this.mContentIcon = bundle.getInt("contentIcon");
                this.mContentIconGravity = bundle.getInt("contentIconGravity", 8388613);
                this.mContentActionIndex = bundle.getInt("contentActionIndex", -1);
                this.mCustomSizePreset = bundle.getInt("customSizePreset", 0);
                this.mCustomContentHeight = bundle.getInt("customContentHeight");
                this.mGravity = bundle.getInt("gravity", 80);
                this.mHintScreenTimeout = bundle.getInt("hintScreenTimeout");
                this.mDismissalId = bundle.getString("dismissalId");
                this.mBridgeTag = bundle.getString("bridgeTag");
            }
        }
        
        private static Notification$Action getActionFromActionCompat(final Action action) {
            final int sdk_INT = Build$VERSION.SDK_INT;
            int i = 0;
            Notification$Action$Builder notification$Action$Builder;
            if (sdk_INT >= 23) {
                final IconCompat iconCompat = action.getIconCompat();
                Icon icon;
                if (iconCompat == null) {
                    icon = null;
                }
                else {
                    icon = iconCompat.toIcon();
                }
                notification$Action$Builder = new Notification$Action$Builder(icon, action.getTitle(), action.getActionIntent());
            }
            else {
                final IconCompat iconCompat2 = action.getIconCompat();
                int resId;
                if (iconCompat2 != null && iconCompat2.getType() == 2) {
                    resId = iconCompat2.getResId();
                }
                else {
                    resId = 0;
                }
                notification$Action$Builder = new Notification$Action$Builder(resId, action.getTitle(), action.getActionIntent());
            }
            Bundle bundle;
            if (action.getExtras() != null) {
                bundle = new Bundle(action.getExtras());
            }
            else {
                bundle = new Bundle();
            }
            bundle.putBoolean("android.support.allowGeneratedReplies", action.getAllowGeneratedReplies());
            if (Build$VERSION.SDK_INT >= 24) {
                notification$Action$Builder.setAllowGeneratedReplies(action.getAllowGeneratedReplies());
            }
            notification$Action$Builder.addExtras(bundle);
            final RemoteInput[] remoteInputs = action.getRemoteInputs();
            if (remoteInputs != null) {
                for (android.app.RemoteInput[] fromCompat = RemoteInput.fromCompat(remoteInputs); i < fromCompat.length; ++i) {
                    notification$Action$Builder.addRemoteInput(fromCompat[i]);
                }
            }
            return notification$Action$Builder.build();
        }
        
        private void setFlag(final int n, final boolean b) {
            if (b) {
                this.mFlags |= n;
            }
            else {
                this.mFlags &= ~n;
            }
        }
        
        public WearableExtender addAction(final Action e) {
            this.mActions.add(e);
            return this;
        }
        
        public WearableExtender addActions(final List<Action> c) {
            this.mActions.addAll(c);
            return this;
        }
        
        @Deprecated
        public WearableExtender addPage(final Notification e) {
            this.mPages.add(e);
            return this;
        }
        
        @Deprecated
        public WearableExtender addPages(final List<Notification> c) {
            this.mPages.addAll(c);
            return this;
        }
        
        public WearableExtender clearActions() {
            this.mActions.clear();
            return this;
        }
        
        @Deprecated
        public WearableExtender clearPages() {
            this.mPages.clear();
            return this;
        }
        
        public WearableExtender clone() {
            final WearableExtender wearableExtender = new WearableExtender();
            wearableExtender.mActions = new ArrayList<Action>(this.mActions);
            wearableExtender.mFlags = this.mFlags;
            wearableExtender.mDisplayIntent = this.mDisplayIntent;
            wearableExtender.mPages = new ArrayList<Notification>(this.mPages);
            wearableExtender.mBackground = this.mBackground;
            wearableExtender.mContentIcon = this.mContentIcon;
            wearableExtender.mContentIconGravity = this.mContentIconGravity;
            wearableExtender.mContentActionIndex = this.mContentActionIndex;
            wearableExtender.mCustomSizePreset = this.mCustomSizePreset;
            wearableExtender.mCustomContentHeight = this.mCustomContentHeight;
            wearableExtender.mGravity = this.mGravity;
            wearableExtender.mHintScreenTimeout = this.mHintScreenTimeout;
            wearableExtender.mDismissalId = this.mDismissalId;
            wearableExtender.mBridgeTag = this.mBridgeTag;
            return wearableExtender;
        }
        
        @Override
        public NotificationCompat.Builder extend(final NotificationCompat.Builder builder) {
            final Bundle bundle = new Bundle();
            if (!this.mActions.isEmpty()) {
                if (Build$VERSION.SDK_INT >= 16) {
                    final ArrayList<Bundle> list = new ArrayList<Bundle>(this.mActions.size());
                    for (final Action action : this.mActions) {
                        if (Build$VERSION.SDK_INT >= 20) {
                            list.add((Bundle)getActionFromActionCompat(action));
                        }
                        else {
                            if (Build$VERSION.SDK_INT < 16) {
                                continue;
                            }
                            list.add(NotificationCompatJellybean.getBundleForAction(action));
                        }
                    }
                    bundle.putParcelableArrayList("actions", (ArrayList)list);
                }
                else {
                    bundle.putParcelableArrayList("actions", (ArrayList)null);
                }
            }
            final int mFlags = this.mFlags;
            if (mFlags != 1) {
                bundle.putInt("flags", mFlags);
            }
            final PendingIntent mDisplayIntent = this.mDisplayIntent;
            if (mDisplayIntent != null) {
                bundle.putParcelable("displayIntent", (Parcelable)mDisplayIntent);
            }
            if (!this.mPages.isEmpty()) {
                final ArrayList<Notification> mPages = this.mPages;
                bundle.putParcelableArray("pages", (Parcelable[])mPages.toArray((Parcelable[])new Notification[mPages.size()]));
            }
            final Bitmap mBackground = this.mBackground;
            if (mBackground != null) {
                bundle.putParcelable("background", (Parcelable)mBackground);
            }
            final int mContentIcon = this.mContentIcon;
            if (mContentIcon != 0) {
                bundle.putInt("contentIcon", mContentIcon);
            }
            final int mContentIconGravity = this.mContentIconGravity;
            if (mContentIconGravity != 8388613) {
                bundle.putInt("contentIconGravity", mContentIconGravity);
            }
            final int mContentActionIndex = this.mContentActionIndex;
            if (mContentActionIndex != -1) {
                bundle.putInt("contentActionIndex", mContentActionIndex);
            }
            final int mCustomSizePreset = this.mCustomSizePreset;
            if (mCustomSizePreset != 0) {
                bundle.putInt("customSizePreset", mCustomSizePreset);
            }
            final int mCustomContentHeight = this.mCustomContentHeight;
            if (mCustomContentHeight != 0) {
                bundle.putInt("customContentHeight", mCustomContentHeight);
            }
            final int mGravity = this.mGravity;
            if (mGravity != 80) {
                bundle.putInt("gravity", mGravity);
            }
            final int mHintScreenTimeout = this.mHintScreenTimeout;
            if (mHintScreenTimeout != 0) {
                bundle.putInt("hintScreenTimeout", mHintScreenTimeout);
            }
            final String mDismissalId = this.mDismissalId;
            if (mDismissalId != null) {
                bundle.putString("dismissalId", mDismissalId);
            }
            final String mBridgeTag = this.mBridgeTag;
            if (mBridgeTag != null) {
                bundle.putString("bridgeTag", mBridgeTag);
            }
            builder.getExtras().putBundle("android.wearable.EXTENSIONS", bundle);
            return builder;
        }
        
        public List<Action> getActions() {
            return this.mActions;
        }
        
        @Deprecated
        public Bitmap getBackground() {
            return this.mBackground;
        }
        
        public String getBridgeTag() {
            return this.mBridgeTag;
        }
        
        public int getContentAction() {
            return this.mContentActionIndex;
        }
        
        @Deprecated
        public int getContentIcon() {
            return this.mContentIcon;
        }
        
        @Deprecated
        public int getContentIconGravity() {
            return this.mContentIconGravity;
        }
        
        public boolean getContentIntentAvailableOffline() {
            final int mFlags = this.mFlags;
            int n = 1;
            if ((mFlags & n) == 0x0) {
                n = 0;
            }
            return n != 0;
        }
        
        @Deprecated
        public int getCustomContentHeight() {
            return this.mCustomContentHeight;
        }
        
        @Deprecated
        public int getCustomSizePreset() {
            return this.mCustomSizePreset;
        }
        
        public String getDismissalId() {
            return this.mDismissalId;
        }
        
        @Deprecated
        public PendingIntent getDisplayIntent() {
            return this.mDisplayIntent;
        }
        
        @Deprecated
        public int getGravity() {
            return this.mGravity;
        }
        
        @Deprecated
        public boolean getHintAmbientBigPicture() {
            return (0x20 & this.mFlags) != 0x0;
        }
        
        @Deprecated
        public boolean getHintAvoidBackgroundClipping() {
            return (0x10 & this.mFlags) != 0x0;
        }
        
        public boolean getHintContentIntentLaunchesActivity() {
            return (0x40 & this.mFlags) != 0x0;
        }
        
        @Deprecated
        public boolean getHintHideIcon() {
            return (0x2 & this.mFlags) != 0x0;
        }
        
        @Deprecated
        public int getHintScreenTimeout() {
            return this.mHintScreenTimeout;
        }
        
        @Deprecated
        public boolean getHintShowBackgroundOnly() {
            return (0x4 & this.mFlags) != 0x0;
        }
        
        @Deprecated
        public List<Notification> getPages() {
            return this.mPages;
        }
        
        public boolean getStartScrollBottom() {
            return (0x8 & this.mFlags) != 0x0;
        }
        
        @Deprecated
        public WearableExtender setBackground(final Bitmap mBackground) {
            this.mBackground = mBackground;
            return this;
        }
        
        public WearableExtender setBridgeTag(final String mBridgeTag) {
            this.mBridgeTag = mBridgeTag;
            return this;
        }
        
        public WearableExtender setContentAction(final int mContentActionIndex) {
            this.mContentActionIndex = mContentActionIndex;
            return this;
        }
        
        @Deprecated
        public WearableExtender setContentIcon(final int mContentIcon) {
            this.mContentIcon = mContentIcon;
            return this;
        }
        
        @Deprecated
        public WearableExtender setContentIconGravity(final int mContentIconGravity) {
            this.mContentIconGravity = mContentIconGravity;
            return this;
        }
        
        public WearableExtender setContentIntentAvailableOffline(final boolean b) {
            this.setFlag(1, b);
            return this;
        }
        
        @Deprecated
        public WearableExtender setCustomContentHeight(final int mCustomContentHeight) {
            this.mCustomContentHeight = mCustomContentHeight;
            return this;
        }
        
        @Deprecated
        public WearableExtender setCustomSizePreset(final int mCustomSizePreset) {
            this.mCustomSizePreset = mCustomSizePreset;
            return this;
        }
        
        public WearableExtender setDismissalId(final String mDismissalId) {
            this.mDismissalId = mDismissalId;
            return this;
        }
        
        @Deprecated
        public WearableExtender setDisplayIntent(final PendingIntent mDisplayIntent) {
            this.mDisplayIntent = mDisplayIntent;
            return this;
        }
        
        @Deprecated
        public WearableExtender setGravity(final int mGravity) {
            this.mGravity = mGravity;
            return this;
        }
        
        @Deprecated
        public WearableExtender setHintAmbientBigPicture(final boolean b) {
            this.setFlag(32, b);
            return this;
        }
        
        @Deprecated
        public WearableExtender setHintAvoidBackgroundClipping(final boolean b) {
            this.setFlag(16, b);
            return this;
        }
        
        public WearableExtender setHintContentIntentLaunchesActivity(final boolean b) {
            this.setFlag(64, b);
            return this;
        }
        
        @Deprecated
        public WearableExtender setHintHideIcon(final boolean b) {
            this.setFlag(2, b);
            return this;
        }
        
        @Deprecated
        public WearableExtender setHintScreenTimeout(final int mHintScreenTimeout) {
            this.mHintScreenTimeout = mHintScreenTimeout;
            return this;
        }
        
        @Deprecated
        public WearableExtender setHintShowBackgroundOnly(final boolean b) {
            this.setFlag(4, b);
            return this;
        }
        
        public WearableExtender setStartScrollBottom(final boolean b) {
            this.setFlag(8, b);
            return this;
        }
    }
}
