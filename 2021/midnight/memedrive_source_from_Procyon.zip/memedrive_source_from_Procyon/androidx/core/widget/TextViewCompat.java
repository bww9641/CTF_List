// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.widget;

import android.view.MenuItem;
import android.view.ActionMode;
import android.view.Menu;
import android.text.Editable;
import java.util.Iterator;
import android.app.Activity;
import java.util.ArrayList;
import java.util.List;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.pm.ResolveInfo;
import android.content.Intent;
import java.lang.reflect.Method;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Annotation;
import android.graphics.Paint$FontMetricsInt;
import android.view.ActionMode$Callback;
import android.util.Log;
import android.graphics.Paint;
import android.text.TextPaint;
import androidx.core.text.PrecomputedTextCompat;
import android.icu.text.DecimalFormatSymbols;
import android.text.method.PasswordTransformationMethod;
import android.text.TextDirectionHeuristics;
import android.text.TextDirectionHeuristic;
import android.graphics.drawable.Drawable;
import android.graphics.PorterDuff$Mode;
import androidx.core.util.Preconditions;
import android.content.res.ColorStateList;
import android.os.Build$VERSION;
import android.widget.TextView;
import java.lang.reflect.Field;

public final class TextViewCompat
{
    public static final int AUTO_SIZE_TEXT_TYPE_NONE = 0;
    public static final int AUTO_SIZE_TEXT_TYPE_UNIFORM = 1;
    private static final int LINES = 1;
    private static final String LOG_TAG = "TextViewCompat";
    private static Field sMaxModeField;
    private static boolean sMaxModeFieldFetched;
    private static Field sMaximumField;
    private static boolean sMaximumFieldFetched;
    private static Field sMinModeField;
    private static boolean sMinModeFieldFetched;
    private static Field sMinimumField;
    private static boolean sMinimumFieldFetched;
    
    private TextViewCompat() {
    }
    
    public static int getAutoSizeMaxTextSize(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 27) {
            return textView.getAutoSizeMaxTextSize();
        }
        if (textView instanceof AutoSizeableTextView) {
            return ((AutoSizeableTextView)textView).getAutoSizeMaxTextSize();
        }
        return -1;
    }
    
    public static int getAutoSizeMinTextSize(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 27) {
            return textView.getAutoSizeMinTextSize();
        }
        if (textView instanceof AutoSizeableTextView) {
            return ((AutoSizeableTextView)textView).getAutoSizeMinTextSize();
        }
        return -1;
    }
    
    public static int getAutoSizeStepGranularity(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 27) {
            return textView.getAutoSizeStepGranularity();
        }
        if (textView instanceof AutoSizeableTextView) {
            return ((AutoSizeableTextView)textView).getAutoSizeStepGranularity();
        }
        return -1;
    }
    
    public static int[] getAutoSizeTextAvailableSizes(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 27) {
            return textView.getAutoSizeTextAvailableSizes();
        }
        if (textView instanceof AutoSizeableTextView) {
            return ((AutoSizeableTextView)textView).getAutoSizeTextAvailableSizes();
        }
        return new int[0];
    }
    
    public static int getAutoSizeTextType(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 27) {
            return textView.getAutoSizeTextType();
        }
        if (textView instanceof AutoSizeableTextView) {
            return ((AutoSizeableTextView)textView).getAutoSizeTextType();
        }
        return 0;
    }
    
    public static ColorStateList getCompoundDrawableTintList(final TextView textView) {
        Preconditions.checkNotNull(textView);
        if (Build$VERSION.SDK_INT >= 24) {
            return textView.getCompoundDrawableTintList();
        }
        if (textView instanceof TintableCompoundDrawablesView) {
            return ((TintableCompoundDrawablesView)textView).getSupportCompoundDrawablesTintList();
        }
        return null;
    }
    
    public static PorterDuff$Mode getCompoundDrawableTintMode(final TextView textView) {
        Preconditions.checkNotNull(textView);
        if (Build$VERSION.SDK_INT >= 24) {
            return textView.getCompoundDrawableTintMode();
        }
        if (textView instanceof TintableCompoundDrawablesView) {
            return ((TintableCompoundDrawablesView)textView).getSupportCompoundDrawablesTintMode();
        }
        return null;
    }
    
    public static Drawable[] getCompoundDrawablesRelative(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 18) {
            return textView.getCompoundDrawablesRelative();
        }
        if (Build$VERSION.SDK_INT >= 17) {
            final int layoutDirection = textView.getLayoutDirection();
            int n = 1;
            if (layoutDirection != n) {
                n = 0;
            }
            final Drawable[] compoundDrawables = textView.getCompoundDrawables();
            if (n != 0) {
                final Drawable drawable = compoundDrawables[2];
                final Drawable drawable2 = compoundDrawables[0];
                compoundDrawables[0] = drawable;
                compoundDrawables[2] = drawable2;
            }
            return compoundDrawables;
        }
        return textView.getCompoundDrawables();
    }
    
    public static int getFirstBaselineToTopHeight(final TextView textView) {
        return textView.getPaddingTop() - textView.getPaint().getFontMetricsInt().top;
    }
    
    public static int getLastBaselineToBottomHeight(final TextView textView) {
        return textView.getPaddingBottom() + textView.getPaint().getFontMetricsInt().bottom;
    }
    
    public static int getMaxLines(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 16) {
            return textView.getMaxLines();
        }
        if (!TextViewCompat.sMaxModeFieldFetched) {
            TextViewCompat.sMaxModeField = retrieveField("mMaxMode");
            TextViewCompat.sMaxModeFieldFetched = true;
        }
        final Field sMaxModeField = TextViewCompat.sMaxModeField;
        if (sMaxModeField != null && retrieveIntFromField(sMaxModeField, textView) == 1) {
            if (!TextViewCompat.sMaximumFieldFetched) {
                TextViewCompat.sMaximumField = retrieveField("mMaximum");
                TextViewCompat.sMaximumFieldFetched = true;
            }
            final Field sMaximumField = TextViewCompat.sMaximumField;
            if (sMaximumField != null) {
                return retrieveIntFromField(sMaximumField, textView);
            }
        }
        return -1;
    }
    
    public static int getMinLines(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 16) {
            return textView.getMinLines();
        }
        if (!TextViewCompat.sMinModeFieldFetched) {
            TextViewCompat.sMinModeField = retrieveField("mMinMode");
            TextViewCompat.sMinModeFieldFetched = true;
        }
        final Field sMinModeField = TextViewCompat.sMinModeField;
        if (sMinModeField != null && retrieveIntFromField(sMinModeField, textView) == 1) {
            if (!TextViewCompat.sMinimumFieldFetched) {
                TextViewCompat.sMinimumField = retrieveField("mMinimum");
                TextViewCompat.sMinimumFieldFetched = true;
            }
            final Field sMinimumField = TextViewCompat.sMinimumField;
            if (sMinimumField != null) {
                return retrieveIntFromField(sMinimumField, textView);
            }
        }
        return -1;
    }
    
    private static int getTextDirection(final TextDirectionHeuristic textDirectionHeuristic) {
        if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
            return 1;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
            return 1;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR) {
            return 2;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.LTR) {
            return 3;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.RTL) {
            return 4;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.LOCALE) {
            return 5;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
            return 6;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
            return 7;
        }
        return 1;
    }
    
    private static TextDirectionHeuristic getTextDirectionHeuristic(final TextView textView) {
        if (textView.getTransformationMethod() instanceof PasswordTransformationMethod) {
            return TextDirectionHeuristics.LTR;
        }
        if (Build$VERSION.SDK_INT >= 28 && (0xF & textView.getInputType()) == 0x3) {
            final byte directionality = Character.getDirectionality(DecimalFormatSymbols.getInstance(textView.getTextLocale()).getDigitStrings()[0].codePointAt(0));
            if (directionality != 1 && directionality != 2) {
                return TextDirectionHeuristics.LTR;
            }
            return TextDirectionHeuristics.RTL;
        }
        else {
            final int layoutDirection = textView.getLayoutDirection();
            boolean b = false;
            if (layoutDirection == 1) {
                b = true;
            }
            switch (textView.getTextDirection()) {
                default: {
                    TextDirectionHeuristic textDirectionHeuristic;
                    if (b) {
                        textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
                    }
                    else {
                        textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR;
                    }
                    return textDirectionHeuristic;
                }
                case 7: {
                    return TextDirectionHeuristics.FIRSTSTRONG_RTL;
                }
                case 6: {
                    return TextDirectionHeuristics.FIRSTSTRONG_LTR;
                }
                case 5: {
                    return TextDirectionHeuristics.LOCALE;
                }
                case 4: {
                    return TextDirectionHeuristics.RTL;
                }
                case 3: {
                    return TextDirectionHeuristics.LTR;
                }
                case 2: {
                    return TextDirectionHeuristics.ANYRTL_LTR;
                }
            }
        }
    }
    
    public static PrecomputedTextCompat.Params getTextMetricsParams(final TextView textView) {
        if (Build$VERSION.SDK_INT >= 28) {
            return new PrecomputedTextCompat.Params(textView.getTextMetricsParams());
        }
        final PrecomputedTextCompat.Params.Builder builder = new PrecomputedTextCompat.Params.Builder(new TextPaint((Paint)textView.getPaint()));
        if (Build$VERSION.SDK_INT >= 23) {
            builder.setBreakStrategy(textView.getBreakStrategy());
            builder.setHyphenationFrequency(textView.getHyphenationFrequency());
        }
        if (Build$VERSION.SDK_INT >= 18) {
            builder.setTextDirection(getTextDirectionHeuristic(textView));
        }
        return builder.build();
    }
    
    private static Field retrieveField(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: astore_1       
        //     2: ldc             Landroid/widget/TextView;.class
        //     4: aload_0        
        //     5: invokevirtual   java/lang/Class.getDeclaredField:(Ljava/lang/String;)Ljava/lang/reflect/Field;
        //     8: astore_1       
        //     9: aload_1        
        //    10: iconst_1       
        //    11: invokevirtual   java/lang/reflect/Field.setAccessible:(Z)V
        //    14: goto            57
        //    17: new             Ljava/lang/StringBuilder;
        //    20: dup            
        //    21: invokespecial   java/lang/StringBuilder.<init>:()V
        //    24: astore_2       
        //    25: aload_2        
        //    26: ldc_w           "Could not retrieve "
        //    29: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    32: pop            
        //    33: aload_2        
        //    34: aload_0        
        //    35: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    38: pop            
        //    39: aload_2        
        //    40: ldc_w           " field."
        //    43: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    46: pop            
        //    47: ldc             "TextViewCompat"
        //    49: aload_2        
        //    50: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    53: invokestatic    android/util/Log.e:(Ljava/lang/String;Ljava/lang/String;)I
        //    56: pop            
        //    57: aload_1        
        //    58: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  2      14     17     57     Ljava/lang/NoSuchFieldException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0057 (coming from #0056).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    private static int retrieveIntFromField(final Field field, final TextView obj) {
        try {
            return field.getInt(obj);
        }
        catch (IllegalAccessException ex) {
            final StringBuilder sb = new StringBuilder();
            sb.append("Could not retrieve value of ");
            sb.append(field.getName());
            sb.append(" field.");
            Log.d("TextViewCompat", sb.toString());
            return -1;
        }
    }
    
    public static void setAutoSizeTextTypeUniformWithConfiguration(final TextView textView, final int n, final int n2, final int n3, final int n4) throws IllegalArgumentException {
        if (Build$VERSION.SDK_INT >= 27) {
            textView.setAutoSizeTextTypeUniformWithConfiguration(n, n2, n3, n4);
        }
        else if (textView instanceof AutoSizeableTextView) {
            ((AutoSizeableTextView)textView).setAutoSizeTextTypeUniformWithConfiguration(n, n2, n3, n4);
        }
    }
    
    public static void setAutoSizeTextTypeUniformWithPresetSizes(final TextView textView, final int[] array, final int n) throws IllegalArgumentException {
        if (Build$VERSION.SDK_INT >= 27) {
            textView.setAutoSizeTextTypeUniformWithPresetSizes(array, n);
        }
        else if (textView instanceof AutoSizeableTextView) {
            ((AutoSizeableTextView)textView).setAutoSizeTextTypeUniformWithPresetSizes(array, n);
        }
    }
    
    public static void setAutoSizeTextTypeWithDefaults(final TextView textView, final int n) {
        if (Build$VERSION.SDK_INT >= 27) {
            textView.setAutoSizeTextTypeWithDefaults(n);
        }
        else if (textView instanceof AutoSizeableTextView) {
            ((AutoSizeableTextView)textView).setAutoSizeTextTypeWithDefaults(n);
        }
    }
    
    public static void setCompoundDrawableTintList(final TextView textView, final ColorStateList list) {
        Preconditions.checkNotNull(textView);
        if (Build$VERSION.SDK_INT >= 24) {
            textView.setCompoundDrawableTintList(list);
        }
        else if (textView instanceof TintableCompoundDrawablesView) {
            ((TintableCompoundDrawablesView)textView).setSupportCompoundDrawablesTintList(list);
        }
    }
    
    public static void setCompoundDrawableTintMode(final TextView textView, final PorterDuff$Mode porterDuff$Mode) {
        Preconditions.checkNotNull(textView);
        if (Build$VERSION.SDK_INT >= 24) {
            textView.setCompoundDrawableTintMode(porterDuff$Mode);
        }
        else if (textView instanceof TintableCompoundDrawablesView) {
            ((TintableCompoundDrawablesView)textView).setSupportCompoundDrawablesTintMode(porterDuff$Mode);
        }
    }
    
    public static void setCompoundDrawablesRelative(final TextView textView, Drawable drawable, final Drawable drawable2, final Drawable drawable3, final Drawable drawable4) {
        if (Build$VERSION.SDK_INT >= 18) {
            textView.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        }
        else if (Build$VERSION.SDK_INT >= 17) {
            final int layoutDirection = textView.getLayoutDirection();
            int n = 1;
            if (layoutDirection != n) {
                n = 0;
            }
            Drawable drawable5;
            if (n != 0) {
                drawable5 = drawable3;
            }
            else {
                drawable5 = drawable;
            }
            if (n == 0) {
                drawable = drawable3;
            }
            textView.setCompoundDrawables(drawable5, drawable2, drawable, drawable4);
        }
        else {
            textView.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        }
    }
    
    public static void setCompoundDrawablesRelativeWithIntrinsicBounds(final TextView textView, int n, final int n2, final int n3, final int n4) {
        if (Build$VERSION.SDK_INT >= 18) {
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(n, n2, n3, n4);
        }
        else if (Build$VERSION.SDK_INT >= 17) {
            final int layoutDirection = textView.getLayoutDirection();
            int n5 = 1;
            if (layoutDirection != n5) {
                n5 = 0;
            }
            int n6;
            if (n5 != 0) {
                n6 = n3;
            }
            else {
                n6 = n;
            }
            if (n5 == 0) {
                n = n3;
            }
            textView.setCompoundDrawablesWithIntrinsicBounds(n6, n2, n, n4);
        }
        else {
            textView.setCompoundDrawablesWithIntrinsicBounds(n, n2, n3, n4);
        }
    }
    
    public static void setCompoundDrawablesRelativeWithIntrinsicBounds(final TextView textView, Drawable drawable, final Drawable drawable2, final Drawable drawable3, final Drawable drawable4) {
        if (Build$VERSION.SDK_INT >= 18) {
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        }
        else if (Build$VERSION.SDK_INT >= 17) {
            final int layoutDirection = textView.getLayoutDirection();
            int n = 1;
            if (layoutDirection != n) {
                n = 0;
            }
            Drawable drawable5;
            if (n != 0) {
                drawable5 = drawable3;
            }
            else {
                drawable5 = drawable;
            }
            if (n == 0) {
                drawable = drawable3;
            }
            textView.setCompoundDrawablesWithIntrinsicBounds(drawable5, drawable2, drawable, drawable4);
        }
        else {
            textView.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        }
    }
    
    public static void setCustomSelectionActionModeCallback(final TextView textView, final ActionMode$Callback actionMode$Callback) {
        textView.setCustomSelectionActionModeCallback(wrapCustomSelectionActionModeCallback(textView, actionMode$Callback));
    }
    
    public static void setFirstBaselineToTopHeight(final TextView textView, final int firstBaselineToTopHeight) {
        Preconditions.checkArgumentNonnegative(firstBaselineToTopHeight);
        if (Build$VERSION.SDK_INT >= 28) {
            textView.setFirstBaselineToTopHeight(firstBaselineToTopHeight);
            return;
        }
        final Paint$FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int a;
        if (Build$VERSION.SDK_INT >= 16 && !textView.getIncludeFontPadding()) {
            a = fontMetricsInt.ascent;
        }
        else {
            a = fontMetricsInt.top;
        }
        if (firstBaselineToTopHeight > Math.abs(a)) {
            textView.setPadding(textView.getPaddingLeft(), firstBaselineToTopHeight + a, textView.getPaddingRight(), textView.getPaddingBottom());
        }
    }
    
    public static void setLastBaselineToBottomHeight(final TextView textView, final int n) {
        Preconditions.checkArgumentNonnegative(n);
        final Paint$FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int a;
        if (Build$VERSION.SDK_INT >= 16 && !textView.getIncludeFontPadding()) {
            a = fontMetricsInt.descent;
        }
        else {
            a = fontMetricsInt.bottom;
        }
        if (n > Math.abs(a)) {
            textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), n - a);
        }
    }
    
    public static void setLineHeight(final TextView textView, final int n) {
        Preconditions.checkArgumentNonnegative(n);
        final int fontMetricsInt = textView.getPaint().getFontMetricsInt((Paint$FontMetricsInt)null);
        if (n != fontMetricsInt) {
            textView.setLineSpacing((float)(n - fontMetricsInt), 1.0f);
        }
    }
    
    public static void setPrecomputedText(final TextView textView, final PrecomputedTextCompat text) {
        if (Build$VERSION.SDK_INT >= 29) {
            textView.setText((CharSequence)text.getPrecomputedText());
        }
        else {
            if (!getTextMetricsParams(textView).equalsWithoutTextDirection(text.getParams())) {
                throw new IllegalArgumentException("Given text can not be applied to TextView.");
            }
            textView.setText((CharSequence)text);
        }
    }
    
    public static void setTextAppearance(final TextView textView, final int textAppearance) {
        if (Build$VERSION.SDK_INT >= 23) {
            textView.setTextAppearance(textAppearance);
        }
        else {
            textView.setTextAppearance(textView.getContext(), textAppearance);
        }
    }
    
    public static void setTextMetricsParams(final TextView textView, final PrecomputedTextCompat.Params params) {
        if (Build$VERSION.SDK_INT >= 18) {
            textView.setTextDirection(getTextDirection(params.getTextDirection()));
        }
        if (Build$VERSION.SDK_INT < 23) {
            final float textScaleX = params.getTextPaint().getTextScaleX();
            textView.getPaint().set(params.getTextPaint());
            if (textScaleX == textView.getTextScaleX()) {
                textView.setTextScaleX(1.0f + textScaleX / 2.0f);
            }
            textView.setTextScaleX(textScaleX);
        }
        else {
            textView.getPaint().set(params.getTextPaint());
            textView.setBreakStrategy(params.getBreakStrategy());
            textView.setHyphenationFrequency(params.getHyphenationFrequency());
        }
    }
    
    public static ActionMode$Callback wrapCustomSelectionActionModeCallback(final TextView textView, final ActionMode$Callback actionMode$Callback) {
        if (Build$VERSION.SDK_INT >= 26 && Build$VERSION.SDK_INT <= 27 && !(actionMode$Callback instanceof OreoCallback)) {
            return (ActionMode$Callback)new OreoCallback(actionMode$Callback, textView);
        }
        return actionMode$Callback;
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface AutoSizeTextType {
    }
    
    private static class OreoCallback implements ActionMode$Callback
    {
        private static final int MENU_ITEM_ORDER_PROCESS_TEXT_INTENT_ACTIONS_START = 100;
        private final ActionMode$Callback mCallback;
        private boolean mCanUseMenuBuilderReferences;
        private boolean mInitializedMenuBuilderReferences;
        private Class<?> mMenuBuilderClass;
        private Method mMenuBuilderRemoveItemAtMethod;
        private final TextView mTextView;
        
        OreoCallback(final ActionMode$Callback mCallback, final TextView mTextView) {
            this.mCallback = mCallback;
            this.mTextView = mTextView;
            this.mInitializedMenuBuilderReferences = false;
        }
        
        private Intent createProcessTextIntent() {
            return new Intent().setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
        }
        
        private Intent createProcessTextIntentForResolveInfo(final ResolveInfo resolveInfo, final TextView textView) {
            return this.createProcessTextIntent().putExtra("android.intent.extra.PROCESS_TEXT_READONLY", true ^ this.isEditable(textView)).setClassName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
        }
        
        private List<ResolveInfo> getSupportedActivities(final Context context, final PackageManager packageManager) {
            final ArrayList<ResolveInfo> list = new ArrayList<ResolveInfo>();
            if (!(context instanceof Activity)) {
                return list;
            }
            for (final ResolveInfo resolveInfo : packageManager.queryIntentActivities(this.createProcessTextIntent(), 0)) {
                if (this.isSupportedActivity(resolveInfo, context)) {
                    list.add(resolveInfo);
                }
            }
            return list;
        }
        
        private boolean isEditable(final TextView textView) {
            return textView instanceof Editable && textView.onCheckIsTextEditor() && textView.isEnabled();
        }
        
        private boolean isSupportedActivity(final ResolveInfo resolveInfo, final Context context) {
            final boolean equals = context.getPackageName().equals(resolveInfo.activityInfo.packageName);
            boolean b = true;
            if (equals) {
                return b;
            }
            if (!resolveInfo.activityInfo.exported) {
                return false;
            }
            if (resolveInfo.activityInfo.permission != null) {
                if (context.checkSelfPermission(resolveInfo.activityInfo.permission) != 0) {
                    b = false;
                }
            }
            return b;
        }
        
        private void recomputeProcessTextMenuItems(final Menu p0) {
            // 
            // This method could not be decompiled.
            // 
            // Original Bytecode:
            // 
            //     1: getfield        androidx/core/widget/TextViewCompat$OreoCallback.mTextView:Landroid/widget/TextView;
            //     4: invokevirtual   android/widget/TextView.getContext:()Landroid/content/Context;
            //     7: astore_2       
            //     8: aload_2        
            //     9: invokevirtual   android/content/Context.getPackageManager:()Landroid/content/pm/PackageManager;
            //    12: astore_3       
            //    13: aload_0        
            //    14: getfield        androidx/core/widget/TextViewCompat$OreoCallback.mInitializedMenuBuilderReferences:Z
            //    17: ifne            87
            //    20: aload_0        
            //    21: iconst_1       
            //    22: putfield        androidx/core/widget/TextViewCompat$OreoCallback.mInitializedMenuBuilderReferences:Z
            //    25: ldc             "com.android.internal.view.menu.MenuBuilder"
            //    27: invokestatic    java/lang/Class.forName:(Ljava/lang/String;)Ljava/lang/Class;
            //    30: astore          14
            //    32: aload_0        
            //    33: aload           14
            //    35: putfield        androidx/core/widget/TextViewCompat$OreoCallback.mMenuBuilderClass:Ljava/lang/Class;
            //    38: iconst_1       
            //    39: anewarray       Ljava/lang/Class;
            //    42: astore          15
            //    44: aload           15
            //    46: iconst_0       
            //    47: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
            //    50: aastore        
            //    51: aload_0        
            //    52: aload           14
            //    54: ldc             "removeItemAt"
            //    56: aload           15
            //    58: invokevirtual   java/lang/Class.getDeclaredMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
            //    61: putfield        androidx/core/widget/TextViewCompat$OreoCallback.mMenuBuilderRemoveItemAtMethod:Ljava/lang/reflect/Method;
            //    64: aload_0        
            //    65: iconst_1       
            //    66: putfield        androidx/core/widget/TextViewCompat$OreoCallback.mCanUseMenuBuilderReferences:Z
            //    69: goto            87
            //    72: aload_0        
            //    73: aconst_null    
            //    74: putfield        androidx/core/widget/TextViewCompat$OreoCallback.mMenuBuilderClass:Ljava/lang/Class;
            //    77: aload_0        
            //    78: aconst_null    
            //    79: putfield        androidx/core/widget/TextViewCompat$OreoCallback.mMenuBuilderRemoveItemAtMethod:Ljava/lang/reflect/Method;
            //    82: aload_0        
            //    83: iconst_0       
            //    84: putfield        androidx/core/widget/TextViewCompat$OreoCallback.mCanUseMenuBuilderReferences:Z
            //    87: aload_0        
            //    88: getfield        androidx/core/widget/TextViewCompat$OreoCallback.mCanUseMenuBuilderReferences:Z
            //    91: ifeq            114
            //    94: aload_0        
            //    95: getfield        androidx/core/widget/TextViewCompat$OreoCallback.mMenuBuilderClass:Ljava/lang/Class;
            //    98: aload_1        
            //    99: invokevirtual   java/lang/Class.isInstance:(Ljava/lang/Object;)Z
            //   102: ifeq            114
            //   105: aload_0        
            //   106: getfield        androidx/core/widget/TextViewCompat$OreoCallback.mMenuBuilderRemoveItemAtMethod:Ljava/lang/reflect/Method;
            //   109: astore          6
            //   111: goto            144
            //   114: aload_1        
            //   115: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
            //   118: astore          4
            //   120: iconst_1       
            //   121: anewarray       Ljava/lang/Class;
            //   124: astore          5
            //   126: aload           5
            //   128: iconst_0       
            //   129: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
            //   132: aastore        
            //   133: aload           4
            //   135: ldc             "removeItemAt"
            //   137: aload           5
            //   139: invokevirtual   java/lang/Class.getDeclaredMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
            //   142: astore          6
            //   144: aload_1        
            //   145: invokeinterface android/view/Menu.size:()I
            //   150: iconst_1       
            //   151: isub           
            //   152: istore          7
            //   154: iload           7
            //   156: iflt            227
            //   159: aload_1        
            //   160: iload           7
            //   162: invokeinterface android/view/Menu.getItem:(I)Landroid/view/MenuItem;
            //   167: astore          11
            //   169: aload           11
            //   171: invokeinterface android/view/MenuItem.getIntent:()Landroid/content/Intent;
            //   176: ifnull          221
            //   179: ldc             "android.intent.action.PROCESS_TEXT"
            //   181: aload           11
            //   183: invokeinterface android/view/MenuItem.getIntent:()Landroid/content/Intent;
            //   188: invokevirtual   android/content/Intent.getAction:()Ljava/lang/String;
            //   191: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
            //   194: ifeq            221
            //   197: iconst_1       
            //   198: anewarray       Ljava/lang/Object;
            //   201: astore          12
            //   203: aload           12
            //   205: iconst_0       
            //   206: iload           7
            //   208: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
            //   211: aastore        
            //   212: aload           6
            //   214: aload_1        
            //   215: aload           12
            //   217: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
            //   220: pop            
            //   221: iinc            7, -1
            //   224: goto            154
            //   227: aload_0        
            //   228: aload_2        
            //   229: aload_3        
            //   230: invokespecial   androidx/core/widget/TextViewCompat$OreoCallback.getSupportedActivities:(Landroid/content/Context;Landroid/content/pm/PackageManager;)Ljava/util/List;
            //   233: astore          8
            //   235: iconst_0       
            //   236: istore          9
            //   238: iload           9
            //   240: aload           8
            //   242: invokeinterface java/util/List.size:()I
            //   247: if_icmpge       310
            //   250: aload           8
            //   252: iload           9
            //   254: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
            //   259: checkcast       Landroid/content/pm/ResolveInfo;
            //   262: astore          10
            //   264: aload_1        
            //   265: iconst_0       
            //   266: iconst_0       
            //   267: iload           9
            //   269: bipush          100
            //   271: iadd           
            //   272: aload           10
            //   274: aload_3        
            //   275: invokevirtual   android/content/pm/ResolveInfo.loadLabel:(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;
            //   278: invokeinterface android/view/Menu.add:(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;
            //   283: aload_0        
            //   284: aload           10
            //   286: aload_0        
            //   287: getfield        androidx/core/widget/TextViewCompat$OreoCallback.mTextView:Landroid/widget/TextView;
            //   290: invokespecial   androidx/core/widget/TextViewCompat$OreoCallback.createProcessTextIntentForResolveInfo:(Landroid/content/pm/ResolveInfo;Landroid/widget/TextView;)Landroid/content/Intent;
            //   293: invokeinterface android/view/MenuItem.setIntent:(Landroid/content/Intent;)Landroid/view/MenuItem;
            //   298: iconst_1       
            //   299: invokeinterface android/view/MenuItem.setShowAsAction:(I)V
            //   304: iinc            9, 1
            //   307: goto            238
            //   310: return         
            //    Exceptions:
            //  Try           Handler
            //  Start  End    Start  End    Type                                         
            //  -----  -----  -----  -----  ---------------------------------------------
            //  25     69     72     87     Ljava/lang/ClassNotFoundException;
            //  25     69     72     87     Ljava/lang/NoSuchMethodException;
            //  87     221    310    311    Ljava/lang/NoSuchMethodException;
            //  87     221    310    311    Ljava/lang/IllegalAccessException;
            //  87     221    310    311    Ljava/lang/reflect/InvocationTargetException;
            // 
            // The error that occurred was:
            // 
            // java.lang.IllegalStateException: Inconsistent stack size at #0087 (coming from #0084).
            //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
            //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
            //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
            //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:576)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
            //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
            //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
            //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
            //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
            //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
            //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
            // 
            throw new IllegalStateException("An error occurred while decompiling this method.");
        }
        
        public boolean onActionItemClicked(final ActionMode actionMode, final MenuItem menuItem) {
            return this.mCallback.onActionItemClicked(actionMode, menuItem);
        }
        
        public boolean onCreateActionMode(final ActionMode actionMode, final Menu menu) {
            return this.mCallback.onCreateActionMode(actionMode, menu);
        }
        
        public void onDestroyActionMode(final ActionMode actionMode) {
            this.mCallback.onDestroyActionMode(actionMode);
        }
        
        public boolean onPrepareActionMode(final ActionMode actionMode, final Menu menu) {
            this.recomputeProcessTextMenuItems(menu);
            return this.mCallback.onPrepareActionMode(actionMode, menu);
        }
    }
}
