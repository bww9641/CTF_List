// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.os;

import android.util.Log;
import android.os.Trace;
import android.os.Build$VERSION;
import java.lang.reflect.Method;

public final class TraceCompat
{
    private static final String TAG = "TraceCompat";
    private static Method sAsyncTraceBeginMethod;
    private static Method sAsyncTraceEndMethod;
    private static Method sIsTagEnabledMethod;
    private static Method sTraceCounterMethod;
    private static long sTraceTagApp;
    
    static {
        if (Build$VERSION.SDK_INT >= 18 && Build$VERSION.SDK_INT < 29) {
            try {
                TraceCompat.sTraceTagApp = Trace.class.getField("TRACE_TAG_APP").getLong(null);
                TraceCompat.sIsTagEnabledMethod = Trace.class.getMethod("isTagEnabled", Long.TYPE);
                TraceCompat.sAsyncTraceBeginMethod = Trace.class.getMethod("asyncTraceBegin", Long.TYPE, String.class, Integer.TYPE);
                TraceCompat.sAsyncTraceEndMethod = Trace.class.getMethod("asyncTraceEnd", Long.TYPE, String.class, Integer.TYPE);
                TraceCompat.sTraceCounterMethod = Trace.class.getMethod("traceCounter", Long.TYPE, String.class, Integer.TYPE);
            }
            catch (Exception ex) {
                Log.i("TraceCompat", "Unable to initialize via reflection.", (Throwable)ex);
            }
        }
    }
    
    private TraceCompat() {
    }
    
    public static void beginAsyncSection(final String p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          29
        //     5: if_icmplt       16
        //     8: aload_0        
        //     9: iload_1        
        //    10: invokestatic    android/os/Trace.beginAsyncSection:(Ljava/lang/String;I)V
        //    13: goto            76
        //    16: getstatic       android/os/Build$VERSION.SDK_INT:I
        //    19: bipush          18
        //    21: if_icmplt       76
        //    24: getstatic       androidx/core/os/TraceCompat.sAsyncTraceBeginMethod:Ljava/lang/reflect/Method;
        //    27: astore_3       
        //    28: iconst_3       
        //    29: anewarray       Ljava/lang/Object;
        //    32: astore          4
        //    34: aload           4
        //    36: iconst_0       
        //    37: getstatic       androidx/core/os/TraceCompat.sTraceTagApp:J
        //    40: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    43: aastore        
        //    44: aload           4
        //    46: iconst_1       
        //    47: aload_0        
        //    48: aastore        
        //    49: aload           4
        //    51: iconst_2       
        //    52: iload_1        
        //    53: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //    56: aastore        
        //    57: aload_3        
        //    58: aconst_null    
        //    59: aload           4
        //    61: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //    64: pop            
        //    65: goto            76
        //    68: ldc             "TraceCompat"
        //    70: ldc             "Unable to invoke asyncTraceBegin() via reflection."
        //    72: invokestatic    android/util/Log.v:(Ljava/lang/String;Ljava/lang/String;)I
        //    75: pop            
        //    76: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  24     65     68     76     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0076 (coming from #0075).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void beginSection(final String s) {
        if (Build$VERSION.SDK_INT >= 18) {
            Trace.beginSection(s);
        }
    }
    
    public static void endAsyncSection(final String p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          29
        //     5: if_icmplt       16
        //     8: aload_0        
        //     9: iload_1        
        //    10: invokestatic    android/os/Trace.endAsyncSection:(Ljava/lang/String;I)V
        //    13: goto            76
        //    16: getstatic       android/os/Build$VERSION.SDK_INT:I
        //    19: bipush          18
        //    21: if_icmplt       76
        //    24: getstatic       androidx/core/os/TraceCompat.sAsyncTraceEndMethod:Ljava/lang/reflect/Method;
        //    27: astore_3       
        //    28: iconst_3       
        //    29: anewarray       Ljava/lang/Object;
        //    32: astore          4
        //    34: aload           4
        //    36: iconst_0       
        //    37: getstatic       androidx/core/os/TraceCompat.sTraceTagApp:J
        //    40: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    43: aastore        
        //    44: aload           4
        //    46: iconst_1       
        //    47: aload_0        
        //    48: aastore        
        //    49: aload           4
        //    51: iconst_2       
        //    52: iload_1        
        //    53: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //    56: aastore        
        //    57: aload_3        
        //    58: aconst_null    
        //    59: aload           4
        //    61: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //    64: pop            
        //    65: goto            76
        //    68: ldc             "TraceCompat"
        //    70: ldc             "Unable to invoke endAsyncSection() via reflection."
        //    72: invokestatic    android/util/Log.v:(Ljava/lang/String;Ljava/lang/String;)I
        //    75: pop            
        //    76: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  24     65     68     76     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0076 (coming from #0075).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void endSection() {
        if (Build$VERSION.SDK_INT >= 18) {
            Trace.endSection();
        }
    }
    
    public static boolean isEnabled() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          29
        //     5: if_icmplt       12
        //     8: invokestatic    android/os/Trace.isEnabled:()Z
        //    11: ireturn        
        //    12: getstatic       android/os/Build$VERSION.SDK_INT:I
        //    15: bipush          18
        //    17: if_icmplt       61
        //    20: getstatic       androidx/core/os/TraceCompat.sIsTagEnabledMethod:Ljava/lang/reflect/Method;
        //    23: astore_1       
        //    24: iconst_1       
        //    25: anewarray       Ljava/lang/Object;
        //    28: astore_2       
        //    29: aload_2        
        //    30: iconst_0       
        //    31: getstatic       androidx/core/os/TraceCompat.sTraceTagApp:J
        //    34: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    37: aastore        
        //    38: aload_1        
        //    39: aconst_null    
        //    40: aload_2        
        //    41: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //    44: checkcast       Ljava/lang/Boolean;
        //    47: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //    50: istore_3       
        //    51: iload_3        
        //    52: ireturn        
        //    53: ldc             "TraceCompat"
        //    55: ldc             "Unable to invoke isTagEnabled() via reflection."
        //    57: invokestatic    android/util/Log.v:(Ljava/lang/String;Ljava/lang/String;)I
        //    60: pop            
        //    61: iconst_0       
        //    62: ireturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  20     51     53     61     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0061 (coming from #0060).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void setCounter(final String p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          29
        //     5: if_icmplt       17
        //     8: aload_0        
        //     9: iload_1        
        //    10: i2l            
        //    11: invokestatic    android/os/Trace.setCounter:(Ljava/lang/String;J)V
        //    14: goto            77
        //    17: getstatic       android/os/Build$VERSION.SDK_INT:I
        //    20: bipush          18
        //    22: if_icmplt       77
        //    25: getstatic       androidx/core/os/TraceCompat.sTraceCounterMethod:Ljava/lang/reflect/Method;
        //    28: astore_3       
        //    29: iconst_3       
        //    30: anewarray       Ljava/lang/Object;
        //    33: astore          4
        //    35: aload           4
        //    37: iconst_0       
        //    38: getstatic       androidx/core/os/TraceCompat.sTraceTagApp:J
        //    41: invokestatic    java/lang/Long.valueOf:(J)Ljava/lang/Long;
        //    44: aastore        
        //    45: aload           4
        //    47: iconst_1       
        //    48: aload_0        
        //    49: aastore        
        //    50: aload           4
        //    52: iconst_2       
        //    53: iload_1        
        //    54: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //    57: aastore        
        //    58: aload_3        
        //    59: aconst_null    
        //    60: aload           4
        //    62: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //    65: pop            
        //    66: goto            77
        //    69: ldc             "TraceCompat"
        //    71: ldc             "Unable to invoke traceCounter() via reflection."
        //    73: invokestatic    android/util/Log.v:(Ljava/lang/String;Ljava/lang/String;)I
        //    76: pop            
        //    77: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  25     66     69     77     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0077 (coming from #0076).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
