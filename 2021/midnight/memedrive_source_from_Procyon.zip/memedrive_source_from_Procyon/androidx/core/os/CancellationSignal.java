// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.os;

import android.os.Build$VERSION;

public final class CancellationSignal
{
    private boolean mCancelInProgress;
    private Object mCancellationSignalObj;
    private boolean mIsCanceled;
    private OnCancelListener mOnCancelListener;
    
    private void waitForCancelFinishedLocked() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        androidx/core/os/CancellationSignal.mCancelInProgress:Z
        //     4: ifeq            17
        //     7: aload_0        
        //     8: invokevirtual   java/lang/Object.wait:()V
        //    11: goto            0
        //    14: goto            0
        //    17: return         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  7      11     14     17     Ljava/lang/InterruptedException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0000 (coming from #0014).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void cancel() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: monitorenter   
        //     2: aload_0        
        //     3: getfield        androidx/core/os/CancellationSignal.mIsCanceled:Z
        //     6: ifeq            12
        //     9: aload_0        
        //    10: monitorexit    
        //    11: return         
        //    12: aload_0        
        //    13: iconst_1       
        //    14: putfield        androidx/core/os/CancellationSignal.mIsCanceled:Z
        //    17: aload_0        
        //    18: iconst_1       
        //    19: putfield        androidx/core/os/CancellationSignal.mCancelInProgress:Z
        //    22: aload_0        
        //    23: getfield        androidx/core/os/CancellationSignal.mOnCancelListener:Landroidx/core/os/CancellationSignal$OnCancelListener;
        //    26: astore_2       
        //    27: aload_0        
        //    28: getfield        androidx/core/os/CancellationSignal.mCancellationSignalObj:Ljava/lang/Object;
        //    31: astore_3       
        //    32: aload_0        
        //    33: monitorexit    
        //    34: aload_2        
        //    35: ifnull          47
        //    38: aload_2        
        //    39: invokeinterface androidx/core/os/CancellationSignal$OnCancelListener.onCancel:()V
        //    44: goto            47
        //    47: aload_3        
        //    48: ifnull          92
        //    51: getstatic       android/os/Build$VERSION.SDK_INT:I
        //    54: bipush          16
        //    56: if_icmplt       92
        //    59: aload_3        
        //    60: checkcast       Landroid/os/CancellationSignal;
        //    63: invokevirtual   android/os/CancellationSignal.cancel:()V
        //    66: goto            92
        //    69: aload_0        
        //    70: monitorenter   
        //    71: aload_0        
        //    72: iconst_0       
        //    73: putfield        androidx/core/os/CancellationSignal.mCancelInProgress:Z
        //    76: aload_0        
        //    77: invokevirtual   java/lang/Object.notifyAll:()V
        //    80: aload_0        
        //    81: monitorexit    
        //    82: aload           5
        //    84: athrow         
        //    85: astore          6
        //    87: aload_0        
        //    88: monitorexit    
        //    89: aload           6
        //    91: athrow         
        //    92: aload_0        
        //    93: monitorenter   
        //    94: aload_0        
        //    95: iconst_0       
        //    96: putfield        androidx/core/os/CancellationSignal.mCancelInProgress:Z
        //    99: aload_0        
        //   100: invokevirtual   java/lang/Object.notifyAll:()V
        //   103: aload_0        
        //   104: monitorexit    
        //   105: return         
        //   106: astore          4
        //   108: aload_0        
        //   109: monitorexit    
        //   110: aload           4
        //   112: athrow         
        //   113: astore_1       
        //   114: aload_0        
        //   115: monitorexit    
        //   116: aload_1        
        //   117: athrow         
        //   118: astore          5
        //   120: goto            69
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  2      34     113    118    Any
        //  38     66     118    92     Any
        //  71     82     85     92     Any
        //  87     89     85     92     Any
        //  94     110    106    113    Any
        //  114    116    113    118    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0047:
        //     at com.strobel.decompiler.ast.Error.expressionLinkedFromMultipleLocations(Error.java:27)
        //     at com.strobel.decompiler.ast.AstOptimizer.mergeDisparateObjectInitializations(AstOptimizer.java:2596)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:235)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public Object getCancellationSignalObject() {
        if (Build$VERSION.SDK_INT < 16) {
            return null;
        }
        synchronized (this) {
            if (this.mCancellationSignalObj == null) {
                final android.os.CancellationSignal mCancellationSignalObj = new android.os.CancellationSignal();
                this.mCancellationSignalObj = mCancellationSignalObj;
                if (this.mIsCanceled) {
                    mCancellationSignalObj.cancel();
                }
            }
            return this.mCancellationSignalObj;
        }
    }
    
    public boolean isCanceled() {
        synchronized (this) {
            return this.mIsCanceled;
        }
    }
    
    public void setOnCancelListener(final OnCancelListener mOnCancelListener) {
        synchronized (this) {
            this.waitForCancelFinishedLocked();
            if (this.mOnCancelListener == mOnCancelListener) {
                return;
            }
            this.mOnCancelListener = mOnCancelListener;
            if (this.mIsCanceled && mOnCancelListener != null) {
                // monitorexit(this)
                mOnCancelListener.onCancel();
            }
        }
    }
    
    public void throwIfCanceled() {
        if (!this.isCanceled()) {
            return;
        }
        throw new OperationCanceledException();
    }
    
    public interface OnCancelListener
    {
        void onCancel();
    }
}
