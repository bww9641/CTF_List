// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.os;

import android.os.Message;
import android.os.Build$VERSION;
import android.os.Handler$Callback;
import android.os.Handler;
import android.os.Looper;

public final class HandlerCompat
{
    private static final String TAG = "HandlerCompat";
    
    private HandlerCompat() {
    }
    
    public static Handler createAsync(final Looper p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          28
        //     5: if_icmplt       13
        //     8: aload_0        
        //     9: invokestatic    android/os/Handler.createAsync:(Landroid/os/Looper;)Landroid/os/Handler;
        //    12: areturn        
        //    13: getstatic       android/os/Build$VERSION.SDK_INT:I
        //    16: bipush          16
        //    18: if_icmplt       141
        //    21: iconst_3       
        //    22: anewarray       Ljava/lang/Class;
        //    25: astore          4
        //    27: aload           4
        //    29: iconst_0       
        //    30: ldc             Landroid/os/Looper;.class
        //    32: aastore        
        //    33: aload           4
        //    35: iconst_1       
        //    36: ldc             Landroid/os/Handler$Callback;.class
        //    38: aastore        
        //    39: aload           4
        //    41: iconst_2       
        //    42: getstatic       java/lang/Boolean.TYPE:Ljava/lang/Class;
        //    45: aastore        
        //    46: ldc             Landroid/os/Handler;.class
        //    48: aload           4
        //    50: invokevirtual   java/lang/Class.getDeclaredConstructor:([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
        //    53: astore          5
        //    55: iconst_3       
        //    56: anewarray       Ljava/lang/Object;
        //    59: astore          6
        //    61: aload           6
        //    63: iconst_0       
        //    64: aload_0        
        //    65: aastore        
        //    66: aload           6
        //    68: iconst_1       
        //    69: aconst_null    
        //    70: aastore        
        //    71: aload           6
        //    73: iconst_2       
        //    74: iconst_1       
        //    75: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //    78: aastore        
        //    79: aload           5
        //    81: aload           6
        //    83: invokevirtual   java/lang/reflect/Constructor.newInstance:([Ljava/lang/Object;)Ljava/lang/Object;
        //    86: checkcast       Landroid/os/Handler;
        //    89: astore          7
        //    91: aload           7
        //    93: areturn        
        //    94: astore_2       
        //    95: aload_2        
        //    96: invokevirtual   java/lang/reflect/InvocationTargetException.getCause:()Ljava/lang/Throwable;
        //    99: astore_3       
        //   100: aload_3        
        //   101: instanceof      Ljava/lang/RuntimeException;
        //   104: ifne            128
        //   107: aload_3        
        //   108: instanceof      Ljava/lang/Error;
        //   111: ifeq            119
        //   114: aload_3        
        //   115: checkcast       Ljava/lang/Error;
        //   118: athrow         
        //   119: new             Ljava/lang/RuntimeException;
        //   122: dup            
        //   123: aload_3        
        //   124: invokespecial   java/lang/RuntimeException.<init>:(Ljava/lang/Throwable;)V
        //   127: athrow         
        //   128: aload_3        
        //   129: checkcast       Ljava/lang/RuntimeException;
        //   132: athrow         
        //   133: ldc             "HandlerCompat"
        //   135: ldc             "Unable to invoke Handler(Looper, Callback, boolean) constructor"
        //   137: invokestatic    android/util/Log.v:(Ljava/lang/String;Ljava/lang/String;)I
        //   140: pop            
        //   141: new             Landroid/os/Handler;
        //   144: dup            
        //   145: aload_0        
        //   146: invokespecial   android/os/Handler.<init>:(Landroid/os/Looper;)V
        //   149: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                         
        //  -----  -----  -----  -----  ---------------------------------------------
        //  21     91     133    141    Ljava/lang/IllegalAccessException;
        //  21     91     133    141    Ljava/lang/InstantiationException;
        //  21     91     133    141    Ljava/lang/NoSuchMethodException;
        //  21     91     94     133    Ljava/lang/reflect/InvocationTargetException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0141 (coming from #0140).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static Handler createAsync(final Looper p0, final Handler$Callback p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          28
        //     5: if_icmplt       14
        //     8: aload_0        
        //     9: aload_1        
        //    10: invokestatic    android/os/Handler.createAsync:(Landroid/os/Looper;Landroid/os/Handler$Callback;)Landroid/os/Handler;
        //    13: areturn        
        //    14: getstatic       android/os/Build$VERSION.SDK_INT:I
        //    17: bipush          16
        //    19: if_icmplt       148
        //    22: iconst_3       
        //    23: anewarray       Ljava/lang/Class;
        //    26: astore          5
        //    28: aload           5
        //    30: iconst_0       
        //    31: ldc             Landroid/os/Looper;.class
        //    33: aastore        
        //    34: aload           5
        //    36: iconst_1       
        //    37: ldc             Landroid/os/Handler$Callback;.class
        //    39: aastore        
        //    40: aload           5
        //    42: iconst_2       
        //    43: getstatic       java/lang/Boolean.TYPE:Ljava/lang/Class;
        //    46: aastore        
        //    47: ldc             Landroid/os/Handler;.class
        //    49: aload           5
        //    51: invokevirtual   java/lang/Class.getDeclaredConstructor:([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
        //    54: astore          6
        //    56: iconst_3       
        //    57: anewarray       Ljava/lang/Object;
        //    60: astore          7
        //    62: aload           7
        //    64: iconst_0       
        //    65: aload_0        
        //    66: aastore        
        //    67: aload           7
        //    69: iconst_1       
        //    70: aload_1        
        //    71: aastore        
        //    72: aload           7
        //    74: iconst_2       
        //    75: iconst_1       
        //    76: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //    79: aastore        
        //    80: aload           6
        //    82: aload           7
        //    84: invokevirtual   java/lang/reflect/Constructor.newInstance:([Ljava/lang/Object;)Ljava/lang/Object;
        //    87: checkcast       Landroid/os/Handler;
        //    90: astore          8
        //    92: aload           8
        //    94: areturn        
        //    95: astore_3       
        //    96: aload_3        
        //    97: invokevirtual   java/lang/reflect/InvocationTargetException.getCause:()Ljava/lang/Throwable;
        //   100: astore          4
        //   102: aload           4
        //   104: instanceof      Ljava/lang/RuntimeException;
        //   107: ifne            134
        //   110: aload           4
        //   112: instanceof      Ljava/lang/Error;
        //   115: ifeq            124
        //   118: aload           4
        //   120: checkcast       Ljava/lang/Error;
        //   123: athrow         
        //   124: new             Ljava/lang/RuntimeException;
        //   127: dup            
        //   128: aload           4
        //   130: invokespecial   java/lang/RuntimeException.<init>:(Ljava/lang/Throwable;)V
        //   133: athrow         
        //   134: aload           4
        //   136: checkcast       Ljava/lang/RuntimeException;
        //   139: athrow         
        //   140: ldc             "HandlerCompat"
        //   142: ldc             "Unable to invoke Handler(Looper, Callback, boolean) constructor"
        //   144: invokestatic    android/util/Log.v:(Ljava/lang/String;Ljava/lang/String;)I
        //   147: pop            
        //   148: new             Landroid/os/Handler;
        //   151: dup            
        //   152: aload_0        
        //   153: aload_1        
        //   154: invokespecial   android/os/Handler.<init>:(Landroid/os/Looper;Landroid/os/Handler$Callback;)V
        //   157: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                         
        //  -----  -----  -----  -----  ---------------------------------------------
        //  22     92     140    148    Ljava/lang/IllegalAccessException;
        //  22     92     140    148    Ljava/lang/InstantiationException;
        //  22     92     140    148    Ljava/lang/NoSuchMethodException;
        //  22     92     95     140    Ljava/lang/reflect/InvocationTargetException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0148 (coming from #0147).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean postDelayed(final Handler handler, final Runnable runnable, final Object obj, final long n) {
        if (Build$VERSION.SDK_INT >= 28) {
            return handler.postDelayed(runnable, obj, n);
        }
        final Message obtain = Message.obtain(handler, runnable);
        obtain.obj = obj;
        return handler.sendMessageDelayed(obtain, n);
    }
}
