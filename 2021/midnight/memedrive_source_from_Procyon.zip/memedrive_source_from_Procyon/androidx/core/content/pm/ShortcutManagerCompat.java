// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.content.pm;

import android.os.Bundle;
import android.content.IntentSender$SendIntentException;
import android.os.Handler;
import android.content.IntentSender$OnFinished;
import android.content.BroadcastReceiver;
import android.content.IntentSender;
import android.text.TextUtils;
import android.content.pm.ResolveInfo;
import androidx.core.content.ContextCompat;
import android.content.Intent;
import java.util.Iterator;
import android.content.pm.ShortcutManager;
import android.content.pm.ShortcutInfo;
import java.util.ArrayList;
import android.os.Build$VERSION;
import java.util.List;
import android.content.Context;

public class ShortcutManagerCompat
{
    static final String ACTION_INSTALL_SHORTCUT = "com.android.launcher.action.INSTALL_SHORTCUT";
    public static final String EXTRA_SHORTCUT_ID = "android.intent.extra.shortcut.ID";
    static final String INSTALL_SHORTCUT_PERMISSION = "com.android.launcher.permission.INSTALL_SHORTCUT";
    private static volatile ShortcutInfoCompatSaver<?> sShortcutInfoCompatSaver;
    
    private ShortcutManagerCompat() {
    }
    
    public static boolean addDynamicShortcuts(final Context context, final List<ShortcutInfoCompat> list) {
        if (Build$VERSION.SDK_INT >= 25) {
            final ArrayList<ShortcutInfo> list2 = new ArrayList<ShortcutInfo>();
            final Iterator<ShortcutInfoCompat> iterator = list.iterator();
            while (iterator.hasNext()) {
                list2.add(iterator.next().toShortcutInfo());
            }
            if (!((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).addDynamicShortcuts((List)list2)) {
                return false;
            }
        }
        getShortcutInfoSaverInstance(context).addShortcuts(list);
        return true;
    }
    
    public static Intent createShortcutResultIntent(final Context context, final ShortcutInfoCompat shortcutInfoCompat) {
        Intent shortcutResultIntent;
        if (Build$VERSION.SDK_INT >= 26) {
            shortcutResultIntent = ((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).createShortcutResultIntent(shortcutInfoCompat.toShortcutInfo());
        }
        else {
            shortcutResultIntent = null;
        }
        if (shortcutResultIntent == null) {
            shortcutResultIntent = new Intent();
        }
        return shortcutInfoCompat.addToIntent(shortcutResultIntent);
    }
    
    public static List<ShortcutInfoCompat> getDynamicShortcuts(final Context context) {
        if (Build$VERSION.SDK_INT >= 25) {
            final List dynamicShortcuts = ((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).getDynamicShortcuts();
            final ArrayList list = new ArrayList<ShortcutInfoCompat>(dynamicShortcuts.size());
            final Iterator<ShortcutInfo> iterator = dynamicShortcuts.iterator();
            while (iterator.hasNext()) {
                list.add(new ShortcutInfoCompat.Builder(context, iterator.next()).build());
            }
            return (List<ShortcutInfoCompat>)list;
        }
        try {
            return getShortcutInfoSaverInstance(context).getShortcuts();
        }
        catch (Exception ex) {
            return new ArrayList<ShortcutInfoCompat>();
        }
    }
    
    public static int getMaxShortcutCountPerActivity(final Context context) {
        if (Build$VERSION.SDK_INT >= 25) {
            return ((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).getMaxShortcutCountPerActivity();
        }
        return 0;
    }
    
    private static ShortcutInfoCompatSaver<?> getShortcutInfoSaverInstance(final Context p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: ifnonnull       76
        //     6: getstatic       android/os/Build$VERSION.SDK_INT:I
        //     9: bipush          23
        //    11: if_icmplt       60
        //    14: ldc             "androidx.sharetarget.ShortcutInfoCompatSaverImpl"
        //    16: iconst_0       
        //    17: ldc             Landroidx/core/content/pm/ShortcutManagerCompat;.class
        //    19: invokevirtual   java/lang/Class.getClassLoader:()Ljava/lang/ClassLoader;
        //    22: invokestatic    java/lang/Class.forName:(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
        //    25: ldc             "getInstance"
        //    27: iconst_1       
        //    28: anewarray       Ljava/lang/Class;
        //    31: dup            
        //    32: iconst_0       
        //    33: ldc             Landroid/content/Context;.class
        //    35: aastore        
        //    36: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //    39: aconst_null    
        //    40: iconst_1       
        //    41: anewarray       Ljava/lang/Object;
        //    44: dup            
        //    45: iconst_0       
        //    46: aload_0        
        //    47: aastore        
        //    48: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //    51: checkcast       Landroidx/core/content/pm/ShortcutInfoCompatSaver;
        //    54: putstatic       androidx/core/content/pm/ShortcutManagerCompat.sShortcutInfoCompatSaver:Landroidx/core/content/pm/ShortcutInfoCompatSaver;
        //    57: goto            60
        //    60: getstatic       androidx/core/content/pm/ShortcutManagerCompat.sShortcutInfoCompatSaver:Landroidx/core/content/pm/ShortcutInfoCompatSaver;
        //    63: ifnonnull       76
        //    66: new             Landroidx/core/content/pm/ShortcutInfoCompatSaver$NoopImpl;
        //    69: dup            
        //    70: invokespecial   androidx/core/content/pm/ShortcutInfoCompatSaver$NoopImpl.<init>:()V
        //    73: putstatic       androidx/core/content/pm/ShortcutManagerCompat.sShortcutInfoCompatSaver:Landroidx/core/content/pm/ShortcutInfoCompatSaver;
        //    76: getstatic       androidx/core/content/pm/ShortcutManagerCompat.sShortcutInfoCompatSaver:Landroidx/core/content/pm/ShortcutInfoCompatSaver;
        //    79: areturn        
        //    Signature:
        //  (Landroid/content/Context;)Landroidx/core/content/pm/ShortcutInfoCompatSaver<*>;
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  14     57     60     76     Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0076 (coming from #0063).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static boolean isRequestPinShortcutSupported(final Context context) {
        if (Build$VERSION.SDK_INT >= 26) {
            return ((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).isRequestPinShortcutSupported();
        }
        if (ContextCompat.checkSelfPermission(context, "com.android.launcher.permission.INSTALL_SHORTCUT") != 0) {
            return false;
        }
        final Iterator<ResolveInfo> iterator = context.getPackageManager().queryBroadcastReceivers(new Intent("com.android.launcher.action.INSTALL_SHORTCUT"), 0).iterator();
        while (iterator.hasNext()) {
            final String permission = iterator.next().activityInfo.permission;
            if (TextUtils.isEmpty((CharSequence)permission) || "com.android.launcher.permission.INSTALL_SHORTCUT".equals(permission)) {
                return true;
            }
        }
        return false;
    }
    
    public static void removeAllDynamicShortcuts(final Context context) {
        if (Build$VERSION.SDK_INT >= 25) {
            ((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).removeAllDynamicShortcuts();
        }
        getShortcutInfoSaverInstance(context).removeAllShortcuts();
    }
    
    public static void removeDynamicShortcuts(final Context context, final List<String> list) {
        if (Build$VERSION.SDK_INT >= 25) {
            ((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).removeDynamicShortcuts((List)list);
        }
        getShortcutInfoSaverInstance(context).removeShortcuts(list);
    }
    
    public static boolean requestPinShortcut(final Context context, final ShortcutInfoCompat shortcutInfoCompat, final IntentSender intentSender) {
        if (Build$VERSION.SDK_INT >= 26) {
            return ((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).requestPinShortcut(shortcutInfoCompat.toShortcutInfo(), intentSender);
        }
        if (!isRequestPinShortcutSupported(context)) {
            return false;
        }
        final Intent addToIntent = shortcutInfoCompat.addToIntent(new Intent("com.android.launcher.action.INSTALL_SHORTCUT"));
        if (intentSender == null) {
            context.sendBroadcast(addToIntent);
            return true;
        }
        context.sendOrderedBroadcast(addToIntent, (String)null, (BroadcastReceiver)new BroadcastReceiver() {
            public void onReceive(final Context context, final Intent intent) {
                try {
                    intentSender.sendIntent(context, 0, (Intent)null, (IntentSender$OnFinished)null, (Handler)null);
                }
                catch (IntentSender$SendIntentException ex) {}
            }
        }, (Handler)null, -1, (String)null, (Bundle)null);
        return true;
    }
    
    public static boolean updateShortcuts(final Context context, final List<ShortcutInfoCompat> list) {
        if (Build$VERSION.SDK_INT >= 25) {
            final ArrayList<ShortcutInfo> list2 = new ArrayList<ShortcutInfo>();
            final Iterator<ShortcutInfoCompat> iterator = list.iterator();
            while (iterator.hasNext()) {
                list2.add(iterator.next().toShortcutInfo());
            }
            if (!((ShortcutManager)context.getSystemService((Class)ShortcutManager.class)).updateShortcuts((List)list2)) {
                return false;
            }
        }
        getShortcutInfoSaverInstance(context).addShortcuts(list);
        return true;
    }
}
