// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.content.pm;

import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.Annotation;
import android.os.Build$VERSION;
import android.content.pm.PermissionInfo;

public final class PermissionInfoCompat
{
    private PermissionInfoCompat() {
    }
    
    public static int getProtection(final PermissionInfo permissionInfo) {
        if (Build$VERSION.SDK_INT >= 28) {
            return permissionInfo.getProtection();
        }
        return 0xF & permissionInfo.protectionLevel;
    }
    
    public static int getProtectionFlags(final PermissionInfo permissionInfo) {
        if (Build$VERSION.SDK_INT >= 28) {
            return permissionInfo.getProtectionFlags();
        }
        return 0xFFFFFFF0 & permissionInfo.protectionLevel;
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface Protection {
    }
    
    @Retention(RetentionPolicy.SOURCE)
    public @interface ProtectionFlags {
    }
}
