// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.content.pm;

import java.util.Collection;
import java.util.HashSet;
import android.os.Build$VERSION;
import android.text.TextUtils;
import android.content.pm.ShortcutInfo$Builder;
import android.content.pm.ShortcutInfo;
import java.util.Arrays;
import android.os.PersistableBundle;
import androidx.core.app.Person;
import android.content.Intent;
import androidx.core.graphics.drawable.IconCompat;
import android.content.Context;
import java.util.Set;
import android.content.ComponentName;

public class ShortcutInfoCompat
{
    private static final String EXTRA_LONG_LIVED = "extraLongLived";
    private static final String EXTRA_PERSON_ = "extraPerson_";
    private static final String EXTRA_PERSON_COUNT = "extraPersonCount";
    ComponentName mActivity;
    Set<String> mCategories;
    Context mContext;
    CharSequence mDisabledMessage;
    IconCompat mIcon;
    String mId;
    Intent[] mIntents;
    boolean mIsAlwaysBadged;
    boolean mIsLongLived;
    CharSequence mLabel;
    CharSequence mLongLabel;
    Person[] mPersons;
    int mRank;
    
    ShortcutInfoCompat() {
    }
    
    private PersistableBundle buildLegacyExtrasBundle() {
        final PersistableBundle persistableBundle = new PersistableBundle();
        final Person[] mPersons = this.mPersons;
        if (mPersons != null && mPersons.length > 0) {
            persistableBundle.putInt("extraPersonCount", mPersons.length);
            int j;
            for (int i = 0; i < this.mPersons.length; i = j) {
                final StringBuilder sb = new StringBuilder();
                sb.append("extraPerson_");
                j = i + 1;
                sb.append(j);
                persistableBundle.putPersistableBundle(sb.toString(), this.mPersons[i].toPersistableBundle());
            }
        }
        persistableBundle.putBoolean("extraLongLived", this.mIsLongLived);
        return persistableBundle;
    }
    
    static boolean getLongLivedFromExtra(final PersistableBundle persistableBundle) {
        return persistableBundle != null && persistableBundle.containsKey("extraLongLived") && persistableBundle.getBoolean("extraLongLived");
    }
    
    static Person[] getPersonsFromExtra(final PersistableBundle persistableBundle) {
        if (persistableBundle != null && persistableBundle.containsKey("extraPersonCount")) {
            final int int1 = persistableBundle.getInt("extraPersonCount");
            final Person[] array = new Person[int1];
            int j;
            for (int i = 0; i < int1; i = j) {
                final StringBuilder sb = new StringBuilder();
                sb.append("extraPerson_");
                j = i + 1;
                sb.append(j);
                array[i] = Person.fromPersistableBundle(persistableBundle.getPersistableBundle(sb.toString()));
            }
            return array;
        }
        return null;
    }
    
    Intent addToIntent(final Intent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     4: astore_2       
        //     5: aload_1        
        //     6: ldc             "android.intent.extra.shortcut.INTENT"
        //     8: aload_2        
        //     9: iconst_m1      
        //    10: aload_2        
        //    11: arraylength    
        //    12: iadd           
        //    13: aaload         
        //    14: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
        //    17: ldc             "android.intent.extra.shortcut.NAME"
        //    19: aload_0        
        //    20: getfield        androidx/core/content/pm/ShortcutInfoCompat.mLabel:Ljava/lang/CharSequence;
        //    23: invokeinterface java/lang/CharSequence.toString:()Ljava/lang/String;
        //    28: invokevirtual   android/content/Intent.putExtra:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
        //    31: pop            
        //    32: aload_0        
        //    33: getfield        androidx/core/content/pm/ShortcutInfoCompat.mIcon:Landroidx/core/graphics/drawable/IconCompat;
        //    36: ifnull          121
        //    39: aload_0        
        //    40: getfield        androidx/core/content/pm/ShortcutInfoCompat.mIsAlwaysBadged:Z
        //    43: istore          4
        //    45: aconst_null    
        //    46: astore          5
        //    48: iload           4
        //    50: ifeq            107
        //    53: aload_0        
        //    54: getfield        androidx/core/content/pm/ShortcutInfoCompat.mContext:Landroid/content/Context;
        //    57: invokevirtual   android/content/Context.getPackageManager:()Landroid/content/pm/PackageManager;
        //    60: astore          6
        //    62: aload_0        
        //    63: getfield        androidx/core/content/pm/ShortcutInfoCompat.mActivity:Landroid/content/ComponentName;
        //    66: astore          7
        //    68: aconst_null    
        //    69: astore          5
        //    71: aload           7
        //    73: ifnull          88
        //    76: aload           6
        //    78: aload           7
        //    80: invokevirtual   android/content/pm/PackageManager.getActivityIcon:(Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;
        //    83: astore          5
        //    85: goto            88
        //    88: aload           5
        //    90: ifnonnull       107
        //    93: aload_0        
        //    94: getfield        androidx/core/content/pm/ShortcutInfoCompat.mContext:Landroid/content/Context;
        //    97: invokevirtual   android/content/Context.getApplicationInfo:()Landroid/content/pm/ApplicationInfo;
        //   100: aload           6
        //   102: invokevirtual   android/content/pm/ApplicationInfo.loadIcon:(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;
        //   105: astore          5
        //   107: aload_0        
        //   108: getfield        androidx/core/content/pm/ShortcutInfoCompat.mIcon:Landroidx/core/graphics/drawable/IconCompat;
        //   111: aload_1        
        //   112: aload           5
        //   114: aload_0        
        //   115: getfield        androidx/core/content/pm/ShortcutInfoCompat.mContext:Landroid/content/Context;
        //   118: invokevirtual   androidx/core/graphics/drawable/IconCompat.addToShortcutIntent:(Landroid/content/Intent;Landroid/graphics/drawable/Drawable;Landroid/content/Context;)V
        //   121: aload_1        
        //   122: areturn        
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                     
        //  -----  -----  -----  -----  ---------------------------------------------------------
        //  76     85     88     107    Landroid/content/pm/PackageManager$NameNotFoundException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0107 (coming from #0090).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public ComponentName getActivity() {
        return this.mActivity;
    }
    
    public Set<String> getCategories() {
        return this.mCategories;
    }
    
    public CharSequence getDisabledMessage() {
        return this.mDisabledMessage;
    }
    
    public IconCompat getIcon() {
        return this.mIcon;
    }
    
    public String getId() {
        return this.mId;
    }
    
    public Intent getIntent() {
        final Intent[] mIntents = this.mIntents;
        return mIntents[-1 + mIntents.length];
    }
    
    public Intent[] getIntents() {
        final Intent[] mIntents = this.mIntents;
        return Arrays.copyOf(mIntents, mIntents.length);
    }
    
    public CharSequence getLongLabel() {
        return this.mLongLabel;
    }
    
    public int getRank() {
        return this.mRank;
    }
    
    public CharSequence getShortLabel() {
        return this.mLabel;
    }
    
    public ShortcutInfo toShortcutInfo() {
        final ShortcutInfo$Builder setIntents = new ShortcutInfo$Builder(this.mContext, this.mId).setShortLabel(this.mLabel).setIntents(this.mIntents);
        final IconCompat mIcon = this.mIcon;
        if (mIcon != null) {
            setIntents.setIcon(mIcon.toIcon(this.mContext));
        }
        if (!TextUtils.isEmpty(this.mLongLabel)) {
            setIntents.setLongLabel(this.mLongLabel);
        }
        if (!TextUtils.isEmpty(this.mDisabledMessage)) {
            setIntents.setDisabledMessage(this.mDisabledMessage);
        }
        final ComponentName mActivity = this.mActivity;
        if (mActivity != null) {
            setIntents.setActivity(mActivity);
        }
        final Set<String> mCategories = this.mCategories;
        if (mCategories != null) {
            setIntents.setCategories((Set)mCategories);
        }
        setIntents.setRank(this.mRank);
        if (Build$VERSION.SDK_INT >= 29) {
            final Person[] mPersons = this.mPersons;
            if (mPersons != null && mPersons.length > 0) {
                final int length = mPersons.length;
                final android.app.Person[] persons = new android.app.Person[length];
                for (int i = 0; i < length; ++i) {
                    persons[i] = this.mPersons[i].toAndroidPerson();
                }
                setIntents.setPersons(persons);
            }
            setIntents.setLongLived(this.mIsLongLived);
        }
        else {
            setIntents.setExtras(this.buildLegacyExtrasBundle());
        }
        return setIntents.build();
    }
    
    public static class Builder
    {
        private final ShortcutInfoCompat mInfo;
        
        public Builder(final Context mContext, final ShortcutInfo shortcutInfo) {
            final ShortcutInfoCompat mInfo = new ShortcutInfoCompat();
            this.mInfo = mInfo;
            mInfo.mContext = mContext;
            mInfo.mId = shortcutInfo.getId();
            final Intent[] intents = shortcutInfo.getIntents();
            mInfo.mIntents = Arrays.copyOf(intents, intents.length);
            mInfo.mActivity = shortcutInfo.getActivity();
            mInfo.mLabel = shortcutInfo.getShortLabel();
            mInfo.mLongLabel = shortcutInfo.getLongLabel();
            mInfo.mDisabledMessage = shortcutInfo.getDisabledMessage();
            mInfo.mCategories = (Set<String>)shortcutInfo.getCategories();
            mInfo.mPersons = ShortcutInfoCompat.getPersonsFromExtra(shortcutInfo.getExtras());
            mInfo.mRank = shortcutInfo.getRank();
        }
        
        public Builder(final Context mContext, final String mId) {
            final ShortcutInfoCompat mInfo = new ShortcutInfoCompat();
            this.mInfo = mInfo;
            mInfo.mContext = mContext;
            mInfo.mId = mId;
        }
        
        public Builder(final ShortcutInfoCompat shortcutInfoCompat) {
            final ShortcutInfoCompat mInfo = new ShortcutInfoCompat();
            this.mInfo = mInfo;
            mInfo.mContext = shortcutInfoCompat.mContext;
            mInfo.mId = shortcutInfoCompat.mId;
            mInfo.mIntents = Arrays.copyOf(shortcutInfoCompat.mIntents, shortcutInfoCompat.mIntents.length);
            mInfo.mActivity = shortcutInfoCompat.mActivity;
            mInfo.mLabel = shortcutInfoCompat.mLabel;
            mInfo.mLongLabel = shortcutInfoCompat.mLongLabel;
            mInfo.mDisabledMessage = shortcutInfoCompat.mDisabledMessage;
            mInfo.mIcon = shortcutInfoCompat.mIcon;
            mInfo.mIsAlwaysBadged = shortcutInfoCompat.mIsAlwaysBadged;
            mInfo.mIsLongLived = shortcutInfoCompat.mIsLongLived;
            mInfo.mRank = shortcutInfoCompat.mRank;
            if (shortcutInfoCompat.mPersons != null) {
                mInfo.mPersons = Arrays.copyOf(shortcutInfoCompat.mPersons, shortcutInfoCompat.mPersons.length);
            }
            if (shortcutInfoCompat.mCategories != null) {
                mInfo.mCategories = new HashSet<String>(shortcutInfoCompat.mCategories);
            }
        }
        
        public ShortcutInfoCompat build() {
            if (TextUtils.isEmpty(this.mInfo.mLabel)) {
                throw new IllegalArgumentException("Shortcut must have a non-empty label");
            }
            if (this.mInfo.mIntents != null && this.mInfo.mIntents.length != 0) {
                return this.mInfo;
            }
            throw new IllegalArgumentException("Shortcut must have an intent");
        }
        
        public Builder setActivity(final ComponentName mActivity) {
            this.mInfo.mActivity = mActivity;
            return this;
        }
        
        public Builder setAlwaysBadged() {
            this.mInfo.mIsAlwaysBadged = true;
            return this;
        }
        
        public Builder setCategories(final Set<String> mCategories) {
            this.mInfo.mCategories = mCategories;
            return this;
        }
        
        public Builder setDisabledMessage(final CharSequence mDisabledMessage) {
            this.mInfo.mDisabledMessage = mDisabledMessage;
            return this;
        }
        
        public Builder setIcon(final IconCompat mIcon) {
            this.mInfo.mIcon = mIcon;
            return this;
        }
        
        public Builder setIntent(final Intent intent) {
            return this.setIntents(new Intent[] { intent });
        }
        
        public Builder setIntents(final Intent[] mIntents) {
            this.mInfo.mIntents = mIntents;
            return this;
        }
        
        public Builder setLongLabel(final CharSequence mLongLabel) {
            this.mInfo.mLongLabel = mLongLabel;
            return this;
        }
        
        @Deprecated
        public Builder setLongLived() {
            this.mInfo.mIsLongLived = true;
            return this;
        }
        
        public Builder setLongLived(final boolean mIsLongLived) {
            this.mInfo.mIsLongLived = mIsLongLived;
            return this;
        }
        
        public Builder setPerson(final Person person) {
            return this.setPersons(new Person[] { person });
        }
        
        public Builder setPersons(final Person[] mPersons) {
            this.mInfo.mPersons = mPersons;
            return this;
        }
        
        public Builder setRank(final int mRank) {
            this.mInfo.mRank = mRank;
            return this;
        }
        
        public Builder setShortLabel(final CharSequence mLabel) {
            this.mInfo.mLabel = mLabel;
            return this;
        }
    }
}
