// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.content.res;

import android.graphics.Color;
import android.content.res.TypedArray;
import android.util.StateSet;
import androidx.core.R;
import android.util.Log;
import java.io.IOException;
import android.util.AttributeSet;
import org.xmlpull.v1.XmlPullParserException;
import android.util.Xml;
import android.content.res.ColorStateList;
import android.content.res.Resources$Theme;
import org.xmlpull.v1.XmlPullParser;
import android.content.res.Resources;

public final class ColorStateListInflaterCompat
{
    private ColorStateListInflaterCompat() {
    }
    
    public static ColorStateList createFromXml(final Resources resources, final XmlPullParser xmlPullParser, final Resources$Theme resources$Theme) throws XmlPullParserException, IOException {
        final AttributeSet attributeSet = Xml.asAttributeSet(xmlPullParser);
        int next;
        do {
            next = xmlPullParser.next();
        } while (next != 2 && next != 1);
        if (next == 2) {
            return createFromXmlInner(resources, xmlPullParser, attributeSet, resources$Theme);
        }
        throw new XmlPullParserException("No start tag found");
    }
    
    public static ColorStateList createFromXmlInner(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) throws XmlPullParserException, IOException {
        final String name = xmlPullParser.getName();
        if (name.equals("selector")) {
            return inflate(resources, xmlPullParser, set, resources$Theme);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append(xmlPullParser.getPositionDescription());
        sb.append(": invalid color state list tag ");
        sb.append(name);
        throw new XmlPullParserException(sb.toString());
    }
    
    public static ColorStateList inflate(final Resources resources, final int n, final Resources$Theme resources$Theme) {
        try {
            return createFromXml(resources, (XmlPullParser)resources.getXml(n), resources$Theme);
        }
        catch (Exception ex) {
            Log.e("CSLCompat", "Failed to inflate ColorStateList.", (Throwable)ex);
            return null;
        }
    }
    
    private static ColorStateList inflate(final Resources resources, final XmlPullParser xmlPullParser, final AttributeSet set, final Resources$Theme resources$Theme) throws XmlPullParserException, IOException {
        final int depth = xmlPullParser.getDepth();
        int n = 1;
        final int n2 = depth + n;
        int[][] array = new int[20][];
        int[] append = new int[20];
        int n3 = 0;
        while (true) {
            final int next = xmlPullParser.next();
            if (next == n) {
                break;
            }
            final int depth2 = xmlPullParser.getDepth();
            if (depth2 < n2 && next == 3) {
                break;
            }
            if (next == 2 && depth2 <= n2) {
                if (xmlPullParser.getName().equals("item")) {
                    final TypedArray obtainAttributes = obtainAttributes(resources, resources$Theme, set, R.styleable.ColorStateListItem);
                    final int color = obtainAttributes.getColor(R.styleable.ColorStateListItem_android_color, -65281);
                    float n4 = 1.0f;
                    if (obtainAttributes.hasValue(R.styleable.ColorStateListItem_android_alpha)) {
                        n4 = obtainAttributes.getFloat(R.styleable.ColorStateListItem_android_alpha, n4);
                    }
                    else if (obtainAttributes.hasValue(R.styleable.ColorStateListItem_alpha)) {
                        n4 = obtainAttributes.getFloat(R.styleable.ColorStateListItem_alpha, n4);
                    }
                    obtainAttributes.recycle();
                    final int attributeCount = set.getAttributeCount();
                    final int[] array2 = new int[attributeCount];
                    int i = 0;
                    int n5 = 0;
                    while (i < attributeCount) {
                        int attributeNameResource = set.getAttributeNameResource(i);
                        if (attributeNameResource != 16843173 && attributeNameResource != 16843551 && attributeNameResource != R.attr.alpha) {
                            final int n6 = n5 + 1;
                            if (!set.getAttributeBooleanValue(i, false)) {
                                attributeNameResource = -attributeNameResource;
                            }
                            array2[n5] = attributeNameResource;
                            n5 = n6;
                        }
                        ++i;
                    }
                    final int[] trimStateSet = StateSet.trimStateSet(array2, n5);
                    append = GrowingArrayUtils.append(append, n3, modulateColorAlpha(color, n4));
                    array = GrowingArrayUtils.append(array, n3, trimStateSet);
                    ++n3;
                }
            }
            n = 1;
        }
        final int[] array3 = new int[n3];
        final int[][] array4 = new int[n3][];
        System.arraycopy(append, 0, array3, 0, n3);
        System.arraycopy(array, 0, array4, 0, n3);
        return new ColorStateList(array4, array3);
    }
    
    private static int modulateColorAlpha(final int n, final float n2) {
        return (n & 0xFFFFFF) | Math.round(n2 * Color.alpha(n)) << 24;
    }
    
    private static TypedArray obtainAttributes(final Resources resources, final Resources$Theme resources$Theme, final AttributeSet set, final int[] array) {
        TypedArray typedArray;
        if (resources$Theme == null) {
            typedArray = resources.obtainAttributes(set, array);
        }
        else {
            typedArray = resources$Theme.obtainStyledAttributes(set, array, 0, 0);
        }
        return typedArray;
    }
}
