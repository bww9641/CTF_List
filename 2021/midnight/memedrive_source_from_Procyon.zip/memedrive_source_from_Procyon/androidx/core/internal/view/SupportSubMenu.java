// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.internal.view;

import android.view.SubMenu;

public interface SupportSubMenu extends SupportMenu, SubMenu
{
}
