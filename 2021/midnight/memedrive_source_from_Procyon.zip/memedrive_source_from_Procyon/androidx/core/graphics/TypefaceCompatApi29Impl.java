// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.graphics;

import android.graphics.fonts.FontFamily;
import java.io.InputStream;
import androidx.core.provider.FontsContractCompat;
import android.os.CancellationSignal;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontStyle;
import android.graphics.Typeface$CustomFallbackBuilder;
import java.io.IOException;
import android.graphics.fonts.FontFamily$Builder;
import android.graphics.fonts.Font$Builder;
import android.graphics.Typeface;
import android.content.res.Resources;
import androidx.core.content.res.FontResourcesParserCompat;
import android.content.Context;

public class TypefaceCompatApi29Impl extends TypefaceCompatBaseImpl
{
    @Override
    public Typeface createFromFontFamilyFilesResourceEntry(final Context context, final FontResourcesParserCompat.FontFamilyFilesResourceEntry fontFamilyFilesResourceEntry, final Resources resources, final int n) {
        final FontResourcesParserCompat.FontFileResourceEntry[] entries = fontFamilyFilesResourceEntry.getEntries();
        final int length = entries.length;
        FontFamily$Builder fontFamily$Builder = null;
        int n2 = 0;
        while (true) {
            int slant = 1;
            if (n2 >= length) {
                break;
            }
            while (true) {
                final FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = entries[n2];
                while (true) {
                    Label_0211: {
                        try {
                            final Font$Builder setWeight = new Font$Builder(resources, fontFileResourceEntry.getResourceId()).setWeight(fontFileResourceEntry.getWeight());
                            if (!fontFileResourceEntry.isItalic()) {
                                break Label_0211;
                            }
                            final Font build = setWeight.setSlant(slant).setTtcIndex(fontFileResourceEntry.getTtcIndex()).setFontVariationSettings(fontFileResourceEntry.getVariationSettings()).build();
                            if (fontFamily$Builder == null) {
                                fontFamily$Builder = new FontFamily$Builder(build);
                            }
                            else {
                                fontFamily$Builder.addFont(build);
                            }
                        }
                        catch (IOException ex) {}
                        break;
                    }
                    slant = 0;
                    continue;
                }
            }
            ++n2;
        }
        if (fontFamily$Builder == null) {
            return null;
        }
        int n3;
        if ((n & 0x1) != 0x0) {
            n3 = 700;
        }
        else {
            n3 = 400;
        }
        final int n4 = n & 0x2;
        int n5 = 0;
        if (n4 != 0) {
            n5 = 1;
        }
        return new Typeface$CustomFallbackBuilder(fontFamily$Builder.build()).setStyle(new FontStyle(n3, n5)).build();
    }
    
    @Override
    public Typeface createFromFontInfo(final Context p0, final CancellationSignal p1, final FontsContractCompat.FontInfo[] p2, final int p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokevirtual   android/content/Context.getContentResolver:()Landroid/content/ContentResolver;
        //     4: astore          5
        //     6: aload_3        
        //     7: arraylength    
        //     8: istore          6
        //    10: aconst_null    
        //    11: astore          7
        //    13: iconst_0       
        //    14: istore          8
        //    16: iconst_1       
        //    17: istore          9
        //    19: iload           8
        //    21: iload           6
        //    23: if_icmpge       175
        //    26: aload_3        
        //    27: iload           8
        //    29: aaload         
        //    30: astore          14
        //    32: aload           5
        //    34: aload           14
        //    36: invokevirtual   androidx/core/provider/FontsContractCompat$FontInfo.getUri:()Landroid/net/Uri;
        //    39: ldc             "r"
        //    41: aload_2        
        //    42: invokevirtual   android/content/ContentResolver.openFileDescriptor:(Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
        //    45: astore          15
        //    47: aload           15
        //    49: ifnonnull       65
        //    52: aload           15
        //    54: ifnull          169
        //    57: aload           15
        //    59: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //    62: goto            169
        //    65: new             Landroid/graphics/fonts/Font$Builder;
        //    68: dup            
        //    69: aload           15
        //    71: invokespecial   android/graphics/fonts/Font$Builder.<init>:(Landroid/os/ParcelFileDescriptor;)V
        //    74: aload           14
        //    76: invokevirtual   androidx/core/provider/FontsContractCompat$FontInfo.getWeight:()I
        //    79: invokevirtual   android/graphics/fonts/Font$Builder.setWeight:(I)Landroid/graphics/fonts/Font$Builder;
        //    82: astore          18
        //    84: aload           14
        //    86: invokevirtual   androidx/core/provider/FontsContractCompat$FontInfo.isItalic:()Z
        //    89: ifeq            253
        //    92: goto            95
        //    95: aload           18
        //    97: iload           9
        //    99: invokevirtual   android/graphics/fonts/Font$Builder.setSlant:(I)Landroid/graphics/fonts/Font$Builder;
        //   102: aload           14
        //   104: invokevirtual   androidx/core/provider/FontsContractCompat$FontInfo.getTtcIndex:()I
        //   107: invokevirtual   android/graphics/fonts/Font$Builder.setTtcIndex:(I)Landroid/graphics/fonts/Font$Builder;
        //   110: invokevirtual   android/graphics/fonts/Font$Builder.build:()Landroid/graphics/fonts/Font;
        //   113: astore          19
        //   115: aload           7
        //   117: ifnonnull       134
        //   120: new             Landroid/graphics/fonts/FontFamily$Builder;
        //   123: dup            
        //   124: aload           19
        //   126: invokespecial   android/graphics/fonts/FontFamily$Builder.<init>:(Landroid/graphics/fonts/Font;)V
        //   129: astore          7
        //   131: goto            142
        //   134: aload           7
        //   136: aload           19
        //   138: invokevirtual   android/graphics/fonts/FontFamily$Builder.addFont:(Landroid/graphics/fonts/Font;)Landroid/graphics/fonts/FontFamily$Builder;
        //   141: pop            
        //   142: aload           15
        //   144: ifnull          169
        //   147: goto            57
        //   150: astore          16
        //   152: aload           15
        //   154: ifnull          165
        //   157: aload           15
        //   159: invokevirtual   android/os/ParcelFileDescriptor.close:()V
        //   162: goto            166
        //   165: pop            
        //   166: aload           16
        //   168: athrow         
        //   169: iinc            8, 1
        //   172: goto            16
        //   175: aload           7
        //   177: ifnonnull       182
        //   180: aconst_null    
        //   181: areturn        
        //   182: iload           4
        //   184: iconst_1       
        //   185: iand           
        //   186: ifeq            197
        //   189: sipush          700
        //   192: istore          10
        //   194: goto            202
        //   197: sipush          400
        //   200: istore          10
        //   202: iload           4
        //   204: iconst_2       
        //   205: iand           
        //   206: istore          11
        //   208: iconst_0       
        //   209: istore          12
        //   211: iload           11
        //   213: ifeq            219
        //   216: iconst_1       
        //   217: istore          12
        //   219: new             Landroid/graphics/fonts/FontStyle;
        //   222: dup            
        //   223: iload           10
        //   225: iload           12
        //   227: invokespecial   android/graphics/fonts/FontStyle.<init>:(II)V
        //   230: astore          13
        //   232: new             Landroid/graphics/Typeface$CustomFallbackBuilder;
        //   235: dup            
        //   236: aload           7
        //   238: invokevirtual   android/graphics/fonts/FontFamily$Builder.build:()Landroid/graphics/fonts/FontFamily;
        //   241: invokespecial   android/graphics/Typeface$CustomFallbackBuilder.<init>:(Landroid/graphics/fonts/FontFamily;)V
        //   244: aload           13
        //   246: invokevirtual   android/graphics/Typeface$CustomFallbackBuilder.setStyle:(Landroid/graphics/fonts/FontStyle;)Landroid/graphics/Typeface$CustomFallbackBuilder;
        //   249: invokevirtual   android/graphics/Typeface$CustomFallbackBuilder.build:()Landroid/graphics/Typeface;
        //   252: areturn        
        //   253: iconst_0       
        //   254: istore          9
        //   256: goto            95
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  32     62     169    175    Ljava/io/IOException;
        //  65     142    150    169    Any
        //  157    165    165    166    Any
        //  165    169    169    175    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Inconsistent stack size at #0016 (coming from #0172).
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2183)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    protected Typeface createFromInputStream(final Context context, final InputStream inputStream) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }
    
    @Override
    public Typeface createFromResourcesFontFile(final Context context, final Resources resources, final int n, final String s, final int n2) {
        try {
            final FontFamily build = new FontFamily$Builder(new Font$Builder(resources, n).build()).build();
            int n3;
            if ((n2 & 0x1) != 0x0) {
                n3 = 700;
            }
            else {
                n3 = 400;
            }
            boolean b;
            if ((n2 & 0x2) != 0x0) {
                b = true;
            }
            else {
                b = false;
            }
            return new Typeface$CustomFallbackBuilder(build).setStyle(new FontStyle(n3, (int)(b ? 1 : 0))).build();
        }
        catch (IOException ex) {
            return null;
        }
    }
    
    @Override
    protected FontsContractCompat.FontInfo findBestInfo(final FontsContractCompat.FontInfo[] array, final int n) {
        throw new RuntimeException("Do not use this function in API 29 or later.");
    }
}
