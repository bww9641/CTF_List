// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.graphics;

import android.graphics.Color;

public final class ColorUtils
{
    private static final int MIN_ALPHA_SEARCH_MAX_ITERATIONS = 10;
    private static final int MIN_ALPHA_SEARCH_PRECISION = 1;
    private static final ThreadLocal<double[]> TEMP_ARRAY;
    private static final double XYZ_EPSILON = 0.008856;
    private static final double XYZ_KAPPA = 903.3;
    private static final double XYZ_WHITE_REFERENCE_X = 95.047;
    private static final double XYZ_WHITE_REFERENCE_Y = 100.0;
    private static final double XYZ_WHITE_REFERENCE_Z = 108.883;
    
    static {
        TEMP_ARRAY = new ThreadLocal<double[]>();
    }
    
    private ColorUtils() {
    }
    
    public static int HSLToColor(final float[] array) {
        final float n = array[0];
        final float n2 = array[1];
        final float n3 = array[2];
        final float n4 = n2 * (1.0f - Math.abs(n3 * 2.0f - 1.0f));
        final float n5 = n3 - 0.5f * n4;
        final float n6 = n4 * (1.0f - Math.abs(n / 60.0f % 2.0f - 1.0f));
        int n7 = 0;
        int n8 = 0;
        int n9 = 0;
        switch ((int)n / 60) {
            default: {
                n7 = 0;
                n8 = 0;
                n9 = 0;
                break;
            }
            case 5:
            case 6: {
                n7 = Math.round(255.0f * (n4 + n5));
                n8 = Math.round(n5 * 255.0f);
                n9 = Math.round(255.0f * (n6 + n5));
                break;
            }
            case 4: {
                n7 = Math.round(255.0f * (n6 + n5));
                n8 = Math.round(n5 * 255.0f);
                n9 = Math.round(255.0f * (n4 + n5));
                break;
            }
            case 3: {
                n7 = Math.round(n5 * 255.0f);
                n8 = Math.round(255.0f * (n6 + n5));
                n9 = Math.round(255.0f * (n4 + n5));
                break;
            }
            case 2: {
                n7 = Math.round(n5 * 255.0f);
                n8 = Math.round(255.0f * (n4 + n5));
                n9 = Math.round(255.0f * (n6 + n5));
                break;
            }
            case 1: {
                n7 = Math.round(255.0f * (n6 + n5));
                n8 = Math.round(255.0f * (n4 + n5));
                n9 = Math.round(n5 * 255.0f);
                break;
            }
            case 0: {
                n7 = Math.round(255.0f * (n4 + n5));
                n8 = Math.round(255.0f * (n6 + n5));
                n9 = Math.round(n5 * 255.0f);
                break;
            }
        }
        return Color.rgb(constrain(n7, 0, 255), constrain(n8, 0, 255), constrain(n9, 0, 255));
    }
    
    public static int LABToColor(final double n, final double n2, final double n3) {
        final double[] tempDouble3Array = getTempDouble3Array();
        LABToXYZ(n, n2, n3, tempDouble3Array);
        return XYZToColor(tempDouble3Array[0], tempDouble3Array[1], tempDouble3Array[2]);
    }
    
    public static void LABToXYZ(final double n, final double n2, final double n3, final double[] array) {
        final double a = (n + 16.0) / 116.0;
        final double a2 = a + n2 / 500.0;
        final double a3 = a - n3 / 200.0;
        double pow = Math.pow(a2, 3.0);
        if (pow <= 0.008856) {
            pow = (a2 * 116.0 - 16.0) / 903.3;
        }
        double pow2;
        if (n > 7.9996247999999985) {
            pow2 = Math.pow(a, 3.0);
        }
        else {
            pow2 = n / 903.3;
        }
        double pow3 = Math.pow(a3, 3.0);
        if (pow3 <= 0.008856) {
            pow3 = (a3 * 116.0 - 16.0) / 903.3;
        }
        array[0] = pow * 95.047;
        array[1] = pow2 * 100.0;
        array[2] = pow3 * 108.883;
    }
    
    public static void RGBToHSL(final int n, final int n2, final int n3, final float[] array) {
        final float n4 = n / 255.0f;
        final float n5 = n2 / 255.0f;
        final float n6 = n3 / 255.0f;
        final float max = Math.max(n4, Math.max(n5, n6));
        final float min = Math.min(n4, Math.min(n5, n6));
        final float n7 = max - min;
        final float n8 = (max + min) / 2.0f;
        float n9;
        float n10;
        if (max == min) {
            n9 = 0.0f;
            n10 = 0.0f;
        }
        else {
            if (max == n4) {
                n10 = (n5 - n6) / n7 % 6.0f;
            }
            else if (max == n5) {
                n10 = 2.0f + (n6 - n4) / n7;
            }
            else {
                n10 = 4.0f + (n4 - n5) / n7;
            }
            n9 = n7 / (1.0f - Math.abs(2.0f * n8 - 1.0f));
        }
        float n11 = n10 * 60.0f % 360.0f;
        if (n11 < 0.0f) {
            n11 += 360.0f;
        }
        array[0] = constrain(n11, 0.0f, 360.0f);
        array[1] = constrain(n9, 0.0f, 1.0f);
        array[2] = constrain(n8, 0.0f, 1.0f);
    }
    
    public static void RGBToLAB(final int n, final int n2, final int n3, final double[] array) {
        RGBToXYZ(n, n2, n3, array);
        XYZToLAB(array[0], array[1], array[2], array);
    }
    
    public static void RGBToXYZ(final int n, final int n2, final int n3, final double[] array) {
        if (array.length == 3) {
            final double v = n;
            Double.isNaN(v);
            final double n4 = v / 255.0;
            double pow;
            if (n4 < 0.04045) {
                pow = n4 / 12.92;
            }
            else {
                pow = Math.pow((n4 + 0.055) / 1.055, 2.4);
            }
            final double v2 = n2;
            Double.isNaN(v2);
            final double n5 = v2 / 255.0;
            double pow2;
            if (n5 < 0.04045) {
                pow2 = n5 / 12.92;
            }
            else {
                pow2 = Math.pow((n5 + 0.055) / 1.055, 2.4);
            }
            final double v3 = n3;
            Double.isNaN(v3);
            final double n6 = v3 / 255.0;
            double pow3;
            if (n6 < 0.04045) {
                pow3 = n6 / 12.92;
            }
            else {
                pow3 = Math.pow((n6 + 0.055) / 1.055, 2.4);
            }
            array[0] = 100.0 * (0.4124 * pow + 0.3576 * pow2 + 0.1805 * pow3);
            array[1] = 100.0 * (0.2126 * pow + 0.7152 * pow2 + 0.0722 * pow3);
            array[2] = 100.0 * (pow * 0.0193 + pow2 * 0.1192 + pow3 * 0.9505);
            return;
        }
        throw new IllegalArgumentException("outXyz must have a length of 3.");
    }
    
    public static int XYZToColor(final double n, final double n2, final double n3) {
        final double a = (3.2406 * n + -1.5372 * n2 + -0.4986 * n3) / 100.0;
        final double a2 = (-0.9689 * n + 1.8758 * n2 + 0.0415 * n3) / 100.0;
        final double a3 = (0.0557 * n + -0.204 * n2 + 1.057 * n3) / 100.0;
        double n4;
        if (a > 0.0031308) {
            n4 = 1.055 * Math.pow(a, 0.4166666666666667) - 0.055;
        }
        else {
            n4 = a * 12.92;
        }
        double n5;
        if (a2 > 0.0031308) {
            n5 = 1.055 * Math.pow(a2, 0.4166666666666667) - 0.055;
        }
        else {
            n5 = a2 * 12.92;
        }
        double n6;
        if (a3 > 0.0031308) {
            n6 = 1.055 * Math.pow(a3, 0.4166666666666667) - 0.055;
        }
        else {
            n6 = a3 * 12.92;
        }
        return Color.rgb(constrain((int)Math.round(n4 * 255.0), 0, 255), constrain((int)Math.round(n5 * 255.0), 0, 255), constrain((int)Math.round(n6 * 255.0), 0, 255));
    }
    
    public static void XYZToLAB(final double n, final double n2, final double n3, final double[] array) {
        if (array.length == 3) {
            final double pivotXyzComponent = pivotXyzComponent(n / 95.047);
            final double pivotXyzComponent2 = pivotXyzComponent(n2 / 100.0);
            final double pivotXyzComponent3 = pivotXyzComponent(n3 / 108.883);
            array[0] = Math.max(0.0, 116.0 * pivotXyzComponent2 - 16.0);
            array[1] = 500.0 * (pivotXyzComponent - pivotXyzComponent2);
            array[2] = 200.0 * (pivotXyzComponent2 - pivotXyzComponent3);
            return;
        }
        throw new IllegalArgumentException("outLab must have a length of 3.");
    }
    
    public static int blendARGB(final int n, final int n2, final float n3) {
        final float n4 = 1.0f - n3;
        return Color.argb((int)(n4 * Color.alpha(n) + n3 * Color.alpha(n2)), (int)(n4 * Color.red(n) + n3 * Color.red(n2)), (int)(n4 * Color.green(n) + n3 * Color.green(n2)), (int)(n4 * Color.blue(n) + n3 * Color.blue(n2)));
    }
    
    public static void blendHSL(final float[] array, final float[] array2, final float n, final float[] array3) {
        if (array3.length == 3) {
            final float n2 = 1.0f - n;
            array3[0] = circularInterpolate(array[0], array2[0], n);
            array3[1] = n2 * array[1] + n * array2[1];
            array3[2] = n2 * array[2] + n * array2[2];
            return;
        }
        throw new IllegalArgumentException("result must have a length of 3.");
    }
    
    public static void blendLAB(final double[] array, final double[] array2, final double n, final double[] array3) {
        if (array3.length == 3) {
            final double n2 = 1.0 - n;
            array3[0] = n2 * array[0] + n * array2[0];
            array3[1] = n2 * array[1] + n * array2[1];
            array3[2] = n2 * array[2] + n * array2[2];
            return;
        }
        throw new IllegalArgumentException("outResult must have a length of 3.");
    }
    
    public static double calculateContrast(int compositeColors, final int i) {
        if (Color.alpha(i) == 255) {
            if (Color.alpha(compositeColors) < 255) {
                compositeColors = compositeColors(compositeColors, i);
            }
            final double n = 0.05 + calculateLuminance(compositeColors);
            final double n2 = 0.05 + calculateLuminance(i);
            return Math.max(n, n2) / Math.min(n, n2);
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("background can not be translucent: #");
        sb.append(Integer.toHexString(i));
        throw new IllegalArgumentException(sb.toString());
    }
    
    public static double calculateLuminance(final int n) {
        final double[] tempDouble3Array = getTempDouble3Array();
        colorToXYZ(n, tempDouble3Array);
        return tempDouble3Array[1] / 100.0;
    }
    
    public static int calculateMinimumAlpha(final int n, final int i, final float n2) {
        final int alpha = Color.alpha(i);
        int n3 = 255;
        if (alpha != n3) {
            final StringBuilder sb = new StringBuilder();
            sb.append("background can not be translucent: #");
            sb.append(Integer.toHexString(i));
            throw new IllegalArgumentException(sb.toString());
        }
        final double calculateContrast = calculateContrast(setAlphaComponent(n, n3), i);
        final double n4 = n2;
        if (calculateContrast < n4) {
            return -1;
        }
        for (int n5 = 0, n6 = 0; n5 <= 10 && n3 - n6 > 1; ++n5) {
            final int n7 = (n6 + n3) / 2;
            if (calculateContrast(setAlphaComponent(n, n7), i) < n4) {
                n6 = n7;
            }
            else {
                n3 = n7;
            }
        }
        return n3;
    }
    
    static float circularInterpolate(float n, float n2, final float n3) {
        if (Math.abs(n2 - n) > 180.0f) {
            if (n2 > n) {
                n += 360.0f;
            }
            else {
                n2 += 360.0f;
            }
        }
        return (n + n3 * (n2 - n)) % 360.0f;
    }
    
    public static void colorToHSL(final int n, final float[] array) {
        RGBToHSL(Color.red(n), Color.green(n), Color.blue(n), array);
    }
    
    public static void colorToLAB(final int n, final double[] array) {
        RGBToLAB(Color.red(n), Color.green(n), Color.blue(n), array);
    }
    
    public static void colorToXYZ(final int n, final double[] array) {
        RGBToXYZ(Color.red(n), Color.green(n), Color.blue(n), array);
    }
    
    private static int compositeAlpha(final int n, final int n2) {
        return 255 - (255 - n2) * (255 - n) / 255;
    }
    
    public static int compositeColors(final int n, final int n2) {
        final int alpha = Color.alpha(n2);
        final int alpha2 = Color.alpha(n);
        final int compositeAlpha = compositeAlpha(alpha2, alpha);
        return Color.argb(compositeAlpha, compositeComponent(Color.red(n), alpha2, Color.red(n2), alpha, compositeAlpha), compositeComponent(Color.green(n), alpha2, Color.green(n2), alpha, compositeAlpha), compositeComponent(Color.blue(n), alpha2, Color.blue(n2), alpha, compositeAlpha));
    }
    
    public static Color compositeColors(Color convert, final Color color) {
        if ($r8$backportedMethods$utility$Objects$2$equals.equals(convert.getModel(), color.getModel())) {
            if (!$r8$backportedMethods$utility$Objects$2$equals.equals(color.getColorSpace(), convert.getColorSpace())) {
                convert = convert.convert(color.getColorSpace());
            }
            final float[] components = convert.getComponents();
            final float[] components2 = color.getComponents();
            float alpha = convert.alpha();
            float n = color.alpha() * (1.0f - alpha);
            final int n2 = -1 + color.getComponentCount();
            components2[n2] = alpha + n;
            if (components2[n2] > 0.0f) {
                alpha /= components2[n2];
                n /= components2[n2];
            }
            for (int i = 0; i < n2; ++i) {
                components2[i] = alpha * components[i] + n * components2[i];
            }
            return Color.valueOf(components2, color.getColorSpace());
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Color models must match (");
        sb.append(convert.getModel());
        sb.append(" vs. ");
        sb.append(color.getModel());
        sb.append(")");
        throw new IllegalArgumentException(sb.toString());
    }
    
    private static int compositeComponent(final int n, final int n2, final int n3, final int n4, final int n5) {
        if (n5 == 0) {
            return 0;
        }
        return (n2 * (n * 255) + n3 * n4 * (255 - n2)) / (n5 * 255);
    }
    
    private static float constrain(float n, final float n2, final float n3) {
        if (n < n2) {
            n = n2;
        }
        else if (n > n3) {
            n = n3;
        }
        return n;
    }
    
    private static int constrain(int n, final int n2, final int n3) {
        if (n < n2) {
            n = n2;
        }
        else if (n > n3) {
            n = n3;
        }
        return n;
    }
    
    public static double distanceEuclidean(final double[] array, final double[] array2) {
        return Math.sqrt(Math.pow(array[0] - array2[0], 2.0) + Math.pow(array[1] - array2[1], 2.0) + Math.pow(array[2] - array2[2], 2.0));
    }
    
    private static double[] getTempDouble3Array() {
        final ThreadLocal<double[]> temp_ARRAY = ColorUtils.TEMP_ARRAY;
        double[] value = temp_ARRAY.get();
        if (value == null) {
            value = new double[3];
            temp_ARRAY.set(value);
        }
        return value;
    }
    
    private static double pivotXyzComponent(final double a) {
        double pow;
        if (a > 0.008856) {
            pow = Math.pow(a, 0.3333333333333333);
        }
        else {
            pow = (16.0 + a * 903.3) / 116.0;
        }
        return pow;
    }
    
    public static int setAlphaComponent(final int n, final int n2) {
        if (n2 >= 0 && n2 <= 255) {
            return (n & 0xFFFFFF) | n2 << 24;
        }
        throw new IllegalArgumentException("alpha must be between 0 and 255.");
    }
}
