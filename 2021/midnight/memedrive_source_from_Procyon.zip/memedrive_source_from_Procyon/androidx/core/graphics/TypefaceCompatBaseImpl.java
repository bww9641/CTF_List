// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.graphics;

import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.io.Closeable;
import androidx.core.provider.FontsContractCompat;
import android.os.CancellationSignal;
import android.content.res.Resources;
import android.content.Context;
import java.lang.reflect.Field;
import android.util.Log;
import android.graphics.Typeface;
import androidx.core.content.res.FontResourcesParserCompat;
import java.util.concurrent.ConcurrentHashMap;

class TypefaceCompatBaseImpl
{
    private static final int INVALID_KEY = 0;
    private static final String TAG = "TypefaceCompatBaseImpl";
    private ConcurrentHashMap<Long, FontResourcesParserCompat.FontFamilyFilesResourceEntry> mFontFamilies;
    
    TypefaceCompatBaseImpl() {
        this.mFontFamilies = new ConcurrentHashMap<Long, FontResourcesParserCompat.FontFamilyFilesResourceEntry>();
    }
    
    private void addFontFamily(final Typeface typeface, final FontResourcesParserCompat.FontFamilyFilesResourceEntry value) {
        final long uniqueKey = getUniqueKey(typeface);
        if (uniqueKey != 0L) {
            this.mFontFamilies.put(uniqueKey, value);
        }
    }
    
    private FontResourcesParserCompat.FontFileResourceEntry findBestEntry(final FontResourcesParserCompat.FontFamilyFilesResourceEntry fontFamilyFilesResourceEntry, final int n) {
        return findBestFont(fontFamilyFilesResourceEntry.getEntries(), n, (StyleExtractor<FontResourcesParserCompat.FontFileResourceEntry>)new StyleExtractor<FontResourcesParserCompat.FontFileResourceEntry>() {
            public int getWeight(final FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry) {
                return fontFileResourceEntry.getWeight();
            }
            
            public boolean isItalic(final FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry) {
                return fontFileResourceEntry.isItalic();
            }
        });
    }
    
    private static <T> T findBestFont(final T[] array, final int n, final StyleExtractor<T> styleExtractor) {
        int n2;
        if ((n & 0x1) == 0x0) {
            n2 = 400;
        }
        else {
            n2 = 700;
        }
        final boolean b = (n & 0x2) != 0x0;
        T t = null;
        int n3 = Integer.MAX_VALUE;
        for (final T t2 : array) {
            final int n4 = 2 * Math.abs(styleExtractor.getWeight(t2) - n2);
            int n5;
            if (styleExtractor.isItalic(t2) == b) {
                n5 = 0;
            }
            else {
                n5 = 1;
            }
            final int n6 = n4 + n5;
            if (t == null || n3 > n6) {
                t = t2;
                n3 = n6;
            }
        }
        return t;
    }
    
    private static long getUniqueKey(final Typeface obj) {
        if (obj == null) {
            return 0L;
        }
        try {
            final Field declaredField = Typeface.class.getDeclaredField("native_instance");
            declaredField.setAccessible(true);
            return ((Number)declaredField.get(obj)).longValue();
        }
        catch (IllegalAccessException ex) {
            Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", (Throwable)ex);
            return 0L;
        }
        catch (NoSuchFieldException ex2) {
            Log.e("TypefaceCompatBaseImpl", "Could not retrieve font from family.", (Throwable)ex2);
            return 0L;
        }
    }
    
    public Typeface createFromFontFamilyFilesResourceEntry(final Context context, final FontResourcesParserCompat.FontFamilyFilesResourceEntry fontFamilyFilesResourceEntry, final Resources resources, final int n) {
        final FontResourcesParserCompat.FontFileResourceEntry bestEntry = this.findBestEntry(fontFamilyFilesResourceEntry, n);
        if (bestEntry == null) {
            return null;
        }
        final Typeface fromResourcesFontFile = TypefaceCompat.createFromResourcesFontFile(context, resources, bestEntry.getResourceId(), bestEntry.getFileName(), n);
        this.addFontFamily(fromResourcesFontFile, fontFamilyFilesResourceEntry);
        return fromResourcesFontFile;
    }
    
    public Typeface createFromFontInfo(final Context context, final CancellationSignal cancellationSignal, final FontsContractCompat.FontInfo[] array, final int n) {
        if (array.length < 1) {
            return null;
        }
        final FontsContractCompat.FontInfo bestInfo = this.findBestInfo(array, n);
        InputStream openInputStream = null;
        try {
            openInputStream = context.getContentResolver().openInputStream(bestInfo.getUri());
            try {
                final Typeface fromInputStream = this.createFromInputStream(context, openInputStream);
                TypefaceCompatUtil.closeQuietly(openInputStream);
                return fromInputStream;
            }
            catch (IOException ex) {}
        }
        catch (IOException ex2) {}
        TypefaceCompatUtil.closeQuietly(openInputStream);
        return null;
    }
    
    protected Typeface createFromInputStream(final Context context, final InputStream inputStream) {
        final File tempFile = TypefaceCompatUtil.getTempFile(context);
        if (tempFile == null) {
            return null;
        }
        try {
            if (!TypefaceCompatUtil.copyToFile(tempFile, inputStream)) {
                return null;
            }
            return Typeface.createFromFile(tempFile.getPath());
        }
        catch (RuntimeException ex) {
            return null;
        }
        finally {
            tempFile.delete();
        }
    }
    
    public Typeface createFromResourcesFontFile(final Context context, final Resources resources, final int n, final String s, final int n2) {
        final File tempFile = TypefaceCompatUtil.getTempFile(context);
        if (tempFile == null) {
            return null;
        }
        try {
            if (!TypefaceCompatUtil.copyToFile(tempFile, resources, n)) {
                return null;
            }
            return Typeface.createFromFile(tempFile.getPath());
        }
        catch (RuntimeException ex) {
            return null;
        }
        finally {
            tempFile.delete();
        }
    }
    
    protected FontsContractCompat.FontInfo findBestInfo(final FontsContractCompat.FontInfo[] array, final int n) {
        return findBestFont(array, n, (StyleExtractor<FontsContractCompat.FontInfo>)new StyleExtractor<FontsContractCompat.FontInfo>() {
            public int getWeight(final FontsContractCompat.FontInfo fontInfo) {
                return fontInfo.getWeight();
            }
            
            public boolean isItalic(final FontsContractCompat.FontInfo fontInfo) {
                return fontInfo.isItalic();
            }
        });
    }
    
    FontResourcesParserCompat.FontFamilyFilesResourceEntry getFontFamily(final Typeface typeface) {
        final long uniqueKey = getUniqueKey(typeface);
        if (uniqueKey == 0L) {
            return null;
        }
        return this.mFontFamilies.get(uniqueKey);
    }
    
    private interface StyleExtractor<T>
    {
        int getWeight(final T p0);
        
        boolean isItalic(final T p0);
    }
}
