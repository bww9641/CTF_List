// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.graphics;

import androidx.core.util.Preconditions;
import android.graphics.PointF;

public final class PathSegment
{
    private final PointF mEnd;
    private final float mEndFraction;
    private final PointF mStart;
    private final float mStartFraction;
    
    public PathSegment(final PointF pointF, final float mStartFraction, final PointF pointF2, final float mEndFraction) {
        this.mStart = Preconditions.checkNotNull(pointF, "start == null");
        this.mStartFraction = mStartFraction;
        this.mEnd = Preconditions.checkNotNull(pointF2, "end == null");
        this.mEndFraction = mEndFraction;
    }
    
    @Override
    public boolean equals(final Object o) {
        boolean b = true;
        if (this == o) {
            return b;
        }
        if (!(o instanceof PathSegment)) {
            return false;
        }
        final PathSegment pathSegment = (PathSegment)o;
        if (Float.compare(this.mStartFraction, pathSegment.mStartFraction) != 0 || Float.compare(this.mEndFraction, pathSegment.mEndFraction) != 0 || !this.mStart.equals((Object)pathSegment.mStart) || !this.mEnd.equals((Object)pathSegment.mEnd)) {
            b = false;
        }
        return b;
    }
    
    public PointF getEnd() {
        return this.mEnd;
    }
    
    public float getEndFraction() {
        return this.mEndFraction;
    }
    
    public PointF getStart() {
        return this.mStart;
    }
    
    public float getStartFraction() {
        return this.mStartFraction;
    }
    
    @Override
    public int hashCode() {
        final int n = 31 * this.mStart.hashCode();
        final float mStartFraction = this.mStartFraction;
        int floatToIntBits;
        if (mStartFraction != 0.0f) {
            floatToIntBits = Float.floatToIntBits(mStartFraction);
        }
        else {
            floatToIntBits = 0;
        }
        final int n2 = 31 * (31 * (n + floatToIntBits) + this.mEnd.hashCode());
        final float mEndFraction = this.mEndFraction;
        final float n3 = fcmpl(mEndFraction, 0.0f);
        int floatToIntBits2 = 0;
        if (n3 != 0) {
            floatToIntBits2 = Float.floatToIntBits(mEndFraction);
        }
        return n2 + floatToIntBits2;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("PathSegment{start=");
        sb.append(this.mStart);
        sb.append(", startFraction=");
        sb.append(this.mStartFraction);
        sb.append(", end=");
        sb.append(this.mEnd);
        sb.append(", endFraction=");
        sb.append(this.mEndFraction);
        sb.append('}');
        return sb.toString();
    }
}
