// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.graphics;

import android.content.ContentResolver;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import androidx.core.provider.FontsContractCompat;
import android.os.CancellationSignal;
import android.content.res.Resources;
import androidx.core.content.res.FontResourcesParserCompat;
import android.content.Context;
import java.lang.reflect.GenericDeclaration;
import android.util.Log;
import android.system.ErrnoException;
import android.system.OsConstants;
import android.system.Os;
import java.io.File;
import android.os.ParcelFileDescriptor;
import java.lang.reflect.Array;
import android.graphics.Typeface;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl
{
    private static final String ADD_FONT_WEIGHT_STYLE_METHOD = "addFontWeightStyle";
    private static final String CREATE_FROM_FAMILIES_WITH_DEFAULT_METHOD = "createFromFamiliesWithDefault";
    private static final String FONT_FAMILY_CLASS = "android.graphics.FontFamily";
    private static final String TAG = "TypefaceCompatApi21Impl";
    private static Method sAddFontWeightStyle;
    private static Method sCreateFromFamiliesWithDefault;
    private static Class<?> sFontFamily;
    private static Constructor<?> sFontFamilyCtor;
    private static boolean sHasInitBeenCalled = false;
    
    private static boolean addFontWeightStyle(final Object obj, final String s, final int i, final boolean b) {
        init();
        try {
            return (boolean)TypefaceCompatApi21Impl.sAddFontWeightStyle.invoke(obj, s, i, b);
        }
        catch (InvocationTargetException cause) {}
        catch (IllegalAccessException ex) {}
        final InvocationTargetException cause;
        throw new RuntimeException(cause);
    }
    
    private static Typeface createFromFamiliesWithDefault(final Object o) {
        init();
        try {
            final Object instance = Array.newInstance(TypefaceCompatApi21Impl.sFontFamily, 1);
            Array.set(instance, 0, o);
            return (Typeface)TypefaceCompatApi21Impl.sCreateFromFamiliesWithDefault.invoke(null, instance);
        }
        catch (InvocationTargetException cause) {}
        catch (IllegalAccessException ex) {}
        final InvocationTargetException cause;
        throw new RuntimeException(cause);
    }
    
    private File getFile(final ParcelFileDescriptor parcelFileDescriptor) {
        try {
            final StringBuilder sb = new StringBuilder();
            sb.append("/proc/self/fd/");
            sb.append(parcelFileDescriptor.getFd());
            final String readlink = Os.readlink(sb.toString());
            if (OsConstants.S_ISREG(Os.stat(readlink).st_mode)) {
                return new File(readlink);
            }
            return null;
        }
        catch (ErrnoException ex) {
            return null;
        }
    }
    
    private static void init() {
        if (TypefaceCompatApi21Impl.sHasInitBeenCalled) {
            return;
        }
        TypefaceCompatApi21Impl.sHasInitBeenCalled = true;
        Constructor<?> sFontFamilyCtor = null;
        GenericDeclaration forName = null;
        Method method = null;
        Method method2 = null;
        Label_0139: {
            try {
                forName = Class.forName("android.graphics.FontFamily");
                final Constructor<?> constructor = ((Class<?>)forName).getConstructor((Class<?>[])new Class[0]);
                method = ((Class)forName).getMethod("addFontWeightStyle", String.class, Integer.TYPE, Boolean.TYPE);
                method2 = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance((Class<?>)forName, 1).getClass());
                sFontFamilyCtor = constructor;
                break Label_0139;
            }
            catch (NoSuchMethodException ex) {}
            catch (ClassNotFoundException ex2) {}
            final NoSuchMethodException ex;
            Log.e("TypefaceCompatApi21Impl", ex.getClass().getName(), (Throwable)ex);
            method2 = (Method)sFontFamilyCtor;
            forName = (method = method2);
        }
        TypefaceCompatApi21Impl.sFontFamilyCtor = sFontFamilyCtor;
        TypefaceCompatApi21Impl.sFontFamily = (Class<?>)forName;
        TypefaceCompatApi21Impl.sAddFontWeightStyle = method;
        TypefaceCompatApi21Impl.sCreateFromFamiliesWithDefault = method2;
    }
    
    private static Object newFamily() {
        init();
        try {
            return TypefaceCompatApi21Impl.sFontFamilyCtor.newInstance(new Object[0]);
        }
        catch (InvocationTargetException cause) {}
        catch (InstantiationException cause) {}
        catch (IllegalAccessException ex) {}
        final InvocationTargetException cause;
        throw new RuntimeException(cause);
    }
    
    @Override
    public Typeface createFromFontFamilyFilesResourceEntry(final Context context, final FontResourcesParserCompat.FontFamilyFilesResourceEntry fontFamilyFilesResourceEntry, final Resources resources, final int n) {
        final Object family = newFamily();
        final FontResourcesParserCompat.FontFileResourceEntry[] entries = fontFamilyFilesResourceEntry.getEntries();
        final int length = entries.length;
        int i = 0;
        while (i < length) {
            final FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry = entries[i];
            final File tempFile = TypefaceCompatUtil.getTempFile(context);
            if (tempFile == null) {
                return null;
            }
            try {
                if (!TypefaceCompatUtil.copyToFile(tempFile, resources, fontFileResourceEntry.getResourceId())) {
                    return null;
                }
                if (!addFontWeightStyle(family, tempFile.getPath(), fontFileResourceEntry.getWeight(), fontFileResourceEntry.isItalic())) {
                    return null;
                }
                tempFile.delete();
                ++i;
                continue;
            }
            catch (RuntimeException ex) {
                return null;
            }
            finally {
                tempFile.delete();
            }
            break;
        }
        return createFromFamiliesWithDefault(family);
    }
    
    @Override
    public Typeface createFromFontInfo(final Context context, final CancellationSignal cancellationSignal, final FontsContractCompat.FontInfo[] array, final int n) {
        if (array.length < 1) {
            return null;
        }
        final FontsContractCompat.FontInfo bestInfo = this.findBestInfo(array, n);
        final ContentResolver contentResolver = context.getContentResolver();
        try {
            final ParcelFileDescriptor openFileDescriptor = contentResolver.openFileDescriptor(bestInfo.getUri(), "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                }
                return null;
            }
            try {
                final File file = this.getFile(openFileDescriptor);
                if (file != null && file.canRead()) {
                    final Typeface fromFile = Typeface.createFromFile(file);
                    if (openFileDescriptor != null) {
                        openFileDescriptor.close();
                    }
                    return fromFile;
                }
                final FileInputStream fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
                try {
                    final Typeface fromInputStream = super.createFromInputStream(context, fileInputStream);
                    fileInputStream.close();
                    if (openFileDescriptor != null) {
                        openFileDescriptor.close();
                    }
                    return fromInputStream;
                }
                finally {
                    try {
                        fileInputStream.close();
                    }
                    finally {}
                }
            }
            finally {
                if (openFileDescriptor != null) {
                    try {
                        openFileDescriptor.close();
                    }
                    finally {}
                }
            }
        }
        catch (IOException ex) {
            return null;
        }
    }
}
