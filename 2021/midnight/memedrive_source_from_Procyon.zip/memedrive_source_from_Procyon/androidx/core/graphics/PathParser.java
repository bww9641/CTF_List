// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.graphics;

import android.util.Log;
import android.graphics.Path;
import java.util.ArrayList;

public class PathParser
{
    private static final String LOGTAG = "PathParser";
    
    private PathParser() {
    }
    
    private static void addNode(final ArrayList<PathDataNode> list, final char c, final float[] array) {
        list.add(new PathDataNode(c, array));
    }
    
    public static boolean canMorph(final PathDataNode[] array, final PathDataNode[] array2) {
        if (array == null || array2 == null) {
            return false;
        }
        if (array.length != array2.length) {
            return false;
        }
        for (int i = 0; i < array.length; ++i) {
            if (array[i].mType != array2[i].mType || array[i].mParams.length != array2[i].mParams.length) {
                return false;
            }
        }
        return true;
    }
    
    static float[] copyOfRange(final float[] array, final int n, final int n2) {
        if (n > n2) {
            throw new IllegalArgumentException();
        }
        final int length = array.length;
        if (n >= 0 && n <= length) {
            final int a = n2 - n;
            final int min = Math.min(a, length - n);
            final float[] array2 = new float[a];
            System.arraycopy(array, n, array2, 0, min);
            return array2;
        }
        throw new ArrayIndexOutOfBoundsException();
    }
    
    public static PathDataNode[] createNodesFromPathData(final String s) {
        if (s == null) {
            return null;
        }
        final ArrayList<PathDataNode> list = new ArrayList<PathDataNode>();
        int i = 1;
        int n = 0;
        while (i < s.length()) {
            final int nextStart = nextStart(s, i);
            final String trim = s.substring(n, nextStart).trim();
            if (trim.length() > 0) {
                addNode(list, trim.charAt(0), getFloats(trim));
            }
            final int n2 = nextStart + 1;
            n = nextStart;
            i = n2;
        }
        if (i - n == 1 && n < s.length()) {
            addNode(list, s.charAt(n), new float[0]);
        }
        return list.toArray(new PathDataNode[list.size()]);
    }
    
    public static Path createPathFromPathData(final String str) {
        final Path path = new Path();
        final PathDataNode[] nodesFromPathData = createNodesFromPathData(str);
        if (nodesFromPathData != null) {
            try {
                PathDataNode.nodesToPath(nodesFromPathData, path);
                return path;
            }
            catch (RuntimeException cause) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Error in parsing ");
                sb.append(str);
                throw new RuntimeException(sb.toString(), cause);
            }
        }
        return null;
    }
    
    public static PathDataNode[] deepCopyNodes(final PathDataNode[] array) {
        if (array == null) {
            return null;
        }
        final PathDataNode[] array2 = new PathDataNode[array.length];
        for (int i = 0; i < array.length; ++i) {
            array2[i] = new PathDataNode(array[i]);
        }
        return array2;
    }
    
    private static void extract(final String s, final int n, final ExtractFloatResult extractFloatResult) {
        extractFloatResult.mEndWithNegOrDot = false;
        int i = n;
        int n2 = 0;
        int n3 = 0;
        boolean b = false;
        while (i < s.length()) {
            final char char1 = s.charAt(i);
            Label_0141: {
                Label_0135: {
                    if (char1 != ' ') {
                        if (char1 != 'E' && char1 != 'e') {
                            switch (char1) {
                                case 46: {
                                    if (n3 == 0) {
                                        n3 = 1;
                                        n2 = 0;
                                        break Label_0141;
                                    }
                                    extractFloatResult.mEndWithNegOrDot = true;
                                    break Label_0135;
                                }
                                case 45: {
                                    if (i != n && n2 == 0) {
                                        extractFloatResult.mEndWithNegOrDot = true;
                                        break Label_0135;
                                    }
                                    break;
                                }
                                case 44: {
                                    break Label_0135;
                                }
                            }
                            n2 = 0;
                            break Label_0141;
                        }
                        n2 = 1;
                        break Label_0141;
                    }
                }
                n2 = 0;
                b = true;
            }
            if (b) {
                break;
            }
            ++i;
        }
        extractFloatResult.mEndPosition = i;
    }
    
    private static float[] getFloats(final String str) {
        if (str.charAt(0) != 'z') {
            if (str.charAt(0) != 'Z') {
                while (true) {
                    while (true) {
                        int mEndPosition = 0;
                        Label_0181: {
                            try {
                                final float[] array = new float[str.length()];
                                final ExtractFloatResult extractFloatResult = new ExtractFloatResult();
                                final int length = str.length();
                                int i = 1;
                                int n = 0;
                                while (i < length) {
                                    extract(str, i, extractFloatResult);
                                    mEndPosition = extractFloatResult.mEndPosition;
                                    if (i < mEndPosition) {
                                        final int n2 = n + 1;
                                        array[n] = Float.parseFloat(str.substring(i, mEndPosition));
                                        n = n2;
                                    }
                                    if (!extractFloatResult.mEndWithNegOrDot) {
                                        break Label_0181;
                                    }
                                    i = mEndPosition;
                                }
                                return copyOfRange(array, 0, n);
                            }
                            catch (NumberFormatException cause) {
                                final StringBuilder sb = new StringBuilder();
                                sb.append("error in parsing \"");
                                sb.append(str);
                                sb.append("\"");
                                throw new RuntimeException(sb.toString(), cause);
                            }
                            break;
                        }
                        int i = mEndPosition + 1;
                        continue;
                    }
                }
            }
        }
        return new float[0];
    }
    
    public static boolean interpolatePathDataNodes(final PathDataNode[] array, final PathDataNode[] array2, final PathDataNode[] array3, final float n) {
        if (array == null || array2 == null || array3 == null) {
            throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes cannot be null");
        }
        if (array.length != array2.length || array2.length != array3.length) {
            throw new IllegalArgumentException("The nodes to be interpolated and resulting nodes must have the same length");
        }
        final boolean canMorph = canMorph(array2, array3);
        int i = 0;
        if (!canMorph) {
            return false;
        }
        while (i < array.length) {
            array[i].interpolatePathDataNode(array2[i], array3[i], n);
            ++i;
        }
        return true;
    }
    
    private static int nextStart(final String s, int i) {
        while (i < s.length()) {
            final char char1 = s.charAt(i);
            if (((char1 - 'A') * (char1 - 'Z') <= 0 || (char1 - 'a') * (char1 - 'z') <= 0) && char1 != 'e' && char1 != 'E') {
                return i;
            }
            ++i;
        }
        return i;
    }
    
    public static void updateNodes(final PathDataNode[] array, final PathDataNode[] array2) {
        for (int i = 0; i < array2.length; ++i) {
            array[i].mType = array2[i].mType;
            for (int j = 0; j < array2[i].mParams.length; ++j) {
                array[i].mParams[j] = array2[i].mParams[j];
            }
        }
    }
    
    private static class ExtractFloatResult
    {
        int mEndPosition;
        boolean mEndWithNegOrDot;
        
        ExtractFloatResult() {
        }
    }
    
    public static class PathDataNode
    {
        public float[] mParams;
        public char mType;
        
        PathDataNode(final char mType, final float[] mParams) {
            this.mType = mType;
            this.mParams = mParams;
        }
        
        PathDataNode(final PathDataNode pathDataNode) {
            this.mType = pathDataNode.mType;
            final float[] mParams = pathDataNode.mParams;
            this.mParams = PathParser.copyOfRange(mParams, 0, mParams.length);
        }
        
        private static void addCommand(final Path path, final float[] array, final char c, final char c2, final float[] array2) {
            char c3 = c2;
            float n = array[0];
            float n2 = array[1];
            float n3 = array[2];
            float n4 = array[3];
            final float n5 = array[4];
            final float n6 = array[5];
            int n7 = 0;
            Label_0264: {
                switch (c3) {
                    case 90:
                    case 122: {
                        path.close();
                        path.moveTo(n5, n6);
                        n = (n3 = n5);
                        n2 = (n4 = n6);
                        break;
                    }
                    case 81:
                    case 83:
                    case 113:
                    case 115: {
                        n7 = 4;
                        break Label_0264;
                    }
                    case 72:
                    case 86:
                    case 104:
                    case 118: {
                        n7 = 1;
                        break Label_0264;
                    }
                    case 67:
                    case 99: {
                        n7 = 6;
                        break Label_0264;
                    }
                    case 65:
                    case 97: {
                        n7 = 7;
                        break Label_0264;
                    }
                }
                n7 = 2;
            }
            float n8 = n;
            float n9 = n2;
            float n10 = n5;
            float n11 = n6;
            int i = 0;
            char c4 = c;
            while (i < array2.length) {
                int n12 = 0;
                Label_2157: {
                    if (c3 != 'A') {
                        if (c3 == 'C') {
                            n12 = i;
                            final float n13 = array2[n12 + 0];
                            final float n14 = array2[n12 + 1];
                            final int n15 = n12 + 2;
                            final float n16 = array2[n15];
                            final int n17 = n12 + 3;
                            final float n18 = array2[n17];
                            final int n19 = n12 + 4;
                            final float n20 = array2[n19];
                            final int n21 = n12 + 5;
                            path.cubicTo(n13, n14, n16, n18, n20, array2[n21]);
                            n8 = array2[n19];
                            final float n22 = array2[n21];
                            final float n23 = array2[n15];
                            final float n24 = array2[n17];
                            n9 = n22;
                            n4 = n24;
                            n3 = n23;
                            break Label_2157;
                        }
                        if (c3 == 'H') {
                            n12 = i;
                            final float n25 = n9;
                            final int n26 = n12 + 0;
                            path.lineTo(array2[n26], n25);
                            n8 = array2[n26];
                            break Label_2157;
                        }
                        if (c3 == 'Q') {
                            n12 = i;
                            final int n27 = n12 + 0;
                            final float n28 = array2[n27];
                            final int n29 = n12 + 1;
                            final float n30 = array2[n29];
                            final int n31 = n12 + 2;
                            final float n32 = array2[n31];
                            final int n33 = n12 + 3;
                            path.quadTo(n28, n30, n32, array2[n33]);
                            final float n34 = array2[n27];
                            final float n35 = array2[n29];
                            n8 = array2[n31];
                            n9 = array2[n33];
                            n3 = n34;
                            n4 = n35;
                            break Label_2157;
                        }
                        if (c3 == 'V') {
                            n12 = i;
                            final float n36 = n8;
                            final int n37 = n12 + 0;
                            path.lineTo(n36, array2[n37]);
                            n9 = array2[n37];
                            break Label_2157;
                        }
                        if (c3 != 'a') {
                            while (true) {
                                float n47 = 0.0f;
                                float n48 = 0.0f;
                                Label_1521: {
                                    float n49 = 0.0f;
                                    Label_1514: {
                                        if (c3 == 'c') {
                                            final float n38 = array2[i + 0];
                                            final float n39 = array2[i + 1];
                                            final int n40 = i + 2;
                                            final float n41 = array2[n40];
                                            final int n42 = i + 3;
                                            final float n43 = array2[n42];
                                            final int n44 = i + 4;
                                            final float n45 = array2[n44];
                                            final int n46 = i + 5;
                                            path.rCubicTo(n38, n39, n41, n43, n45, array2[n46]);
                                            n47 = n8 + array2[n40];
                                            n48 = n9 + array2[n42];
                                            n8 += array2[n44];
                                            n49 = array2[n46];
                                            break Label_1514;
                                        }
                                        if (c3 != 'h') {
                                            if (c3 == 'q') {
                                                final int n50 = i + 0;
                                                final float n51 = array2[n50];
                                                final int n52 = i + 1;
                                                final float n53 = array2[n52];
                                                final int n54 = i + 2;
                                                final float n55 = array2[n54];
                                                final int n56 = i + 3;
                                                path.rQuadTo(n51, n53, n55, array2[n56]);
                                                n47 = n8 + array2[n50];
                                                n48 = n9 + array2[n52];
                                                n8 += array2[n54];
                                                n49 = array2[n56];
                                                break Label_1514;
                                            }
                                            float n74 = 0.0f;
                                            Label_0840: {
                                                if (c3 != 'v') {
                                                    if (c3 != 'L') {
                                                        if (c3 != 'M') {
                                                            if (c3 == 'S') {
                                                                if (c4 == 'c' || c4 == 's' || c4 == 'C' || c4 == 'S') {
                                                                    n8 = n8 * 2.0f - n3;
                                                                    n9 = n9 * 2.0f - n4;
                                                                }
                                                                final float n57 = n9;
                                                                final float n58 = n8;
                                                                final int n59 = i + 0;
                                                                final float n60 = array2[n59];
                                                                final int n61 = i + 1;
                                                                final float n62 = array2[n61];
                                                                final int n63 = i + 2;
                                                                final float n64 = array2[n63];
                                                                final int n65 = i + 3;
                                                                path.cubicTo(n58, n57, n60, n62, n64, array2[n65]);
                                                                n47 = array2[n59];
                                                                n48 = array2[n61];
                                                                n8 = array2[n63];
                                                                n9 = array2[n65];
                                                                break Label_1521;
                                                            }
                                                            if (c3 == 'T') {
                                                                if (c4 == 'q' || c4 == 't' || c4 == 'Q' || c4 == 'T') {
                                                                    n8 = n8 * 2.0f - n3;
                                                                    n9 = n9 * 2.0f - n4;
                                                                }
                                                                final int n66 = i + 0;
                                                                final float n67 = array2[n66];
                                                                final int n68 = i + 1;
                                                                path.quadTo(n8, n9, n67, array2[n68]);
                                                                final float n69 = array2[n66];
                                                                final float n70 = array2[n68];
                                                                n12 = i;
                                                                n4 = n9;
                                                                n3 = n8;
                                                                n8 = n69;
                                                                n9 = n70;
                                                                break Label_2157;
                                                            }
                                                            if (c3 == 'l') {
                                                                final int n71 = i + 0;
                                                                final float n72 = array2[n71];
                                                                final int n73 = i + 1;
                                                                path.rLineTo(n72, array2[n73]);
                                                                n8 += array2[n71];
                                                                n74 = array2[n73];
                                                                break Label_0840;
                                                            }
                                                            if (c3 != 'm') {
                                                                if (c3 == 's') {
                                                                    float n75;
                                                                    float n76;
                                                                    if (c4 != 'c' && c4 != 's' && c4 != 'C' && c4 != 'S') {
                                                                        n75 = 0.0f;
                                                                        n76 = 0.0f;
                                                                    }
                                                                    else {
                                                                        final float n77 = n8 - n3;
                                                                        n76 = n9 - n4;
                                                                        n75 = n77;
                                                                    }
                                                                    final int n78 = i + 0;
                                                                    final float n79 = array2[n78];
                                                                    final int n80 = i + 1;
                                                                    final float n81 = array2[n80];
                                                                    final int n82 = i + 2;
                                                                    final float n83 = array2[n82];
                                                                    final int n84 = i + 3;
                                                                    path.rCubicTo(n75, n76, n79, n81, n83, array2[n84]);
                                                                    n47 = n8 + array2[n78];
                                                                    n48 = n9 + array2[n80];
                                                                    n8 += array2[n82];
                                                                    n49 = array2[n84];
                                                                    break Label_1514;
                                                                }
                                                                if (c3 != 't') {
                                                                    break Label_0420;
                                                                }
                                                                float n85;
                                                                float n86;
                                                                if (c4 != 'q' && c4 != 't' && c4 != 'Q' && c4 != 'T') {
                                                                    n85 = 0.0f;
                                                                    n86 = 0.0f;
                                                                }
                                                                else {
                                                                    n86 = n8 - n3;
                                                                    n85 = n9 - n4;
                                                                }
                                                                final int n87 = i + 0;
                                                                final float n88 = array2[n87];
                                                                final int n89 = i + 1;
                                                                path.rQuadTo(n86, n85, n88, array2[n89]);
                                                                final float n90 = n86 + n8;
                                                                final float n91 = n85 + n9;
                                                                n8 += array2[n87];
                                                                n9 += array2[n89];
                                                                n4 = n91;
                                                                n3 = n90;
                                                                break Label_0420;
                                                            }
                                                            else {
                                                                final int n92 = i + 0;
                                                                n8 += array2[n92];
                                                                final int n93 = i + 1;
                                                                n9 += array2[n93];
                                                                if (i > 0) {
                                                                    path.rLineTo(array2[n92], array2[n93]);
                                                                    break Label_0420;
                                                                }
                                                                path.rMoveTo(array2[n92], array2[n93]);
                                                            }
                                                        }
                                                        else {
                                                            final int n94 = i + 0;
                                                            n8 = array2[n94];
                                                            final int n95 = i + 1;
                                                            n9 = array2[n95];
                                                            if (i > 0) {
                                                                path.lineTo(array2[n94], array2[n95]);
                                                                break Label_0420;
                                                            }
                                                            path.moveTo(array2[n94], array2[n95]);
                                                        }
                                                        n12 = i;
                                                        n11 = n9;
                                                        n10 = n8;
                                                        break Label_2157;
                                                    }
                                                    final int n96 = i + 0;
                                                    final float n97 = array2[n96];
                                                    final int n98 = i + 1;
                                                    path.lineTo(n97, array2[n98]);
                                                    n8 = array2[n96];
                                                    n9 = array2[n98];
                                                    break Label_0420;
                                                }
                                                else {
                                                    final int n99 = i + 0;
                                                    path.rLineTo(0.0f, array2[n99]);
                                                    n74 = array2[n99];
                                                }
                                            }
                                            n9 += n74;
                                        }
                                        else {
                                            final int n100 = i + 0;
                                            path.rLineTo(array2[n100], 0.0f);
                                            n8 += array2[n100];
                                        }
                                        n12 = i;
                                        break Label_2157;
                                    }
                                    n9 += n49;
                                }
                                n3 = n47;
                                n4 = n48;
                                continue;
                            }
                        }
                        final int n101 = i + 5;
                        final float n102 = n8 + array2[n101];
                        final int n103 = i + 6;
                        final float n104 = n9 + array2[n103];
                        final float n105 = array2[i + 0];
                        final float n106 = array2[i + 1];
                        final float n107 = array2[i + 2];
                        final boolean b = array2[i + 3] != 0.0f;
                        final boolean b2 = array2[i + 4] != 0.0f;
                        final float n108 = n8;
                        final float n109 = n9;
                        n12 = i;
                        final float n110 = n9;
                        final boolean b3 = b;
                        final float n111 = n8;
                        drawArc(path, n108, n109, n102, n104, n105, n106, n107, b3, b2);
                        n8 = n111 + array2[n101];
                        n9 = n110 + array2[n103];
                    }
                    else {
                        n12 = i;
                        final float n112 = n9;
                        final float n113 = n8;
                        final int n114 = n12 + 5;
                        final float n115 = array2[n114];
                        final int n116 = n12 + 6;
                        drawArc(path, n113, n112, n115, array2[n116], array2[n12 + 0], array2[n12 + 1], array2[n12 + 2], array2[n12 + 3] != 0.0f, array2[n12 + 4] != 0.0f);
                        n8 = array2[n114];
                        n9 = array2[n116];
                    }
                    n4 = n9;
                    n3 = n8;
                }
                i = n12 + n7;
                c4 = (c3 = c2);
            }
            final float n117 = n9;
            array[0] = n8;
            array[1] = n117;
            array[2] = n3;
            array[3] = n4;
            array[4] = n10;
            array[5] = n11;
        }
        
        private static void arcToBezier(final Path path, final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8, final double n9) {
            double n10 = n3;
            int n11 = (int)Math.ceil(Math.abs(n9 * 4.0 / 3.141592653589793));
            double cos = Math.cos(n7);
            double sin = Math.sin(n7);
            final double cos2 = Math.cos(n8);
            final double sin2 = Math.sin(n8);
            final double n12 = -n10;
            final double n13 = n12 * cos;
            final double n14 = n13 * sin2;
            final double n15 = n4 * sin;
            final double n16 = n14 - n15 * cos2;
            double n17 = n12 * sin;
            final double n18 = sin2 * n17;
            final double n19 = n4 * cos;
            final double n20 = n18 + cos2 * n19;
            final double v = n11;
            Double.isNaN(v);
            double n21 = n9 / v;
            double n22 = n8;
            double n23 = n20;
            double n24 = n16;
            int i = 0;
            double n25 = n5;
            double n26 = n6;
            while (i < n11) {
                final double n27 = n22 + n21;
                final double sin3 = Math.sin(n27);
                final double cos3 = Math.cos(n27);
                final double n28 = n + cos3 * (n10 * cos);
                final double n29 = n15 * sin3;
                final int n30 = n11;
                final double n31 = n28 - n29;
                final double n32 = n2 + cos3 * (n10 * sin) + n19 * sin3;
                final double n33 = n13 * sin3 - n15 * cos3;
                final double n34 = sin3 * n17 + cos3 * n19;
                final double a = n27 - n22;
                final double tan = Math.tan(a / 2.0);
                final double n35 = Math.sin(a) * (Math.sqrt(4.0 + tan * (tan * 3.0)) - 1.0) / 3.0;
                final double n36 = n25 + n24 * n35;
                final double n37 = n23 * n35;
                final double n38 = cos;
                final double n39 = n26 + n37;
                final double n40 = n35 * n33;
                final double n41 = sin;
                final double n42 = n31 - n40;
                final double n43 = n35 * n34;
                final double n44 = n21;
                final double n45 = n32 - n43;
                final double n46 = n17;
                path.rLineTo(0.0f, 0.0f);
                path.cubicTo((float)n36, (float)n39, (float)n42, (float)n45, (float)n31, (float)n32);
                ++i;
                n21 = n44;
                sin = n41;
                n25 = n31;
                n17 = n46;
                cos = n38;
                n22 = n27;
                n23 = n34;
                n24 = n33;
                n11 = n30;
                n26 = n32;
                n10 = n3;
            }
        }
        
        private static void drawArc(final Path path, final float n, final float n2, final float n3, final float n4, final float n5, final float n6, final float n7, final boolean b, final boolean b2) {
            final double radians = Math.toRadians(n7);
            final double cos = Math.cos(radians);
            final double sin = Math.sin(radians);
            final double v = n;
            Double.isNaN(v);
            final double n8 = v * cos;
            final double n9 = n2;
            Double.isNaN(n9);
            final double n10 = n8 + n9 * sin;
            final double v2 = n5;
            Double.isNaN(v2);
            final double n11 = n10 / v2;
            final double v3 = -n;
            Double.isNaN(v3);
            final double n12 = v3 * sin;
            Double.isNaN(n9);
            final double n13 = n12 + n9 * cos;
            final double v4 = n6;
            Double.isNaN(v4);
            final double n14 = n13 / v4;
            final double v5 = n3;
            Double.isNaN(v5);
            final double n15 = v5 * cos;
            final double n16 = n4;
            Double.isNaN(n16);
            final double n17 = n15 + n16 * sin;
            Double.isNaN(v2);
            final double n18 = n17 / v2;
            final double v6 = -n3;
            Double.isNaN(v6);
            final double n19 = v6 * sin;
            Double.isNaN(n16);
            final double n20 = n19 + n16 * cos;
            Double.isNaN(v4);
            final double n21 = n20 / v4;
            final double n22 = n11 - n18;
            final double n23 = n14 - n21;
            final double n24 = (n11 + n18) / 2.0;
            final double n25 = (n14 + n21) / 2.0;
            final double n26 = n22 * n22 + n23 * n23;
            if (n26 == 0.0) {
                Log.w("PathParser", " Points are coincident");
                return;
            }
            final double a = 1.0 / n26 - 0.25;
            if (a < 0.0) {
                final StringBuilder sb = new StringBuilder();
                sb.append("Points are too far apart ");
                sb.append(n26);
                Log.w("PathParser", sb.toString());
                final float n27 = (float)(Math.sqrt(n26) / 1.99999);
                drawArc(path, n, n2, n3, n4, n5 * n27, n6 * n27, n7, b, b2);
                return;
            }
            final double sqrt = Math.sqrt(a);
            final double n28 = n22 * sqrt;
            final double n29 = sqrt * n23;
            double n30;
            double n31;
            if (b == b2) {
                n30 = n24 - n29;
                n31 = n25 + n28;
            }
            else {
                n30 = n24 + n29;
                n31 = n25 - n28;
            }
            final double atan2 = Math.atan2(n14 - n31, n11 - n30);
            double n32 = Math.atan2(n21 - n31, n18 - n30) - atan2;
            if (b2 != n32 >= 0.0) {
                if (n32 > 0.0) {
                    n32 -= 6.283185307179586;
                }
                else {
                    n32 += 6.283185307179586;
                }
            }
            Double.isNaN(v2);
            final double n33 = n30 * v2;
            Double.isNaN(v4);
            final double n34 = n31 * v4;
            arcToBezier(path, n33 * cos - n34 * sin, n33 * sin + n34 * cos, v2, v4, v, n9, radians, atan2, n32);
        }
        
        public static void nodesToPath(final PathDataNode[] array, final Path path) {
            final float[] array2 = new float[6];
            char mType = 'm';
            for (int i = 0; i < array.length; ++i) {
                addCommand(path, array2, mType, array[i].mType, array[i].mParams);
                mType = array[i].mType;
            }
        }
        
        public void interpolatePathDataNode(final PathDataNode pathDataNode, final PathDataNode pathDataNode2, final float n) {
            this.mType = pathDataNode.mType;
            int n2 = 0;
            while (true) {
                final float[] mParams = pathDataNode.mParams;
                if (n2 >= mParams.length) {
                    break;
                }
                this.mParams[n2] = mParams[n2] * (1.0f - n) + n * pathDataNode2.mParams[n2];
                ++n2;
            }
        }
    }
}
