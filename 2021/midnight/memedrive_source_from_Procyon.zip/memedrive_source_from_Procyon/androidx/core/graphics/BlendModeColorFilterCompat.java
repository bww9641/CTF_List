// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.graphics;

import android.graphics.PorterDuff$Mode;
import android.graphics.BlendMode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.BlendModeColorFilter;
import android.os.Build$VERSION;
import android.graphics.ColorFilter;

public class BlendModeColorFilterCompat
{
    private BlendModeColorFilterCompat() {
    }
    
    public static ColorFilter createBlendModeColorFilterCompat(final int n, final BlendModeCompat blendModeCompat) {
        if (Build$VERSION.SDK_INT >= 29) {
            final BlendMode obtainBlendModeFromCompat = BlendModeUtils.obtainBlendModeFromCompat(blendModeCompat);
            Object o = null;
            if (obtainBlendModeFromCompat != null) {
                o = new BlendModeColorFilter(n, obtainBlendModeFromCompat);
            }
            return (ColorFilter)o;
        }
        final PorterDuff$Mode obtainPorterDuffFromCompat = BlendModeUtils.obtainPorterDuffFromCompat(blendModeCompat);
        Object o2 = null;
        if (obtainPorterDuffFromCompat != null) {
            o2 = new PorterDuffColorFilter(n, obtainPorterDuffFromCompat);
        }
        return (ColorFilter)o2;
    }
}
