// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view;

import android.view.View;

public interface OnApplyWindowInsetsListener
{
    WindowInsetsCompat onApplyWindowInsets(final View p0, final WindowInsetsCompat p1);
}
