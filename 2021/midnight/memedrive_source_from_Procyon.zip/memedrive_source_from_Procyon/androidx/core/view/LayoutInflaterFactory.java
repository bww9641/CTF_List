// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view;

import android.util.AttributeSet;
import android.content.Context;
import android.view.View;

@Deprecated
public interface LayoutInflaterFactory
{
    View onCreateView(final View p0, final String p1, final Context p2, final AttributeSet p3);
}
