// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view;

import androidx.core.util.Preconditions;
import android.text.TextUtils;
import android.app.UiModeManager;
import android.os.Build;
import java.util.ArrayList;
import android.view.Display$Mode;
import android.os.Build$VERSION;
import android.graphics.Point;
import android.view.Display;
import android.content.Context;

public final class DisplayCompat
{
    private static final int DISPLAY_SIZE_4K_HEIGHT = 2160;
    private static final int DISPLAY_SIZE_4K_WIDTH = 3840;
    
    private DisplayCompat() {
    }
    
    private static Point getPhysicalDisplaySize(final Context context, final Display display) {
        Point point;
        if (Build$VERSION.SDK_INT < 28) {
            point = parsePhysicalDisplaySizeFromSystemProperties("sys.display-size", display);
        }
        else {
            point = parsePhysicalDisplaySizeFromSystemProperties("vendor.display-size", display);
        }
        if (point != null) {
            return point;
        }
        if (isSonyBravia4kTv(context)) {
            return new Point(3840, 2160);
        }
        final Point point2 = new Point();
        if (Build$VERSION.SDK_INT >= 23) {
            final Display$Mode mode = display.getMode();
            point2.x = mode.getPhysicalWidth();
            point2.y = mode.getPhysicalHeight();
        }
        else if (Build$VERSION.SDK_INT >= 17) {
            display.getRealSize(point2);
        }
        else {
            display.getSize(point2);
        }
        return point2;
    }
    
    public static ModeCompat[] getSupportedModes(final Context context, final Display display) {
        final Point physicalDisplaySize = getPhysicalDisplaySize(context, display);
        if (Build$VERSION.SDK_INT >= 23) {
            final Display$Mode[] supportedModes = display.getSupportedModes();
            final ArrayList list = new ArrayList<ModeCompat>(supportedModes.length);
            int i = 0;
            boolean b = false;
            while (i < supportedModes.length) {
                if (physicalSizeEquals(supportedModes[i], physicalDisplaySize)) {
                    list.add(i, new ModeCompat(supportedModes[i], true));
                    b = true;
                }
                else {
                    list.add(i, new ModeCompat(supportedModes[i], false));
                }
                ++i;
            }
            if (!b) {
                list.add(new ModeCompat(physicalDisplaySize));
            }
            return list.toArray(new ModeCompat[0]);
        }
        return new ModeCompat[] { new ModeCompat(physicalDisplaySize) };
    }
    
    private static String getSystemProperty(final String s) {
        try {
            final Class<?> forName = Class.forName("android.os.SystemProperties");
            return (String)forName.getMethod("get", String.class).invoke(forName, s);
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    private static boolean isSonyBravia4kTv(final Context context) {
        return isTv(context) && "Sony".equals(Build.MANUFACTURER) && Build.MODEL.startsWith("BRAVIA") && context.getPackageManager().hasSystemFeature("com.sony.dtv.hardware.panel.qfhd");
    }
    
    private static boolean isTv(final Context context) {
        final UiModeManager uiModeManager = (UiModeManager)context.getSystemService("uimode");
        return uiModeManager != null && uiModeManager.getCurrentModeType() == 4;
    }
    
    private static Point parseDisplaySize(final String s) throws NumberFormatException {
        final String[] split = s.trim().split("x", -1);
        if (split.length == 2) {
            final int int1 = Integer.parseInt(split[0]);
            final int int2 = Integer.parseInt(split[1]);
            if (int1 > 0 && int2 > 0) {
                return new Point(int1, int2);
            }
        }
        throw new NumberFormatException();
    }
    
    private static Point parsePhysicalDisplaySizeFromSystemProperties(final String s, final Display display) {
        String systemProperty = null;
        if (display.getDisplayId() == 0) {
            systemProperty = getSystemProperty(s);
            if (!TextUtils.isEmpty((CharSequence)systemProperty)) {}
        }
        try {
            return parseDisplaySize(systemProperty);
        }
        catch (NumberFormatException ex) {
            return null;
        }
    }
    
    private static boolean physicalSizeEquals(final Display$Mode display$Mode, final Point point) {
        return (display$Mode.getPhysicalWidth() == point.x && display$Mode.getPhysicalHeight() == point.y) || (display$Mode.getPhysicalWidth() == point.y && display$Mode.getPhysicalHeight() == point.x);
    }
    
    public static final class ModeCompat
    {
        private final boolean mIsNative;
        private final Display$Mode mMode;
        private final Point mPhysicalDisplaySize;
        
        ModeCompat(final Point mPhysicalDisplaySize) {
            Preconditions.checkNotNull(mPhysicalDisplaySize, "physicalDisplaySize == null");
            this.mIsNative = true;
            this.mPhysicalDisplaySize = mPhysicalDisplaySize;
            this.mMode = null;
        }
        
        ModeCompat(final Display$Mode mMode, final boolean mIsNative) {
            Preconditions.checkNotNull(mMode, "Display.Mode == null, can't wrap a null reference");
            this.mIsNative = mIsNative;
            this.mPhysicalDisplaySize = new Point(mMode.getPhysicalWidth(), mMode.getPhysicalHeight());
            this.mMode = mMode;
        }
        
        public int getPhysicalHeight() {
            return this.mPhysicalDisplaySize.y;
        }
        
        public int getPhysicalWidth() {
            return this.mPhysicalDisplaySize.x;
        }
        
        public boolean isNative() {
            return this.mIsNative;
        }
        
        public Display$Mode toMode() {
            return this.mMode;
        }
    }
}
