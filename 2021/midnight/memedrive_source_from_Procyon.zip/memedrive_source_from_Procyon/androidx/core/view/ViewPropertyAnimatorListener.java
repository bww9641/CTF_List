// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view;

import android.view.View;

public interface ViewPropertyAnimatorListener
{
    void onAnimationCancel(final View p0);
    
    void onAnimationEnd(final View p0);
    
    void onAnimationStart(final View p0);
}
