// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view;

import android.view.DisplayCutout;
import android.view.WindowInsets$Builder;
import android.util.Log;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import android.graphics.Rect;
import androidx.core.util.ObjectsCompat;
import androidx.core.util.Preconditions;
import androidx.core.graphics.Insets;
import android.os.Build$VERSION;
import android.view.WindowInsets;

public class WindowInsetsCompat
{
    public static final WindowInsetsCompat CONSUMED;
    private static final String TAG = "WindowInsetsCompat";
    private final Impl mImpl;
    
    static {
        CONSUMED = new Builder().build().consumeDisplayCutout().consumeStableInsets().consumeSystemWindowInsets();
    }
    
    private WindowInsetsCompat(final WindowInsets windowInsets) {
        if (Build$VERSION.SDK_INT >= 29) {
            this.mImpl = (Impl)new Impl29(this, windowInsets);
        }
        else if (Build$VERSION.SDK_INT >= 28) {
            this.mImpl = (Impl)new Impl28(this, windowInsets);
        }
        else if (Build$VERSION.SDK_INT >= 21) {
            this.mImpl = (Impl)new Impl21(this, windowInsets);
        }
        else if (Build$VERSION.SDK_INT >= 20) {
            this.mImpl = (Impl)new Impl20(this, windowInsets);
        }
        else {
            this.mImpl = new Impl(this);
        }
    }
    
    public WindowInsetsCompat(final WindowInsetsCompat windowInsetsCompat) {
        if (windowInsetsCompat != null) {
            final Impl mImpl = windowInsetsCompat.mImpl;
            if (Build$VERSION.SDK_INT >= 29 && mImpl instanceof Impl29) {
                this.mImpl = (Impl)new Impl29(this, (Impl29)mImpl);
            }
            else if (Build$VERSION.SDK_INT >= 28 && mImpl instanceof Impl28) {
                this.mImpl = (Impl)new Impl28(this, (Impl28)mImpl);
            }
            else if (Build$VERSION.SDK_INT >= 21 && mImpl instanceof Impl21) {
                this.mImpl = (Impl)new Impl21(this, (Impl21)mImpl);
            }
            else if (Build$VERSION.SDK_INT >= 20 && mImpl instanceof Impl20) {
                this.mImpl = (Impl)new Impl20(this, (Impl20)mImpl);
            }
            else {
                this.mImpl = new Impl(this);
            }
        }
        else {
            this.mImpl = new Impl(this);
        }
    }
    
    static Insets insetInsets(final Insets insets, final int n, final int n2, final int n3, final int n4) {
        final int max = Math.max(0, insets.left - n);
        final int max2 = Math.max(0, insets.top - n2);
        final int max3 = Math.max(0, insets.right - n3);
        final int max4 = Math.max(0, insets.bottom - n4);
        if (max == n && max2 == n2 && max3 == n3 && max4 == n4) {
            return insets;
        }
        return Insets.of(max, max2, max3, max4);
    }
    
    public static WindowInsetsCompat toWindowInsetsCompat(final WindowInsets windowInsets) {
        return new WindowInsetsCompat(Preconditions.checkNotNull(windowInsets));
    }
    
    public WindowInsetsCompat consumeDisplayCutout() {
        return this.mImpl.consumeDisplayCutout();
    }
    
    public WindowInsetsCompat consumeStableInsets() {
        return this.mImpl.consumeStableInsets();
    }
    
    public WindowInsetsCompat consumeSystemWindowInsets() {
        return this.mImpl.consumeSystemWindowInsets();
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof WindowInsetsCompat && ObjectsCompat.equals(this.mImpl, ((WindowInsetsCompat)o).mImpl));
    }
    
    public DisplayCutoutCompat getDisplayCutout() {
        return this.mImpl.getDisplayCutout();
    }
    
    public Insets getMandatorySystemGestureInsets() {
        return this.mImpl.getMandatorySystemGestureInsets();
    }
    
    public int getStableInsetBottom() {
        return this.getStableInsets().bottom;
    }
    
    public int getStableInsetLeft() {
        return this.getStableInsets().left;
    }
    
    public int getStableInsetRight() {
        return this.getStableInsets().right;
    }
    
    public int getStableInsetTop() {
        return this.getStableInsets().top;
    }
    
    public Insets getStableInsets() {
        return this.mImpl.getStableInsets();
    }
    
    public Insets getSystemGestureInsets() {
        return this.mImpl.getSystemGestureInsets();
    }
    
    public int getSystemWindowInsetBottom() {
        return this.getSystemWindowInsets().bottom;
    }
    
    public int getSystemWindowInsetLeft() {
        return this.getSystemWindowInsets().left;
    }
    
    public int getSystemWindowInsetRight() {
        return this.getSystemWindowInsets().right;
    }
    
    public int getSystemWindowInsetTop() {
        return this.getSystemWindowInsets().top;
    }
    
    public Insets getSystemWindowInsets() {
        return this.mImpl.getSystemWindowInsets();
    }
    
    public Insets getTappableElementInsets() {
        return this.mImpl.getTappableElementInsets();
    }
    
    public boolean hasInsets() {
        return this.hasSystemWindowInsets() || this.hasStableInsets() || this.getDisplayCutout() != null || !this.getSystemGestureInsets().equals(Insets.NONE) || !this.getMandatorySystemGestureInsets().equals(Insets.NONE) || !this.getTappableElementInsets().equals(Insets.NONE);
    }
    
    public boolean hasStableInsets() {
        return true ^ this.getStableInsets().equals(Insets.NONE);
    }
    
    public boolean hasSystemWindowInsets() {
        return true ^ this.getSystemWindowInsets().equals(Insets.NONE);
    }
    
    @Override
    public int hashCode() {
        final Impl mImpl = this.mImpl;
        int hashCode;
        if (mImpl == null) {
            hashCode = 0;
        }
        else {
            hashCode = mImpl.hashCode();
        }
        return hashCode;
    }
    
    public WindowInsetsCompat inset(final int n, final int n2, final int n3, final int n4) {
        return this.mImpl.inset(n, n2, n3, n4);
    }
    
    public WindowInsetsCompat inset(final Insets insets) {
        return this.inset(insets.left, insets.top, insets.right, insets.bottom);
    }
    
    public boolean isConsumed() {
        return this.mImpl.isConsumed();
    }
    
    public boolean isRound() {
        return this.mImpl.isRound();
    }
    
    @Deprecated
    public WindowInsetsCompat replaceSystemWindowInsets(final int n, final int n2, final int n3, final int n4) {
        return new Builder(this).setSystemWindowInsets(Insets.of(n, n2, n3, n4)).build();
    }
    
    @Deprecated
    public WindowInsetsCompat replaceSystemWindowInsets(final Rect rect) {
        return new Builder(this).setSystemWindowInsets(Insets.of(rect)).build();
    }
    
    public WindowInsets toWindowInsets() {
        final Impl mImpl = this.mImpl;
        WindowInsets mPlatformInsets;
        if (mImpl instanceof Impl20) {
            mPlatformInsets = ((Impl20)mImpl).mPlatformInsets;
        }
        else {
            mPlatformInsets = null;
        }
        return mPlatformInsets;
    }
    
    public static final class Builder
    {
        private final BuilderImpl mImpl;
        
        public Builder() {
            if (Build$VERSION.SDK_INT >= 29) {
                this.mImpl = new BuilderImpl29();
            }
            else if (Build$VERSION.SDK_INT >= 20) {
                this.mImpl = new BuilderImpl20();
            }
            else {
                this.mImpl = new BuilderImpl();
            }
        }
        
        public Builder(final WindowInsetsCompat windowInsetsCompat) {
            if (Build$VERSION.SDK_INT >= 29) {
                this.mImpl = new BuilderImpl29(windowInsetsCompat);
            }
            else if (Build$VERSION.SDK_INT >= 20) {
                this.mImpl = new BuilderImpl20(windowInsetsCompat);
            }
            else {
                this.mImpl = new BuilderImpl(windowInsetsCompat);
            }
        }
        
        public WindowInsetsCompat build() {
            return this.mImpl.build();
        }
        
        public Builder setDisplayCutout(final DisplayCutoutCompat displayCutout) {
            this.mImpl.setDisplayCutout(displayCutout);
            return this;
        }
        
        public Builder setMandatorySystemGestureInsets(final Insets mandatorySystemGestureInsets) {
            this.mImpl.setMandatorySystemGestureInsets(mandatorySystemGestureInsets);
            return this;
        }
        
        public Builder setStableInsets(final Insets stableInsets) {
            this.mImpl.setStableInsets(stableInsets);
            return this;
        }
        
        public Builder setSystemGestureInsets(final Insets systemGestureInsets) {
            this.mImpl.setSystemGestureInsets(systemGestureInsets);
            return this;
        }
        
        public Builder setSystemWindowInsets(final Insets systemWindowInsets) {
            this.mImpl.setSystemWindowInsets(systemWindowInsets);
            return this;
        }
        
        public Builder setTappableElementInsets(final Insets tappableElementInsets) {
            this.mImpl.setTappableElementInsets(tappableElementInsets);
            return this;
        }
    }
    
    private static class BuilderImpl
    {
        private final WindowInsetsCompat mInsets;
        
        BuilderImpl() {
            this(new WindowInsetsCompat((WindowInsetsCompat)null));
        }
        
        BuilderImpl(final WindowInsetsCompat mInsets) {
            this.mInsets = mInsets;
        }
        
        WindowInsetsCompat build() {
            return this.mInsets;
        }
        
        void setDisplayCutout(final DisplayCutoutCompat displayCutoutCompat) {
        }
        
        void setMandatorySystemGestureInsets(final Insets insets) {
        }
        
        void setStableInsets(final Insets insets) {
        }
        
        void setSystemGestureInsets(final Insets insets) {
        }
        
        void setSystemWindowInsets(final Insets insets) {
        }
        
        void setTappableElementInsets(final Insets insets) {
        }
    }
    
    private static class BuilderImpl20 extends BuilderImpl
    {
        private static Constructor<WindowInsets> sConstructor;
        private static boolean sConstructorFetched = false;
        private static Field sConsumedField;
        private static boolean sConsumedFieldFetched = false;
        private WindowInsets mInsets;
        
        BuilderImpl20() {
            this.mInsets = createWindowInsetsInstance();
        }
        
        BuilderImpl20(final WindowInsetsCompat windowInsetsCompat) {
            this.mInsets = windowInsetsCompat.toWindowInsets();
        }
        
        private static WindowInsets createWindowInsetsInstance() {
            if (!BuilderImpl20.sConsumedFieldFetched) {
                try {
                    BuilderImpl20.sConsumedField = WindowInsets.class.getDeclaredField("CONSUMED");
                }
                catch (ReflectiveOperationException ex) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", (Throwable)ex);
                }
                BuilderImpl20.sConsumedFieldFetched = true;
            }
            final Field sConsumedField = BuilderImpl20.sConsumedField;
            if (sConsumedField != null) {
                try {
                    final WindowInsets windowInsets = (WindowInsets)sConsumedField.get(null);
                    if (windowInsets != null) {
                        return new WindowInsets(windowInsets);
                    }
                }
                catch (ReflectiveOperationException ex2) {
                    Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", (Throwable)ex2);
                }
            }
            if (!BuilderImpl20.sConstructorFetched) {
                try {
                    BuilderImpl20.sConstructor = WindowInsets.class.getConstructor(Rect.class);
                }
                catch (ReflectiveOperationException ex3) {
                    Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", (Throwable)ex3);
                }
                BuilderImpl20.sConstructorFetched = true;
            }
            final Constructor<WindowInsets> sConstructor = BuilderImpl20.sConstructor;
            if (sConstructor != null) {
                try {
                    return sConstructor.newInstance(new Rect());
                }
                catch (ReflectiveOperationException ex4) {
                    Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", (Throwable)ex4);
                }
            }
            return null;
        }
        
        @Override
        WindowInsetsCompat build() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mInsets);
        }
        
        @Override
        void setSystemWindowInsets(final Insets insets) {
            final WindowInsets mInsets = this.mInsets;
            if (mInsets != null) {
                this.mInsets = mInsets.replaceSystemWindowInsets(insets.left, insets.top, insets.right, insets.bottom);
            }
        }
    }
    
    private static class BuilderImpl29 extends BuilderImpl
    {
        final WindowInsets$Builder mPlatBuilder;
        
        BuilderImpl29() {
            this.mPlatBuilder = new WindowInsets$Builder();
        }
        
        BuilderImpl29(final WindowInsetsCompat windowInsetsCompat) {
            final WindowInsets windowInsets = windowInsetsCompat.toWindowInsets();
            WindowInsets$Builder mPlatBuilder;
            if (windowInsets != null) {
                mPlatBuilder = new WindowInsets$Builder(windowInsets);
            }
            else {
                mPlatBuilder = new WindowInsets$Builder();
            }
            this.mPlatBuilder = mPlatBuilder;
        }
        
        @Override
        WindowInsetsCompat build() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatBuilder.build());
        }
        
        @Override
        void setDisplayCutout(final DisplayCutoutCompat displayCutoutCompat) {
            final WindowInsets$Builder mPlatBuilder = this.mPlatBuilder;
            DisplayCutout unwrap;
            if (displayCutoutCompat != null) {
                unwrap = displayCutoutCompat.unwrap();
            }
            else {
                unwrap = null;
            }
            mPlatBuilder.setDisplayCutout(unwrap);
        }
        
        @Override
        void setMandatorySystemGestureInsets(final Insets insets) {
            this.mPlatBuilder.setMandatorySystemGestureInsets(insets.toPlatformInsets());
        }
        
        @Override
        void setStableInsets(final Insets insets) {
            this.mPlatBuilder.setStableInsets(insets.toPlatformInsets());
        }
        
        @Override
        void setSystemGestureInsets(final Insets insets) {
            this.mPlatBuilder.setSystemGestureInsets(insets.toPlatformInsets());
        }
        
        @Override
        void setSystemWindowInsets(final Insets insets) {
            this.mPlatBuilder.setSystemWindowInsets(insets.toPlatformInsets());
        }
        
        @Override
        void setTappableElementInsets(final Insets insets) {
            this.mPlatBuilder.setTappableElementInsets(insets.toPlatformInsets());
        }
    }
    
    private static class Impl
    {
        final WindowInsetsCompat mHost;
        
        Impl(final WindowInsetsCompat mHost) {
            this.mHost = mHost;
        }
        
        WindowInsetsCompat consumeDisplayCutout() {
            return this.mHost;
        }
        
        WindowInsetsCompat consumeStableInsets() {
            return this.mHost;
        }
        
        WindowInsetsCompat consumeSystemWindowInsets() {
            return this.mHost;
        }
        
        @Override
        public boolean equals(final Object o) {
            boolean b = true;
            if (this == o) {
                return b;
            }
            if (!(o instanceof Impl)) {
                return false;
            }
            final Impl impl = (Impl)o;
            if (this.isRound() != impl.isRound() || this.isConsumed() != impl.isConsumed() || !ObjectsCompat.equals(this.getSystemWindowInsets(), impl.getSystemWindowInsets()) || !ObjectsCompat.equals(this.getStableInsets(), impl.getStableInsets()) || !ObjectsCompat.equals(this.getDisplayCutout(), impl.getDisplayCutout())) {
                b = false;
            }
            return b;
        }
        
        DisplayCutoutCompat getDisplayCutout() {
            return null;
        }
        
        Insets getMandatorySystemGestureInsets() {
            return this.getSystemWindowInsets();
        }
        
        Insets getStableInsets() {
            return Insets.NONE;
        }
        
        Insets getSystemGestureInsets() {
            return this.getSystemWindowInsets();
        }
        
        Insets getSystemWindowInsets() {
            return Insets.NONE;
        }
        
        Insets getTappableElementInsets() {
            return this.getSystemWindowInsets();
        }
        
        @Override
        public int hashCode() {
            return ObjectsCompat.hash(this.isRound(), this.isConsumed(), this.getSystemWindowInsets(), this.getStableInsets(), this.getDisplayCutout());
        }
        
        WindowInsetsCompat inset(final int n, final int n2, final int n3, final int n4) {
            return WindowInsetsCompat.CONSUMED;
        }
        
        boolean isConsumed() {
            return false;
        }
        
        boolean isRound() {
            return false;
        }
    }
    
    private static class Impl20 extends Impl
    {
        final WindowInsets mPlatformInsets;
        private Insets mSystemWindowInsets;
        
        Impl20(final WindowInsetsCompat windowInsetsCompat, final WindowInsets mPlatformInsets) {
            super(windowInsetsCompat);
            this.mSystemWindowInsets = null;
            this.mPlatformInsets = mPlatformInsets;
        }
        
        Impl20(final WindowInsetsCompat windowInsetsCompat, final Impl20 impl20) {
            this(windowInsetsCompat, new WindowInsets(impl20.mPlatformInsets));
        }
        
        @Override
        final Insets getSystemWindowInsets() {
            if (this.mSystemWindowInsets == null) {
                this.mSystemWindowInsets = Insets.of(this.mPlatformInsets.getSystemWindowInsetLeft(), this.mPlatformInsets.getSystemWindowInsetTop(), this.mPlatformInsets.getSystemWindowInsetRight(), this.mPlatformInsets.getSystemWindowInsetBottom());
            }
            return this.mSystemWindowInsets;
        }
        
        @Override
        WindowInsetsCompat inset(final int n, final int n2, final int n3, final int n4) {
            final Builder builder = new Builder(WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets));
            builder.setSystemWindowInsets(WindowInsetsCompat.insetInsets(this.getSystemWindowInsets(), n, n2, n3, n4));
            builder.setStableInsets(WindowInsetsCompat.insetInsets(((Impl)this).getStableInsets(), n, n2, n3, n4));
            return builder.build();
        }
        
        @Override
        boolean isRound() {
            return this.mPlatformInsets.isRound();
        }
    }
    
    private static class Impl21 extends Impl20
    {
        private Insets mStableInsets;
        
        Impl21(final WindowInsetsCompat windowInsetsCompat, final WindowInsets windowInsets) {
            super(windowInsetsCompat, windowInsets);
            this.mStableInsets = null;
        }
        
        Impl21(final WindowInsetsCompat windowInsetsCompat, final Impl21 impl21) {
            super(windowInsetsCompat, (Impl20)impl21);
            this.mStableInsets = null;
        }
        
        @Override
        WindowInsetsCompat consumeStableInsets() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeStableInsets());
        }
        
        @Override
        WindowInsetsCompat consumeSystemWindowInsets() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeSystemWindowInsets());
        }
        
        @Override
        final Insets getStableInsets() {
            if (this.mStableInsets == null) {
                this.mStableInsets = Insets.of(this.mPlatformInsets.getStableInsetLeft(), this.mPlatformInsets.getStableInsetTop(), this.mPlatformInsets.getStableInsetRight(), this.mPlatformInsets.getStableInsetBottom());
            }
            return this.mStableInsets;
        }
        
        @Override
        boolean isConsumed() {
            return this.mPlatformInsets.isConsumed();
        }
    }
    
    private static class Impl28 extends Impl21
    {
        Impl28(final WindowInsetsCompat windowInsetsCompat, final WindowInsets windowInsets) {
            super(windowInsetsCompat, windowInsets);
        }
        
        Impl28(final WindowInsetsCompat windowInsetsCompat, final Impl28 impl28) {
            super(windowInsetsCompat, (Impl21)impl28);
        }
        
        @Override
        WindowInsetsCompat consumeDisplayCutout() {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.consumeDisplayCutout());
        }
        
        @Override
        public boolean equals(final Object o) {
            return this == o || (o instanceof Impl28 && $r8$backportedMethods$utility$Objects$2$equals.equals(this.mPlatformInsets, ((Impl28)o).mPlatformInsets));
        }
        
        @Override
        DisplayCutoutCompat getDisplayCutout() {
            return DisplayCutoutCompat.wrap(this.mPlatformInsets.getDisplayCutout());
        }
        
        @Override
        public int hashCode() {
            return this.mPlatformInsets.hashCode();
        }
    }
    
    private static class Impl29 extends Impl28
    {
        private Insets mMandatorySystemGestureInsets;
        private Insets mSystemGestureInsets;
        private Insets mTappableElementInsets;
        
        Impl29(final WindowInsetsCompat windowInsetsCompat, final WindowInsets windowInsets) {
            super(windowInsetsCompat, windowInsets);
            this.mSystemGestureInsets = null;
            this.mMandatorySystemGestureInsets = null;
            this.mTappableElementInsets = null;
        }
        
        Impl29(final WindowInsetsCompat windowInsetsCompat, final Impl29 impl29) {
            super(windowInsetsCompat, (Impl28)impl29);
            this.mSystemGestureInsets = null;
            this.mMandatorySystemGestureInsets = null;
            this.mTappableElementInsets = null;
        }
        
        @Override
        Insets getMandatorySystemGestureInsets() {
            if (this.mMandatorySystemGestureInsets == null) {
                this.mMandatorySystemGestureInsets = Insets.toCompatInsets(this.mPlatformInsets.getMandatorySystemGestureInsets());
            }
            return this.mMandatorySystemGestureInsets;
        }
        
        @Override
        Insets getSystemGestureInsets() {
            if (this.mSystemGestureInsets == null) {
                this.mSystemGestureInsets = Insets.toCompatInsets(this.mPlatformInsets.getSystemGestureInsets());
            }
            return this.mSystemGestureInsets;
        }
        
        @Override
        Insets getTappableElementInsets() {
            if (this.mTappableElementInsets == null) {
                this.mTappableElementInsets = Insets.toCompatInsets(this.mPlatformInsets.getTappableElementInsets());
            }
            return this.mTappableElementInsets;
        }
        
        @Override
        WindowInsetsCompat inset(final int n, final int n2, final int n3, final int n4) {
            return WindowInsetsCompat.toWindowInsetsCompat(this.mPlatformInsets.inset(n, n2, n3, n4));
        }
    }
}
