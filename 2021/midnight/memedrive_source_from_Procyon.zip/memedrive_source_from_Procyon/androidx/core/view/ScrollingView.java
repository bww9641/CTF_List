// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view;

public interface ScrollingView
{
    int computeHorizontalScrollExtent();
    
    int computeHorizontalScrollOffset();
    
    int computeHorizontalScrollRange();
    
    int computeVerticalScrollExtent();
    
    int computeVerticalScrollOffset();
    
    int computeVerticalScrollRange();
}
