// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view;

import android.view.View;

public interface ViewPropertyAnimatorUpdateListener
{
    void onAnimationUpdate(final View p0);
}
