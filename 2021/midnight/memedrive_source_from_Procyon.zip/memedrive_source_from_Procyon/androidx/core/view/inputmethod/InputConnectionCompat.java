// 
// Decompiled by Procyon v0.5.36
// 

package androidx.core.view.inputmethod;

import android.net.Uri;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.view.inputmethod.InputConnectionWrapper;
import android.content.ClipDescription;
import android.os.Parcelable;
import android.view.inputmethod.InputContentInfo;
import android.os.Build$VERSION;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

public final class InputConnectionCompat
{
    private static final String COMMIT_CONTENT_ACTION = "androidx.core.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT";
    private static final String COMMIT_CONTENT_CONTENT_URI_INTEROP_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_URI";
    private static final String COMMIT_CONTENT_CONTENT_URI_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_URI";
    private static final String COMMIT_CONTENT_DESCRIPTION_INTEROP_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
    private static final String COMMIT_CONTENT_DESCRIPTION_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
    private static final String COMMIT_CONTENT_FLAGS_INTEROP_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
    private static final String COMMIT_CONTENT_FLAGS_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
    private static final String COMMIT_CONTENT_INTEROP_ACTION = "android.support.v13.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT";
    private static final String COMMIT_CONTENT_LINK_URI_INTEROP_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
    private static final String COMMIT_CONTENT_LINK_URI_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
    private static final String COMMIT_CONTENT_OPTS_INTEROP_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
    private static final String COMMIT_CONTENT_OPTS_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
    private static final String COMMIT_CONTENT_RESULT_INTEROP_RECEIVER_KEY = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER";
    private static final String COMMIT_CONTENT_RESULT_RECEIVER_KEY = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER";
    public static final int INPUT_CONTENT_GRANT_READ_URI_PERMISSION = 1;
    
    @Deprecated
    public InputConnectionCompat() {
    }
    
    public static boolean commitContent(final InputConnection inputConnection, final EditorInfo editorInfo, final InputContentInfoCompat inputContentInfoCompat, final int n, final Bundle bundle) {
        final ClipDescription description = inputContentInfoCompat.getDescription();
        final String[] contentMimeTypes = EditorInfoCompat.getContentMimeTypes(editorInfo);
        final int length = contentMimeTypes.length;
        int i = 0;
        while (true) {
            while (i < length) {
                if (description.hasMimeType(contentMimeTypes[i])) {
                    final boolean b = true;
                    if (!b) {
                        return false;
                    }
                    if (Build$VERSION.SDK_INT >= 25) {
                        return inputConnection.commitContent((InputContentInfo)inputContentInfoCompat.unwrap(), n, bundle);
                    }
                    final int protocol = EditorInfoCompat.getProtocol(editorInfo);
                    boolean b2;
                    if (protocol != 2) {
                        b2 = false;
                        if (protocol != 3) {
                            b2 = false;
                            if (protocol != 4) {
                                return false;
                            }
                        }
                    }
                    else {
                        b2 = true;
                    }
                    final Bundle bundle2 = new Bundle();
                    String s;
                    if (b2) {
                        s = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_URI";
                    }
                    else {
                        s = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_URI";
                    }
                    bundle2.putParcelable(s, (Parcelable)inputContentInfoCompat.getContentUri());
                    String s2;
                    if (b2) {
                        s2 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
                    }
                    else {
                        s2 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
                    }
                    bundle2.putParcelable(s2, (Parcelable)inputContentInfoCompat.getDescription());
                    String s3;
                    if (b2) {
                        s3 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
                    }
                    else {
                        s3 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
                    }
                    bundle2.putParcelable(s3, (Parcelable)inputContentInfoCompat.getLinkUri());
                    String s4;
                    if (b2) {
                        s4 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
                    }
                    else {
                        s4 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
                    }
                    bundle2.putInt(s4, n);
                    String s5;
                    if (b2) {
                        s5 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
                    }
                    else {
                        s5 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
                    }
                    bundle2.putParcelable(s5, (Parcelable)bundle);
                    String s6;
                    if (b2) {
                        s6 = "android.support.v13.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT";
                    }
                    else {
                        s6 = "androidx.core.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT";
                    }
                    return inputConnection.performPrivateCommand(s6, bundle2);
                }
                else {
                    ++i;
                }
            }
            final boolean b = false;
            continue;
        }
    }
    
    public static InputConnection createWrapper(final InputConnection inputConnection, final EditorInfo editorInfo, final OnCommitContentListener onCommitContentListener) {
        if (inputConnection == null) {
            throw new IllegalArgumentException("inputConnection must be non-null");
        }
        if (editorInfo == null) {
            throw new IllegalArgumentException("editorInfo must be non-null");
        }
        if (onCommitContentListener == null) {
            throw new IllegalArgumentException("onCommitContentListener must be non-null");
        }
        if (Build$VERSION.SDK_INT >= 25) {
            return (InputConnection)new InputConnectionWrapper(inputConnection, false) {
                public boolean commitContent(final InputContentInfo inputContentInfo, final int n, final Bundle bundle) {
                    return onCommitContentListener.onCommitContent(InputContentInfoCompat.wrap(inputContentInfo), n, bundle) || super.commitContent(inputContentInfo, n, bundle);
                }
            };
        }
        if (EditorInfoCompat.getContentMimeTypes(editorInfo).length == 0) {
            return inputConnection;
        }
        return (InputConnection)new InputConnectionWrapper(inputConnection, false) {
            public boolean performPrivateCommand(final String s, final Bundle bundle) {
                return InputConnectionCompat.handlePerformPrivateCommand(s, bundle, onCommitContentListener) || super.performPrivateCommand(s, bundle);
            }
        };
    }
    
    static boolean handlePerformPrivateCommand(final String s, final Bundle bundle, final OnCommitContentListener onCommitContentListener) {
        int onCommitContent = 0;
        if (bundle == null) {
            return false;
        }
        boolean b;
        if (TextUtils.equals((CharSequence)"androidx.core.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT", (CharSequence)s)) {
            b = false;
        }
        else {
            if (!TextUtils.equals((CharSequence)"android.support.v13.view.inputmethod.InputConnectionCompat.COMMIT_CONTENT", (CharSequence)s)) {
                return false;
            }
            b = true;
        }
        ResultReceiver resultReceiver = null;
        Label_0047: {
            if (!b) {
                final String s2 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER";
                break Label_0047;
            }
            String s2;
            String s3;
            Uri uri;
            String s4;
            ClipDescription clipDescription;
            String s5;
            Uri uri2;
            String s6;
            int int1;
            String s7;
            Bundle bundle2;
            Label_0099_Outer:Label_0126_Outer:Label_0153_Outer:Label_0177_Outer:
            while (true) {
                while (true) {
                Label_0302:
                    while (true) {
                    Label_0295:
                        while (true) {
                        Label_0288:
                            while (true) {
                            Label_0281:
                                while (true) {
                                    Label_0274: {
                                        try {
                                            s2 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_RESULT_RECEIVER";
                                            resultReceiver = (ResultReceiver)bundle.getParcelable(s2);
                                            if (!b) {
                                                break Label_0274;
                                            }
                                            try {
                                                s3 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_URI";
                                                onCommitContent = 0;
                                                uri = (Uri)bundle.getParcelable(s3);
                                                onCommitContent = 0;
                                                if (!b) {
                                                    break Label_0281;
                                                }
                                                s4 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
                                                onCommitContent = 0;
                                                clipDescription = (ClipDescription)bundle.getParcelable(s4);
                                                onCommitContent = 0;
                                                if (!b) {
                                                    break Label_0288;
                                                }
                                                s5 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
                                                onCommitContent = 0;
                                                uri2 = (Uri)bundle.getParcelable(s5);
                                                onCommitContent = 0;
                                                if (!b) {
                                                    break Label_0295;
                                                }
                                                s6 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
                                                onCommitContent = 0;
                                                int1 = bundle.getInt(s6);
                                                onCommitContent = 0;
                                                if (b) {
                                                    s7 = "android.support.v13.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
                                                    onCommitContent = 0;
                                                    bundle2 = (Bundle)bundle.getParcelable(s7);
                                                    onCommitContent = 0;
                                                    if (uri != null) {
                                                        onCommitContent = 0;
                                                        if (clipDescription != null) {
                                                            onCommitContent = (onCommitContentListener.onCommitContent(new InputContentInfoCompat(uri, clipDescription, uri2), int1, bundle2) ? 1 : 0);
                                                        }
                                                    }
                                                    if (resultReceiver != null) {
                                                        resultReceiver.send(onCommitContent, (Bundle)null);
                                                    }
                                                    return onCommitContent != 0;
                                                }
                                                break Label_0302;
                                            }
                                            finally {}
                                        }
                                        finally {
                                            resultReceiver = null;
                                        }
                                        break;
                                    }
                                    s3 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_URI";
                                    continue Label_0099_Outer;
                                }
                                s4 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_DESCRIPTION";
                                continue Label_0126_Outer;
                            }
                            s5 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_LINK_URI";
                            continue Label_0153_Outer;
                        }
                        s6 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_FLAGS";
                        continue Label_0177_Outer;
                    }
                    s7 = "androidx.core.view.inputmethod.InputConnectionCompat.CONTENT_OPTS";
                    continue;
                }
            }
        }
        if (resultReceiver != null) {
            resultReceiver.send(onCommitContent, (Bundle)null);
        }
        throw;
    }
    
    public interface OnCommitContentListener
    {
        boolean onCommitContent(final InputContentInfoCompat p0, final int p1, final Bundle p2);
    }
}
