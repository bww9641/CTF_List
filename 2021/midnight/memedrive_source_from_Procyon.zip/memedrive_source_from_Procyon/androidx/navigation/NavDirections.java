// 
// Decompiled by Procyon v0.5.36
// 

package androidx.navigation;

import android.os.Bundle;

public interface NavDirections
{
    int getActionId();
    
    Bundle getArguments();
}
