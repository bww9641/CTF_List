// 
// Decompiled by Procyon v0.5.36
// 

package androidx.navigation.fragment;

import java.util.Collections;
import java.util.LinkedHashMap;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.navigation.NavigatorProvider;
import java.util.Iterator;
import androidx.fragment.app.FragmentTransaction;
import android.view.View;
import java.util.Map;
import android.util.Log;
import androidx.navigation.NavOptions;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import androidx.navigation.NavDestination;
import androidx.fragment.app.FragmentManager;
import android.content.Context;
import java.util.ArrayDeque;
import androidx.navigation.Navigator;

@Name("fragment")
public class FragmentNavigator extends Navigator<Destination>
{
    private static final String KEY_BACK_STACK_IDS = "androidx-nav-fragment:navigator:backStackIds";
    private static final String TAG = "FragmentNavigator";
    private ArrayDeque<Integer> mBackStack;
    private final int mContainerId;
    private final Context mContext;
    private final FragmentManager mFragmentManager;
    
    public FragmentNavigator(final Context mContext, final FragmentManager mFragmentManager, final int mContainerId) {
        this.mBackStack = new ArrayDeque<Integer>();
        this.mContext = mContext;
        this.mFragmentManager = mFragmentManager;
        this.mContainerId = mContainerId;
    }
    
    private String generateBackStackName(final int i, final int j) {
        final StringBuilder sb = new StringBuilder();
        sb.append(i);
        sb.append("-");
        sb.append(j);
        return sb.toString();
    }
    
    @Override
    public Destination createDestination() {
        return new Destination(this);
    }
    
    @Deprecated
    public Fragment instantiateFragment(final Context context, final FragmentManager fragmentManager, final String s, final Bundle bundle) {
        return fragmentManager.getFragmentFactory().instantiate(context.getClassLoader(), s);
    }
    
    @Override
    public NavDestination navigate(final Destination destination, final Bundle arguments, final NavOptions navOptions, final Navigator.Extras extras) {
        if (this.mFragmentManager.isStateSaved()) {
            Log.i("FragmentNavigator", "Ignoring navigate() call: FragmentManager has already saved its state");
            return null;
        }
        String str = destination.getClassName();
        if (str.charAt(0) == '.') {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.mContext.getPackageName());
            sb.append(str);
            str = sb.toString();
        }
        final Fragment instantiateFragment = this.instantiateFragment(this.mContext, this.mFragmentManager, str, arguments);
        instantiateFragment.setArguments(arguments);
        final FragmentTransaction beginTransaction = this.mFragmentManager.beginTransaction();
        int enterAnim;
        if (navOptions != null) {
            enterAnim = navOptions.getEnterAnim();
        }
        else {
            enterAnim = -1;
        }
        int exitAnim;
        if (navOptions != null) {
            exitAnim = navOptions.getExitAnim();
        }
        else {
            exitAnim = -1;
        }
        int popEnterAnim;
        if (navOptions != null) {
            popEnterAnim = navOptions.getPopEnterAnim();
        }
        else {
            popEnterAnim = -1;
        }
        int popExitAnim;
        if (navOptions != null) {
            popExitAnim = navOptions.getPopExitAnim();
        }
        else {
            popExitAnim = -1;
        }
        if (enterAnim != -1 || exitAnim != -1 || popEnterAnim != -1 || popExitAnim != -1) {
            if (enterAnim == -1) {
                enterAnim = 0;
            }
            if (exitAnim == -1) {
                exitAnim = 0;
            }
            if (popEnterAnim == -1) {
                popEnterAnim = 0;
            }
            if (popExitAnim == -1) {
                popExitAnim = 0;
            }
            beginTransaction.setCustomAnimations(enterAnim, exitAnim, popEnterAnim, popExitAnim);
        }
        beginTransaction.replace(this.mContainerId, instantiateFragment);
        beginTransaction.setPrimaryNavigationFragment(instantiateFragment);
        final int id = destination.getId();
        final boolean empty = this.mBackStack.isEmpty();
        final boolean b = navOptions != null && !empty && navOptions.shouldLaunchSingleTop() && this.mBackStack.peekLast() == id;
        boolean b2 = false;
        Label_0449: {
            if (!empty) {
                if (b) {
                    final int size = this.mBackStack.size();
                    b2 = false;
                    if (size > 1) {
                        this.mFragmentManager.popBackStack(this.generateBackStackName(this.mBackStack.size(), this.mBackStack.peekLast()), 1);
                        beginTransaction.addToBackStack(this.generateBackStackName(this.mBackStack.size(), id));
                        b2 = false;
                    }
                    break Label_0449;
                }
                else {
                    beginTransaction.addToBackStack(this.generateBackStackName(1 + this.mBackStack.size(), id));
                }
            }
            b2 = true;
        }
        if (extras instanceof Extras) {
            for (final Map.Entry<View, String> entry : ((Extras)extras).getSharedElements().entrySet()) {
                beginTransaction.addSharedElement(entry.getKey(), entry.getValue());
            }
        }
        beginTransaction.setReorderingAllowed(true);
        beginTransaction.commit();
        if (b2) {
            this.mBackStack.add(id);
            return destination;
        }
        return null;
    }
    
    @Override
    public void onRestoreState(final Bundle bundle) {
        if (bundle != null) {
            final int[] intArray = bundle.getIntArray("androidx-nav-fragment:navigator:backStackIds");
            if (intArray != null) {
                this.mBackStack.clear();
                for (int length = intArray.length, i = 0; i < length; ++i) {
                    this.mBackStack.add(intArray[i]);
                }
            }
        }
    }
    
    @Override
    public Bundle onSaveState() {
        final Bundle bundle = new Bundle();
        final int[] array = new int[this.mBackStack.size()];
        final Iterator<Integer> iterator = this.mBackStack.iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final Integer n2 = iterator.next();
            final int n3 = n + 1;
            array[n] = n2;
            n = n3;
        }
        bundle.putIntArray("androidx-nav-fragment:navigator:backStackIds", array);
        return bundle;
    }
    
    @Override
    public boolean popBackStack() {
        if (this.mBackStack.isEmpty()) {
            return false;
        }
        if (this.mFragmentManager.isStateSaved()) {
            Log.i("FragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
            return false;
        }
        this.mFragmentManager.popBackStack(this.generateBackStackName(this.mBackStack.size(), this.mBackStack.peekLast()), 1);
        this.mBackStack.removeLast();
        return true;
    }
    
    public static class Destination extends NavDestination
    {
        private String mClassName;
        
        public Destination(final Navigator<? extends Destination> navigator) {
            super(navigator);
        }
        
        public Destination(final NavigatorProvider navigatorProvider) {
            this(navigatorProvider.getNavigator(FragmentNavigator.class));
        }
        
        public final String getClassName() {
            final String mClassName = this.mClassName;
            if (mClassName != null) {
                return mClassName;
            }
            throw new IllegalStateException("Fragment class was not set");
        }
        
        @Override
        public void onInflate(final Context context, final AttributeSet set) {
            super.onInflate(context, set);
            final TypedArray obtainAttributes = context.getResources().obtainAttributes(set, R.styleable.FragmentNavigator);
            final String string = obtainAttributes.getString(R.styleable.FragmentNavigator_android_name);
            if (string != null) {
                this.setClassName(string);
            }
            obtainAttributes.recycle();
        }
        
        public final Destination setClassName(final String mClassName) {
            this.mClassName = mClassName;
            return this;
        }
        
        @Override
        public String toString() {
            final StringBuilder sb = new StringBuilder();
            sb.append(super.toString());
            sb.append(" class=");
            final String mClassName = this.mClassName;
            if (mClassName == null) {
                sb.append("null");
            }
            else {
                sb.append(mClassName);
            }
            return sb.toString();
        }
    }
    
    public static final class Extras implements Navigator.Extras
    {
        private final LinkedHashMap<View, String> mSharedElements;
        
        Extras(final Map<View, String> m) {
            (this.mSharedElements = new LinkedHashMap<View, String>()).putAll((Map<?, ?>)m);
        }
        
        public Map<View, String> getSharedElements() {
            return Collections.unmodifiableMap((Map<? extends View, ? extends String>)this.mSharedElements);
        }
        
        public static final class Builder
        {
            private final LinkedHashMap<View, String> mSharedElements;
            
            public Builder() {
                this.mSharedElements = new LinkedHashMap<View, String>();
            }
            
            public Builder addSharedElement(final View key, final String value) {
                this.mSharedElements.put(key, value);
                return this;
            }
            
            public Builder addSharedElements(final Map<View, String> map) {
                for (final Map.Entry<View, String> entry : map.entrySet()) {
                    final View view = entry.getKey();
                    final String s = entry.getValue();
                    if (view != null && s != null) {
                        this.addSharedElement(view, s);
                    }
                }
                return this;
            }
            
            public Extras build() {
                return new Extras(this.mSharedElements);
            }
        }
    }
}
