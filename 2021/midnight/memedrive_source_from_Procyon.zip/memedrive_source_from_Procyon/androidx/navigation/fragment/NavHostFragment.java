// 
// Decompiled by Procyon v0.5.36
// 

package androidx.navigation.fragment;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.fragment.app.FragmentContainerView;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import androidx.navigation.NavDestination;
import androidx.lifecycle.LifecycleOwner;
import android.content.Context;
import androidx.navigation.Navigator;
import android.app.Dialog;
import androidx.fragment.app.DialogFragment;
import androidx.navigation.Navigation;
import androidx.navigation.NavController;
import android.os.Bundle;
import android.view.View;
import androidx.navigation.NavHostController;
import androidx.navigation.NavHost;
import androidx.fragment.app.Fragment;

public class NavHostFragment extends Fragment implements NavHost
{
    private static final String KEY_DEFAULT_NAV_HOST = "android-support-nav:fragment:defaultHost";
    private static final String KEY_GRAPH_ID = "android-support-nav:fragment:graphId";
    private static final String KEY_NAV_CONTROLLER_STATE = "android-support-nav:fragment:navControllerState";
    private static final String KEY_START_DESTINATION_ARGS = "android-support-nav:fragment:startDestinationArgs";
    private boolean mDefaultNavHost;
    private int mGraphId;
    private Boolean mIsPrimaryBeforeOnCreate;
    private NavHostController mNavController;
    private View mViewParent;
    
    public NavHostFragment() {
        this.mIsPrimaryBeforeOnCreate = null;
    }
    
    public static NavHostFragment create(final int n) {
        return create(n, null);
    }
    
    public static NavHostFragment create(final int n, final Bundle bundle) {
        Bundle arguments;
        if (n != 0) {
            arguments = new Bundle();
            arguments.putInt("android-support-nav:fragment:graphId", n);
        }
        else {
            arguments = null;
        }
        if (bundle != null) {
            if (arguments == null) {
                arguments = new Bundle();
            }
            arguments.putBundle("android-support-nav:fragment:startDestinationArgs", bundle);
        }
        final NavHostFragment navHostFragment = new NavHostFragment();
        if (arguments != null) {
            navHostFragment.setArguments(arguments);
        }
        return navHostFragment;
    }
    
    public static NavController findNavController(final Fragment obj) {
        for (Fragment parentFragment = obj; parentFragment != null; parentFragment = parentFragment.getParentFragment()) {
            if (parentFragment instanceof NavHostFragment) {
                return ((NavHostFragment)parentFragment).getNavController();
            }
            final Fragment primaryNavigationFragment = parentFragment.getParentFragmentManager().getPrimaryNavigationFragment();
            if (primaryNavigationFragment instanceof NavHostFragment) {
                return ((NavHostFragment)primaryNavigationFragment).getNavController();
            }
        }
        final View view = obj.getView();
        if (view != null) {
            return Navigation.findNavController(view);
        }
        Dialog dialog;
        if (obj instanceof DialogFragment) {
            dialog = ((DialogFragment)obj).getDialog();
        }
        else {
            dialog = null;
        }
        if (dialog != null && dialog.getWindow() != null) {
            return Navigation.findNavController(dialog.getWindow().getDecorView());
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Fragment ");
        sb.append(obj);
        sb.append(" does not have a NavController set");
        throw new IllegalStateException(sb.toString());
    }
    
    private int getContainerId() {
        final int id = this.getId();
        if (id != 0 && id != -1) {
            return id;
        }
        return R.id.nav_host_fragment_container;
    }
    
    @Deprecated
    protected Navigator<? extends FragmentNavigator.Destination> createFragmentNavigator() {
        return (Navigator<? extends FragmentNavigator.Destination>)new FragmentNavigator(this.requireContext(), this.getChildFragmentManager(), this.getContainerId());
    }
    
    @Override
    public final NavController getNavController() {
        final NavHostController mNavController = this.mNavController;
        if (mNavController != null) {
            return mNavController;
        }
        throw new IllegalStateException("NavController is not available before onCreate()");
    }
    
    @Override
    public void onAttach(final Context context) {
        super.onAttach(context);
        if (this.mDefaultNavHost) {
            this.getParentFragmentManager().beginTransaction().setPrimaryNavigationFragment(this).commit();
        }
    }
    
    @Override
    public void onAttachFragment(final Fragment fragment) {
        super.onAttachFragment(fragment);
        this.mNavController.getNavigatorProvider().getNavigator(DialogFragmentNavigator.class).onAttachFragment(fragment);
    }
    
    @Override
    public void onCreate(final Bundle bundle) {
        (this.mNavController = new NavHostController(this.requireContext())).setLifecycleOwner(this);
        this.mNavController.setOnBackPressedDispatcher(this.requireActivity().getOnBackPressedDispatcher());
        final NavHostController mNavController = this.mNavController;
        final Boolean mIsPrimaryBeforeOnCreate = this.mIsPrimaryBeforeOnCreate;
        mNavController.enableOnBackPressed(mIsPrimaryBeforeOnCreate != null && mIsPrimaryBeforeOnCreate);
        this.mIsPrimaryBeforeOnCreate = null;
        this.mNavController.setViewModelStore(this.getViewModelStore());
        this.onCreateNavController(this.mNavController);
        Bundle bundle2;
        if (bundle != null) {
            bundle2 = bundle.getBundle("android-support-nav:fragment:navControllerState");
            if (bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
                this.mDefaultNavHost = true;
                this.getParentFragmentManager().beginTransaction().setPrimaryNavigationFragment(this).commit();
            }
            this.mGraphId = bundle.getInt("android-support-nav:fragment:graphId");
        }
        else {
            bundle2 = null;
        }
        if (bundle2 != null) {
            this.mNavController.restoreState(bundle2);
        }
        final int mGraphId = this.mGraphId;
        if (mGraphId != 0) {
            this.mNavController.setGraph(mGraphId);
        }
        else {
            final Bundle arguments = this.getArguments();
            int int1 = 0;
            if (arguments != null) {
                int1 = arguments.getInt("android-support-nav:fragment:graphId");
            }
            Bundle bundle3 = null;
            if (arguments != null) {
                bundle3 = arguments.getBundle("android-support-nav:fragment:startDestinationArgs");
            }
            if (int1 != 0) {
                this.mNavController.setGraph(int1, bundle3);
            }
        }
        super.onCreate(bundle);
    }
    
    protected void onCreateNavController(final NavController navController) {
        navController.getNavigatorProvider().addNavigator(new DialogFragmentNavigator(this.requireContext(), this.getChildFragmentManager()));
        navController.getNavigatorProvider().addNavigator(this.createFragmentNavigator());
    }
    
    @Override
    public View onCreateView(final LayoutInflater layoutInflater, final ViewGroup viewGroup, final Bundle bundle) {
        final FragmentContainerView fragmentContainerView = new FragmentContainerView(layoutInflater.getContext());
        fragmentContainerView.setId(this.getContainerId());
        return (View)fragmentContainerView;
    }
    
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        final View mViewParent = this.mViewParent;
        if (mViewParent != null && Navigation.findNavController(mViewParent) == this.mNavController) {
            Navigation.setViewNavController(this.mViewParent, null);
        }
        this.mViewParent = null;
    }
    
    @Override
    public void onInflate(final Context context, final AttributeSet set, final Bundle bundle) {
        super.onInflate(context, set, bundle);
        final TypedArray obtainStyledAttributes = context.obtainStyledAttributes(set, androidx.navigation.R.styleable.NavHost);
        final int resourceId = obtainStyledAttributes.getResourceId(androidx.navigation.R.styleable.NavHost_navGraph, 0);
        if (resourceId != 0) {
            this.mGraphId = resourceId;
        }
        obtainStyledAttributes.recycle();
        final TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(set, R.styleable.NavHostFragment);
        if (obtainStyledAttributes2.getBoolean(R.styleable.NavHostFragment_defaultNavHost, false)) {
            this.mDefaultNavHost = true;
        }
        obtainStyledAttributes2.recycle();
    }
    
    @Override
    public void onPrimaryNavigationFragmentChanged(final boolean b) {
        final NavHostController mNavController = this.mNavController;
        if (mNavController != null) {
            mNavController.enableOnBackPressed(b);
        }
        else {
            this.mIsPrimaryBeforeOnCreate = b;
        }
    }
    
    @Override
    public void onSaveInstanceState(final Bundle bundle) {
        super.onSaveInstanceState(bundle);
        final Bundle saveState = this.mNavController.saveState();
        if (saveState != null) {
            bundle.putBundle("android-support-nav:fragment:navControllerState", saveState);
        }
        if (this.mDefaultNavHost) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
        final int mGraphId = this.mGraphId;
        if (mGraphId != 0) {
            bundle.putInt("android-support-nav:fragment:graphId", mGraphId);
        }
    }
    
    @Override
    public void onViewCreated(final View obj, final Bundle bundle) {
        super.onViewCreated(obj, bundle);
        if (obj instanceof ViewGroup) {
            Navigation.setViewNavController(obj, this.mNavController);
            if (obj.getParent() != null) {
                final View mViewParent = (View)obj.getParent();
                this.mViewParent = mViewParent;
                if (mViewParent.getId() == this.getId()) {
                    Navigation.setViewNavController(this.mViewParent, this.mNavController);
                }
            }
            return;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("created host view ");
        sb.append(obj);
        sb.append(" is not a ViewGroup");
        throw new IllegalStateException(sb.toString());
    }
}
