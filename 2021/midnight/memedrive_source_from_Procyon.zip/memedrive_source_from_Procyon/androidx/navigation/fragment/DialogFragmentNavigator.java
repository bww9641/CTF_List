// 
// Decompiled by Procyon v0.5.36
// 

package androidx.navigation.fragment;

import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.navigation.NavigatorProvider;
import androidx.navigation.FloatingWindow;
import androidx.lifecycle.LifecycleObserver;
import android.util.Log;
import androidx.navigation.NavOptions;
import android.os.Bundle;
import androidx.navigation.NavDestination;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import java.util.HashSet;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.fragment.app.FragmentManager;
import android.content.Context;
import androidx.navigation.Navigator;

@Name("dialog")
public final class DialogFragmentNavigator extends Navigator<Destination>
{
    private static final String DIALOG_TAG = "androidx-nav-fragment:navigator:dialog:";
    private static final String KEY_DIALOG_COUNT = "androidx-nav-dialogfragment:navigator:count";
    private static final String TAG = "DialogFragmentNavigator";
    private final Context mContext;
    private int mDialogCount;
    private final FragmentManager mFragmentManager;
    private LifecycleEventObserver mObserver;
    private final HashSet<String> mRestoredTagsAwaitingAttach;
    
    public DialogFragmentNavigator(final Context mContext, final FragmentManager mFragmentManager) {
        this.mDialogCount = 0;
        this.mRestoredTagsAwaitingAttach = new HashSet<String>();
        this.mObserver = new LifecycleEventObserver() {
            @Override
            public void onStateChanged(final LifecycleOwner lifecycleOwner, final Lifecycle.Event event) {
                if (event == Lifecycle.Event.ON_STOP) {
                    final DialogFragment dialogFragment = (DialogFragment)lifecycleOwner;
                    if (!dialogFragment.requireDialog().isShowing()) {
                        NavHostFragment.findNavController(dialogFragment).popBackStack();
                    }
                }
            }
        };
        this.mContext = mContext;
        this.mFragmentManager = mFragmentManager;
    }
    
    @Override
    public Destination createDestination() {
        return new Destination(this);
    }
    
    @Override
    public NavDestination navigate(final Destination destination, final Bundle arguments, final NavOptions navOptions, final Extras extras) {
        if (this.mFragmentManager.isStateSaved()) {
            Log.i("DialogFragmentNavigator", "Ignoring navigate() call: FragmentManager has already saved its state");
            return null;
        }
        String str = destination.getClassName();
        if (str.charAt(0) == '.') {
            final StringBuilder sb = new StringBuilder();
            sb.append(this.mContext.getPackageName());
            sb.append(str);
            str = sb.toString();
        }
        final Fragment instantiate = this.mFragmentManager.getFragmentFactory().instantiate(this.mContext.getClassLoader(), str);
        if (DialogFragment.class.isAssignableFrom(((DialogFragment)instantiate).getClass())) {
            final DialogFragment dialogFragment = (DialogFragment)instantiate;
            dialogFragment.setArguments(arguments);
            dialogFragment.getLifecycle().addObserver(this.mObserver);
            final FragmentManager mFragmentManager = this.mFragmentManager;
            final StringBuilder sb2 = new StringBuilder();
            sb2.append("androidx-nav-fragment:navigator:dialog:");
            sb2.append(this.mDialogCount++);
            dialogFragment.show(mFragmentManager, sb2.toString());
            return destination;
        }
        final StringBuilder sb3 = new StringBuilder();
        sb3.append("Dialog destination ");
        sb3.append(destination.getClassName());
        sb3.append(" is not an instance of DialogFragment");
        throw new IllegalArgumentException(sb3.toString());
    }
    
    void onAttachFragment(final Fragment fragment) {
        if (this.mRestoredTagsAwaitingAttach.remove(fragment.getTag())) {
            fragment.getLifecycle().addObserver(this.mObserver);
        }
    }
    
    @Override
    public void onRestoreState(final Bundle bundle) {
        if (bundle != null) {
            int i = 0;
            this.mDialogCount = bundle.getInt("androidx-nav-dialogfragment:navigator:count", 0);
            while (i < this.mDialogCount) {
                final FragmentManager mFragmentManager = this.mFragmentManager;
                final StringBuilder sb = new StringBuilder();
                sb.append("androidx-nav-fragment:navigator:dialog:");
                sb.append(i);
                final DialogFragment dialogFragment = (DialogFragment)mFragmentManager.findFragmentByTag(sb.toString());
                if (dialogFragment != null) {
                    dialogFragment.getLifecycle().addObserver(this.mObserver);
                }
                else {
                    final HashSet<String> mRestoredTagsAwaitingAttach = this.mRestoredTagsAwaitingAttach;
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append("androidx-nav-fragment:navigator:dialog:");
                    sb2.append(i);
                    mRestoredTagsAwaitingAttach.add(sb2.toString());
                }
                ++i;
            }
        }
    }
    
    @Override
    public Bundle onSaveState() {
        if (this.mDialogCount == 0) {
            return null;
        }
        final Bundle bundle = new Bundle();
        bundle.putInt("androidx-nav-dialogfragment:navigator:count", this.mDialogCount);
        return bundle;
    }
    
    @Override
    public boolean popBackStack() {
        if (this.mDialogCount == 0) {
            return false;
        }
        if (this.mFragmentManager.isStateSaved()) {
            Log.i("DialogFragmentNavigator", "Ignoring popBackStack() call: FragmentManager has already saved its state");
            return false;
        }
        final FragmentManager mFragmentManager = this.mFragmentManager;
        final StringBuilder sb = new StringBuilder();
        sb.append("androidx-nav-fragment:navigator:dialog:");
        sb.append(--this.mDialogCount);
        final Fragment fragmentByTag = mFragmentManager.findFragmentByTag(sb.toString());
        if (fragmentByTag != null) {
            fragmentByTag.getLifecycle().removeObserver(this.mObserver);
            ((DialogFragment)fragmentByTag).dismiss();
        }
        return true;
    }
    
    public static class Destination extends NavDestination implements FloatingWindow
    {
        private String mClassName;
        
        public Destination(final Navigator<? extends Destination> navigator) {
            super(navigator);
        }
        
        public Destination(final NavigatorProvider navigatorProvider) {
            this(navigatorProvider.getNavigator(DialogFragmentNavigator.class));
        }
        
        public final String getClassName() {
            final String mClassName = this.mClassName;
            if (mClassName != null) {
                return mClassName;
            }
            throw new IllegalStateException("DialogFragment class was not set");
        }
        
        @Override
        public void onInflate(final Context context, final AttributeSet set) {
            super.onInflate(context, set);
            final TypedArray obtainAttributes = context.getResources().obtainAttributes(set, R.styleable.DialogFragmentNavigator);
            final String string = obtainAttributes.getString(R.styleable.DialogFragmentNavigator_android_name);
            if (string != null) {
                this.setClassName(string);
            }
            obtainAttributes.recycle();
        }
        
        public final Destination setClassName(final String mClassName) {
            this.mClassName = mClassName;
            return this;
        }
    }
}
