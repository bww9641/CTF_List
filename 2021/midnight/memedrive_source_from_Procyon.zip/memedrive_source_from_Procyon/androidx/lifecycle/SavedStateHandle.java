// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.HashMap;
import android.util.SizeF;
import android.util.Size;
import android.os.Build$VERSION;
import android.util.SparseArray;
import java.io.Serializable;
import android.os.Parcelable;
import java.util.ArrayList;
import android.os.Bundle;
import android.os.Binder;
import androidx.savedstate.SavedStateRegistry;
import java.util.Map;

public final class SavedStateHandle
{
    private static final Class[] ACCEPTABLE_CLASSES;
    private static final String KEYS = "keys";
    private static final String VALUES = "values";
    private final Map<String, SavingStateLiveData<?>> mLiveDatas;
    final Map<String, Object> mRegular;
    private final SavedStateRegistry.SavedStateProvider mSavedStateProvider;
    
    static {
        final Class[] acceptable_CLASSES = { Boolean.TYPE, boolean[].class, Double.TYPE, double[].class, Integer.TYPE, int[].class, Long.TYPE, long[].class, String.class, String[].class, Binder.class, Bundle.class, Byte.TYPE, byte[].class, Character.TYPE, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, Float.TYPE, float[].class, Parcelable.class, Parcelable[].class, Serializable.class, Short.TYPE, short[].class, SparseArray.class, null, null };
        Serializable type;
        if (Build$VERSION.SDK_INT >= 21) {
            type = Size.class;
        }
        else {
            type = Integer.TYPE;
        }
        acceptable_CLASSES[27] = (Class)type;
        Serializable type2;
        if (Build$VERSION.SDK_INT >= 21) {
            type2 = SizeF.class;
        }
        else {
            type2 = Integer.TYPE;
        }
        acceptable_CLASSES[28] = (Class)type2;
        ACCEPTABLE_CLASSES = acceptable_CLASSES;
    }
    
    public SavedStateHandle() {
        this.mLiveDatas = new HashMap<String, SavingStateLiveData<?>>();
        this.mSavedStateProvider = new SavedStateRegistry.SavedStateProvider() {
            @Override
            public Bundle saveState() {
                final Set<String> keySet = SavedStateHandle.this.mRegular.keySet();
                final ArrayList list = new ArrayList<String>(keySet.size());
                final ArrayList list2 = new ArrayList<Object>(list.size());
                for (final String e : keySet) {
                    list.add(e);
                    list2.add(SavedStateHandle.this.mRegular.get(e));
                }
                final Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("keys", list);
                bundle.putParcelableArrayList("values", list2);
                return bundle;
            }
        };
        this.mRegular = new HashMap<String, Object>();
    }
    
    public SavedStateHandle(final Map<String, Object> m) {
        this.mLiveDatas = new HashMap<String, SavingStateLiveData<?>>();
        this.mSavedStateProvider = new SavedStateRegistry.SavedStateProvider() {
            @Override
            public Bundle saveState() {
                final Set<String> keySet = SavedStateHandle.this.mRegular.keySet();
                final ArrayList list = new ArrayList<String>(keySet.size());
                final ArrayList list2 = new ArrayList<Object>(list.size());
                for (final String e : keySet) {
                    list.add(e);
                    list2.add(SavedStateHandle.this.mRegular.get(e));
                }
                final Bundle bundle = new Bundle();
                bundle.putParcelableArrayList("keys", list);
                bundle.putParcelableArrayList("values", list2);
                return bundle;
            }
        };
        this.mRegular = new HashMap<String, Object>(m);
    }
    
    static SavedStateHandle createHandle(final Bundle bundle, final Bundle bundle2) {
        if (bundle == null && bundle2 == null) {
            return new SavedStateHandle();
        }
        final HashMap<String, Object> hashMap = new HashMap<String, Object>();
        if (bundle2 != null) {
            for (final String s : bundle2.keySet()) {
                hashMap.put(s, bundle2.get(s));
            }
        }
        if (bundle == null) {
            return new SavedStateHandle(hashMap);
        }
        final ArrayList parcelableArrayList = bundle.getParcelableArrayList("keys");
        final ArrayList parcelableArrayList2 = bundle.getParcelableArrayList("values");
        if (parcelableArrayList != null && parcelableArrayList2 != null && parcelableArrayList.size() == parcelableArrayList2.size()) {
            for (int i = 0; i < parcelableArrayList.size(); ++i) {
                hashMap.put(parcelableArrayList.get(i), parcelableArrayList2.get(i));
            }
            return new SavedStateHandle(hashMap);
        }
        throw new IllegalStateException("Invalid bundle passed as restored state");
    }
    
    private <T> MutableLiveData<T> getLiveDataInternal(final String s, final boolean b, final T t) {
        final SavingStateLiveData<?> savingStateLiveData = this.mLiveDatas.get(s);
        if (savingStateLiveData != null) {
            return (MutableLiveData<T>)savingStateLiveData;
        }
        SavingStateLiveData<Object> savingStateLiveData2;
        if (this.mRegular.containsKey(s)) {
            savingStateLiveData2 = new SavingStateLiveData<Object>(this, s, this.mRegular.get(s));
        }
        else if (b) {
            savingStateLiveData2 = new SavingStateLiveData<Object>(this, s, t);
        }
        else {
            savingStateLiveData2 = new SavingStateLiveData<Object>(this, s);
        }
        this.mLiveDatas.put(s, savingStateLiveData2);
        return (MutableLiveData<T>)savingStateLiveData2;
    }
    
    private static void validateValue(final Object o) {
        if (o == null) {
            return;
        }
        final Class[] acceptable_CLASSES = SavedStateHandle.ACCEPTABLE_CLASSES;
        for (int length = acceptable_CLASSES.length, i = 0; i < length; ++i) {
            if (acceptable_CLASSES[i].isInstance(o)) {
                return;
            }
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("Can't put value with type ");
        sb.append(o.getClass());
        sb.append(" into saved state");
        throw new IllegalArgumentException(sb.toString());
    }
    
    public boolean contains(final String s) {
        return this.mRegular.containsKey(s);
    }
    
    public <T> T get(final String s) {
        return (T)this.mRegular.get(s);
    }
    
    public <T> MutableLiveData<T> getLiveData(final String s) {
        return this.getLiveDataInternal(s, false, (T)null);
    }
    
    public <T> MutableLiveData<T> getLiveData(final String s, final T t) {
        return this.getLiveDataInternal(s, true, t);
    }
    
    public Set<String> keys() {
        return Collections.unmodifiableSet((Set<? extends String>)this.mRegular.keySet());
    }
    
    public <T> T remove(final String s) {
        final Object remove = this.mRegular.remove(s);
        final SavingStateLiveData<?> savingStateLiveData = this.mLiveDatas.remove(s);
        if (savingStateLiveData != null) {
            savingStateLiveData.detach();
        }
        return (T)remove;
    }
    
    SavedStateRegistry.SavedStateProvider savedStateProvider() {
        return this.mSavedStateProvider;
    }
    
    public <T> void set(final String s, final T value) {
        validateValue(value);
        final SavingStateLiveData<?> savingStateLiveData = this.mLiveDatas.get(s);
        if (savingStateLiveData != null) {
            savingStateLiveData.setValue(value);
        }
        else {
            this.mRegular.put(s, value);
        }
    }
    
    static class SavingStateLiveData<T> extends MutableLiveData<T>
    {
        private SavedStateHandle mHandle;
        private String mKey;
        
        SavingStateLiveData(final SavedStateHandle mHandle, final String mKey) {
            this.mKey = mKey;
            this.mHandle = mHandle;
        }
        
        SavingStateLiveData(final SavedStateHandle mHandle, final String mKey, final T t) {
            super(t);
            this.mKey = mKey;
            this.mHandle = mHandle;
        }
        
        void detach() {
            this.mHandle = null;
        }
        
        @Override
        public void setValue(final T value) {
            final SavedStateHandle mHandle = this.mHandle;
            if (mHandle != null) {
                mHandle.mRegular.put(this.mKey, value);
            }
            super.setValue(value);
        }
    }
}
