// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import androidx.savedstate.SavedStateRegistryOwner;
import androidx.savedstate.SavedStateRegistry;
import android.os.Bundle;

public abstract class AbstractSavedStateViewModelFactory extends KeyedFactory
{
    static final String TAG_SAVED_STATE_HANDLE_CONTROLLER = "androidx.lifecycle.savedstate.vm.tag";
    private final Bundle mDefaultArgs;
    private final Lifecycle mLifecycle;
    private final SavedStateRegistry mSavedStateRegistry;
    
    public AbstractSavedStateViewModelFactory(final SavedStateRegistryOwner savedStateRegistryOwner, final Bundle mDefaultArgs) {
        this.mSavedStateRegistry = savedStateRegistryOwner.getSavedStateRegistry();
        this.mLifecycle = savedStateRegistryOwner.getLifecycle();
        this.mDefaultArgs = mDefaultArgs;
    }
    
    @Override
    public final <T extends ViewModel> T create(final Class<T> clazz) {
        final String canonicalName = clazz.getCanonicalName();
        if (canonicalName != null) {
            return this.create(canonicalName, clazz);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }
    
    @Override
    public final <T extends ViewModel> T create(final String s, final Class<T> clazz) {
        final SavedStateHandleController create = SavedStateHandleController.create(this.mSavedStateRegistry, this.mLifecycle, s, this.mDefaultArgs);
        final ViewModel create2 = this.create(s, clazz, create.getHandle());
        create2.setTagIfAbsent("androidx.lifecycle.savedstate.vm.tag", create);
        return (T)create2;
    }
    
    protected abstract <T extends ViewModel> T create(final String p0, final Class<T> p1, final SavedStateHandle p2);
    
    @Override
    void onRequery(final ViewModel viewModel) {
        SavedStateHandleController.attachHandleIfNeeded(viewModel, this.mSavedStateRegistry, this.mLifecycle);
    }
}
