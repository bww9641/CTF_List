// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

@Deprecated
public interface LifecycleRegistryOwner extends LifecycleOwner
{
    LifecycleRegistry getLifecycle();
}
