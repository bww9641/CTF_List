// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

public final class R
{
    private R() {
    }
}
