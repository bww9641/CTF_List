// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

public interface Observer<T>
{
    void onChanged(final T p0);
}
