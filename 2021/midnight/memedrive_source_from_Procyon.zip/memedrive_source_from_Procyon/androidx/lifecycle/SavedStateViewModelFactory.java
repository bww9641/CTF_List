// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.lang.reflect.Constructor;
import androidx.savedstate.SavedStateRegistryOwner;
import androidx.savedstate.SavedStateRegistry;
import android.os.Bundle;
import android.app.Application;

public final class SavedStateViewModelFactory extends KeyedFactory
{
    private static final Class<?>[] ANDROID_VIEWMODEL_SIGNATURE;
    private static final Class<?>[] VIEWMODEL_SIGNATURE;
    private final Application mApplication;
    private final Bundle mDefaultArgs;
    private final AndroidViewModelFactory mFactory;
    private final Lifecycle mLifecycle;
    private final SavedStateRegistry mSavedStateRegistry;
    
    static {
        ANDROID_VIEWMODEL_SIGNATURE = new Class[] { Application.class, SavedStateHandle.class };
        VIEWMODEL_SIGNATURE = new Class[] { SavedStateHandle.class };
    }
    
    public SavedStateViewModelFactory(final Application application, final SavedStateRegistryOwner savedStateRegistryOwner) {
        this(application, savedStateRegistryOwner, null);
    }
    
    public SavedStateViewModelFactory(final Application mApplication, final SavedStateRegistryOwner savedStateRegistryOwner, final Bundle mDefaultArgs) {
        this.mSavedStateRegistry = savedStateRegistryOwner.getSavedStateRegistry();
        this.mLifecycle = savedStateRegistryOwner.getLifecycle();
        this.mDefaultArgs = mDefaultArgs;
        this.mApplication = mApplication;
        this.mFactory = ViewModelProvider.AndroidViewModelFactory.getInstance(mApplication);
    }
    
    private static <T> Constructor<T> findMatchingConstructor(final Class<T> clazz, final Class<?>[] a) {
        for (final Constructor constructor : clazz.getConstructors()) {
            if (Arrays.equals(a, constructor.getParameterTypes())) {
                return (Constructor<T>)constructor;
            }
        }
        return null;
    }
    
    @Override
    public <T extends ViewModel> T create(final Class<T> clazz) {
        final String canonicalName = clazz.getCanonicalName();
        if (canonicalName != null) {
            return this.create(canonicalName, clazz);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }
    
    @Override
    public <T extends ViewModel> T create(final String s, final Class<T> obj) {
        final boolean assignable = AndroidViewModel.class.isAssignableFrom(obj);
        Constructor<T> constructor;
        if (assignable) {
            constructor = findMatchingConstructor(obj, SavedStateViewModelFactory.ANDROID_VIEWMODEL_SIGNATURE);
        }
        else {
            constructor = findMatchingConstructor(obj, SavedStateViewModelFactory.VIEWMODEL_SIGNATURE);
        }
        if (constructor == null) {
            return this.mFactory.create(obj);
        }
        final SavedStateHandleController create = SavedStateHandleController.create(this.mSavedStateRegistry, this.mLifecycle, s, this.mDefaultArgs);
        Label_0106: {
            if (!assignable) {
                break Label_0106;
            }
            try {
                ViewModel viewModel = constructor.newInstance(this.mApplication, create.getHandle());
                while (true) {
                    viewModel.setTagIfAbsent("androidx.lifecycle.savedstate.vm.tag", create);
                    return (T)viewModel;
                    viewModel = constructor.newInstance(create.getHandle());
                    continue;
                }
            }
            catch (InvocationTargetException ex) {
                final StringBuilder sb = new StringBuilder();
                sb.append("An exception happened in constructor of ");
                sb.append(obj);
                throw new RuntimeException(sb.toString(), ex.getCause());
            }
            catch (InstantiationException cause) {
                final StringBuilder sb2 = new StringBuilder();
                sb2.append("A ");
                sb2.append(obj);
                sb2.append(" cannot be instantiated.");
                throw new RuntimeException(sb2.toString(), cause);
            }
            catch (IllegalAccessException cause2) {
                final StringBuilder sb3 = new StringBuilder();
                sb3.append("Failed to access ");
                sb3.append(obj);
                throw new RuntimeException(sb3.toString(), cause2);
            }
        }
    }
    
    @Override
    void onRequery(final ViewModel viewModel) {
        SavedStateHandleController.attachHandleIfNeeded(viewModel, this.mSavedStateRegistry, this.mLifecycle);
    }
}
