// 
// Decompiled by Procyon v0.5.36
// 

package androidx.lifecycle;

class CompositeGeneratedAdaptersObserver implements LifecycleEventObserver
{
    private final GeneratedAdapter[] mGeneratedAdapters;
    
    CompositeGeneratedAdaptersObserver(final GeneratedAdapter[] mGeneratedAdapters) {
        this.mGeneratedAdapters = mGeneratedAdapters;
    }
    
    @Override
    public void onStateChanged(final LifecycleOwner lifecycleOwner, final Lifecycle.Event event) {
        final MethodCallsLogger methodCallsLogger = new MethodCallsLogger();
        final GeneratedAdapter[] mGeneratedAdapters = this.mGeneratedAdapters;
        final int length = mGeneratedAdapters.length;
        int i = 0;
        for (int j = 0; j < length; ++j) {
            mGeneratedAdapters[j].callMethods(lifecycleOwner, event, false, methodCallsLogger);
        }
        for (GeneratedAdapter[] mGeneratedAdapters2 = this.mGeneratedAdapters; i < mGeneratedAdapters2.length; ++i) {
            mGeneratedAdapters2[i].callMethods(lifecycleOwner, event, true, methodCallsLogger);
        }
    }
}
